USE [CMS]
GO
/****** Object:  Schema [AdminControl]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SCHEMA [AdminControl]
GO
/****** Object:  Schema [AdminLog]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SCHEMA [AdminLog]
GO
/****** Object:  Schema [AdminServer]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SCHEMA [AdminServer]
GO
/****** Object:  Schema [ays]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SCHEMA [ays]
GO
/****** Object:  Schema [Check_Server]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SCHEMA [Check_Server]
GO
/****** Object:  Schema [col]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SCHEMA [col]
GO
/****** Object:  Schema [Collection]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SCHEMA [Collection]
GO
/****** Object:  Schema [eva]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SCHEMA [eva]
GO
/****** Object:  Schema [imp]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SCHEMA [imp]
GO
/****** Object:  Schema [Maint]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SCHEMA [Maint]
GO
/****** Object:  Schema [PRSCOAD\Patrol]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SCHEMA [PRSCOAD\Patrol]
GO
/****** Object:  Schema [rpt]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SCHEMA [rpt]
GO
/****** Object:  Schema [Security]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SCHEMA [Security]
GO
/****** Object:  Schema [stg]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SCHEMA [stg]
GO
/****** Object:  Schema [svc]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SCHEMA [svc]
GO
/****** Object:  UserDefinedTableType [dbo].[backuplist]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE TYPE [dbo].[backuplist] AS TABLE(
	[dbrank] [int] NULL,
	[databasename] [varchar](128) NULL,
	[backupfiles] [varchar](max) NULL,
	[is_cdc_enabled] [bit] NULL
)
GO
/****** Object:  Synonym [dbo].[ifn_sqlversion]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SYNONYM [dbo].[ifn_sqlversion] FOR [dbo].[fnGetSqlVersion]
GO
/****** Object:  Synonym [dbo].[tfn_SplitStrings]    Script Date: 11/4/2025 9:51:02 PM ******/
CREATE SYNONYM [dbo].[tfn_SplitStrings] FOR [dbo].[fnSplitString]
GO
/****** Object:  UserDefinedFunction [AdminServer].[fn_cal_diskadd]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [AdminServer].[fn_cal_diskadd]
(@currentsize DECIMAL(10,2), @currentfree DECIMAL(10,2), @targetper TinyInt = 25)
RETURNS INT
AS BEGIN
    
	DECLARE @targetadd Int

	SET @targetadd =  CEILING((CONVERT(DECIMAL(5,2),((@targetper/100.0)*@currentsize) - @currentfree)/(1 - CONVERT(DECIMAL(5,2),(@targetper/100.0)))));

	RETURN (@targetadd);

END
GO
/****** Object:  UserDefinedFunction [AdminServer].[fn_endofmonth]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [AdminServer].[fn_endofmonth] (@iDate DateTime)
RETURNS DateTime
AS
	BEGIN
		DECLARE @odate DateTime
		SELECT @odate = DATEADD(dd, -1, DATEADD(MONTH, DATEDIFF(MONTH, 0, @iDate) + 1, 0))
		RETURN (@odate);
	END


GO
/****** Object:  UserDefinedFunction [AdminServer].[fn_startofmonth]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [AdminServer].[fn_startofmonth] (@iDate DateTime)
RETURNS DateTime
AS
	BEGIN
		DECLARE @odate DateTime
		SELECT @odate = DATEADD(MONTH, DATEDIFF(MONTH, 0, @iDate), 0)
		RETURN (@odate);
	END


GO
/****** Object:  UserDefinedFunction [dbo].[fn_get_defaultBackupdir]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[fn_get_defaultBackupdir] ()
RETURNS Nvarchar(4000)
/*******************************************************************************

This function get output of default backup directory by calling extended stored 
procedure. The value is saved under registry settings.

SQL version: SQL 2005,2008,2008 R2 & SQL2012

Author          Date created                 Comments
--------------------------------------------------------------------------------
Harsha vasa     06/20/2013                  Initial Draft

*******************************************************************************/
AS
	BEGIN

		DECLARE @Path Nvarchar(4000)

		EXEC master.dbo.xp_instance_regread	N'HKEY_LOCAL_MACHINE'
											,N'Software\Microsoft\MSSQLServer\MSSQLServer'
											,N'BackupDirectory'
											,@Path OUTPUT
											,'no_output'
		RETURN @Path

	END;
GO
/****** Object:  UserDefinedFunction [dbo].[fnFormatTimeDuration]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[fnFormatTimeDuration] (@StartTime DATETIME
											  ,@EndTime	  DATETIME)
RETURNS VARCHAR(32)
AS

	/***************************************************************************************************************************************
	    Copyright © 2019 Ensono LP, USA. All rights reserved

		Purpose: Format Date time values in DD.HH:MM:SS
		

		History:
		---------------------------------------
		Author                       Comments
		---------------------------------------
		Harsha vasa               Initial draft


		Documentation:
		--------------



		Execution Samples:
		------------------


    ***************************************************************************************************************************************/

	BEGIN
		RETURN (
			  SELECT
				  CASE
					  WHEN DATEDIFF( ss,@StartTime,@EndTime ) / (24 * 3600) > 0 THEN CAST( DATEDIFF( ss,@StartTime,@EndTime ) / (24 * 3600) AS NVARCHAR ) + '.'
					  ELSE ''
				  END + RIGHT( CONVERT( NVARCHAR,@EndTime - @StartTime,121 ),12 )

		)
	END
GO
/****** Object:  UserDefinedFunction [dbo].[fnSplitString]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[fnSplitString] ( @String	   NVARCHAR(MAX)
								   ,@Delimiter VARCHAR(10) = ',' )
RETURNS @Lists TABLE (list VARCHAR(8000))
AS
	BEGIN


		-- Trimming the trails
		SELECT @String = REPLACE( LTRIM( RTRIM( @String ) ),@Delimiter + ' ',@Delimiter );

		DECLARE @Ll INT
		DECLARE @Ld INT;

		SELECT @Ll = LEN( @String ) + 1,@Ld = LEN( @Delimiter );


		/*   INSERTING DATABASES LIST IF THE INPUT IS HAS dbs  */

		IF @String = 'userdbs'
			 BEGIN
				 INSERT INTO @Lists( list )
				 SELECT
					 [name]
				 FROM sys.databases
				 WHERE database_id > 4
				 AND [name] COLLATE database_default NOT IN (SELECT gsd.[DatabaseName] FROM dbo.fnUserSystemDbs( ) AS gsd)
				 ORDER BY [name];

			 END
		ELSE

		IF @String = 'sysdbs'
			 BEGIN
				 INSERT INTO @Lists( list )
				 SELECT
					 [name] COLLATE database_default
				 FROM sys.databases
				 WHERE database_id IN (1,3,4)
				 UNION ALL
				 SELECT
					 [DatabaseName]
				 FROM dbo.fnUserSystemDbs( ) AS gsd;

			 END
		ELSE

		IF @String = 'alldbs'
			 BEGIN
				 INSERT INTO @Lists( list )
				 SELECT [name] FROM sys.databases ORDER BY database_id;

			 END
		ELSE

			 BEGIN
				 ;
				 WITH a
				 AS (
					   SELECT
						   [start] = 1
						  ,[end] =	 COALESCE( NULLIF( CHARINDEX( @Delimiter,@String,@Ld ),0 ),@Ll )
						  ,[value] = SUBSTRING( @String,1,COALESCE( NULLIF( CHARINDEX( @Delimiter,@String,@Ld ),0 ),@Ll ) - 1 )
					   UNION ALL
					   SELECT
						   [start] = CONVERT( INT,[end] ) + @Ld
						  ,[end] =	 COALESCE( NULLIF( CHARINDEX( @Delimiter,@String,[end] + @Ld ),0 ),@Ll )
						  ,[value] = SUBSTRING( @String,[end] + @Ld,COALESCE( NULLIF( CHARINDEX( @Delimiter,@String,[end] + @Ld ),0 ),@Ll ) - [end] - @Ld )
					   FROM a
					   WHERE [end] < @Ll
				 )

				 INSERT @Lists
				 SELECT LTRIM( RTRIM( [value] ) ) FROM a WHERE LEN( [value] ) > 0 OPTION (MAXRECURSION 0);
			 END

		RETURN;
	END
GO
/****** Object:  Table [AdminControl].[DBServersAll]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminControl].[DBServersAll](
	[DBServersAllKEY] [int] NOT NULL,
	[DBSACustomerName] [varchar](128) NOT NULL,
	[DBSAServerName] [varchar](128) NOT NULL,
	[DBSAServerConnection] [varchar](128) NULL,
	[DBSAServerConnectionMethod] [varchar](50) NULL,
	[DBSADomain] [varchar](80) NOT NULL,
	[DBSAServerType] [varchar](2) NOT NULL,
	[DBSAActive] [bit] NOT NULL,
	[DBSAManaged] [bit] NULL,
	[DBSAJobHistory] [bit] NOT NULL,
	[DBSABackupHistory] [bit] NOT NULL,
	[DBSATableLevel] [bit] NOT NULL,
	[DBSALoginsDetail] [bit] NOT NULL,
	[DBSADTSPackages] [bit] NOT NULL,
	[DBSAInstanceBilled] [char](2) NULL,
	[DBSAInstanceSupported] [char](2) NULL,
	[DBSADescription] [varchar](250) NULL,
	[DBSADiskCapacityAllocationMB] [int] NULL,
	[DBSALightSpeed] [bit] NOT NULL,
	[DBSAClustered] [bit] NOT NULL,
	[DBSASANAttached] [bit] NOT NULL,
	[DBSAProcessors] [int] NULL,
	[DBSAServerDBA_Primary] [varchar](50) NULL,
	[DBSAServerDBA_Secondary] [varchar](50) NULL,
	[DBSABackupRepository] [varchar](256) NULL,
	[DBSASANName] [varchar](50) NULL,
	[DBSAServerIPAddress] [varchar](25) NULL,
	[DBSAServerClusterdNode1IPAddress] [varchar](25) NULL,
	[DBSAServerClusterdNode2IPAddress] [varchar](25) NULL,
	[DBSAServerClusterdNode3IPAddress] [varchar](25) NULL,
	[DBSAServerClusterdNode4IPAddress] [varchar](25) NULL,
	[DBSAServerClusterdIPAddress] [varchar](25) NULL,
	[DBSASpotlightDayTimeMonitoring] [varchar](64) NULL,
	[DBSAServerClusterdVirtualName] [varchar](128) NULL,
	[DBSAServerClusterdNode1Name] [varchar](128) NULL,
	[DBSAServerClusterdNode2Name] [varchar](128) NULL,
	[DBSAServerClusterdNode3Name] [varchar](128) NULL,
	[DBSAServerClusterdNode4Name] [varchar](128) NULL,
	[DBSAServerIPAddress_NAT] [varchar](25) NULL,
	[DBSAInstallationType] [varchar](50) NULL,
	[DBSAVirtualMachine] [bit] NULL,
	[DBSAPortNumber] [int] NULL,
	[DBSAUpdateDate] [datetime] NULL,
	[DBSAUpdateBy] [varchar](25) NULL,
	[DBSAOffshoreAllowed] [char](2) NULL,
	[DBSAServerClusteredPreferredNode] [varchar](128) NULL,
	[DBSASLA] [varchar](2) NULL,
	[DBSAMaintSchedule] [varchar](128) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminServer].[Database_IO_Information]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[Database_IO_Information](
	[Date_Key] [datetime] NOT NULL,
	[Server_Name] [nvarchar](128) NULL,
	[Database_Name] [nvarchar](128) NULL,
	[ProcessorCount] [int] NULL,
	[Disk_Drive] [nvarchar](128) NULL,
	[Physical_File_Name] [nvarchar](520) NULL,
	[File_Type] [nvarchar](10) NULL,
	[AverageIOStallsperMS] [int] NULL,
	[FileSize] [int] NULL,
	[GrowthType] [nvarchar](50) NULL,
	[Growth] [nvarchar](50) NULL,
	[File_Read_Percentage] [int] NULL,
	[File_Write_Percentage] [int] NULL,
	[Maximum_File_Size] [nvarchar](50) NULL,
	[Space_RemainingMB] [nvarchar](50) NULL,
	[Number_Of_Reads] [bigint] NULL,
	[Number_Bytes_Read] [bigint] NULL,
	[IOStall_Reads_MS] [bigint] NULL,
	[Number_Of_Writes] [bigint] NULL,
	[Number_Bytes_Written] [bigint] NULL,
	[IOStall_Writes_MB] [bigint] NULL,
	[Total_IOStall_Reads_Writes] [bigint] NULL
) ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Admin_Database_Growth_Review]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO







CREATE VIEW [AdminServer].[HPS_Admin_Database_Growth_Review]
AS
SELECT     
	D.Date_Key, 
	D.Server_Name, 
	D.Database_Name, 
	M.DBSAServerDBA_Primary AS PrimaryDBA_Support, 
	D.Physical_File_Name, 
	D.File_Type, 
	D.FileSize, 
	D.GrowthType, 
	CASE	WHEN D.GrowthType <> 'MBs' THEN 'Database File not set to MBs Growth'
			ELSE 'GrowthType set correct' END as GrowthType_Review, 
	D.Growth, 
	CASE	WHEN D.Growth = 'Unknown' AND D.FileSize > 30720 THEN 'Database File Set to NOT Grow and Greater than 30 GB File Size. Add another File to the FileGroup and redistribute the data'
			WHEN D.Growth = 'Unknown' AND D.FileSize <= 30720 THEN 'Database File Set to NOT Grow. Perform Analysis to allow file to grow'
			WHEN D.FileSize > '500' and D.Growth <> '100' THEN 'DB File Growth not set to 100 (Standard). File needs to be set to 100 MB Growth Increment'
			WHEN D.FileSize < '500' and D.Growth <> '10'  THEN 'DB File Growth not set to 10 (Standard). File needs to be set to 10 MB Growth Increment'
			ELSE 'DB File Growth set to standard' END AS Growth_Review,
	D.Maximum_File_Size,
	CASE	WHEN D.Growth = 'Unknown'  THEN 'File not set to autogrow (Standard). File needs to be set to autogrow'
			WHEN D.Maximum_File_Size <> 'UNLIMITED'	 THEN 'File not set to autogrow (Standard). File needs to be set to autogrow'
			ELSE 'File Set to autogrow' END AS AutoGrowth_Review 
FROM	AdminServer.Database_IO_Information AS D INNER JOIN AdminControl.DBServersAll AS M ON 
		D.Server_Name = M.DBSAServerName
WHERE	(D.Date_Key = (SELECT     MAX(Date_Key) AS Date_Key FROM AdminServer.Database_IO_Information))
		AND D.Database_Name NOT IN ('master','msdb','tempdb','model','DBA')





GO
/****** Object:  View [AdminServer].[HPS_Admin_Database_IO_Information_PROD_Warnings]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Admin_Database_IO_Information_PROD_Warnings]
AS
SELECT     D.Date_Key, D.Server_Name, D.Database_Name, M.DBSAServerDBA_Primary AS PrimaryDBA_Support, M.DBSAServerDBA_Secondary AS SecondaryDBA_Support, 
                      D.ProcessorCount, D.Disk_Drive, D.Physical_File_Name, D.File_Type, D.AverageIOStallsperMS, D.FileSize, D.GrowthType, D.Growth, D.File_Read_Percentage, 
                      D.File_Write_Percentage, D.Maximum_File_Size, D.Space_RemainingMB, D.Number_Of_Reads, D.Number_Bytes_Read, D.IOStall_Reads_MS, D.Number_Of_Writes, 
                      D.Number_Bytes_Written, D.IOStall_Writes_MB, D.Total_IOStall_Reads_Writes
FROM         AdminServer.Database_IO_Information AS D INNER JOIN
                      AdminControl.DBServersAll AS M ON D.Server_Name = M.DBSAServerName
WHERE     (D.AverageIOStallsperMS > 100) AND (M.DBSAServerType = 'P') AND (D.Date_Key =
                          (SELECT     MAX(Date_Key) AS Expr1
                            FROM          AdminServer.Database_IO_Information))



GO
/****** Object:  Table [AdminServer].[SQLServerDatabaseProperties_Repository]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[SQLServerDatabaseProperties_Repository](
	[Date_Key] [datetime] NOT NULL,
	[ServerName] [nvarchar](128) NULL,
	[name] [nvarchar](128) NOT NULL,
	[Database_Owner] [nvarchar](128) NULL,
	[create_date] [datetime2](3) NOT NULL,
	[compatibility_level] [tinyint] NOT NULL,
	[collation_name] [nvarchar](128) NULL,
	[is_read_only] [bit] NULL,
	[is_auto_close_on] [bit] NULL,
	[is_auto_shrink_on] [bit] NULL,
	[state] [tinyint] NULL,
	[state_desc] [nvarchar](60) NULL,
	[is_in_standby] [bit] NULL,
	[is_cleanly_shutdown] [bit] NULL,
	[is_supplemental_logging_enabled] [bit] NULL,
	[snapshot_isolation_state] [tinyint] NULL,
	[snapshot_isolation_state_desc] [nvarchar](60) NULL,
	[is_read_committed_snapshot_on] [bit] NULL,
	[recovery_model] [tinyint] NULL,
	[recovery_model_desc] [nvarchar](60) NULL,
	[page_verify_option] [tinyint] NULL,
	[page_verify_option_desc] [nvarchar](60) NULL,
	[is_auto_create_stats_on] [bit] NULL,
	[is_auto_update_stats_on] [bit] NULL,
	[is_auto_update_stats_async_on] [bit] NULL,
	[is_ansi_null_default_on] [bit] NULL,
	[is_ansi_nulls_on] [bit] NULL,
	[is_ansi_padding_on] [bit] NULL,
	[is_ansi_warnings_on] [bit] NULL,
	[is_arithabort_on] [bit] NULL,
	[is_concat_null_yields_null_on] [bit] NULL,
	[is_numeric_roundabort_on] [bit] NULL,
	[is_quoted_identifier_on] [bit] NULL,
	[is_recursive_triggers_on] [bit] NULL,
	[is_cursor_close_on_commit_on] [bit] NULL,
	[is_local_cursor_default] [bit] NULL,
	[is_fulltext_enabled] [bit] NULL,
	[is_trustworthy_on] [bit] NULL,
	[is_db_chaining_on] [bit] NULL,
	[is_parameterization_forced] [bit] NULL,
	[is_master_key_encrypted_by_server] [bit] NULL,
	[is_published] [bit] NULL,
	[is_subscribed] [bit] NULL,
	[is_merge_published] [bit] NULL,
	[is_distributor] [bit] NULL,
	[is_sync_with_backup] [bit] NULL,
	[is_broker_enabled] [bit] NULL,
	[log_reuse_wait] [tinyint] NULL,
	[log_reuse_wait_desc] [nvarchar](60) NULL,
	[is_date_correlation_on] [bit] NULL,
	[is_cdc_enabled] [bit] NULL,
	[is_encrypted] [bit] NULL,
	[is_honor_broker_priority_on] [bit] NULL
) ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Admin_Database_Properties_ALL_Current]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [AdminServer].[HPS_Admin_Database_Properties_ALL_Current]
AS
SELECT TOP 100 PERCENT
	   [Date_Key]
      ,[ServerName]
      ,[name]
      ,[Database_Owner]
      ,[create_date]
      ,[compatibility_level]
      ,[collation_name]
      ,[is_read_only]
      ,[is_auto_close_on]
      ,[is_auto_shrink_on]
      ,[state]
      ,[state_desc]
      ,[is_in_standby]
      ,[is_cleanly_shutdown]
      ,[is_supplemental_logging_enabled]
      ,[snapshot_isolation_state]
      ,[snapshot_isolation_state_desc]
      ,[is_read_committed_snapshot_on]
      ,[recovery_model]
      ,[recovery_model_desc]
      ,[page_verify_option]
      ,[page_verify_option_desc]
      ,[is_auto_create_stats_on]
      ,[is_auto_update_stats_on]
      ,[is_auto_update_stats_async_on]
      ,[is_ansi_null_default_on]
      ,[is_ansi_nulls_on]
      ,[is_ansi_padding_on]
      ,[is_ansi_warnings_on]
      ,[is_arithabort_on]
      ,[is_concat_null_yields_null_on]
      ,[is_numeric_roundabort_on]
      ,[is_quoted_identifier_on]
      ,[is_recursive_triggers_on]
      ,[is_cursor_close_on_commit_on]
      ,[is_local_cursor_default]
      ,[is_fulltext_enabled]
      ,[is_trustworthy_on]
      ,[is_db_chaining_on]
      ,[is_parameterization_forced]
      ,[is_master_key_encrypted_by_server]
      ,[is_published]
      ,[is_subscribed]
      ,[is_merge_published]
      ,[is_distributor]
      ,[is_sync_with_backup]
      ,[is_broker_enabled]
      ,[log_reuse_wait]
      ,[log_reuse_wait_desc]
      ,[is_date_correlation_on]
      ,[is_cdc_enabled]
      ,[is_encrypted]
      ,[is_honor_broker_priority_on]
  FROM [AdminServer].[SQLServerDatabaseProperties_Repository]
  WHERE Date_Key = (SELECT MAX(Date_Key) FROM [AdminServer].[SQLServerDatabaseProperties_Repository]) 
  ORDER BY ServerName, name
  
  








GO
/****** Object:  Table [AdminServer].[DBINFO_Information]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[DBINFO_Information](
	[Date_Key] [datetime] NOT NULL,
	[customer] [varchar](128) NOT NULL,
	[server] [varchar](128) NOT NULL,
	[sla] [char](1) NULL,
	[db] [varchar](128) NULL,
	[crdate] [varchar](20) NULL,
	[dbsize] [decimal](14, 2) NULL,
	[comments] [varchar](128) NULL,
	[updated] [varchar](20) NULL,
	[by] [varchar](16) NULL
) ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Admin_DBINFO_Exceptions_List]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Admin_DBINFO_Exceptions_List]
AS
SELECT     TOP (100) PERCENT DBSAServerName
FROM         AdminControl.DBServersAll AS LogTable
WHERE	(DBSAManaged = 1) AND 
		(DBSAActive = 1)  AND 
		(DBSAServerName NOT IN
		(SELECT DISTINCT server
         FROM          AdminServer.DBINFO_Information
         WHERE      (Date_Key = (SELECT MAX(Date_Key) AS Date_Key
                                 FROM AdminServer.DBINFO_Information 
                                 AS Admin_Server_DBINFO_Information_1))))




GO
/****** Object:  Table [AdminLog].[DailyBackupAudit]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[DailyBackupAudit](
	[DailyBackupAuditReposKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[BestPractices]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[BestPractices](
	[DBINFOKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[CapacityReview]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[CapacityReview](
	[CapacityReviewKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[DBINFO]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[DBINFO](
	[DBINFOKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[DBInformation]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[DBInformation](
	[DBInformationKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[DBInformation_IO]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[DBInformation_IO](
	[DBIOInfofKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[DiskSpace]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[DiskSpace](
	[DiskSpaceKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[ErrorLogs]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[ErrorLogs](
	[ErrorLogsKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[JobHistory]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[JobHistory](
	[JobHistoryKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[JobInformation]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[JobInformation](
	[JobInformationKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[LoginsDetail]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[LoginsDetail](
	[LoginsDetailKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[MountPoints]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[MountPoints](
	[MountPointsKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[ServerService]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[ServerService](
	[ServerServiceKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[SQLServerDatabaseProperties]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[SQLServerDatabaseProperties](
	[SQLServerDatabasePropertiesKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[SQLServerDatabaseProperties_2005]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[SQLServerDatabaseProperties_2005](
	[SQLServerDatabaseProperties_2005Key] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[SQLServerProperties]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[SQLServerProperties](
	[SQLServerPropertiesKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[SQLServerVersion]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[SQLServerVersion](
	[SQLServerVersionKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[UpTimeAnalysis]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[UpTimeAnalysis](
	[UpTimeAnalysisKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Admin_Import_Error_Checks]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO







CREATE VIEW [AdminServer].[HPS_Admin_Import_Error_Checks]
AS
	/****** Script for SelectTopNRows command from SSMS  ******/
	SELECT TOP (1000)
		[DBINFOKey]
	   ,[ServerName]
	   ,[RunDate]
	   ,[RunResults]
	   ,'BestPractices' AS LogFileName
	FROM [AdminLog].[BestPractices]
	WHERE RunResults IS NULL
	UNION
	SELECT TOP (1000)
		[CapacityReviewKey]
	   ,[ServerName]
	   ,[RunDate]
	   ,[RunResults]
	   ,'CapacityReview' AS LogFileName
	FROM [AdminLog].[CapacityReview]
	WHERE RunResults IS NULL
	UNION
	SELECT TOP 100 PERCENT
		[DailyBackupAuditReposKey]
	   ,[ServerName]
	   ,REPLACE( REPLACE( REPLACE( CONVERT( VARCHAR(8000),[RunDate] ),CHAR( 13 ),'' ),CHAR( 10 ),'' ),CHAR( 9 ),'' ) AS RunDate
	   ,[RunResults]
	   ,'DailyBackupAudit'																							 AS LogFileName
	FROM [AdminLog].[DailyBackupAudit]
	WHERE RunResults IS NULL
	UNION
	SELECT TOP 100 PERCENT
		[DBINFOKey]
	   ,[ServerName]
	   ,REPLACE( REPLACE( REPLACE( CONVERT( VARCHAR(8000),[RunDate] ),CHAR( 13 ),'' ),CHAR( 10 ),'' ),CHAR( 9 ),'' ) AS RunDate
	   ,[RunResults]
	   ,'DBINFO'																									 AS LogFileName
	FROM [AdminLog].[DBINFO]
	WHERE RunResults IS NULL
	UNION
	SELECT TOP 100 PERCENT
		[DBInformationKey]
	   ,[ServerName]
	   ,REPLACE( REPLACE( REPLACE( CONVERT( VARCHAR(8000),[RunDate] ),CHAR( 13 ),'' ),CHAR( 10 ),'' ),CHAR( 9 ),'' ) AS RunDate
	   ,[RunResults]
	   ,'DBInformation'																								 AS LogFileName
	FROM [AdminLog].[DBInformation]
	WHERE RunResults IS NULL
	UNION
	SELECT TOP 100 PERCENT
		[DBIOInfofKey]
	   ,[ServerName]
	   ,REPLACE( REPLACE( REPLACE( CONVERT( VARCHAR(8000),[RunDate] ),CHAR( 13 ),'' ),CHAR( 10 ),'' ),CHAR( 9 ),'' ) AS RunDate
	   ,[RunResults]
	   ,'DBInformation_IO'																							 AS LogFileName
	FROM [AdminLog].[DBInformation_IO]
	WHERE RunResults IS NULL
	UNION
	SELECT TOP 100 PERCENT
		[DiskSpaceKey]
	   ,[ServerName]
	   ,REPLACE( REPLACE( REPLACE( CONVERT( VARCHAR(8000),[RunDate] ),CHAR( 13 ),'' ),CHAR( 10 ),'' ),CHAR( 9 ),'' ) AS RunDate
	   ,[RunResults]
	   ,'DiskSpace'																									 AS LogFileName
	FROM [AdminLog].[DiskSpace]
	WHERE RunResults IS NULL
	UNION
	/*
	SELECT TOP 100 PERCENT [DTSPackagesKey]
	      ,[ServerName]
	      ,REPLACE(REPLACE(REPLACE(CONVERT(varchar(8000),[RunDate]), CHAR(13),''),CHAR(10),''), CHAR(9),'') AS RunDate
	      ,[RunResults]
		  ,'DTSPackages' AS LogFileName
	FROM [AdminLog].[DTSPackages]
	WHERE RunResults Is NULL
	UNION
	*/
	SELECT TOP 100 PERCENT
		[ErrorLogsKey]
	   ,[ServerName]
	   ,REPLACE( REPLACE( REPLACE( CONVERT( VARCHAR(8000),[RunDate] ),CHAR( 13 ),'' ),CHAR( 10 ),'' ),CHAR( 9 ),'' ) AS RunDate
	   ,[RunResults]
	   ,'ErrorLogs'																									 AS LogFileName
	FROM [AdminLog].[ErrorLogs]
	WHERE RunResults IS NULL
	UNION
	SELECT TOP 100 PERCENT
		[JobHistoryKey]
	   ,[ServerName]
	   ,REPLACE( REPLACE( REPLACE( CONVERT( VARCHAR(8000),[RunDate] ),CHAR( 13 ),'' ),CHAR( 10 ),'' ),CHAR( 9 ),'' ) AS RunDate
	   ,[RunResults]
	   ,'JobHistory'																								 AS LogFileName
	FROM [AdminLog].[JobHistory]
	WHERE RunResults IS NULL
	UNION
	SELECT TOP 100 PERCENT
		[LoginsDetailKey]
	   ,[ServerName]
	   ,REPLACE( REPLACE( REPLACE( CONVERT( VARCHAR(8000),[RunDate] ),CHAR( 13 ),'' ),CHAR( 10 ),'' ),CHAR( 9 ),'' ) AS RunDate
	   ,[RunResults]
	   ,'LoginsDetail'																								 AS LogFileName
	FROM [AdminLog].[LoginsDetail]
	WHERE RunResults IS NULL
	UNION
	SELECT TOP 100 PERCENT
		[MountPointsKey]
	   ,[ServerName]
	   ,REPLACE( REPLACE( REPLACE( CONVERT( VARCHAR(8000),[RunDate] ),CHAR( 13 ),'' ),CHAR( 10 ),'' ),CHAR( 9 ),'' ) AS RunDate
	   ,[RunResults]
	   ,'MountPoints'																								 AS LogFileName
	FROM [AdminLog].[MountPoints]
	WHERE RunResults IS NULL
	UNION
	SELECT TOP 100 PERCENT
		[ServerServiceKey]
	   ,[ServerName]
	   ,REPLACE( REPLACE( REPLACE( CONVERT( VARCHAR(8000),[RunDate] ),CHAR( 13 ),'' ),CHAR( 10 ),'' ),CHAR( 9 ),'' ) AS RunDate
	   ,[RunResults]
	   ,'ServerService'																								 AS LogFileName
	FROM [AdminLog].[ServerService]
	WHERE RunResults IS NULL
	UNION
	SELECT TOP 100 PERCENT
		[SQLServerDatabasePropertiesKey]
	   ,[ServerName]
	   ,REPLACE( REPLACE( REPLACE( CONVERT( VARCHAR(8000),[RunDate] ),CHAR( 13 ),'' ),CHAR( 10 ),'' ),CHAR( 9 ),'' ) AS RunDate
	   ,[RunResults]
	   ,'SQLServerDatabaseProperties'																				 AS LogFileName
	FROM [AdminLog].[SQLServerDatabaseProperties]
	WHERE RunResults IS NULL
	UNION
	SELECT TOP 100 PERCENT
		[SQLServerDatabaseProperties_2005Key]
	   ,[ServerName]
	   ,REPLACE( REPLACE( REPLACE( CONVERT( VARCHAR(8000),[RunDate] ),CHAR( 13 ),'' ),CHAR( 10 ),'' ),CHAR( 9 ),'' ) AS RunDate
	   ,[RunResults]
	   ,'SQLServerDatabaseProperties_2005'																			 AS LogFileName
	FROM [AdminLog].[SQLServerDatabaseProperties_2005]
	WHERE RunResults IS NULL
	UNION
	SELECT TOP 100 PERCENT
		[SQLServerPropertiesKey]
	   ,[ServerName]
	   ,REPLACE( REPLACE( REPLACE( CONVERT( VARCHAR(8000),[RunDate] ),CHAR( 13 ),'' ),CHAR( 10 ),'' ),CHAR( 9 ),'' ) AS RunDate
	   ,[RunResults]
	   ,'SQLServerProperties'																						 AS LogFileName
	FROM [AdminLog].[SQLServerProperties]
	WHERE RunResults IS NULL
	UNION
	SELECT TOP 100 PERCENT
		[SQLServerVersionKey]
	   ,[ServerName]
	   ,REPLACE( REPLACE( REPLACE( CONVERT( VARCHAR(8000),[RunDate] ),CHAR( 13 ),'' ),CHAR( 10 ),'' ),CHAR( 9 ),'' ) AS RunDate
	   ,[RunResults]
	   ,'SQLServerVersion'																							 AS LogFileName
	FROM [AdminLog].[SQLServerVersion]
	WHERE RunResults IS NULL
	UNION
	/*
	SELECT TOP 100 PERCENT [SSISPackagesKey]
	      ,[ServerName]
	      ,REPLACE(REPLACE(REPLACE(CONVERT(varchar(8000),[RunDate]), CHAR(13),''),CHAR(10),''), CHAR(9),'') AS RunDate
	      ,[RunResults]
		  ,'SSISPackages' AS LogFileName
	  FROM [AdminLog].[SSISPackages]
	  WHERE RunResults Is NULL
	UNION
	*/
	SELECT TOP 100 PERCENT
		[UpTimeAnalysisKey]
	   ,[ServerName]
	   ,REPLACE( REPLACE( REPLACE( CONVERT( VARCHAR(8000),[RunDate] ),CHAR( 13 ),'' ),CHAR( 10 ),'' ),CHAR( 9 ),'' ) AS RunDate
	   ,[RunResults]
	   ,'UpTimeAnalysis'																							 AS LogFileName
	FROM [AdminLog].[UpTimeAnalysis]
	WHERE RunResults IS NULL
	UNION
	SELECT TOP (1000)
		[JobInformationKey]
	   ,[ServerName]
	   ,[RunDate]
	   ,[RunResults]
	   ,'JobInformation' AS LogFileName
	FROM [AdminLog].[JobInformation]
	WHERE RunResults IS NULL
	ORDER BY ServerName,LogFileName,RunDate
GO
/****** Object:  Table [AdminServer].[LastBackupAudit]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[LastBackupAudit](
	[date_key] [datetime] NOT NULL,
	[server_name] [nvarchar](128) NOT NULL,
	[database_name] [nvarchar](128) NOT NULL,
	[backup_type] [char](1) NOT NULL,
	[backup_finish_date] [datetime] NULL,
	[user_name] [nvarchar](128) NULL,
	[time_taken_seconds] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  View [AdminServer].[HPS_Admin_LastBackup_Audit_Daily]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [AdminServer].[HPS_Admin_LastBackup_Audit_Daily]
AS
	SELECT
		CONVERT( DATE,date_key )																   AS Date_Key
	   ,lba.server_name																			   AS ServerName
	   ,lba.[database_name]																		   AS DatabaseName
	   ,CASE lba.backup_type
			WHEN 'D' THEN 'FULL'
			WHEN 'L' THEN 'LOG'
		END																						   AS BackupType
	   ,COALESCE( CONVERT( VARCHAR(24),backup_finish_date,100 ),'N/A' )							   AS BackupFinishedDate
	   ,COALESCE( CONVERT( VARCHAR(8),DATEDIFF( HH,lba.backup_finish_date,lba.date_key ) ),'N/A' ) AS HoursOld
	   ,CASE lba.backup_type
			WHEN 'D' THEN N'No Full Backup taken in last ' + CAST( HrsCheck.HoursOldToLook AS VARCHAR(2) ) + ' hours'
			WHEN 'L' THEN N'No Tlog backup taken in last ' + CAST( HrsCheck.HoursOldToLook AS VARCHAR(2) ) + ' hours. Ensure TLog Backup jobs are enabled'
		END																						   AS Review
	FROM [AdminServer].[LastBackupAudit] AS lba
	CROSS APPLY (
		  SELECT
			  'D' AS BackupType
			 ,30  AS HoursOldToLook
		  UNION ALL
		  SELECT
			  'L'
			 ,2
	) HrsCheck
	WHERE (lba.date_key > DATEADD( HH,HrsCheck.HoursOldToLook,lba.backup_finish_date ) OR lba.backup_finish_date IS NULL)
	AND lba.backup_type = HrsCheck.BackupType
;
GO
/****** Object:  Table [AdminServer].[Backup_Audit_Daily]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[Backup_Audit_Daily](
	[Date_Key] [datetime] NOT NULL,
	[User] [nvarchar](128) NULL,
	[Database] [nvarchar](128) NULL,
	[Server] [nvarchar](128) NULL,
	[BackupType] [char](1) NULL,
	[Review] [varchar](23) NOT NULL,
	[Backup Started] [datetime] NULL,
	[Backup Finished] [datetime] NULL,
	[Total Time] [varchar](116) NULL,
	[BackupFileName] [nvarchar](260) NULL
) ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Export_DailyBackupAudit_Current]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Export_DailyBackupAudit_Current]
AS
SELECT     Date_Key, [User], [Database], Server, BackupType, Review, [Backup Started], [Backup Finished], [Total Time], BackupFileName
FROM         AdminServer.Backup_Audit_Daily INNER JOIN AdminControl.DBServersAll ON
AdminServer.Backup_Audit_Daily.Server = AdminControl.DBServersAll.DBSAServerName
WHERE Admincontrol.DBServersAll.DBSAManaged = 1




GO
/****** Object:  Table [AdminServer].[Database_Information]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[Database_Information](
	[Date_Key] [datetime] NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[DatabaseName] [varchar](128) NOT NULL,
	[FileSizeMB] [int] NOT NULL,
	[LogicalFileName] [sysname] NOT NULL,
	[PhysicalFileName] [nvarchar](520) NOT NULL,
	[Status] [sysname] NOT NULL,
	[Updateability] [sysname] NOT NULL,
	[RecoveryMode] [sysname] NOT NULL,
	[FreeSpaceMB] [int] NOT NULL,
	[FreeSpacePct] [varchar](7) NOT NULL,
	[PollDate] [datetime] NOT NULL,
	[Applications] [varchar](256) NULL,
	[FunctionalGroups] [varchar](256) NULL,
	[Owners] [varchar](256) NULL
) ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Export_DatabaseInformation_Current]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Export_DatabaseInformation_Current]
AS
SELECT	TOP (100) PERCENT 
	DI.Date_Key, 
	M.DBSACustomerName, 
	M.DBSAServerName, 
	M.DBSAServerType, 
	M.DBSADomain, 
	DI.DatabaseName, 
	DI.FileSizeMB, 
	DI.LogicalFileName, 
	DI.PhysicalFileName, 
	DI.Status, 
	DI.Updateability, 
	DI.RecoveryMode, 
	DI.FreeSpaceMB, 
	DI.FreeSpacePct, 
	DI.Applications, 
	DI.FunctionalGroups, 
	DI.Owners
FROM    AdminServer.Database_Information AS DI INNER JOIN
        AdminControl.DBServersAll AS M ON DI.ServerName = M.DBSAServerName
WHERE     M.DBSAManaged = 1 AND DI.Date_Key = (SELECT     MAX(Date_Key) AS Date_Key FROM AdminServer.Database_Information) 
ORDER BY DI.Date_Key, M.DBSACustomerName, DI.ServerName, DI.DatabaseName




GO
/****** Object:  Table [AdminServer].[Job_History_Repository]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[Job_History_Repository](
	[Server] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NULL,
	[name] [nvarchar](128) NOT NULL,
	[step_id] [int] NOT NULL,
	[step_name] [nvarchar](128) NULL,
	[Message] [nvarchar](1024) NULL,
	[Run_Status] [int] NOT NULL,
	[Run_Duration] [varchar](36) NULL
) ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Export_JobHistory_Current]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Export_JobHistory_Current]
AS
SELECT     Server, RunDate, name, step_id, step_name, Message, Run_Status, Run_Duration
FROM         AdminServer.Job_History_Repository INNER JOIN AdminControl.DBServersAll ON
AdminServer.Job_History_Repository.Server = AdminControl.DBServersAll.DBSAServerName
WHERE AdminControl.DBServersAll.DBSAManaged = 1




GO
/****** Object:  Table [AdminServer].[StageErrorLog]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[StageErrorLog](
	[LogDate] [datetime] NULL,
	[ProcessInfo] [nvarchar](50) NULL,
	[Text] [nvarchar](max) NULL,
	[Server] [sysname] NULL
) ON [PRIMARY] TEXTIMAGE_ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Export_StageErrorLog_Current]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Export_StageErrorLog_Current]
AS
SELECT     LogDate, ProcessInfo, Text, Server
FROM         AdminServer.StageErrorLog INNER JOIN AdminControl.DBServersAll ON
AdminServer.StageErrorLog.Server = AdminControl.DBServersAll.DBSAServerName
WHERE AdminControl.DBServersAll.DBSAManaged = 1




GO
/****** Object:  View [AdminServer].[HPS_Inventory_Customer_TotalsBySLA_Supported_DG]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [AdminServer].[HPS_Inventory_Customer_TotalsBySLA_Supported_DG]
AS

SELECT TOP (100) PERCENT 
	S1.Date_Key, 
	S1.Customer, 
	S1.SLA, 
	COUNT(DISTINCT S1.Server) AS Server_Count_By_SLA, 
	SUM(CASE WHEN [db] NOT IN ('System DBs', 'DBA') THEN 1
	           ELSE 0 END) AS Database_Count_By_SLA, 
	SUM(dbsize) AS Total_Size_By_SLA
FROM
(
SELECT  
	Date_Key, 
	customer, 
	server, 
	  CASE WHEN S.DBSAServerName = 'ACWIN-SQLT01\SQL002'	   THEN 'BS'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC' 
	       ELSE 'Undefined' END AS SLA, 
	db, 
	crdate, 
	dbsize, 
	comments, 
	updated, 
	[by]
FROM	AdminServer.DBINFO_Information AS D INNER JOIN AdminControl.DBServersAll AS S ON
		D.server = S.DBSAServerName
WHERE	S.DBSAManaged = 1 AND
		S.DBSAInstanceSupported = 'Y' AND   
		S.DBSAInstanceBilled = 'Y' AND
		S.DBSASpotlightDayTimeMonitoring = 'DG' AND
		(Date_Key = (SELECT MAX(Date_Key) AS Date_Key
          FROM   AdminServer.DBINFO_Information))
) AS S1
GROUP BY S1.Date_Key, S1.Customer, S1.SLA
ORDER BY S1.Date_Key, S1.Customer, S1.SLA






GO
/****** Object:  View [AdminServer].[HPS_Inventory_Customer_TotalsBySLA_Total]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [AdminServer].[HPS_Inventory_Customer_TotalsBySLA_Total]
AS
SELECT TOP (100) PERCENT 
	Date_Key, 
	Customer, 
	SLA, 
	COUNT(DISTINCT server) AS Server_Count_By_SLA, 
	SUM(CASE WHEN [db] NOT IN ('System DBs', 'DBA') THEN 1
	           ELSE 0 END) AS Database_Count_By_SLA, 
	SUM(dbsize) AS Total_Size_By_SLA
FROM (SELECT  D.Date_Key, D.customer, D.server,
	  CASE WHEN S.DBSAServerName = 'ACWIN-SQLT01\SQL002'	   THEN 'BS'
	       WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC' 
	       ELSE 'Undefined' END AS SLA, 
	       D.db, D.crdate, D.dbsize, D.comments, D.updated, D.[by]
      FROM	AdminServer.DBINFO_Information AS D 
			INNER JOIN
			AdminControl.DBServersAll AS S ON D.server = S.DBSAServerName
      WHERE S.DBSAManaged = 1 AND (D.Date_Key = (SELECT MAX(Date_Key) AS Date_Key
                           FROM   AdminServer.DBINFO_Information))) AS S1
GROUP BY Date_Key, customer, SLA
ORDER BY Date_Key, customer, SLA






GO
/****** Object:  View [AdminServer].[HPS_Inventory_CustomerTotals_Supported]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Inventory_CustomerTotals_Supported]
AS
SELECT     TOP (100) PERCENT 
	D.customer, 
	SUM(CASE WHEN [db] NOT IN ('System DBs', 'DBA') THEN 1
	           ELSE 0 END) AS DatabaseCount, 
	CAST(ROUND(SUM(D.dbsize / 1024), 0) AS INT) AS SLA_Total_GB
FROM         AdminServer.DBINFO_Information AS D INNER JOIN
                      AdminControl.DBServersAll AS M ON D.server = M.DBSAServerName
WHERE M.DBSAManaged = 1 AND (M.DBSAInstanceSupported = 'Y') AND (D.Date_Key =
                          (SELECT     MAX(Date_Key) AS Date_Key
                            FROM          AdminServer.DBINFO_Information))
GROUP BY D.customer
ORDER BY D.customer





GO
/****** Object:  View [AdminServer].[HPS_Inventory_CustomerTotals_Total]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Inventory_CustomerTotals_Total]
AS
SELECT     TOP (100) PERCENT customer, 
	SUM(CASE WHEN [db] NOT IN ('System DBs', 'DBA') THEN 1
	           ELSE 0 END) AS DatabaseCount, 
	CAST(ROUND(SUM(dbsize / 1024), 0) AS INT) AS SLA_Total_GB
FROM         AdminServer.DBINFO_Information INNER JOIN AdminControl.DBServersAll ON
AdminServer.DBINFO_Information.server = AdminControl.DBServersAll.DBSAServerName
WHERE  AdminControl.DBServersAll.DBSAManaged = 1 AND (Date_Key =
                          (SELECT     MAX(Date_Key) AS Date_Key
                            FROM          AdminServer.DBINFO_Information AS Admin_Server_DBINFO_Information_1))
GROUP BY customer
ORDER BY customer





GO
/****** Object:  View [AdminServer].[HPS_Inventory_Database_Environment_IP_Address_Information]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [AdminServer].[HPS_Inventory_Database_Environment_IP_Address_Information]
AS
SELECT
	DBSAServerName AS Server_Name, 
	CASE WHEN DBSAClustered = 1 THEN 'Clustered'
	     WHEN DBSAClustered = 0 THEN 'Not Clustered'
	     ELSE 'Undefined' END AS IsClustered,
	DBSAServerIPAddress AS DatabaseEnvironmentIPAddress, 
	DBSAServerClusterdIPAddress AS ServerClusterIPAddress,
	DBSAServerClusterdNode1IPAddress AS ClusterNode1IPAddress, 
	DBSAServerClusterdNode2IPAddress AS ClusterNode2IPAddress, 
	DBSAServerClusterdNode3IPAddress AS ClusterNode3IPAddress
FROM AdminControl.DBServersAll







GO
/****** Object:  Table [AdminControl].[Server_DR_Information]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminControl].[Server_DR_Information](
	[SDRI_KEY] [int] NOT NULL,
	[SDRI_CustomerName] [varchar](128) NOT NULL,
	[SDRI_PRODServerName] [varchar](128) NOT NULL,
	[SDRI_DRServerName] [varchar](128) NULL,
	[SDRI_DRType] [varchar](80) NULL,
	[SDRI_ConsistencyGroups] [varchar](50) NULL
) ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Inventory_DR_Server_Matrix]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [AdminServer].[HPS_Inventory_DR_Server_Matrix]
AS
SELECT     SDRI_CustomerName AS CustomerName, SDRI_PRODServerName AS PRODServerName, SDRI_DRServerName AS DRServerName, 
                      SDRI_DRType AS DRType
FROM         AdminControl.Server_DR_Information






GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_CustomerServerCounts]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [AdminServer].[HPS_Inventory_Server_CustomerServerCounts]
AS
SELECT CustomerName, COUNT(ServerType) AS Server_Count
FROM
(
SELECT  TOP (100) PERCENT 
	DBSACustomerName AS CustomerName, 
	CASE WHEN DBSAInstanceSupported = 'N'						THEN '1 - Future Environments'
		 WHEN DBSAInstanceBilled = 'N' AND DBSAServerType = 'B' THEN '3 - Non-Active Disaster Revovery Environments'
		 WHEN DBSAServerType = 'B'								THEN '2 - Active Disaster Recovery Environments'
		 WHEN DBSAServerType = 'P'								THEN '4 - Production Environments'
		 WHEN DBSAServerType = 'D'								THEN '5 - Development Environments'
		 WHEN DBSAServerType = 'S'								THEN '6 - Stage Environments'
 		 WHEN DBSAServerType = 'T'								THEN '7 - Test Environments'
		 ELSE DBSAServerType END AS ServerType
FROM  AdminControl.DBServersAll
WHERE AdminControl.DBServersAll.DBSAManaged = 1 AND
	  DBSAInstanceSupported = 'Y' AND
	  DBSAInstanceBilled = 'Y'
	  ) AS S1
GROUP BY CustomerName






GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_CustomerServerCounts_By_ServerType]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [AdminServer].[HPS_Inventory_Server_CustomerServerCounts_By_ServerType]
AS
SELECT CustomerName, COUNT(ServerType) AS Server_Count, ServerType
FROM
(
SELECT  TOP (100) PERCENT 
	DBSACustomerName AS CustomerName, 
	CASE WHEN DBSAInstanceSupported = 'N'						THEN '1 - Future Environments'
		 WHEN DBSAInstanceBilled = 'N' AND DBSAServerType = 'B' THEN '3 - Non-Active Disaster Revovery Environments'
		 WHEN DBSAServerType = 'B'								THEN '2 - Active Disaster Recovery Environments'
		 WHEN DBSAServerType = 'P'								THEN '4 - Production Environments'
		 WHEN DBSAServerType = 'D'								THEN '5 - Development Environments'
		 WHEN DBSAServerType = 'S'								THEN '6 - Stage Environments'
 		 WHEN DBSAServerType = 'T'								THEN '7 - Test Environments'
		 ELSE DBSAServerType END AS ServerType
FROM  AdminControl.DBServersAll
WHERE AdminControl.DBServersAll.DBSAManaged = 1) AS S1
GROUP BY CustomerName, ServerType








GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_CustomerServerCounts_Futures]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO









CREATE VIEW [AdminServer].[HPS_Inventory_Server_CustomerServerCounts_Futures]
AS
SELECT  TOP 100 PERCENT
	DBSACustomerName AS CustomerName, 
	DBSAServerName AS FutureDatabaseEnvironment,
	DBSADomain AS Domain,
	CASE WHEN DBSAManaged = 1 THEN 'Ensono Managed'
		 ELSE 'Customer DBA Managed' END AS Managed,
	CASE 
		 WHEN DBSAServerType = 'B'								THEN 'Disaster Recovery'
		 WHEN DBSAServerType = 'P'								THEN 'Production'
		 WHEN DBSAServerType = 'D'								THEN 'Development'
		 WHEN DBSAServerType = 'S'								THEN 'Stage'
 		 WHEN DBSAServerType = 'T'								THEN 'Test'
		 ELSE DBSAServerType END AS ServerType,
	DBSADescription AS Description
FROM  AdminControl.DBServersAll
WHERE DBSAInstanceSupported = 'N' and DBSAManaged = 1
ORDER BY DBSACustomerName, DBSAServerName












GO
/****** Object:  Table [AdminControl].[SQLVersionInformation]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminControl].[SQLVersionInformation](
	[Build_Key] [nvarchar](255) NOT NULL,
	[SQL_Version] [nvarchar](255) NULL,
	[Product_Level] [nvarchar](255) NULL,
	[Life_Cycle_Start_Date] [datetime] NULL,
	[Mainstream_Support_End_Date] [datetime] NULL,
	[Extended_Support_End_Date] [datetime] NULL,
	[Service_Pack_Support_End_Date] [datetime] NULL,
	[Service_Pack_Support_Comments] [nvarchar](255) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [AdminServer].[SQLServerProperties_Repository]    Script Date: 11/4/2025 9:51:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[SQLServerProperties_Repository](
	[SQLServerRepository_Key] [int] IDENTITY(1,1) NOT NULL,
	[Date_Key] [datetime] NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[ComputerName] [nvarchar](128) NULL,
	[MachineName] [nvarchar](128) NULL,
	[Edition] [nvarchar](128) NULL,
	[ProductLevel] [nvarchar](128) NULL,
	[ProductVersion] [nvarchar](128) NULL,
	[Collation] [nvarchar](128) NULL,
	[IsClusterd] [varchar](100) NULL,
	[IsFullTextInstalled] [varchar](100) NULL,
	[IsIntegratedSecurityOn] [varchar](100) NULL,
	[LicenseType] [nvarchar](128) NULL,
	[NumLicenses] [nvarchar](128) NULL,
	[ResourceLastUpdateDateTime] [nvarchar](128) NULL,
	[ResourceVersion] [nvarchar](128) NULL,
	[SqlCharSetName] [nvarchar](128) NULL,
	[SqlSortOrderName] [nvarchar](128) NULL,
	[FileStreamShareName] [nvarchar](128) NULL,
	[FileStreamConfigureLevel] [nvarchar](128) NULL,
	[FileStreamEffectiveLevel] [nvarchar](128) NULL
) ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_Support_Information]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Inventory_Server_Support_Information]
AS
SELECT TOP 100 PERCENT
	R.Date_Key, 
	M.DBSACustomerName AS CustomerName,
	R.ServerName AS DatabaseEnvironmentName, 
	V.SQL_Version,
	R.Edition, 
	R.ProductLevel, 
	R.ProductVersion, 
	V.[Life_Cycle_Start_Date],
	V.[Mainstream_Support_End_Date],
	V.[Extended_Support_End_Date],
	V.[Service_Pack_Support_End_Date],
	V.[Service_Pack_Support_Comments]
FROM AdminServer.SQLServerProperties_Repository AS R INNER JOIN Admincontrol.DBServersAll AS M ON
	R.ServerName = M.DBSAServerName INNER JOIN
	(SELECT ServerName, MAX(Date_Key) AS Date_Key
                   FROM   AdminServer.SQLServerProperties_Repository
                   GROUP BY ServerName) AS S1 ON
                   R.ServerName = S1.ServerName AND
                   R.Date_Key = S1.Date_Key LEFT OUTER JOIN [AdminControl].[SQLVersionInformation] AS V ON 
				   R.ProductVersion = V.Build_Key
WHERE M.DBSAManaged = 1 
ORDER BY M.DBSACustomerName, R.ServerName





GO
/****** Object:  View [AdminServer].[HPS_Server_DBINFO_Customer_Clustered_Information]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*AND (DBSAInstanceSupported = 'Y')*/
CREATE VIEW [AdminServer].[HPS_Server_DBINFO_Customer_Clustered_Information]
AS
SELECT     DBSACustomerName AS Customer_Name, DBSAServerName AS Server_Name, DBSADescription, DBSADomain AS Domain, 
                      DBSAServerType AS Server_Type, DBSASANName, DBSAServerClusterdVirtualName AS Server_Virtual_Name, 
                      DBSAServerClusterdNode1Name AS Server_Node_1_Name, DBSAServerClusterdNode2Name AS Server_Node_2_Name, 
                      DBSAServerClusterdNode3Name AS Server_Node_3_Name, DBSAServerIPAddress_NAT AS HPS_NAT_Address, DBSAServerIPAddress AS Server_Real_IP_Address, 
                      DBSAServerClusterdIPAddress AS Cluster_IP_Address, DBSAServerClusterdNode1IPAddress AS Cluster_Node_1_IP_Address, 
                      DBSAServerClusterdNode2IPAddress AS Cluster_Node_2_IP_Address
FROM         AdminControl.DBServersAll
WHERE  DBSAManaged = 1 AND DBSAClustered = 1




GO
/****** Object:  View [AdminServer].[HPS_Server_DBINFO_Customer_Standalone_Information]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Server_DBINFO_Customer_Standalone_Information]
AS
SELECT     DBSACustomerName AS Customer_Name, DBSAServerName AS Server_Name, DBSADescription, DBSADomain AS Domain, 
                      DBSAServerType AS Server_Type, DBSASANName, DBSAServerClusterdVirtualName AS Server_Virtual_Name, 
                      DBSAServerClusterdNode1Name AS Server_Node_1_Name, DBSAServerClusterdNode2Name AS Server_Node_2_Name, 
                      DBSAServerIPAddress_NAT AS HPS_NAT_Address, DBSAServerIPAddress AS Server_Real_IP_Address, 
                      DBSAServerClusterdIPAddress AS Cluster_IP_Address, DBSAServerClusterdNode1IPAddress AS Cluster_Node_1_IP_Address, 
                      DBSAServerClusterdNode2IPAddress AS Cluster_Node_2_IP_Address
FROM         AdminControl.DBServersAll
WHERE  DBSAManaged = 1 AND DBSAClustered = 0




GO
/****** Object:  Table [AdminServer].[DTS_Information]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[DTS_Information](
	[Date_Key] [datetime] NULL,
	[Server_Name] [sysname] NULL,
	[DTS_Package_Name] [nvarchar](128) NOT NULL,
	[DTS_Description] [nvarchar](1024) NULL,
	[DTS_Creation_Date] [datetime] NULL
) ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Server_DTSPackages]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Server_DTSPackages]
AS
SELECT     TOP (100) PERCENT 
	AdminServer.DTS_Information.Date_Key AS Date_Key,
	AdminControl.DBServersAll.DBSACustomerName AS CustomerName, 
	AdminServer.DTS_Information.Server_Name, 
    AdminServer.DTS_Information.DTS_Package_Name, 
	AdminServer.DTS_Information.DTS_Description, 
	AdminServer.DTS_Information.DTS_Creation_Date
FROM	Admincontrol.DBServersAll INNER JOIN AdminServer.DTS_Information ON 
AdminControl.DBServersAll.DBSAServerName = AdminServer.DTS_Information.Server_Name
WHERE AdminControl.DBServersAll.DBSAManaged = 1 AND AdminServer.DTS_Information.Date_Key = (SELECT MAX(Date_Key) from AdminServer.DTS_Information)
ORDER BY CustomerName, AdminServer.DTS_Information.Server_Name, AdminServer.DTS_Information.DTS_Package_Name






GO
/****** Object:  View [AdminServer].[HPS_Server_IP_Address_Inforamtion]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Server_IP_Address_Inforamtion]
AS
SELECT
	DBSAServerName AS Server_Name, 
	DBSAClustered AS IsClustered, 
	DBSAServerIPAddress AS ServerIPAddress, 
	DBSAServerClusterdNode1IPAddress AS ClusterNode1IPAddress, 
	DBSAServerClusterdNode2IPAddress AS ClusterNode2IPAddress, 
	DBSAServerClusterdIPAddress AS ServerClusterIPAddress
FROM AdminControl.DBServersAll




GO
/****** Object:  Table [AdminServer].[Logins]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[Logins](
	[Date_Key] [datetime] NOT NULL,
	[Server] [varchar](128) NULL,
	[Login Name] [nvarchar](128) NULL,
	[Default Database] [nvarchar](128) NULL,
	[CreateDate] [datetime] NULL,
	[UpdateDate] [datetime] NULL,
	[AccDate] [datetime] NULL,
	[NT Name] [int] NULL,
	[NT Grp] [int] NULL,
	[NT User] [int] NULL,
	[Sys Adm] [int] NULL,
	[Sec Adm] [int] NULL,
	[Srvr Adm] [int] NULL,
	[Setup Adm] [int] NULL,
	[Proc Adm] [int] NULL,
	[Disk Adm] [int] NULL,
	[DB Creator] [int] NULL,
	[Bulk Adm] [int] NULL
) ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Server_Logins]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Server_Logins]
AS
SELECT     TOP (100) PERCENT 
	AdminServer.Logins.Date_Key,
	AdminControl.DBServersAll.DBSACustomerName AS [Customer Name], 
	AdminServer.Logins.Server AS [Server Name], 
	Admincontrol.DBServersAll.DBSADomain AS Domain, 
	AdminServer.Logins.[Login Name], 
	AdminServer.Logins.[Default Database], 
	AdminServer.Logins.[CreateDate],
	AdminServer.Logins.[UpdateDate],
	AdminServer.Logins.[AccDate],
	AdminServer.Logins.[NT Name], 
	AdminServer.Logins.[NT Grp], 
	AdminServer.Logins.[NT User], 
	AdminServer.Logins.[Sys Adm], 
	AdminServer.Logins.[Sec Adm], 
	AdminServer.Logins.[Srvr Adm], 
	AdminServer.Logins.[Setup Adm], 
	AdminServer.Logins.[Proc Adm], 
	AdminServer.Logins.[Disk Adm], 
	AdminServer.Logins.[DB Creator], 
	AdminServer.Logins.[Bulk Adm]
FROM         AdminServer.Logins INNER JOIN
                      AdminControl.DBServersAll ON AdminServer.Logins.Server = AdminControl.DBServersAll.DBSAServerName
WHERE Admincontrol.DBServersAll.DBSAManaged = 1 AND AdminServer.Logins.Date_Key = (SELECT MAX(Date_Key) from AdminServer.Logins) 
ORDER BY AdminControl.DBServersAll.DBSACustomerName, [Server Name], AdminServer.Logins.[Login Name]




GO
/****** Object:  View [AdminServer].[HPS_Server_SAN_Information]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW [AdminServer].[HPS_Server_SAN_Information]
AS
SELECT     TOP (100) PERCENT DBSACustomerName AS CustomerName, DBSAServerName AS ServerName, 
                      CASE WHEN [DBSAVirtualMachine] = 1 THEN 'Yes' ELSE 'No' END AS VirtualName, CASE WHEN [DBSAClustered] = 1 THEN 'Yes' ELSE 'No' END AS [Clustered], 
                      CASE WHEN [DBSASANAttached] = 1 THEN 'Yes' ELSE 'No' END AS SANAttached, CASE WHEN [DBSASANName] IS NOT NULL 
                      THEN [DBSASANName] WHEN [DBSAInstanceSupported] = 'N' THEN 'New TT Build' WHEN [DBSAVirtualMachine] = 1 THEN 'VM Host System SAN' ELSE 'No SAN At This Time'
                       END AS SANName, DBSAServerClusterdNode1Name AS ServerClusterdNode1Name, DBSAServerClusterdNode2Name AS ServerClusterdNode2Name, 
                      DBSAServerClusterdNode3Name AS ServerClusterdNode3Name, DBSAServerClusteredPreferredNode AS ServerClusteredPreferredNode
FROM         AdminControl.DBServersAll



GO
/****** Object:  Table [dbo].[crProcessDetails]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[crProcessDetails](
	[crid] [int] NOT NULL,
	[DatabaseName] [varchar](128) NOT NULL,
	[StartTime] [smalldatetime] NOT NULL,
	[EndTime] [smalldatetime] NOT NULL,
	[UpdateTime] [smalldatetime] NOT NULL,
 CONSTRAINT [PK_crProcessDetails_StartTime_DatabaseName] PRIMARY KEY CLUSTERED 
(
	[StartTime] ASC,
	[DatabaseName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  UserDefinedFunction [dbo].[fn_cr_check_database_overlap]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[fn_cr_check_database_overlap] (	@dbs	Varchar(Max)
													,@start	SmallDateTime
													,@end	SmallDateTime)
RETURNS TABLE
AS
	RETURN (
	-- Select rows from a Table or View 'CRtracker' in schema 'dbo'
	SELECT	ct.DatabaseName
			,ct.StartTime
			,ct.EndTime
	FROM dbo.[crProcessDetails] AS ct
	CROSS APPLY dbo.fnSplitString(@dbs, ',') AS t
	WHERE ct.StartTime <= @end AND 
	ct.EndTime >= @start AND
	ct.DatabaseName = LTRIM(RTRIM(t.list))
		
		
	);
GO
/****** Object:  Table [dbo].[crProcess]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[crProcess](
	[crid] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [varchar](128) NOT NULL,
	[CTNumber] [varchar](64) NOT NULL,
	[CasdNum] [int] NOT NULL,
	[Enteredby] [varchar](128) NOT NULL,
	[Requester] [varchar](128) NOT NULL,
	[CCEmail] [varchar](128) NULL,
	[Accpwd] [varchar](max) NOT NULL,
	[LoggedTime] [smalldatetime] NOT NULL,
	[Reminder] [bit] NOT NULL,
 CONSTRAINT [PK_crProcess_crid] PRIMARY KEY NONCLUSTERED 
(
	[crid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_cr_GetRolloutDetails]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_cr_GetRolloutDetails] WITH SCHEMABINDING
AS
/***************************************************************************************************************************************


	Copyright(c) 2016 Harsha Vasa
	All rights reserved. No part of this script may be reproduced/shared in any form or by making any changes - without written
	permissions from the author

	Purpose: To view the code rollout info


	History:
	------------------------------------------------------------------------------------------------------------------------------------
	Author                                 Date Created                Comments
	------------------------------------------------------------------------------------------------------------------------------------
	Harsha vasa                              2017-03-28                 Initial draft



    ------------------------------------------------------------------------------------------------------------------------------------

	Documentation:
	--------------



	Execution Samples:
	------------------


***************************************************************************************************************************************/
SELECT cr.ServerName
	  ,cr.CTNumber
	  ,cr.CasdNum
	  ,ct.DatabaseName
	  ,ct.StartTime
	  ,ct.EndTime
	  ,cr.Enteredby
	  ,cr.[Requester]
	  ,cr.[CCEmail]
	  ,cr.Reminder
FROM dbo.[crProcess] AS cr
INNER JOIN dbo.[crProcessDetails] AS ct ON cr.crid = ct.crid;
GO
/****** Object:  UserDefinedFunction [dbo].[fn_cr_find_dbs_complete]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[fn_cr_find_dbs_complete] (@schedulename VARCHAR(8))
RETURNS TABLE
AS
	RETURN
	(
		  SELECT
			  DatabaseName
		  FROM dbo.vw_cr_GetRolloutDetails AS vcr
		  WHERE StartTime >= CONVERT( SMALLDATETIME,@schedulename )
		  AND EndTime < current_timestamp
		  EXCEPT
		  SELECT
			  DatabaseName
		  FROM dbo.vw_cr_GetRolloutDetails AS vcr
		  WHERE EndTime > current_timestamp
		  AND StartTime <= DATEADD( dd,1,CONVERT( SMALLDATETIME,@schedulename ) )
	)

GO
/****** Object:  Table [eva].[ServerDetail]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [eva].[ServerDetail](
	[date_key] [datetime] NOT NULL,
	[servername] [nvarchar](128) NOT NULL,
	[is_prod] [bit] NOT NULL,
	[is_ag] [bit] NOT NULL,
	[is_logshipping] [bit] NOT NULL,
	[is_replication] [bit] NULL,
	[is_mirroring] [bit] NULL,
	[customer] [varchar](50) NOT NULL,
	[primary_contact_email_address] [varchar](128) NULL,
	[primary_customer_dba_email_group] [varchar](128) NULL,
	[ensono_dba_email_group] [varchar](50) NULL,
	[smtp_server] [varchar](50) NULL,
	[smtp_email_address] [varchar](50) NULL,
	[netbackup_sort_by] [varchar](50) NULL,
 CONSTRAINT [PK_ServerDetail_servername] PRIMARY KEY CLUSTERED 
(
	[servername] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  UserDefinedFunction [eva].[fnFileRetention]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [eva].[fnFileRetention] (@Type VARCHAR(32))
RETURNS TINYINT
WITH SCHEMABINDING
AS
	/***************************************************************************************************************************************

			Purpose: Define Retention Standard To Delete Old Files from the FileSystem Path based on the type and label_id


			History:
			------------------------------------------------------------------------------------------------------------------------------------
			Author                                 Date Created                Comments
			------------------------------------------------------------------------------------------------------------------------------------
			Harsha vasa                              2018-10-05                  Initial draft



		    ------------------------------------------------------------------------------------------------------------------------------------

			Documentation: USER STORY #236
			--------------
			 (Ensono)                      PROD                    NONPROD
              Backup						15                      7
              ErrorLog						30                      15

			  Default
			  Retention = 35 (EDP Backup Max Retention on the Disk)

			Extensions:  bak, trn, diff, txt, log, sqlaudit, sql and * (Wild Char)



			Execution Samples:
			------------------
			#1
			SELECT [eva].[fnFileRetention](1,'backup')

			#3
			SELECT [eva].[fnFileRetention](0, 'errorlog')


	    ***************************************************************************************************************************************/

	BEGIN
		DECLARE @Retention TINYINT;

		IF (SELECT sd.is_prod FROM eva.ServerDetail AS sd) = 1
			 BEGIN

				 IF @Type = 'backup'
					 SET @Retention = 15;
				 ELSE

				 IF @Type = 'errorlog'
					 SET @Retention = 30;

			 END;
		ELSE
			 BEGIN

				 IF @Type = 'backup'
					 SET @Retention = 7;
				 ELSE

				 IF @Type = 'errorlog'
					 SET @Retention = 15;

			 END;

		RETURN @Retention;

	END;

GO
/****** Object:  UserDefinedFunction [eva].[fnGetRecoveryModel]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [eva].[fnGetRecoveryModel] ()
RETURNS VARCHAR(8)
WITH SCHEMABINDING
AS
	BEGIN
		DECLARE @rm VARCHAR(64)

		IF (SELECT sd.is_prod FROM eva.ServerDetail AS sd) = 1
			SET @rm = N'FULL'
		ELSE
			SET @rm = N'SIMPLE'

		RETURN (@rm);
	END

GO
/****** Object:  Table [AdminServer].[Disk_Space_Repository]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[Disk_Space_Repository](
	[Date_Key] [datetime] NOT NULL,
	[ServerName] [nvarchar](128) NULL,
	[DiskDrive] [char](1) NULL,
	[Label] [varchar](20) NULL,
	[FreeDiskSpaceMB] [numeric](18, 0) NULL,
	[UsedDiskSpaceMB] [numeric](18, 0) NULL,
	[TotalDiskSpaceMB] [numeric](18, 0) NULL,
	[PercentageFree] [numeric](4, 2) NULL
) ON [HPS]
GO
/****** Object:  View [dbo].[vw_DiskSpace]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[vw_DiskSpace]
AS
SELECT TOP (100) PERCENT 
	   S1.Date_Key, 
	   S1.ServerName,
	   S1.FDQNServerName, 
	   S1.DiskDrive, 
	   S1.FreeDiskSpaceMB, 
	   S1.UsedDiskSpaceMB, 
	   S1.TotalDiskSpaceMB, 
	   S1.PercentageFree
FROM
(
SELECT TOP (100) PERCENT 
	   Date_Key, 
	   ServerName, 
	   CASE WHEN DBSAClustered = 1 and DBSAInstallationType <> 'default' THEN DBSAServerClusterdVirtualName + '.' + [DBSADomain] + '\' + DBSAInstallationType
                  WHEN DBSAServerName like '%\%' THEN DBSAServerClusterdVirtualName + '.' + [DBSADomain] + '\' + DBSAInstallationType 
                  ELSE [DBSAServerName] + '.' +[DBSADomain] END AS FDQNServerName,
       CONVERT(char(1),DiskDrive) + ':\' as DiskDrive, 
	   FreeDiskSpaceMB, 
	   UsedDiskSpaceMB, 
	   TotalDiskSpaceMB, 
	   PercentageFree
FROM   DBA.AdminServer.Disk_Space_Repository INNER JOIN AdminControl.DBServersAll ON
DBA.AdminServer.Disk_Space_Repository.ServerName = AdminControl.DBServersAll.DBSAServerName
WHERE AdminControl.DBServersAll.DBSAManaged = 1 AND (Date_Key =
       (SELECT MAX(Date_Key) AS Date_Key
        FROM   AdminServer.Disk_Space_Repository)) AND
        ServerName NOT IN (SELECT ServerName FROM [ENSONODBA].[AdminServer].[HPS_Export_MountPoints_Current])) AS S1
UNION
SELECT TOP 100 PERCENT 
	   [Date_Key]
      ,[ServerName]
	  ,CASE WHEN DBSAClustered = 1 and DBSAInstallationType <> 'default' THEN DBSAServerClusterdVirtualName + '.' + [DBSADomain] + '\' + DBSAInstallationType
                  WHEN DBSAServerName like '%\%' THEN DBSAServerClusterdVirtualName + '.' + [DBSADomain] + '\' + DBSAInstallationType 
                  ELSE [DBSAServerName] + '.' +[DBSADomain] END AS FDQNServerName
      ,[MountPoint] AS DiskDrive
      ,[FreeDiskSpaceMB]
      ,[UsedDiskSpaceMB]
      ,[TotalDiskSpaceMB]
      ,[PercentageFree]
FROM [ENSONODBA].[AdminServer].[HPS_Export_MountPoints_Current] INNER JOIN AdminControl.DBServersAll ON
[ENSONODBA].[AdminServer].[HPS_Export_MountPoints_Current].ServerName = AdminControl.DBServersAll.DBSAServerName
WHERE  (Date_Key = 
	   (SELECT MAX(Date_Key) AS Date_Key
        FROM   [ENSONODBA].[AdminServer].[Disk_Space_Repository_MountPoints] AS Disk_Space_Repository_MountPoints_1))
ORDER BY ServerName, DiskDrive



GO
/****** Object:  View [dbo].[vw_DatabaseInformation]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[vw_DatabaseInformation]
AS
SELECT	TOP 100 PERCENT Date_Key, 
		ServerName, 
		CASE WHEN DBSAClustered = 1 and DBSAInstallationType <> 'default' THEN DBSAServerClusterdVirtualName + '.' + [DBSADomain] + '\' + DBSAInstallationType
                  WHEN DBSAServerName like '%\%' THEN DBSAServerClusterdVirtualName + '.' + [DBSADomain] + '\' + DBSAInstallationType 
                  ELSE [DBSAServerName] + '.' +[DBSADomain] END AS FDQNServerName,
		DatabaseName, 
		FileSizeMB, 
		LogicalFileName, 
		PhysicalFileName, 
		Status, 
		Updateability, 
		RecoveryMode, 
		FreeSpaceMB, 
		FreeSpacePct, 
		PollDate
FROM	AdminServer.Database_Information INNER JOIN AdminControl.DBServersAll ON
AdminServer.Database_Information.ServerName = AdminControl.DBServersAll.DBSAServerName
WHERE AdminControl.DBServersAll.DBSAManaged = 1 AND (Date_Key =
                          (SELECT     MAX(Date_Key) AS Date_Key
                            FROM          AdminServer.Database_Information AS Admin_Server_Database_Information_1))
ORDER BY ServerName, DatabaseName, PhysicalFileName



GO
/****** Object:  UserDefinedFunction [eva].[fnPurgeRetention]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [eva].[fnPurgeRetention] ()
RETURNS TINYINT
WITH SCHEMABINDING
AS
	/***************************************************************************************************************************************
		
		Purpose: Define Retention Standard To Purge "DBA" and "MSDB" Backup/Restore/Job History Tables
		

		History:
		------------------------------------------------------------------------------------------------------------------------------------
		Author                                 Date Created                Comments
		------------------------------------------------------------------------------------------------------------------------------------
		Harsha vasa                              2018-10-05                  Initial draft



	    ------------------------------------------------------------------------------------------------------------------------------------

		Documentation: User Story #262
		--------------
		PROD : 60 (days)
		NON PROD : 35

		Labelid : 0 
	    Retention = 35 (EDP Backup Max Retention on the Disk)
		
		Lookup Table Data: [dbo].[PurgeConditions]

		Execution Samples:
		------------------
		#1 
		SELECT [eva].[fnPurgeRetention](1)

		#2 
		SELECT [eva].[fnPurgeRetention](0)

    ***************************************************************************************************************************************/

	BEGIN
		DECLARE @Retention TINYINT;

		IF (SELECT sd.is_prod FROM eva.ServerDetail AS sd) = 1
			SET @Retention = 60
		ELSE
			SET @Retention = 35

		RETURN @Retention;

	END;

GO
/****** Object:  View [AdminServer].[HPS_Export_DiskSpace_Current_New]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Export_DiskSpace_Current_New]
AS
SELECT TOP (100) PERCENT 
	   S1.Date_Key, 
	   S1.ServerName, 
	   S1.DiskDrive, 
	   S1.FreeDiskSpaceMB, 
	   S1.UsedDiskSpaceMB, 
	   S1.TotalDiskSpaceMB, 
	   S1.PercentageFree
FROM
(
SELECT TOP (100) PERCENT 
	   Date_Key, 
	   ServerName, 
	   CONVERT(char(1),DiskDrive) + ':\' as DiskDrive, 
	   FreeDiskSpaceMB, 
	   UsedDiskSpaceMB, 
	   TotalDiskSpaceMB, 
	   PercentageFree
FROM   DBA.AdminServer.Disk_Space_Repository INNER JOIN AdminControl.DBServersAll ON
DBA.AdminServer.Disk_Space_Repository.ServerName = AdminControl.DBServersAll.DBSAServerName
WHERE Admincontrol.DBServersAll.DBSAManaged = 1 AND (Date_Key =
       (SELECT MAX(Date_Key) AS Date_Key
        FROM   AdminServer.Disk_Space_Repository)) AND
        ServerName NOT IN (SELECT ServerName FROM [ENSONODBA].[AdminServer].[HPS_Export_MountPoints_Current])) AS S1
UNION
SELECT TOP 100 PERCENT 
	   [Date_Key]
      ,[ServerName]
      ,[MountPoint] AS DiskDrive
      ,[FreeDiskSpaceMB]
      ,[UsedDiskSpaceMB]
      ,[TotalDiskSpaceMB]
      ,[PercentageFree]
FROM [ENSONODBA].[AdminServer].[HPS_Export_MountPoints_Current]
WHERE  (Date_Key = 
	   (SELECT MAX(Date_Key) AS Date_Key
        FROM   [ENSONODBA].[AdminServer].[Disk_Space_Repository_MountPoints] AS Disk_Space_Repository_MountPoints_1))
ORDER BY ServerName, DiskDrive




GO
/****** Object:  View [AdminServer].[HPS_Admin_Disk_Space_Information_Daily]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Admin_Disk_Space_Information_Daily]
AS
SELECT     TOP (100) PERCENT 
	AdminServer.HPS_Export_DiskSpace_Current_New.Date_Key, 
	AdminControl.DBServersAll.DBSACustomerName AS CustomerName, 
	AdminServer.HPS_Export_DiskSpace_Current_New.ServerName, 
	AdminControl.DBServersAll.DBSAServerType AS SLA,
	AdminControl.DBServersAll.DBSAServerDBA_Primary AS PrimaryDBASupport, 
	AdminServer.HPS_Export_DiskSpace_Current_New.DiskDrive, 
	AdminServer.HPS_Export_DiskSpace_Current_New.UsedDiskSpaceMB, 
	AdminServer.HPS_Export_DiskSpace_Current_New.FreeDiskSpaceMB, 
	CONVERT(INTEGER,AdminServer.HPS_Export_DiskSpace_Current_New.TotalDiskSpaceMB*.15) AS Threshhold15percent,
	CONVERT(INTEGER,AdminServer.HPS_Export_DiskSpace_Current_New.TotalDiskSpaceMB*.05) AS Threshhold05percent,
	AdminServer.HPS_Export_DiskSpace_Current_New.TotalDiskSpaceMB, 
	AdminServer.HPS_Export_DiskSpace_Current_New.PercentageFree,
	CASE WHEN AdminServer.HPS_Export_DiskSpace_Current_New.FreeDiskSpaceMB < 
			  CONVERT(INTEGER,AdminServer.HPS_Export_DiskSpace_Current_New.TotalDiskSpaceMB*.05) THEN 
				'Free Disk Space Less than 5 Percent'
		 WHEN AdminServer.HPS_Export_DiskSpace_Current_New.FreeDiskSpaceMB < 
			  CONVERT(INTEGER,AdminServer.HPS_Export_DiskSpace_Current_New.TotalDiskSpaceMB*.10) THEN
			  	'Free Disk Space Less than 10 Percent'
		 WHEN AdminServer.HPS_Export_DiskSpace_Current_New.FreeDiskSpaceMB < 
			  CONVERT(INTEGER,AdminServer.HPS_Export_DiskSpace_Current_New.TotalDiskSpaceMB*.15) THEN
			  	'Free Disk Space Less than 15 Percent'
		 WHEN AdminServer.HPS_Export_DiskSpace_Current_New.FreeDiskSpaceMB < 
			  CONVERT(INTEGER,AdminServer.HPS_Export_DiskSpace_Current_New.TotalDiskSpaceMB*.20) THEN
			  	'Free Disk Space Less than 20 Percent'
		 ELSE 'Disk Space above Current threshholds' END AS DiskSpaceReview
FROM	AdminServer.HPS_Export_DiskSpace_Current_New INNER JOIN AdminControl.DBServersAll ON 
		AdminServer.HPS_Export_DiskSpace_Current_New.ServerName = AdminControl.DBServersAll.DBSAServerName
WHERE AdminControl.DBServersAll.DBSAManaged = 1 AND AdminControl.DBServersAll.DBSAInstanceSupported = 'Y'  
	  AND TotalDiskSpaceMB > 0 AND PercentageFree <> 0
--ORDER BY AdminServer.HPS_Export_DiskSpace_Current_New.ServerName, 
--		 AdminServer.HPS_Export_DiskSpace_Current_New.DiskDrive
UNION 
SELECT     TOP (100) PERCENT 
	AdminServer.HPS_Export_DiskSpace_Current_New.Date_Key, 
	AdminControl.DBServersAll.DBSACustomerName AS CustomerName, 
	AdminServer.HPS_Export_DiskSpace_Current_New.ServerName, 
	AdminControl.DBServersAll.DBSAServerType AS SLA,
	AdminControl.DBServersAll.DBSAServerDBA_Primary AS PrimaryDBASupport, 
	AdminServer.HPS_Export_DiskSpace_Current_New.DiskDrive, 
	AdminServer.HPS_Export_DiskSpace_Current_New.UsedDiskSpaceMB, 
	AdminServer.HPS_Export_DiskSpace_Current_New.FreeDiskSpaceMB, 
	CONVERT(INTEGER,AdminServer.HPS_Export_DiskSpace_Current_New.TotalDiskSpaceMB*.15) AS Threshhold15percent,
	CONVERT(INTEGER,AdminServer.HPS_Export_DiskSpace_Current_New.TotalDiskSpaceMB*.05) AS Threshhold05percent,
	AdminServer.HPS_Export_DiskSpace_Current_New.TotalDiskSpaceMB, 
	AdminServer.HPS_Export_DiskSpace_Current_New.PercentageFree,
	CASE WHEN AdminServer.HPS_Export_DiskSpace_Current_New.FreeDiskSpaceMB < 
			  CONVERT(INTEGER,AdminServer.HPS_Export_DiskSpace_Current_New.TotalDiskSpaceMB*.05) THEN 
				'Free Disk Space Less than 5 Percent'
		 WHEN AdminServer.HPS_Export_DiskSpace_Current_New.FreeDiskSpaceMB < 
			  CONVERT(INTEGER,AdminServer.HPS_Export_DiskSpace_Current_New.TotalDiskSpaceMB*.10) THEN
			  	'Free Disk Space Less than 10 Percent'
		 WHEN AdminServer.HPS_Export_DiskSpace_Current_New.FreeDiskSpaceMB < 
			  CONVERT(INTEGER,AdminServer.HPS_Export_DiskSpace_Current_New.TotalDiskSpaceMB*.15) THEN
			  	'Free Disk Space Less than 15 Percent'
		 WHEN AdminServer.HPS_Export_DiskSpace_Current_New.FreeDiskSpaceMB < 
			  CONVERT(INTEGER,AdminServer.HPS_Export_DiskSpace_Current_New.TotalDiskSpaceMB*.20) THEN
			  	'Free Disk Space Less than 20 Percent'
		 ELSE 'Disk Space above Current threshholds' END AS DiskSpaceReview
FROM	AdminServer.HPS_Export_DiskSpace_Current_New INNER JOIN AdminControl.DBServersAll ON 
		AdminServer.HPS_Export_DiskSpace_Current_New.ServerName = AdminControl.DBServersAll.DBSAServerName
WHERE AdminControl.DBServersAll.DBSAManaged = 1 AND AdminControl.DBServersAll.DBSAInstanceSupported = 'Y'  
	  AND TotalDiskSpaceMB > 0 AND (AdminServer.HPS_Export_DiskSpace_Current_New.DiskDrive <> 'I:\'  AND PercentageFree = 0)
ORDER BY AdminServer.HPS_Export_DiskSpace_Current_New.ServerName, 
		 AdminServer.HPS_Export_DiskSpace_Current_New.DiskDrive


GO
/****** Object:  Table [eva].[Categories]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [eva].[Categories](
	[id] [smallint] IDENTITY(1,1) NOT NULL,
	[name] [varchar](128) NOT NULL,
	[parent_category_id] [smallint] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [eva].[PolicyAttributes]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [eva].[PolicyAttributes](
	[policy_id] [smallint] NOT NULL,
	[key_name] [varchar](256) NOT NULL,
	[value] [varchar](256) NULL,
	[category_id] [smallint] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [eva].[zDbaJobsFeed]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [eva].[zDbaJobsFeed](
	[job_name] [varchar](128) NOT NULL,
	[job_type] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[job_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [eva].[vGetAllDBAJobsPolicyDetails]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [eva].[vGetAllDBAJobsPolicyDetails]
AS

	WITH c1
	AS (
		  SELECT
			  ec.id
			 ,ec.[name]
			 ,ec.parent_category_id
		  FROM eva.Categories AS ec
		  WHERE ec.id = 3
		  UNION ALL
		  SELECT
			  ec.id
			 ,ec.[name]
			 ,ec.parent_category_id
		  FROM eva.Categories AS ec
		  INNER JOIN c1 ON ec.parent_category_id = c1.id
	)
	SELECT
		edjf.job_name
	   ,edjf.[job_type]
	   ,CAST( t1.job_category AS VARCHAR(256) )											AS job_category
	   ,CAST( t1.job_owner AS VARCHAR(256) )											AS job_owner
	   ,CAST( REPLACE( t1.job_output_path,'{JobName}',edjf.job_name ) AS VARCHAR(256) ) AS job_output_path
	FROM eva.zDbaJobsFeed AS edjf
	INNER JOIN c1 ON [name] = edjf.[job_type]
	INNER JOIN (
		  SELECT
			  p.category_id
			 ,p.job_category
			 ,p.job_owner
			 ,p.job_output_path
		  FROM (
				SELECT
					epa.category_id
				   ,epa.[key_name]
				   ,epa.[value]
				FROM eva.PolicyAttributes AS epa
				WHERE epa.policy_id = 2
		  ) AS t
		  PIVOT (
		  MAX( t.[value] )
		  FOR t.[key_name] IN ([job_category],[job_owner],[job_output_path])
		  ) p
	) AS t1 ON parent_category_id = t1.category_id
--CROSS APPLY (
--	  SELECT
--		  CASE
--			  WHEN (
--					SELECT
--						is_prod
--					FROM eva.ServerDetail
--			  ) = 1 AND edjf.[job_type] = 'vip_jobs' THEN REPLACE( REPLACE( job_prefix,'{','' ),'}','' )
--			  ELSE REPLACE( job_prefix,'{VIP}','' )
--		  END AS job_prefix
--) pref
;

GO
/****** Object:  View [AdminServer].[HPS_Admin_Disk_Space_LowDisk_Daily_40]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Admin_Disk_Space_LowDisk_Daily_40]
AS
SELECT [Date_Key]
      ,[CustomerName]
      ,[ServerName]
	  ,[SLA]
      ,[PrimaryDBASupport]
      ,[DiskDrive]
      ,[UsedDiskSpaceMB]
      ,[FreeDiskSpaceMB]
      ,[Threshhold15percent]
      ,[Threshhold05percent]
      ,[TotalDiskSpaceMB]
      ,[PercentageFree]
		,CASE WHEN CONVERT(INTEGER,PercentageFree) <  5 THEN 'Free Disk Space Less than 5 Percent'
			 WHEN CONVERT(INTEGER,PercentageFree) < 15 THEN 'Free Disk Space Less than 15 Percent'
			 WHEN CONVERT(INTEGER,PercentageFree) < 20 THEN 'Free Disk Space Less than 20 Percent'
			 WHEN CONVERT(INTEGER,PercentageFree) < 40 THEN 'Free Disk Space Less than 35 Percent'
		 ELSE 'Disk Space above Current threshholds' END AS DiskSpaceReview
  FROM [AdminServer].[HPS_Admin_Disk_Space_Information_Daily]
  WHERE DiskDrive NOT IN ('C:\','D:\') 
		AND PercentageFree < 35.0
		--AND [ServerName] IN (
		--'FWPAXD-SQLPV005\SQL001',
		--'FWPAXD-SQLPV006\SQL002',
		--'FWPAXD-SQLPV007\SQL001',
		--'FWPAXD-SQLPV007\SQL001',
		--'FWPAXE-SQLPV002\SQL002',
		--'FWSAXD-SQLPV001\SQL001',
		--'FWSAXD-SQLPV002\SQL002',
		--'FWTAXD-SQLT001\SQL001',
		--'FWTAXD-SQLT001\SQL002',
		--'FWTAXD-SQLT001\SQL003',
		--'FWTAXE-SQLVM001'
		--)

GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_Totals_Non-Production_DG]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [AdminServer].[HPS_Inventory_Server_Totals_Non-Production_DG]
AS
SELECT Top 100 PERCENT 
	   T.[customer]
      ,T.[server]
      ,T.[SLA]
      ,T.[DatabaseCount]
      ,T.[Server_Total_MB]
      ,T.[ProductName]
      ,T.[ProductLevel]
      ,T.[ProductVersion]
  FROM [ENSONODBA].[AdminServer].[HPS_Inventory_Server_Totals_All] AS T Inner join AdminControl.DBServersAll AS M ON
T.server = M.DBSAServerName
WHERE M.DBSAServerType IN ('D', 'S', 'T') AND M.DBSASpotlightDayTimeMonitoring = 'DG'
ORDER By T.server 








GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_Totals_Non-Production_EGV]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO







CREATE VIEW [AdminServer].[HPS_Inventory_Server_Totals_Non-Production_EGV]
AS
SELECT Top 100 PERCENT 
	   T.[customer]
      ,T.[server]
      ,T.[SLA]
      ,T.[DatabaseCount]
      ,T.[Server_Total_MB]
      ,T.[ProductName]
      ,T.[ProductLevel]
      ,T.[ProductVersion]
  FROM [ENSONODBA].[AdminServer].[HPS_Inventory_Server_Totals_All] AS T Inner join AdminControl.DBServersAll AS M ON
T.server = M.DBSAServerName
WHERE M.DBSAServerType IN ('D', 'S', 'T') AND M.DBSASpotlightDayTimeMonitoring = 'EGV'
ORDER By T.server 









GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_Totals_Production_DG]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO







CREATE VIEW [AdminServer].[HPS_Inventory_Server_Totals_Production_DG]
AS
SELECT Top 100 PERCENT 
	   T.[customer]
      ,T.[server]
      ,T.[SLA]
      ,T.[DatabaseCount]
      ,T.[Server_Total_MB]
      ,T.[ProductName]
      ,T.[ProductLevel]
      ,T.[ProductVersion]
  FROM [ENSONODBA].[AdminServer].[HPS_Inventory_Server_Totals_All] AS T Inner join AdminControl.DBServersAll AS M ON
T.server = M.DBSAServerName
WHERE M.DBSAServerType = 'P' AND M.DBSASpotlightDayTimeMonitoring = 'DG'
ORDER By T.server 









GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_Totals_Production_EGV]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO








CREATE VIEW [AdminServer].[HPS_Inventory_Server_Totals_Production_EGV]
AS
SELECT Top 100 PERCENT 
	   T.[customer]
      ,T.[server]
      ,T.[SLA]
      ,T.[DatabaseCount]
      ,T.[Server_Total_MB]
      ,T.[ProductName]
      ,T.[ProductLevel]
      ,T.[ProductVersion]
  FROM [ENSONODBA].[AdminServer].[HPS_Inventory_Server_Totals_All] AS T Inner join AdminControl.DBServersAll AS M ON
T.server = M.DBSAServerName
WHERE M.DBSAServerType = 'P' AND M.DBSASpotlightDayTimeMonitoring = 'EGV'
ORDER By T.server 










GO
/****** Object:  View [AdminServer].[HPS_Admin_Disk_Space_LowDisk_Daily]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Admin_Disk_Space_LowDisk_Daily]
AS
SELECT [Date_Key]
      ,[CustomerName]
      ,[ServerName]
	  ,[SLA]
      ,[PrimaryDBASupport]
      ,[DiskDrive]
      ,[UsedDiskSpaceMB]
      ,[FreeDiskSpaceMB]
      ,[Threshhold15percent]
      ,[Threshhold05percent]
      ,[TotalDiskSpaceMB]
      ,[PercentageFree]
      ,[DiskSpaceReview]
  FROM [AdminServer].[HPS_Admin_Disk_Space_Information_Daily]
  WHERE DiskDrive NOT IN ('C:\','D:\') AND PercentageFree < 20.0 

GO
/****** Object:  View [AdminServer].[HPS_Export_MountPoints_Current]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Export_MountPoints_Current]
AS
SELECT     TOP (100) PERCENT 
	   [Date_Key]
      ,[ServerName]
      ,[MountPoint]
      ,[TotalDiskSpaceMB]
      ,[FreeDiskSpaceMB]
      ,[UsedDiskSpaceMB]
      ,[PercentageFree]
FROM [DBA].[AdminServer].[Disk_Space_Repository_MountPoints] INNER JOIN AdminControl.DBServersAll ON
[DBA].[AdminServer].[Disk_Space_Repository_MountPoints].ServerName = AdminControl.DBServersAll.DBSAServerName
WHERE Admincontrol.DBServersAll.DBSAManaged = 1 AND (Date_Key = (SELECT MAX(Date_Key) AS Date_Key
                    FROM   [DBA].[AdminServer].[Disk_Space_Repository_MountPoints] AS Disk_Space_Repository_MountPoints_1))
ORDER BY ServerName, MountPoint




GO
/****** Object:  View [AdminServer].[HPS_Admin_Database_IO_Information_All_Current]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





CREATE VIEW [AdminServer].[HPS_Admin_Database_IO_Information_All_Current]
AS
SELECT     
	D.Date_Key, 
	D.Server_Name, 
	D.Database_Name, 
	M.DBSAServerDBA_Primary AS PrimaryDBA_Support, 
	M.DBSAServerDBA_Secondary AS SecondaryDBA_Support, 
	D.ProcessorCount, 
	CASE WHEN UPPER(LEFT(D.Physical_File_Name,13)) = 'O:\SQLDATA01\' THEN 'O:\SQLDATA01\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,13)) = 'O:\SQLDATA02\' THEN 'O:\SQLDATA02\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,13)) = 'O:\SQLDATA03\' THEN 'O:\SQLDATA03\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,13)) = 'O:\SQLDATA04\' THEN 'O:\SQLDATA04\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,13)) = 'O:\SQLDATA05\' THEN 'O:\SQLDATA05\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,13)) = 'O:\SQLDATA06\' THEN 'O:\SQLDATA06\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'O:\SQLDATA1\' THEN 'O:\SQLDATA1\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'O:\SQLDATA2\' THEN 'O:\SQLDATA2\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'O:\SQLDATA3\' THEN 'O:\SQLDATA3\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'O:\SQLDATA4\' THEN 'O:\SQLDATA4\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'O:\SQLDATA5\' THEN 'O:\SQLDATA5\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'O:\SQLDATA6\' THEN 'O:\SQLDATA6\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'O:\SQLDATA7\' THEN 'O:\SQLDATA7\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,11)) = 'O:\SQLDATA\' THEN 'O:\SQLDATA\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,11)) = 'O:\SQLLOGS\' THEN 'O:\SQLLOGS\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'O:\SQLLOGS1\' THEN 'O:\SQLLOGS1\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'O:\SQLLOGS2\' THEN 'O:\SQLLOGS2\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,13)) = 'O:\SQLTEMPDB\' THEN 'O:\SQLTEMPDB\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,15)) = 'O:\SQLSYSTEMDB\' THEN 'O:\SQLSYSTEMDB\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'P:\SQLDATA1\' THEN 'P:\SQLDATA1\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'P:\SQLDATA2\' THEN 'P:\SQLDATA2\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'P:\SQLDATA3\' THEN 'P:\SQLDATA3\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'P:\SQLDATA4\' THEN 'P:\SQLDATA4\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'P:\SQLDATA5\' THEN 'P:\SQLDATA5\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'P:\SQLDATA6\' THEN 'P:\SQLDATA6\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,11)) = 'P:\SQLDATA\' THEN 'P:\SQLDATA\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'P:\SQLLOGS1\' THEN 'P:\SQLLOGS1\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'P:\SQLLOGS2\' THEN 'P:\SQLLOGS2\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,11)) = 'P:\SQLLOGS\' THEN 'P:\SQLLOGS\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,13)) = 'P:\SQLTEMPDB\' THEN 'P:\SQLTEMPDB\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,15)) = 'P:\SQLSYSTEMDB\' THEN 'P:\SQLSYSTEMDB\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'N:\SQLDATA1\' THEN 'N:\SQLDATA1\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'N:\SQLDATA2\' THEN 'N:\SQLDATA2\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'N:\SQLDATA3\' THEN 'N:\SQLDATA3\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'N:\SQLDATA4\' THEN 'N:\SQLDATA4\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'N:\SQLDATA5\' THEN 'N:\SQLDATA5\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,11)) = 'N:\SQLDATA\' THEN 'N:\SQLDATA\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,11)) = 'N:\SQLLOGS\' THEN 'N:\SQLLOGS\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'N:\SQLLOGS1\' THEN 'N:\SQLLOGS1\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'N:\SQLLOGS2\' THEN 'N:\SQLLOGS2\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,13)) = 'N:\SQLTEMPDB\' THEN 'N:\SQLTEMPDB\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,15)) = 'N:\SQLSYSTEMDB\' THEN 'N:\SQLSYSTEMDB\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,9)) = 'O:\DATA1\' THEN 'O:\DATA1\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,9)) = 'O:\DATA2\' THEN 'O:\DATA2\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,9)) = 'O:\DATA3\' THEN 'O:\DATA3\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,9)) = 'O:\DATA4\' THEN 'O:\DATA4\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,9)) = 'O:\DATA5\' THEN 'O:\DATA5\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,9)) = 'O:\DATA6\' THEN 'O:\DATA6\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,9)) = 'O:\DATA7\' THEN 'O:\DATA7\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,10)) = 'O:\TLOGS1\' THEN 'O:\TLOGS1\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,10)) = 'O:\TLOGS2\' THEN 'O:\TLOGS2\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,10)) = 'O:\TEMPDB\' THEN 'O:\TEMPDB\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'O:\SYSTEMDB\' THEN 'O:\SYSTEMDB\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,9)) = 'P:\DATA1\' THEN 'P:\DATA1\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,9)) = 'P:\DATA2\' THEN 'P:\DATA2\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,9)) = 'P:\DATA3\' THEN 'P:\DATA3\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,9)) = 'P:\DATA4\' THEN 'P:\DATA4\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,9)) = 'P:\DATA5\' THEN 'P:\DATA5\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,9)) = 'P:\DATA6\' THEN 'P:\DATA6\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,9)) = 'P:\DATA7\' THEN 'P:\DATA7\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,10)) = 'P:\TLOGS1\' THEN 'P:\TLOGS1\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,10)) = 'P:\TLOGS2\' THEN 'P:\TLOGS2\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,10)) = 'P:\TEMPDB\' THEN 'P:\TEMPDB\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'P:\SYSTEMDB\' THEN 'P:\SYSTEMDB\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,13)) = 'P:\V2_TEMPDB\' THEN 'P:\V2_TEMPDB\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,15)) = 'P:\V2_SYSTEMDB\' THEN 'P:\V2_SYSTEMDB\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,16)) = 'P:\V2_SQLDATA01\' THEN 'P:\V2_SQLDATA01\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,16)) = 'P:\V2_SQLDATA02\' THEN 'P:\V2_SQLDATA02\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,16)) = 'P:\V2_SQLDATA03\' THEN 'P:\V2_SQLDATA03\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,13)) = 'S:\SQLTEMPDB\' THEN 'S:\SQLTEMPDB\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,15)) = 'S:\SQLSYSTEMDB\' THEN 'S:\SQLSYSTEMDB\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'S:\SQLDATA1\' THEN 'S:\SQLDATA1\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'S:\SQLDATA2\' THEN 'S:\SQLDATA2\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'S:\SQLDATA3\' THEN 'S:\SQLDATA3\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'S:\SQLDATA4\' THEN 'S:\SQLDATA4\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,12)) = 'S:\SQLDATA5\' THEN 'S:\SQLDATA5\'
	     WHEN UPPER(LEFT(D.Physical_File_Name,11)) = 'S:\SQLLOGS\' THEN 'S:\SQLLOGS\'	
	ELSE UPPER(LEFT(D.Physical_File_Name,2)) END AS Disk_Drive, 
	D.Physical_File_Name, 
	D.File_Type, 
	D.AverageIOStallsperMS, 
	D.FileSize, 
	D.GrowthType, 
	D.Growth, 
	D.File_Read_Percentage, 
	D.File_Write_Percentage, 
	D.Maximum_File_Size, 
	D.Space_RemainingMB, 
	D.Number_Of_Reads, 
	D.Number_Bytes_Read, 
	D.IOStall_Reads_MS, 
	D.Number_Of_Writes, 
	D.Number_Bytes_Written, 
	D.IOStall_Writes_MB, 
	D.Total_IOStall_Reads_Writes
FROM         AdminServer.Database_IO_Information AS D INNER JOIN
                      AdminControl.DBServersAll AS M ON D.Server_Name = M.DBSAServerName
WHERE     (D.Date_Key =
                          (SELECT     MAX(Date_Key) AS Expr1
                            FROM          AdminServer.Database_IO_Information))






GO
/****** Object:  View [AdminServer].[HPS_Admin_Database_IO_Information_Exceptions]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [AdminServer].[HPS_Admin_Database_IO_Information_Exceptions]
AS
SELECT     DBSAServerName
FROM         AdminControl.DBServersAll
WHERE     (DBSAServerType <> 'B') AND (DBSAInstanceSupported = 'Y') AND (DBSAServerName NOT IN
                          (SELECT     Server_Name
                            FROM          AdminServer.HPS_Admin_Database_IO_Information_All_Current))




GO
/****** Object:  View [AdminServer].[HPS_Admin_SQLServerProperties_Current]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Admin_SQLServerProperties_Current]
AS
SELECT TOP 100 PERCENT
	R.Date_Key, 
	M.DBSACustomerName AS CustomerName,
	R.ServerName, 
	R.ComputerName, 
	R.MachineName, 
	R.Edition, 
	R.ProductLevel, 
	R.ProductVersion, 
	R.Collation, 
	R.IsClusterd, 
	R.IsFullTextInstalled, 
    R.IsIntegratedSecurityOn, 
    R.LicenseType, 
    R.NumLicenses, 
    R.ResourceLastUpdateDateTime, 
    R.ResourceVersion, 
    R.SqlCharSetName, 
    R.SqlSortOrderName, 
    R.FileStreamShareName, 
    R.FileStreamConfigureLevel, 
    R.FileStreamEffectiveLevel
FROM AdminServer.SQLServerProperties_Repository AS R INNER JOIN AdminControl.DBServersAll AS M ON
	R.ServerName = M.DBSAServerName INNER JOIN
	(SELECT ServerName, MAX(Date_Key) AS Date_Key
                   FROM   AdminServer.SQLServerProperties_Repository
                   GROUP BY ServerName) AS S1 ON
                   R.ServerName = S1.ServerName AND
                   R.Date_Key = S1.Date_Key
WHERE M.DBSAManaged = 1 
ORDER BY M.DBSACustomerName, R.ServerName




GO
/****** Object:  Table [AdminServer].[SQLServerVersion_Repository]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[SQLServerVersion_Repository](
	[SQLServerRepository_Key] [int] IDENTITY(1,1) NOT NULL,
	[Date_Key] [datetime] NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[ProductName] [nvarchar](128) NULL,
	[ProductVersion] [nvarchar](128) NULL,
	[Language] [nvarchar](128) NULL,
	[Platform] [nvarchar](128) NULL,
	[SQLVersion] [nvarchar](128) NULL,
	[FileVersion] [nvarchar](128) NULL,
	[WindowsVersion] [nvarchar](128) NULL,
	[ProcessorCount] [nvarchar](128) NULL,
	[ProcessorAffinity] [nvarchar](128) NULL,
	[ProcessorType] [nvarchar](128) NULL,
	[PhysicalMemory] [nvarchar](128) NULL
) ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Admin_SQLServerVersion_Current]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Admin_SQLServerVersion_Current]
AS
SELECT     
	R.SQLServerRepository_Key, 
	R.Date_Key, 
	R.ServerName, 
	R.ProductName, 
	R.ProductVersion, 
	R.Language, 
	R.Platform, 
	R.SQLVersion, 
	R.FileVersion, 
	R.WindowsVersion, 
	CASE 
		WHEN R.[WindowsVersion] LIKE '6.3%' THEN 'Windows Server 2012 R2'
		WHEN R.[WindowsVersion] LIKE '6.2%' THEN 'Windows Server 2012'
		WHEN R.[WindowsVersion] LIKE '6.1%' THEN 'Windows Server 2008 R2'
		WHEN R.[WindowsVersion] LIKE '6.0%' THEN 'Windows Server 2008'
		WHEN R.[WindowsVersion] LIKE '5.2%' THEN 'Windows Server 2003'
		WHEN R.[WindowsVersion] LIKE '5.0%' THEN 'Windows Server 2000'
		ELSE 'Undefined' END AS [WindowsVersionDescription],
	R.ProcessorCount, 
	R.ProcessorAffinity, 
	R.ProcessorType, 
	R.PhysicalMemory
FROM AdminServer.SQLServerVersion_Repository AS R INNER JOIN AdminControl.DBServersAll AS M ON
R.ServerName = M.DBSAServerName 
INNER JOIN (
SELECT ServerName,MAX(Date_Key) AS Date_Key
FROM   AdminServer.SQLServerVersion_Repository AS SQLServerVersion_Repository_1
GROUP By ServerName) AS S1 ON
R.ServerName = S1.ServerName AND
R.Date_Key = S1.Date_Key
WHERE M.DBSAManaged = 1





GO
/****** Object:  View [AdminServer].[HPS_Admin_Disk_Space_Information_Bowne]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Admin_Disk_Space_Information_Bowne]
AS
SELECT D.[Date_Key]
      ,D.[CustomerName]
      ,D.[ServerName]
	  ,D.[SLA]
      ,D.[PrimaryDBASupport]
      ,D.[DiskDrive]
      ,D.[UsedDiskSpaceMB]
      ,D.[FreeDiskSpaceMB]
      ,D.[Threshhold15percent]
      ,D.[Threshhold05percent]
      ,D.[TotalDiskSpaceMB]
      ,D.[PercentageFree]
      ,D.[DiskSpaceReview]
  FROM [ENSONODBA].[AdminServer].[HPS_Admin_Disk_Space_Information_Daily] AS D INNER JOIN [ENSONODBA].AdminServer.HPS_Admin_Server_Information_Bowne AS S ON
d.ServerName = S.ServerName

GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_Totals_Bowne]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [AdminServer].[HPS_Inventory_Server_Totals_Bowne]
AS
SELECT DISTINCT Top 100 percent T.[customer]
      ,T.[server]
      ,T.[SLA]
      ,T.[DatabaseCount]
      ,T.[Server_Total_MB]
      ,T.[ProductName]
      ,T.[ProductLevel]
      ,T.[ProductVersion]
  FROM [ENSONODBA].[AdminServer].[HPS_Inventory_Server_Totals_All] AS T Inner join AdminServer.HPS_Admin_Disk_Space_Information_Bowne AS B ON
T.server = B.ServerName
ORDER By T.server 






GO
/****** Object:  View [AdminServer].[HPS_Export_SQLServerProperties_Current]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Export_SQLServerProperties_Current]
AS
SELECT TOP 100 PERCENT
	R.Date_Key, 
	M.DBSACustomerName AS CustomerName,
	R.ServerName, 
	R.ComputerName, 
	R.MachineName, 
	R.Edition, 
	R.ProductLevel, 
	R.ProductVersion, 
	V.[Life_Cycle_Start_Date],
	V.[Mainstream_Support_End_Date],
	V.[Extended_Support_End_Date],
	V.[Service_Pack_Support_End_Date],
	V.[Service_Pack_Support_Comments],
	R.Collation, 
	R.IsClusterd, 
	R.IsFullTextInstalled, 
    R.IsIntegratedSecurityOn, 
    R.LicenseType, 
    R.NumLicenses, 
    R.ResourceLastUpdateDateTime, 
    R.ResourceVersion, 
    R.SqlCharSetName, 
    R.SqlSortOrderName, 
    R.FileStreamShareName, 
    R.FileStreamConfigureLevel, 
    R.FileStreamEffectiveLevel
FROM AdminServer.SQLServerProperties_Repository AS R INNER JOIN Admincontrol.DBServersAll AS M ON
	R.ServerName = M.DBSAServerName INNER JOIN
	(SELECT ServerName, MAX(Date_Key) AS Date_Key
                   FROM   AdminServer.SQLServerProperties_Repository
                   GROUP BY ServerName) AS S1 ON
                   R.ServerName = S1.ServerName AND
                   R.Date_Key = S1.Date_Key LEFT OUTER JOIN [AdminControl].[SQLVersionInformation] AS V ON 
				   R.ProductVersion = V.Build_Key
WHERE M.DBSAManaged = 1 
ORDER BY M.DBSACustomerName, R.ServerName





GO
/****** Object:  View [AdminServer].[HPS_Admin_Disk_Space_Information_EOL]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Admin_Disk_Space_Information_EOL]
AS
SELECT D.[Date_Key]
      ,D.[CustomerName]
      ,D.[ServerName]
	  ,D.[SLA]
      ,D.[PrimaryDBASupport]
      ,D.[DiskDrive]
      ,D.[UsedDiskSpaceMB]
      ,D.[FreeDiskSpaceMB]
      ,D.[Threshhold15percent]
      ,D.[Threshhold05percent]
      ,D.[TotalDiskSpaceMB]
      ,D.[PercentageFree]
      ,D.[DiskSpaceReview]
  FROM [ENSONODBA].[AdminServer].[HPS_Admin_Disk_Space_Information_Daily] AS D INNER JOIN [ENSONODBA].AdminServer.HPS_Admin_Server_Information_EOL AS S ON
d.ServerName = S.ServerName

GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_Totals_EOL]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





CREATE VIEW [AdminServer].[HPS_Inventory_Server_Totals_EOL]
AS
SELECT DISTINCT Top 100 percent T.[customer]
      ,T.[server]
      ,T.[SLA]
      ,T.[DatabaseCount]
      ,T.[Server_Total_MB]
      ,T.[ProductName]
      ,T.[ProductLevel]
      ,T.[ProductVersion]
  FROM [ENSONODBA].[AdminServer].[HPS_Inventory_Server_Totals_All] AS T Inner join AdminServer.HPS_Admin_Disk_Space_Information_EOL AS B ON
T.server = B.ServerName
ORDER By T.server 







GO
/****** Object:  View [AdminServer].[HPS_Export_SQLServerVersion_Current]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Export_SQLServerVersion_Current]
AS
SELECT     
	R.SQLServerRepository_Key, 
	R.Date_Key, 
	R.ServerName, 
	R.ProductName, 
	R.ProductVersion, 
	R.Language, 
	R.Platform, 
	R.SQLVersion, 
	R.FileVersion, 
	R.WindowsVersion, 
    CASE 
			WHEN R.[WindowsVersion] LIKE '6.3%' THEN 'Windows Server 2012 R2'
			WHEN R.[WindowsVersion] LIKE '6.2%' THEN 'Windows Server 2012'
			WHEN R.[WindowsVersion] LIKE '6.1%' THEN 'Windows Server 2008 R2'
			WHEN R.[WindowsVersion] LIKE '6.0%' THEN 'Windows Server 2008'
			WHEN R.[WindowsVersion] LIKE '5.2%' THEN 'Windows Server 2003'
			WHEN R.[WindowsVersion] LIKE '5.0%' THEN 'Windows Server 2000'
			ELSE 'Undefined' END AS [WindowsVersionDescription],
	R.ProcessorCount, 
	R.ProcessorAffinity, 
	R.ProcessorType, 
	R.PhysicalMemory
FROM AdminServer.SQLServerVersion_Repository AS R INNER JOIN AdminControl.DBServersAll AS M ON
R.ServerName = M.DBSAServerName 
INNER JOIN (
SELECT ServerName,MAX(Date_Key) AS Date_Key
FROM   AdminServer.SQLServerVersion_Repository AS SQLServerVersion_Repository_1
GROUP By ServerName) AS S1 ON
R.ServerName = S1.ServerName AND
R.Date_Key = S1.Date_Key
WHERE M.DBSAManaged = 1





GO
/****** Object:  Table [AdminControl].[Database_Control_Information]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminControl].[Database_Control_Information](
	[CustomerName] [nvarchar](128) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[DatabaseName] [nvarchar](128) NOT NULL,
	[CreateDate] [nvarchar](20) NULL,
	[UpdateDate] [datetime] NULL,
	[Application] [nvarchar](255) NULL,
	[Owners] [nvarchar](255) NULL,
	[Functional Group] [nvarchar](255) NULL,
	[ARC] [nvarchar](10) NULL
) ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Admin_Database_OFFLINE_Exceptions]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [AdminServer].[HPS_Admin_Database_OFFLINE_Exceptions]
AS
SELECT TOP 100 percent [Date_Key]
      ,[ServerName]
      ,[name]
      ,[create_date]
      ,[compatibility_level]
      ,[state_desc]
      ,[DBSAServerDBA_Primary] AS DBA_Primary
  FROM [DBA].[AdminServer].[SQLServerDatabaseProperties_Repository] INNER JOIN [DBA].[AdminControl].[DBServersAll] ON
  [DBA].[AdminServer].[SQLServerDatabaseProperties_Repository].[ServerName] = [DBA].[AdminControl].[DBServersAll].[DBSAServerName]
WHERE [Date_Key] = (SELECT MAX(Date_Key) AS Date_Key FROM [DBA].[AdminServer].[SQLServerDatabaseProperties_Repository])
	AND [state_desc] <> 'ONLINE'
ORDER BY [ServerName], [name]
  
  



GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_CustomerDataBases_All]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [AdminServer].[HPS_Inventory_Server_CustomerDataBases_All]
AS
	SELECT TOP (100) PERCENT
		D.Date_Key		 AS Date_Key
	   ,D.customer		 AS customer
	   ,D.[server]		 AS Server
	   ,CASE
			WHEN D.[server] = 'ACWIN-SQLT01\SQL002' THEN 'BS'
			WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
			WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE'
			WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
			WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE'
			WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE'
			WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE'
			WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS'
			WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC'
			WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS'
			WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC'
			ELSE 'Undefined'
		END				 AS sla
	   ,D.db			 AS db
	   ,D.crdate		 AS crdate
	   ,D.dbsize		 AS dbsize
	   ,DBC.ARC			 AS ARC
	   ,D.comments		 AS comments
	   ,V.ProductName	 AS ProductName
	   ,P.ProductLevel	 AS ProductLevel
	   ,P.ProductVersion AS ProductVersion
	   ,D.updated		 AS updated
	   ,D.[by]			 AS [by]
	FROM AdminServer.DBINFO_Information AS D
	LEFT OUTER JOIN AdminControl.DBServersAll AS S ON S.DBSAServerName = D.[server]
	LEFT OUTER JOIN AdminServer.HPS_Export_SQLServerVersion_Current AS V ON S.DBSAServerName = V.ServerName
	LEFT OUTER JOIN AdminServer.HPS_Export_SQLServerProperties_Current AS P ON S.DBSAServerName = P.ServerName
	LEFT OUTER JOIN AdminControl.Database_Control_Information AS DBC ON D.[server] = DBC.ServerName AND
	D.db = DBC.DatabaseName
	WHERE S.DBSAManaged = 1
	AND (D.Date_Key =
	(
		  SELECT
			  MAX( Date_Key ) AS Date_Key
		  FROM AdminServer.DBINFO_Information
	)
	)
	UNION
	SELECT TOP (100) PERCENT
		Date_Key =									   
		(
			  SELECT
				  MAX( Date_Key )
			  FROM AdminServer.DBINFO_Information
		)
	   ,S.DBSACustomerName							   AS customer
	   ,S.DBSAServerName							   AS Server
	   ,CASE
			WHEN S.DBSAServerName = 'ACWIN-SQLT01\SQL002' THEN 'BS'
			WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
			WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE'
			WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
			WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE'
			WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE'
			WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE'
			WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS'
			WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC'
			WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS'
			WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC'
			ELSE 'Undefined'
		END											   AS sla
	   ,'System DBs'								   AS db
	   ,NULL										   AS crdate
	   ,0											   AS dbsize
	   ,'Not Billed'								   AS ARC
	   ,'SYSTEM Databases'							   AS comments
	   ,ISNULL( 'Microsoft SQL Server',V.ProductName ) AS ProductName
	   ,P.ProductLevel								   AS ProductLevel
	   ,P.ProductVersion							   AS ProductVersion
	   ,NULL										   AS updated
	   ,NULL										   AS [by]
	FROM AdminControl.DBServersAll AS S
	LEFT OUTER JOIN AdminServer.HPS_Export_SQLServerVersion_Current AS V ON S.DBSAServerName = V.ServerName
	LEFT OUTER JOIN AdminServer.HPS_Export_SQLServerProperties_Current AS P ON S.DBSAServerName = P.ServerName
	WHERE S.DBSAManaged = 1
	AND S.DBSAInstanceSupported = 'Y'
	AND S.DBSAServerType <> 'B'
	AND S.DBSAServerName NOT IN
	(
		  SELECT
			  Server
		  FROM AdminServer.DBINFO_Information
		  WHERE AdminServer.DBINFO_Information.Date_Key <>
		  (
				SELECT
					MAX( Date_Key ) AS Date_Key
				FROM AdminServer.DBINFO_Information
		  )
	)
	UNION
	SELECT TOP (100) PERCENT
		Date_Key =									   
		(
			  SELECT
				  MAX( Date_Key )
			  FROM AdminServer.DBINFO_Information
		)
	   ,T.DBSACustomerName							   AS customer
	   ,O.[ServerName]								   AS Server
	   ,CASE
			WHEN T.DBSAServerName = 'ACWIN-SQLT01\SQL002' THEN 'BS'
			WHEN T.DBSAServerType = 'T' AND T.DBSAClustered = 0 THEN 'BE'
			WHEN T.DBSAServerType = 'T' AND T.DBSAClustered = 1 THEN 'BE'
			WHEN T.DBSAServerType = 'D' AND T.DBSAClustered = 0 THEN 'BE'
			WHEN T.DBSAServerType = 'D' AND T.DBSAClustered = 1 THEN 'BE'
			WHEN T.DBSAServerType = 'S' AND T.DBSAClustered = 0 THEN 'BE'
			WHEN T.DBSAServerType = 'S' AND T.DBSAClustered = 1 THEN 'BE'
			WHEN T.DBSAServerType = 'P' AND T.DBSAClustered = 0 THEN 'BS'
			WHEN T.DBSAServerType = 'P' AND T.DBSAClustered = 1 THEN 'BC'
			WHEN T.DBSAServerType = 'B' AND T.DBSAClustered = 0 THEN 'BS'
			WHEN T.DBSAServerType = 'B' AND T.DBSAClustered = 1 THEN 'BC'
			ELSE 'Undefined'
		END											   AS sla
	   ,O.[name]									   AS db
	   ,NULL										   AS crdate
	   ,0											   AS dbsize
	   ,'Billed'									   AS ARC
	   ,[state_desc]								   AS comments
	   ,ISNULL( 'Microsoft SQL Server',V.ProductName ) AS ProductName
	   ,P.ProductLevel								   AS ProductLevel
	   ,P.ProductVersion							   AS ProductVersion
	   ,NULL										   AS updated
	   ,NULL										   AS [by]
	FROM [AdminServer].[HPS_Admin_Database_OFFLINE_Exceptions] AS O
	INNER JOIN AdminControl.DBServersAll AS T ON O.ServerName = T.DBSAServerName
	LEFT OUTER JOIN AdminServer.HPS_Export_SQLServerVersion_Current AS V ON T.DBSAServerName = V.ServerName
	LEFT OUTER JOIN AdminServer.HPS_Export_SQLServerProperties_Current AS P ON T.DBSAServerName = P.ServerName
	WHERE T.DBSAManaged = 1
	AND T.DBSAInstanceSupported = 'Y'
	AND T.DBSAServerType <> 'B'
	ORDER BY Server,db
GO
/****** Object:  View [AdminServer].[HPS_Admin_Audit_CI_From_DBINFO]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Admin_Audit_CI_From_DBINFO] AS (
SELECT 
CASE CHARINDEX('\',[Server])
	WHEN 0 THEN
		[db]+ '::' + [Server] 
	ELSE
		[db]+':'+ RIGHT([Server], (LEN([Server]) - CHARINDEX('\',[Server]))) + ':'+ LEFT([Server], CHARINDEX('\',[Server]) - 1)
END AS 'DBINFO_CI'
,[Server]
,DBSAServerDBA_Primary
FROM [ENSONODBA].[AdminServer].[DBINFO_Information] DI1 INNER JOIN [ENSONODBA].AdminControl.DBServersAll SA ON ([Server] = DBSAServerName)
WHERE DI1.Date_Key = (SELECT MAX(DI2.Date_Key)  FROM [ENSONODBA].[AdminServer].[DBINFO_Information] DI2)
AND SA.DBSAInstanceSupported ='Y' AND [db] NOT LIKE 'System DBs%'
UNION
SELECT 
CASE CHARINDEX('\',[ServerName])
	WHEN 0 THEN
		[name]+ '::' + [ServerName] 
	ELSE
		[name]+':'+ RIGHT([ServerName], (LEN([ServerName]) - CHARINDEX('\',[ServerName]))) + ':'+ LEFT([ServerName], CHARINDEX('\',[ServerName]) - 1)
END AS 'DBINFO_CI'
,[ServerName]
,DBSAServerDBA_Primary
FROM [ENSONODBA].[AdminServer].[HPS_Admin_Database_OFFLINE_Exceptions] DI1 INNER JOIN [ENSONODBA].AdminControl.DBServersAll SA ON ([ServerName] = DBSAServerName)
WHERE SA.DBSAInstanceSupported ='Y' 
UNION
SELECT 
CASE CHARINDEX('\',[Server])
	WHEN 0 THEN
		':' + [Server] 
	ELSE
		RIGHT([Server], (LEN([Server]) - CHARINDEX('\',[Server]))) + ':'+ LEFT([Server], CHARINDEX('\',[Server]) - 1)
END AS 'DBINFO_CI'
,[Server]
,DBSAServerDBA_Primary

   FROM [ENSONODBA].[AdminServer].[DBINFO_Information] DI1 INNER JOIN [ENSONODBA].AdminControl.DBServersAll SA ON ([Server] = DBSAServerName)
  WHERE DI1.Date_Key = (SELECT MAX(DI2.Date_Key)  FROM [ENSONODBA].[AdminServer].[DBINFO_Information] DI2)
  AND [db]='master'
  AND SA.DBSAInstanceSupported ='Y'

)




GO
/****** Object:  View [AdminServer].[HPS_Admin_Audit_CI_Audit]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [AdminServer].[HPS_Admin_Audit_CI_Audit]
AS
	(
	SELECT
		DBINFO.DBINFO_CI													  AS DBIBFO_Name
			 ,Existing.[Name]													  AS CASD_Name
			 ,SUBSTRING( RTRIM( [Name] ),1,CHARINDEX( ':',RTRIM( Name ),1 ) - 1 ) AS DatabaseName
			 ,CASE
				  WHEN DBINFO.[Server] IS NULL THEN 
				  CASE PATINDEX('%:',(STUFF(REPLACE([Name],LTRIM(RIGHT ([Name],CHARINDEX (':',REVERSE([Name])))),''),1,CHARINDEX(':',[Name]) - 1, LTRIM(RIGHT ([Name],CHARINDEX (':',REVERSE([Name])) - 1)))))
						WHEN 0 THEN REPLACE(STUFF(REPLACE([Name],LTRIM(RIGHT ([Name],CHARINDEX (':',REVERSE([Name])))),''),1,CHARINDEX(':',[Name]) - 1, LTRIM(RIGHT ([Name],CHARINDEX (':',REVERSE([Name])) - 1))),':','\')
						ELSE REPLACE(STUFF(REPLACE([Name],LTRIM(RIGHT ([Name],CHARINDEX (':',REVERSE([Name])))),''),1,CHARINDEX(':',[Name]) - 1, LTRIM(RIGHT ([Name],CHARINDEX (':',REVERSE([Name])) - 1))),':','')
			  END
				  ELSE DBINFO.[Server]
			  END																  AS 'Server'
			 ,DBINFO.DBSAServerDBA_Primary										  AS 'Primary'
			 ,CASE
				  WHEN DBINFO_CI = [Name] THEN 'Match'
				  WHEN DBINFO_CI IS NULL THEN 'Check/Confirm/Retire CI'
				  ELSE 'Create CI'
			  END																  AS 'Task'
	FROM AdminServer.HPS_Admin_Audit_CI_From_DBINFO DBINFO
		FULL OUTER JOIN AdminServer.HPS_Inventory_CASD_EXTRACT Existing ON (DBINFO_CI = [Name])
	--If you add these you will never see the ones that you may need to retire
	--INNER JOIN AdminControl.DBServersAll SA ON (DBINFO.[Server] = SA.DBSAServerName) 
	--INNER JOIN AdminLog.DBINFO DI3 ON ([ServerName] = SA.DBSAServerConnection)
	--WHERE DI3.RunResults is not null
	)
GO
/****** Object:  View [AdminServer].[HPS_Admin_SQLServerVersion_Audit_Ensono]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO











CREATE VIEW [AdminServer].[HPS_Admin_SQLServerVersion_Audit_Ensono]
AS
SELECT     
	M.DBSACustomerName AS [Tenant Name], 
	R.ServerName AS [Configuration Item or Environment Name], 
	'SW' AS [Configuration Type HW/SW],
	R.ProductName + ' ' + P.Edition + ' ' + R.ProductVersion + ' ' + P.ProductLevel AS [Currency Actual],
	CASE WHEN R.ProductVersion LIKE '9%' THEN 'No Longer Supported'
		 WHEN R.ProductVersion LIKE '10.0%' AND P.ProductLevel <> 'SP4' THEN 'SQL Version Not Supported, Should be at SP4'
		 WHEN R.ProductVersion LIKE '10.00.6556%' AND P.ProductLevel = 'SP4' THEN 'SQL Version Supported and Spectre Patch Applied'
		 WHEN R.ProductVersion LIKE '10.0%' AND P.ProductLevel = 'SP4'  THEN 'SQL Version Supported, At Current Release Level. Spectre Patch Not Applied'
		 WHEN R.ProductVersion LIKE '10.5%' AND P.ProductLevel <> 'SP3' THEN 'SQL Version Not Supported, Should be at SP3'
		 WHEN R.ProductVersion LIKE '10.50.6560%' AND P.ProductLevel = 'SP3'  THEN 'SQL Version Supported and Spectre Patch Applied'
		 WHEN R.ProductVersion LIKE '10.5%' AND P.ProductLevel = 'SP3'  THEN 'SQL Version Supported, At Current Release Level. Spectre Patch Not Applied'
		 WHEN R.ProductVersion LIKE '11.0.6615.2%' AND P.ProductLevel = 'SP3'  THEN 'SQL Version Supported and Spectre Patch Applied'
		 WHEN R.ProductVersion LIKE '11.0%' AND P.ProductLevel = 'SP3'  THEN 'SQL Version Supported. Spectre Patch Not Applied'
		 WHEN R.ProductVersion LIKE '11.0%' AND P.ProductLevel <> 'SP4' THEN 'SQL Version Not Supported, Should be at SP4'
		 WHEN R.ProductVersion LIKE '11.0.7462.6%' AND P.ProductLevel = 'SP4'  THEN 'SQL Version Supported and Spectre Patch Applied'
		 WHEN R.ProductVersion LIKE '11.0%' AND P.ProductLevel = 'SP4'  THEN 'SQL Version Supported. Spectre Patch Not Applied'
		 WHEN R.ProductVersion LIKE '12.0%' AND P.ProductLevel <> 'SP2' THEN 'SQL Version Not Supported, Should be at SP2'
		 WHEN R.ProductVersion LIKE '12.0.5571.0%' AND P.ProductLevel = 'SP2'  THEN 'SQL Version Supported and Spectre Patch Applied'
		 WHEN R.ProductVersion LIKE '12.0%' AND P.ProductLevel = 'SP2'  THEN 'SQL Version Supported. Spectre Patch Not Applied'
		 WHEN R.ProductVersion LIKE '13.0%' AND P.ProductLevel <> 'SP1' THEN 'SQL Version Not Supported, Should be at SP1'
		 WHEN R.ProductVersion LIKE '13.0.4466.4%' AND P.ProductLevel = 'SP1'  THEN 'SQL Version Supported and Spectre Patch Applied. Specter Patch Not Applied'
		 WHEN R.ProductVersion LIKE '13.0%' AND P.ProductLevel = 'SP1'  THEN 'SQL Version Supported, At Current Release Level. Spectre Patch Not Applied'
		 ELSE 'Version Not Supported'
		 END AS [Currency Target],
	'Microsoft' AS [Supporting Vendor or N/A],
	' ' AS [Upgrade Plan YES/NO/Current or UnSupported],
	SQLVersion.[Extended_Support_End_Date] AS [End of Support Date],
	' ' AS [Pending Upgrade Date],
	SQLVersion.[Service_Pack_Support_Comments] AS [Comments],
	'Database' AS [Tower],
	'Chris Murray' AS [Tower Owner],
	' ' AS [Tower Owner Contract Information]
FROM  AdminControl.DBServersAll AS M INNER JOIN AdminServer.SQLServerVersion_Repository AS R ON
M.DBSAServerName = R.ServerName INNER JOIN 
[AdminServer].[HPS_Admin_SQLServerProperties_Current] AS P ON
M.DBSAServerName = P.ServerName
INNER JOIN (
SELECT ServerName,MAX(Date_Key) AS Date_Key
FROM   AdminServer.SQLServerVersion_Repository AS SQLServerVersion_Repository_1
GROUP By ServerName) AS S1 ON
R.ServerName = S1.ServerName AND
R.Date_Key = S1.Date_Key
LEFT JOIN (
SELECT [Build_Key]
      ,[SQL_Version]
      ,[Product_Level]
      ,[Life_Cycle_Start_Date]
      ,[Mainstream_Support_End_Date]
      ,[Extended_Support_End_Date]
      ,[Service_Pack_Support_End_Date]
      ,[Service_Pack_Support_Comments]
  FROM [DBA].[AdminControl].[SQLVersionInformation]) AS SQLVersion ON
  R.ProductVersion = SQLVersion.Build_Key
WHERE M.DBSAManaged = 1











GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_Totals_All]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


Create VIEW [AdminServer].[HPS_Inventory_Server_Totals_All]
AS
SELECT TOP 100 PERCENT
	S.DBSACustomerName AS customer,
	S.DBSAServerName AS server,
	S1.SLA,
	S1.DatabaseCount,
	S1.Server_Total_MB,
	ISNULL('Microsoft SQL Server',V.ProductName) AS ProductName,
	P.ProductLevel,
	P.ProductVersion
FROM AdminControl.DBServersAll AS S  
	LEFT OUTER JOIN 
	AdminServer.HPS_Export_SQLServerVersion_Current AS V ON
	S.DBSAServerName = V.ServerName
	LEFT OUTER JOIN
	AdminServer.HPS_Export_SQLServerProperties_Current AS P ON
	S.DBSAServerName = P.ServerName
	LEFT OUTER JOIN
(
SELECT TOP (100) PERCENT 
	customer, 
	server, 
	  CASE WHEN S.DBSAServerName = 'ACWIN-SQLT01\SQL002'	   THEN 'BS'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC' 
	       ELSE 'Undefined' END AS SLA, 
	SUM(CASE WHEN [db] NOT IN ('System DBs', 'DBA') THEN 1
	           ELSE 0 END) AS DatabaseCount, 
	CAST(ROUND(SUM(dbsize), 0) AS INT) AS Server_Total_MB
FROM AdminServer.DBINFO_Information
	INNER JOIN
	  AdminControl.DBServersAll AS S ON 
	server = S.DBSAServerName
WHERE S.DBSAManaged = 1 AND (Date_Key = (SELECT MAX(Date_Key) AS Date_Key
                       FROM AdminServer.DBINFO_Information AS Admin_Server_DBINFO_Information_1))
GROUP BY customer, server, 
	  CASE WHEN S.DBSAServerName = 'ACWIN-SQLT01\SQL002'	   THEN 'BS'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC' 
	       ELSE 'Undefined' END 
ORDER BY customer, 
	  CASE WHEN S.DBSAServerName = 'ACWIN-SQLT01\SQL002'	   THEN 'BS'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC' 
	       ELSE 'Undefined' END, 
server) AS S1 ON
S.DBSAServerName = S1.server
WHERE S.DBSAManaged = 1 AND S.DBSAInstanceSupported = 'Y' AND S.DBSAInstanceBilled = 'Y'
ORDER BY server





GO
/****** Object:  View [AdminServer].[HPS_Inventory_CASD_Totals]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO








CREATE VIEW [AdminServer].[HPS_Inventory_CASD_Totals]
AS

SELECT TOP 100 PERCENT customer AS Customer
         ,'RRD DBA Database Collections' AS Worksheet
      ,count([server]) AS Totals
      ,0.0000 AS Percentage  
         ,1 AS SortOrder
FROM [AdminServer].[HPS_Inventory_CASD_RRD_DBA_Collections]
GROUP BY Customer
UNION
SELECT TOP 100 PERCENT Tenant AS Customer
         ,'CASD Extract' AS Worksheet
      ,count([Name]) AS Totals
      ,0.0000 AS Percentage  
         ,2 AS SortOrder
FROM [AdminServer].[HPS_Inventory_CASD_EXTRACT]
GROUP BY Tenant
UNION
SELECT TOP 100 PERCENT C.Customer, A.Worksheet, convert(int, A.Totals), convert(decimal(6,4), A.TOTALS/B.CASD)*100 AS Percentage, 3 AS SortOrder FROM 
(SELECT 'CIs with No Match in Customer' AS Worksheet, convert(decimal(10,6), count([Server])) AS Totals FROM [AdminServer].[HPS_Admin_Audit_CI_Audit] WHERE Task <> 'Match' ) AS A
INNER JOIN 
(SELECT 'CIs with No Match in Customer' AS Worksheet, convert(decimal(10,6), count([Name])) AS CASD FROM [AdminServer].[HPS_Inventory_CASD_EXTRACT] ) AS B ON
A.Worksheet = B.Worksheet
INNER JOIN (SELECT TOP 1 'CIs with No Match in Customer' AS Worksheet, DBSACustomerName AS Customer FROM [AdminControl].[DBServersAll]) AS C ON 
A.Worksheet = C.Worksheet
UNION
SELECT TOP 100 PERCENT C.Customer, A.Worksheet, convert(int, A.Totals), CONVERT(DECIMAL(6,4),A.Totals/B.CASD)*100 AS Percentage, 4 AS SortOrder FROM 
(SELECT 'CIs with Match in Customer' AS Worksheet, convert(decimal(10,6),count([Server])) AS Totals FROM [AdminServer].[HPS_Admin_Audit_CI_Audit] WHERE Task = 'Match') AS A
INNER JOIN 
(SELECT 'CIs with Match in Customer' AS Worksheet, convert(decimal(10,6),count([Name])) AS CASD FROM [AdminServer].[HPS_Inventory_CASD_EXTRACT] ) AS B ON
A.Worksheet = B.Worksheet
INNER JOIN (SELECT TOP 1 'CIs with Match in Customer' AS Worksheet, DBSACustomerName AS Customer FROM [AdminControl].[DBServersAll]) AS C ON 
A.Worksheet = C.Worksheet
ORDER BY SortOrder









GO
/****** Object:  Table [AdminServer].[UpTimeAnalysis_Repository]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[UpTimeAnalysis_Repository](
	[UpTimeAnalysisRepository_Key] [int] IDENTITY(1,1) NOT NULL,
	[Date_Key] [datetime] NOT NULL,
	[MachineName] [nvarchar](128) NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[EnvironmentType] [nvarchar](10) NOT NULL,
	[ManagedBy] [nvarchar](10) NOT NULL,
	[Edition] [nvarchar](128) NULL,
	[ProductLevel] [nvarchar](128) NULL,
	[ProductVersion] [nvarchar](128) NULL,
	[IsClusterd] [varchar](100) NULL,
	[ServerUpTime] [varchar](100) NULL,
	[SQLServerUptimeInDays] [int] NULL,
	[SQLServerUptimeInHrs] [int] NULL,
	[SQLServerUptimeInMins] [int] NULL
) ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Admin_SQLServerUpTimeAnalysis]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW [AdminServer].[HPS_Admin_SQLServerUpTimeAnalysis]
AS
SELECT     TOP 100 PERCENT 
	R.Date_Key, 
	R.MachineName, 
	R.ServerName, 
	M.DBSAServerClusteredPreferredNode, 
    CASE WHEN DBSAServerType = 'P' THEN 'Production'
		 WHEN DBSAServerType = 'T' THEN 'Test'
		 WHEN DBSAServerType = 'S' THEN 'Staging'
		 WHEN DBSAServerType = 'D' THEN 'Development'
		 WHEN DBSAServerType = 'B' THEN 'Disaster Recovery'
		 ELSE 'Undefined' END AS Server_Type,
	CASE WHEN R.IsClusterd = 'Clustered' AND R.MachineName <> M.DBSAServerClusteredPreferredNode THEN 'Not Running on Preferred Node' 
		 WHEN R.IsClusterd = 'Clustered' AND  R.MachineName = M.DBSAServerClusteredPreferredNode THEN ' Running on Correct Node' 
		 ELSE 'Not a Clustered Environment' END AS EnvironmentReview, 
	CASE WHEN R.SQLServerUptimeInDays > 31 THEN 'Database Environment not Restarted within 31 days'
		 WHEN R.SQLServerUptimeInDays < 7  THEN 'Database Environment Restarted within the last 7 Days'
		 ELSE 'Database Environment Status to be Determined' End AS UpTimeReview, 
	R.EnvironmentType, 
	R.ManagedBy, 
	R.Edition, 
	R.ProductLevel, 
	R.ProductVersion, 
	R.IsClusterd, 
	R.ServerUpTime,
	R.SQLServerUptimeInDays, 
	R.SQLServerUptimeInHrs, 
	R.SQLServerUptimeInMins
FROM AdminServer.UpTimeAnalysis_Repository AS R INNER JOIN
     AdminControl.DBServersAll AS M ON R.ServerName = M.DBSAServerName
     ORDER BY R.MachineName, R.ServerName








GO
/****** Object:  View [AdminServer].[HPS_Admin_Login_Failure_Information_RRD]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [AdminServer].[HPS_Admin_Login_Failure_Information_RRD]
AS
SELECT     TOP (100) PERCENT 
	R.DBSACustomerName AS CustomerName, 
	L.Server AS ServerName,
    L.[LogDate],
	L.ProcessInfo,
	L.Text
FROM [DBA].[AdminServer].[SQL_ErrorLog] AS L INNER JOIN
     AdminControl.DBServersAll AS R ON L.Server = R.DBSAServerName
WHERE R.DBSAManaged = 1 AND DATEDIFF(HH, LogDate, GETDATE()) < 24 AND 
	R.DBSACustomerName = 'LSC Communications, Inc.' AND
	Text like '%Login%' AND 
	Text like '%failed%' 
ORDER BY R.DBSACustomerName, L.Server, L.LogDate DESC




GO
/****** Object:  View [AdminServer].[HPS_Admin_Login_Failure_Information_Counts]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





CREATE VIEW [AdminServer].[HPS_Admin_Login_Failure_Information_Counts]
AS
SELECT     TOP (100) PERCENT M.DBSACustomerName AS CustomerName,ServerName, COUNT(C.LogDate) AS Login_Failures, M.DBSAServerDBA_Primary AS PrimaryDBA, Text
FROM         AdminServer.HPS_Admin_Login_Failure_Information_RRD AS C INNER JOIN AdminControl.DBServersAll AS M ON
C.ServerName = M.DBSAServerName 
GROUP BY M.DBSACustomerName, ServerName, M.DBSAServerDBA_Primary, Text 
ORDER BY M.DBSACustomerName, ServerName, M.DBSAServerDBA_Primary, Text 






GO
/****** Object:  View [AdminServer].[HPS_Admin_Database_Information_All]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Admin_Database_Information_All]
AS
SELECT	TOP (100) PERCENT 
	DI.Date_Key, 
	M.DBSACustomerName, 
	M.DBSAServerName, 
	M.DBSAServerType, 
	M.DBSADomain, 
	DI.DatabaseName, 
	DI.FileSizeMB, 
	DI.LogicalFileName, 
	DI.PhysicalFileName, 
	DI.Status, 
	DI.Updateability, 
	DI.RecoveryMode, 
	DI.FreeSpaceMB, 
	DI.FreeSpacePct, 
	DI.Applications, 
	DI.FunctionalGroups, 
	DI.Owners
FROM    AdminServer.Database_Information AS DI INNER JOIN
        AdminControl.DBServersAll AS M ON DI.ServerName = M.DBSAServerName
WHERE     M.DBSAManaged = 1 AND DI.Date_Key = (SELECT     MAX(Date_Key) AS Date_Key FROM AdminServer.Database_Information) 
ORDER BY DI.Date_Key, M.DBSACustomerName, DI.ServerName, DI.DatabaseName




GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_Totals_All_Previous]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [AdminServer].[HPS_Inventory_Server_Totals_All_Previous]
AS
SELECT TOP 100 PERCENT
	S1.Date_Key AS Date_Key,
	S.DBSACustomerName AS customer,
	S.DBSAServerName AS server,
	S1.SLA,
	ISNULL(S1.DatabaseCount,0) AS DatabaseCount,
	ISNULL(S1.Server_Total_MB,0) AS Server_Total_MB,
	ISNULL('Microsoft SQL Server',V.ProductName) AS ProductName,
	P.ProductLevel,
	P.ProductVersion
FROM AdminControl.DBServersAll AS S  
	LEFT OUTER JOIN 
	AdminServer.HPS_Export_SQLServerVersion_Current AS V ON
	S.DBSAServerName = V.ServerName
	LEFT OUTER JOIN
	AdminServer.HPS_Export_SQLServerProperties_Current AS P ON
	S.DBSAServerName = P.ServerName
	LEFT OUTER JOIN
(
SELECT TOP (100) PERCENT 
	Date_Key,
	customer, 
	server, 
	  CASE WHEN S.DBSAServerName = 'ACWIN-SQLT01\SQL002'	   THEN 'BS'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC' 
	       ELSE 'Undefined' END AS SLA, 
	SUM(CASE WHEN [db] NOT IN ('System DBs', 'DBA') THEN 1
	           ELSE 0 END) AS DatabaseCount, 
	CAST(ROUND(SUM(dbsize), 0) AS INT) AS Server_Total_MB
FROM AdminServer.DBINFO_Information
	INNER JOIN
	  AdminControl.DBServersAll AS S ON 
	server = S.DBSAServerName
WHERE S.DBSAManaged = 1 AND (Date_Key = 
(SELECT TOP 1 S2.Date_Key FROM (
SELECT DISTINCT TOP 2 Date_Key AS Date_Key
FROM AdminServer.DBINFO_Information AS Admin_Server_DBINFO_Information_1
ORDER BY Date_Key DESC) AS S2
ORDER BY S2.Date_Key ASC
))
GROUP BY Date_Key, customer, server, 
	  CASE WHEN S.DBSAServerName = 'ACWIN-SQLT01\SQL002'	   THEN 'BS'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC' 
	       ELSE 'Undefined' END 
ORDER BY Date_Key, customer, 
	  CASE WHEN S.DBSAServerName = 'ACWIN-SQLT01\SQL002'	   THEN 'BS'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC' 
	       ELSE 'Undefined' END, 
server) AS S1 ON
S.DBSAServerName = S1.server
WHERE S.DBSAManaged = 1 AND S.DBSAInstanceSupported = 'Y' AND S.DBSAInstanceBilled = 'Y'
ORDER BY server







GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_Totals_All_Current]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [AdminServer].[HPS_Inventory_Server_Totals_All_Current]
AS
SELECT TOP 100 PERCENT
	S1.Date_Key,
	S.DBSACustomerName AS customer,
	S.DBSAServerName AS server,
	S1.SLA,
	S1.DatabaseCount,
	S1.Server_Total_MB,
	ISNULL('Microsoft SQL Server',V.ProductName) AS ProductName,
	P.ProductLevel,
	P.ProductVersion
FROM AdminControl.DBServersAll AS S  
	LEFT OUTER JOIN 
	AdminServer.HPS_Export_SQLServerVersion_Current AS V ON
	S.DBSAServerName = V.ServerName
	LEFT OUTER JOIN
	AdminServer.HPS_Export_SQLServerProperties_Current AS P ON
	S.DBSAServerName = P.ServerName
	LEFT OUTER JOIN
(
SELECT TOP (100) PERCENT 
	Date_Key,
	customer, 
	server, 
	  CASE WHEN S.DBSAServerName = 'ACWIN-SQLT01\SQL002'	   THEN 'BS'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC' 
	       ELSE 'Undefined' END AS SLA, 
	SUM(CASE WHEN [db] NOT IN ('System DBs', 'DBA') THEN 1
	           ELSE 0 END) AS DatabaseCount, 
	CAST(ROUND(SUM(dbsize), 0) AS INT) AS Server_Total_MB
FROM AdminServer.DBINFO_Information
	INNER JOIN
	  AdminControl.DBServersAll AS S ON 
	server = S.DBSAServerName
WHERE S.DBSAManaged = 1 AND (Date_Key = (SELECT MAX(Date_Key) AS Date_Key
                       FROM AdminServer.DBINFO_Information AS Admin_Server_DBINFO_Information_1))
GROUP BY Date_Key, customer, server, 
	  CASE WHEN S.DBSAServerName = 'ACWIN-SQLT01\SQL002'	   THEN 'BS'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC' 
	       ELSE 'Undefined' END 
ORDER BY Date_Key, customer, 
	  CASE WHEN S.DBSAServerName = 'ACWIN-SQLT01\SQL002'	   THEN 'BS'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC' 
	       ELSE 'Undefined' END, 
server) AS S1 ON
S.DBSAServerName = S1.server
WHERE S.DBSAManaged = 1 AND S.DBSAInstanceSupported = 'Y' AND S.DBSAInstanceBilled = 'Y'
ORDER BY server






GO
/****** Object:  View [AdminServer].[HPS_Admin_SQLServerVersion_Audit]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
















CREATE VIEW [AdminServer].[HPS_Admin_SQLServerVersion_Audit]
AS
SELECT     
	R.Date_Key, 
	R.ServerName, 
	R.ProductName,
	P.Edition AS CurrentSQLEdition, 
	R.ProductVersion AS CurrentProductVersion,
	P.ProductLevel AS CurrentProductLevel,
	SQLVersion.SQL_Version,
	SQLVersion.Product_Level, 
	CASE WHEN R.ProductVersion LIKE '9%' THEN 'No Longer Supported'
		 WHEN R.ProductVersion LIKE '10.00.6556%' AND P.ProductLevel = 'SP4' THEN 'SQL Version Supported and Spectre Patch Applied'
		 WHEN R.ProductVersion LIKE '10.0%' AND P.ProductLevel = 'SP4'  THEN 'SQL Version Supported, At Current Release Level. Spectre Patch Not Applied'
		 WHEN R.ProductVersion LIKE '10.0%' AND P.ProductLevel <> 'SP4' THEN 'SQL Version Not Supported, Should be at SP4'
		 WHEN R.ProductVersion LIKE '10.50.6560.0%' AND P.ProductLevel = 'SP3'  THEN 'SQL Version Supported and Spectre Patch Applied'
		 WHEN R.ProductVersion LIKE '10.5%' AND P.ProductLevel = 'SP3'  THEN 'SQL Version Supported, At Current Release Level. Spectre Patch Not Applied'
		 WHEN R.ProductVersion LIKE '10.5%' AND P.ProductLevel <> 'SP3' THEN 'SQL Version Not Supported, Should be at SP3'
		 WHEN R.ProductVersion LIKE '11.0.6615.2%' AND P.ProductLevel = 'SP3'  THEN 'SQL Version Supported and Spectre Patch Applied'
		 WHEN R.ProductVersion LIKE '11.0.7462.6%' AND P.ProductLevel = 'SP4'  THEN 'SQL Version Supported and Spectre Patch Applied'
		 WHEN R.ProductVersion LIKE '11.0%' AND P.ProductLevel = 'SP3'  THEN 'SQL Version Supported. Spectre Patch Not Applied'
		 WHEN R.ProductVersion LIKE '11.0%' AND P.ProductLevel <> 'SP4' THEN 'SQL Version Not Supported, Should be at SP4'
		 WHEN R.ProductVersion LIKE '11.0%' AND P.ProductLevel = 'SP4'  THEN 'SQL Version Supported. Spectre Patch Not Applied'
		 WHEN R.ProductVersion LIKE '12.0.5571.0%' AND P.ProductLevel = 'SP2'  THEN 'SQL Version Supported and Spectre Patch Applied'
		 WHEN R.ProductVersion LIKE '12.0%' AND P.ProductLevel <> 'SP2' THEN 'SQL Version Not Supported, Should be at SP2'
		 WHEN R.ProductVersion LIKE '12.0%' AND P.ProductLevel = 'SP2'  THEN 'SQL Version Supported. Spectre Patch Not Applied'
		 WHEN R.ProductVersion LIKE '13.0.4466.%' AND P.ProductLevel = 'SP1'  THEN 'SQL Version Supported and Spectre Patch Applied'
		 WHEN R.ProductVersion LIKE '13.0%' AND P.ProductLevel = 'SP2'  THEN 'SQL Version Supported, At Current Release Level'
		 WHEN R.ProductVersion LIKE '13.0%' AND P.ProductLevel = 'SP1' THEN 'SQL Version Supported and Spectre Patch Not Applied'
		 ELSE 'Version Not Supported'
		 END AS SQLAuditReview,
	--SQLVersion.Extended_Support_End_Date,
	--SQLVersion.Life_Cycle_Start_Date,
	--SQLVersion.Mainstream_Support_End_Date,
	--SQLVersion.Product_Level,
	--SQLVersion.Service_Pack_Support_End_Date,
	--SQLVersion.Service_Pack_Support_Comments,
	R.WindowsVersion, 
	CASE 
		WHEN R.[WindowsVersion] = '6.3 (14393)' THEN 'Windows Server 2016 Standard'
		WHEN R.[WindowsVersion] LIKE '6.3%' THEN 'Windows Server 2012 R2'
		WHEN R.[WindowsVersion] LIKE '6.2%' THEN 'Windows Server 2012'
		WHEN R.[WindowsVersion] LIKE '6.1%' THEN 'Windows Server 2008 R2'
		WHEN R.[WindowsVersion] LIKE '6.0%' THEN 'Windows Server 2008'
		WHEN R.[WindowsVersion] LIKE '5.2%' THEN 'Windows Server 2003'
		WHEN R.[WindowsVersion] LIKE '5.0%' THEN 'Windows Server 2000'
		ELSE 'Undefined' END AS [WindowsVersionDescription],
	CASE WHEN R.[WindowsVersion] = '6.3 (14393)' THEN 'Windows Version Current'
		 WHEN R.[WindowsVersion] LIKE '6.3%' THEN 'Windows Version Current'
		 WHEN R.[WindowsVersion] LIKE '6.2%' THEN 'Consider Upgrade to Windows Server 2016'
	     WHEN R.[WindowsVersion] LIKE '6.1%' THEN 'Consider Upgrade to Windows Server 2016'
		 WHEN R.[WindowsVersion] LIKE '6.1%' THEN 'Consider Upgrade to Windows Server 2016'
		 WHEN R.[WindowsVersion] LIKE '6.0%' THEN 'Consider Upgrade to Windows Server 2016'
		 WHEN R.[WindowsVersion] LIKE '5.2%' THEN 'Version Not Supported'
		 WHEN R.[WindowsVersion] LIKE '5.0%' THEN 'Version Not Supported'
		 ELSE 'Version Not Supported'
		 END AS WindowsAuditReview
FROM  AdminControl.DBServersAll AS M INNER JOIN AdminServer.SQLServerVersion_Repository AS R ON
M.DBSAServerName = R.ServerName INNER JOIN 
[AdminServer].[HPS_Admin_SQLServerProperties_Current] AS P ON
M.DBSAServerName = P.ServerName
INNER JOIN (
SELECT ServerName,MAX(Date_Key) AS Date_Key
FROM   AdminServer.SQLServerVersion_Repository AS SQLServerVersion_Repository_1
GROUP By ServerName) AS S1 ON
R.ServerName = S1.ServerName AND
R.Date_Key = S1.Date_Key
LEFT JOIN (
SELECT [Build_Key]
      ,[SQL_Version]
      ,[Product_Level]
      ,[Life_Cycle_Start_Date]
      ,[Mainstream_Support_End_Date]
      ,[Extended_Support_End_Date]
      ,[Service_Pack_Support_End_Date]
      ,[Service_Pack_Support_Comments]
  FROM [DBA].[AdminControl].[SQLVersionInformation]) AS SQLVersion ON
  R.ProductVersion = SQLVersion.Build_Key
WHERE M.DBSAManaged = 1
















GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_Totals_Non-Bowne_EOL]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



Create VIEW [AdminServer].[HPS_Inventory_Server_Totals_Non-Bowne_EOL]
AS
SELECT TOP 100 PERCENT
	S.DBSACustomerName AS customer,
	S.DBSAServerName AS server,
	S1.SLA,
	S1.DatabaseCount,
	S1.Server_Total_MB,
	ISNULL('Microsoft SQL Server',V.ProductName) AS ProductName,
	P.ProductLevel,
	P.ProductVersion
FROM AdminControl.DBServersAll AS S  
	LEFT OUTER JOIN 
	AdminServer.HPS_Export_SQLServerVersion_Current AS V ON
	S.DBSAServerName = V.ServerName
	LEFT OUTER JOIN
	AdminServer.HPS_Export_SQLServerProperties_Current AS P ON
	S.DBSAServerName = P.ServerName
	LEFT OUTER JOIN
(
SELECT TOP (100) PERCENT 
	customer, 
	server, 
	  CASE WHEN S.DBSAServerName = 'ACWIN-SQLT01\SQL002'	   THEN 'BS'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC' 
	       ELSE 'Undefined' END AS SLA, 
	SUM(CASE WHEN [db] NOT IN ('System DBs', 'DBA') THEN 1
	           ELSE 0 END) AS DatabaseCount, 
	CAST(ROUND(SUM(dbsize), 0) AS INT) AS Server_Total_MB
FROM AdminServer.DBINFO_Information
	INNER JOIN
	  AdminControl.DBServersAll AS S ON 
	server = S.DBSAServerName
WHERE S.DBSAManaged = 1 AND (Date_Key = (SELECT MAX(Date_Key) AS Date_Key
                       FROM AdminServer.DBINFO_Information AS Admin_Server_DBINFO_Information_1))
GROUP BY customer, server, 
	  CASE WHEN S.DBSAServerName = 'ACWIN-SQLT01\SQL002'	   THEN 'BS'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC' 
	       ELSE 'Undefined' END 
ORDER BY customer, 
	  CASE WHEN S.DBSAServerName = 'ACWIN-SQLT01\SQL002'	   THEN 'BS'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 0 THEN 'BE'
		   WHEN S.DBSAServerType = 'T' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 0 THEN 'BE'
	       WHEN S.DBSAServerType = 'D' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 0 THEN 'BE' 
	       WHEN S.DBSAServerType = 'S' AND S.DBSAClustered = 1 THEN 'BE' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'P' AND S.DBSAClustered = 1 THEN 'BC' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 0 THEN 'BS' 
	       WHEN S.DBSAServerType = 'B' AND S.DBSAClustered = 1 THEN 'BC' 
	       ELSE 'Undefined' END, 
server) AS S1 ON
S.DBSAServerName = S1.server
WHERE S.DBSAManaged = 1 AND S.DBSAInstanceSupported = 'Y' AND S.DBSAInstanceBilled = 'Y' AND
      S.[DBSADescription] NOT LIKE '%EOL%' AND
	  S.[DBSADescription] NOT LIKE '%Bowne%' 
ORDER BY server




GO
/****** Object:  View [AdminServer].[HPS_Admin_Backup_Daily_Audit]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Admin_Backup_Daily_Audit]
AS
SELECT     TOP (100) PERCENT 
	S1.Date_Key, 
	M.DBSACustomerName AS CustomerName, 
	S1.Server,
	M.DBSAServerConnection AS ServerConnection, 
	S1.[Database], 
	S1.BackupType, 
    CASE 
    WHEN S1.BackupType Is NULL THEN S1.Review
    WHEN S1.BackupType = 'D' AND S1.DaysOld < 1.25 THEN S1.Review --This determines NO DB Backup Performed
    WHEN S1.BackupType = 'D' AND S1.DaysOld < 8.0 THEN 'Check for Differential' -- This is for a Weekly Full Backup to Check for the current Differential
    WHEN S1.BackupType = 'D' THEN 'Full Backup Obsolete' -- At this point the FULL is Obsolete
    WHEN S1.BackupType = 'I' AND S1.DaysOld < 1.25 THEN S1.Review -- This indicates the Differential may not have been performed for the prior day 
    WHEN S1.BackupType = 'I' AND S1.DaysOld < 8.0 THEN 'Check for Current Full Backup' -- This indicates that a Full Backup should have been performed
    WHEN S1.BackupType = 'I' THEN 'Differential Backup Obsolete' -- At this Point Differential is obsolete 
    WHEN S1.BackupType = 'L' AND S1.DaysOld < .25 THEN S1.Review -- This indiacates the Log Backup File is 6 hours and within tolerance  
    WHEN S1.BackupType = 'L' AND S1.DaysOld < 2.0 THEN 'Check for Full or Diff Backup' -- This indicates Log Backup is old and to check a Diff or Full 
    WHEN S1.BackupType = 'L' AND S1.Review Like 'Error%' THEN 'Log Backup ' + S1.Review -- Indicates Log Backup Error-DB in Simple Mode
    WHEN S1.BackupType = 'L' THEN 'Log Backup Obsolete' -- At this point Log Backup is Obsolete
    ELSE 'Unknown Category' END AS Review, -- Unknown Category
    S1.BackupFinished, S1.DaysOld,
    M.DBSAServerDBA_Primary AS PrimarySupportDBA,
	M.DBSAServerType AS SLA
FROM         (SELECT     TOP (100) PERCENT MAX(Date_Key) AS Date_Key, MAX(Server) AS Server, MAX([Database]) AS [Database], MAX(BackupType) 
                                              AS BackupType, MAX(Review) AS Review, MAX([Backup Finished]) AS BackupFinished, CASE WHEN MAX(BackupType) IS NOT NULL 
                                              THEN CONVERT(decimal(8, 1), DATEDIFF(HH, isnull(MAX([Backup Finished]), DATEADD(yy, - 1, getdate())), getdate()) / 24.0) 
                                              ELSE 0 END AS DaysOld
                       FROM          AdminServer.Backup_Audit_Daily
                       GROUP BY Date_Key, Server, [Database], BackupType, [Backup Finished], Review) AS S1 
INNER JOIN
	AdminControl.DBServersAll AS M ON S1.Server = M.DBSAServerName
WHERE (S1.[Database] NOT IN ('CP015512') AND S1.Server = 'ACWIN-EWHP06') --Select specific Server for exceptions
UNION
SELECT     TOP (100) PERCENT 
	S1.Date_Key, 
	M.DBSACustomerName AS CustomerName, 
	S1.Server, 
	M.DBSAServerConnection AS ServerConnection, 
	S1.[Database], 
	S1.BackupType, 
    CASE 
    WHEN S1.BackupType Is NULL THEN S1.Review
    WHEN S1.BackupType = 'D' AND S1.DaysOld < 1.25 THEN S1.Review --This determines NO DB Backup Performed
    WHEN S1.BackupType = 'D' AND S1.DaysOld < 8.0 THEN 'Check for Differential' -- This is for a Weekly Full Backup to Check for the current Differential
    WHEN S1.BackupType = 'D' THEN 'Full Backup Obsolete' -- At this point the FULL is Obsolete
    WHEN S1.BackupType = 'I' AND S1.DaysOld < 1.25 THEN S1.Review -- This indicates the Differential may not have been performed for the prior day 
    WHEN S1.BackupType = 'I' AND S1.DaysOld < 8.0 THEN 'Check for Current Full Backup' -- This indicates that a Full Backup should have been performed
    WHEN S1.BackupType = 'I' THEN 'Differential Backup Obsolete' -- At this Point Differential is obsolete 
    WHEN S1.BackupType = 'L' AND S1.DaysOld < .25 THEN S1.Review -- This indiacates the Log Backup File is 6 hours and within tolerance  
    WHEN S1.BackupType = 'L' AND S1.DaysOld < 2.0 THEN 'Check for Full or Diff Backup' -- This indicates Log Backup is old and to check a Diff or Full 
    WHEN S1.BackupType = 'L' AND S1.Review Like 'Error%' THEN 'Log Backup ' + S1.Review -- Indicates Log Backup Error-DB in Simple Mode
    WHEN S1.BackupType = 'L' THEN 'Log Backup Obsolete' -- At this point Log Backup is Obsolete
    ELSE 'Unknown Category' END AS Review, -- Unknown Category
    S1.BackupFinished, S1.DaysOld,
    M.DBSAServerDBA_Primary AS PrimarySupportDBA,
	M.DBSAServerType AS SLA
FROM         (SELECT     TOP (100) PERCENT MAX(Date_Key) AS Date_Key, MAX(Server) AS Server, MAX([Database]) AS [Database], MAX(BackupType) 
                                              AS BackupType, MAX(Review) AS Review, MAX([Backup Finished]) AS BackupFinished, CASE WHEN MAX(BackupType) IS NOT NULL 
                                              THEN CONVERT(decimal(8, 1), DATEDIFF(HH, isnull(MAX([Backup Finished]), DATEADD(yy, - 1, getdate())), getdate()) / 24.0) 
                                              ELSE 0 END AS DaysOld
                       FROM          AdminServer.Backup_Audit_Daily
                       GROUP BY Date_Key, Server, [Database], BackupType, [Backup Finished], Review) AS S1 
INNER JOIN
	Admincontrol.DBServersAll AS M ON S1.Server = M.DBSAServerName
WHERE (S1.[Database] NOT LIKE '%Simulation' AND S1.Server = 'ACWIN-DFDBV02') --Select specific Server for exceptions
UNION
SELECT     TOP (100) PERCENT 
	S1.Date_Key, 
	M.DBSACustomerName AS CustomerName, 
	S1.Server, 
	M.DBSAServerConnection AS ServerConnection, 
	S1.[Database], 
	S1.BackupType, 
    CASE 
    WHEN S1.BackupType Is NULL THEN S1.Review
    WHEN S1.BackupType = 'D' AND S1.DaysOld < 1.25 THEN S1.Review --This determines NO DB Backup Performed
    WHEN S1.BackupType = 'D' AND S1.DaysOld < 8.0 THEN 'Check for Differential' -- This is for a Weekly Full Backup to Check for the current Differential
    WHEN S1.BackupType = 'D' THEN 'Full Backup Obsolete' -- At this point the FULL is Obsolete
    WHEN S1.BackupType = 'I' AND S1.DaysOld < 1.25 THEN S1.Review -- This indicates the Differential may not have been performed for the prior day 
    WHEN S1.BackupType = 'I' AND S1.DaysOld < 8.0 THEN 'Check for Current Full Backup' -- This indicates that a Full Backup should have been performed
    WHEN S1.BackupType = 'I' THEN 'Differential Backup Obsolete' -- At this Point Differential is obsolete 
    WHEN S1.BackupType = 'L' AND S1.DaysOld < .25 THEN S1.Review -- This indiacates the Log Backup File is 6 hours and within tolerance  
    WHEN S1.BackupType = 'L' AND S1.DaysOld < 2.0 THEN 'Check for Full or Diff Backup' -- This indicates Log Backup is old and to check a Diff or Full 
    WHEN S1.BackupType = 'L' AND S1.Review Like 'Error%' THEN 'Log Backup ' + S1.Review -- Indicates Log Backup Error-DB in Simple Mode
    WHEN S1.BackupType = 'L' THEN 'Log Backup Obsolete' -- At this point Log Backup is Obsolete
    ELSE 'Unknown Category' END AS Review, -- Unknown Category
    S1.BackupFinished, S1.DaysOld,
    M.DBSAServerDBA_Primary AS PrimarySupportDBA,
	M.DBSAServerType AS SLA
FROM         (SELECT     TOP (100) PERCENT MAX(Date_Key) AS Date_Key, MAX(Server) AS Server, MAX([Database]) AS [Database], MAX(BackupType) 
                                              AS BackupType, MAX(Review) AS Review, MAX([Backup Finished]) AS BackupFinished, CASE WHEN MAX(BackupType) IS NOT NULL 
                                              THEN CONVERT(decimal(8, 1), DATEDIFF(HH, isnull(MAX([Backup Finished]), DATEADD(yy, - 1, getdate())), getdate()) / 24.0) 
                                              ELSE 0 END AS DaysOld
                       FROM          AdminServer.Backup_Audit_Daily
                       GROUP BY Date_Key, Server, [Database], BackupType, [Backup Finished], Review) AS S1 
INNER JOIN
	AdminControl.DBServersAll AS M ON S1.Server = M.DBSAServerName
WHERE ((S1.Server NOT IN ('RRWIN-SQLPMOOD2','ACWIN-DFDBV02'))) AND DBSAManaged = 1
ORDER BY S1.Date_Key, CustomerName, S1.Server, S1.[Database], S1.BackupFinished DESC



GO
/****** Object:  View [AdminServer].[HPS_Admin_Backup_Daily_Audit_Exceptions]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Admin_Backup_Daily_Audit_Exceptions]
AS
SELECT	DBSAServerName
FROM	AdminControl.DBServersAll
WHERE	(DBSAServerType <> 'B' AND DBSAInstanceSupported <> 'N')
		AND (DBSAServerName NOT IN
                          (SELECT     Server
                            FROM          AdminServer.HPS_Admin_Backup_Daily_Audit))





GO
/****** Object:  View [AdminServer].[HPS_Admin_Backup_Daily_Audit_TopLevel]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Admin_Backup_Daily_Audit_TopLevel]
AS
	--Full Backup Not Current Check for Differential or Log Backup
	SELECT
		CAST( A.Date_Key AS DATE )					   AS Date_Key
	   ,A.[CustomerName]
	   ,A.[Server]
	   ,A.[ServerConnection]
	   ,A.[database]
	   ,A.[BackupType]
	   ,A.Review + ' - Database needs to be backed up' AS Review
	   ,A.[BackupFinished]
	   ,A.[DaysOld]
	   ,A.PrimarySupportDBA
	   ,A.sla
	FROM [AdminServer].[HPS_Admin_Backup_Daily_Audit] AS A
	WHERE (A.Review LIKE '%Full Backup Obsolete%')
	AND A.BackupType = 'D'
	UNION
	SELECT
		CAST( A.Date_Key AS DATE )				   AS Date_Key
	   ,A.[CustomerName]
	   ,A.[Server]
	   ,A.[ServerConnection]
	   ,A.[database]
	   ,A.[BackupType]
	   ,A.Review + ' - No Current Diff\Log Backup' AS Review
	   ,A.[BackupFinished]
	   ,A.[DaysOld]
	   ,A.PrimarySupportDBA
	   ,A.sla
	FROM [AdminServer].[HPS_Admin_Backup_Daily_Audit] AS A
	LEFT JOIN (
		  SELECT
			  CustomerName
			 ,[Server]
			 ,[ServerConnection]
			 ,[database]
		  FROM [AdminServer].[HPS_Admin_Backup_Daily_Audit]
		  WHERE (Review LIKE '%Diff Backup Current%' AND BackupType = 'I')
		  OR (Review LIKE '%Log Backup Current%' AND BackupType = 'L')
	) AS FC ON A.CustomerName = FC.CustomerName AND
	A.[Server] = FC.[Server] AND
	A.[database] = FC.[database]
	WHERE (A.Review LIKE '%Check for Differential%')
	AND  --OR A.Review Like '%Full Backup Obsolete%'
	A.BackupType = 'D'
	AND FC.CustomerName IS NULL
	UNION
	--Differential Backup Check - Check for Current Full or Differential
	SELECT
		CAST( A.Date_Key AS DATE )						AS Date_Key
	   ,A.[CustomerName]
	   ,A.[Server]
	   ,A.[ServerConnection]
	   ,A.[database]
	   ,A.[BackupType]
	   ,A.[Review] + ' - No Current Full or Log Backup' AS Review
	   ,A.[BackupFinished]
	   ,A.[DaysOld]
	   ,A.PrimarySupportDBA
	   ,A.sla
	FROM [AdminServer].[HPS_Admin_Backup_Daily_Audit] AS A
	LEFT JOIN (
		  SELECT
			  CustomerName
			 ,[Server]
			 ,[ServerConnection]
			 ,[database]
		  FROM [AdminServer].[HPS_Admin_Backup_Daily_Audit]
		  WHERE ((Review LIKE '%Full Backup Current%' OR Review LIKE '%Check For Differential%') AND BackupType = 'D')
		  OR (Review LIKE '%Log Backup Current%' AND BackupType = 'L')
	) AS FC ON A.CustomerName = FC.CustomerName AND
	A.[Server] = FC.[Server] AND
	A.[database] = FC.[database]
	WHERE (A.Review LIKE '%Diff Backup Not Current%' OR A.Review LIKE '%Check for Current Full Backup%' OR A.Review LIKE '%Differential Backup Obsolete%')
	AND A.BackupType = 'I'
	AND FC.CustomerName IS NULL
	UNION
	--Log Backup Current or Not Current - Check for Current Full or Diferential Backup
	SELECT
		CAST( A.Date_Key AS DATE )									AS Date_Key
	   ,A.[CustomerName]
	   ,A.[Server]
	   ,A.[ServerConnection]
	   ,A.[database]
	   ,A.[BackupType]
	   ,A.[Review] + ' - No Full or Diff Backup Less than 30 hours' AS Review
	   ,A.[BackupFinished]
	   ,A.[DaysOld]
	   ,A.PrimarySupportDBA
	   ,A.sla
	FROM [AdminServer].[HPS_Admin_Backup_Daily_Audit] AS A
	LEFT JOIN (
		  SELECT
			  CustomerName
			 ,[Server]
			 ,[ServerConnection]
			 ,[database]
		  FROM [AdminServer].[HPS_Admin_Backup_Daily_Audit]
		  WHERE ((Review LIKE '%Full Backup Current%' OR Review LIKE '%Check For Differential%') AND BackupType = 'D')
		  OR ((Review LIKE '%Diff Backup Current%' OR Review LIKE '%Check for Current Full Backup%') AND BackupType = 'I')
	) AS LC ON A.CustomerName = LC.CustomerName AND
	A.[Server] = LC.[Server] AND
	A.[database] = LC.[database]
	WHERE A.Review LIKE '%Log Backup Not Current%'
	AND A.BackupType = 'L'
	--      AND LC.CustomerName Is Null
	UNION
	--Log Backup Obsolete - Check for Current Full or Diferential Backup
	SELECT
		CAST( A.Date_Key AS DATE )								 AS Date_Key
	   ,A.[CustomerName]
	   ,A.[Server]
	   ,A.[ServerConnection]
	   ,A.[database]
	   ,A.[BackupType]
	   ,A.[Review] + ' - Full or Diff Backup Less than 30 hours' AS Review
	   ,A.[BackupFinished]
	   ,A.[DaysOld]
	   ,A.PrimarySupportDBA
	   ,A.sla
	FROM [AdminServer].[HPS_Admin_Backup_Daily_Audit] AS A
	LEFT JOIN (
		  SELECT
			  CustomerName
			 ,[Server]
			 ,[ServerConnection]
			 ,[database]
		  FROM [AdminServer].[HPS_Admin_Backup_Daily_Audit]
		  WHERE (Review LIKE '%Full Backup Current%' AND BackupType = 'D')
		  OR (Review LIKE '%Diff Backup Current%' AND BackupType = 'I')
	) AS LC ON A.CustomerName = LC.CustomerName AND
	A.[Server] = LC.[Server] AND
	A.[database] = LC.[database]
	WHERE A.Review LIKE '%Log Backup Obsolete%'
	AND A.BackupType = 'L'
	UNION
	/*
	--Log Backup Error-DB in Simple Mode
	SELECT A.[Date_Key]
	      ,A.[CustomerName]
	      ,A.[Server]
	      ,A.[Database]
	      ,A.[BackupType]
	      ,A.Review 
	      ,A.[BackupFinished]
	      ,A.[DaysOld]
	FROM [AdminServer].[HPS_Admin_Backup_Daily_Audit] AS A 
	WHERE A.Review Like '%Error%' AND A.BackupType = 'L'
	UNION
	*/
	--No Backups ever Performed
	SELECT
		CAST( A.Date_Key AS DATE ) AS Date_Key
	   ,A.[CustomerName]
	   ,A.[Server]
	   ,A.[ServerConnection]
	   ,A.[database]
	   ,A.[BackupType]
	   ,A.Review
	   ,A.[BackupFinished]
	   ,A.[DaysOld]
	   ,A.PrimarySupportDBA
	   ,A.sla
	FROM [AdminServer].[HPS_Admin_Backup_Daily_Audit] AS A
	WHERE A.Review LIKE '%NO DB%'
	AND A.BackupType IS NULL
GO
/****** Object:  View [AdminServer].[HPS_Admin_SQLServerVersion_Processor_Info_Current]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW [AdminServer].[HPS_Admin_SQLServerVersion_Processor_Info_Current]
AS
SELECT     TOP (100) PERCENT 
	S.DBSACustomerName AS CustomerName, 
	S.DBSAServerName AS ServerName, 
	V.ProductVersion, 
	V.Platform, 
	V.ProcessorCount, 
	V.ProcessorAffinity, 
	CASE	WHEN [ProcessorCount] = 1 AND [ProcessorAffinity] = '00000001'          THEN 'Affinity set'
			WHEN [ProcessorCount] = 1 AND [ProcessorAffinity] = '               1'  THEN 'Affinity set'
			WHEN [ProcessorCount] = 2 AND [ProcessorAffinity] = '               f'  THEN 'Affinity set'
			WHEN [ProcessorCount] = 2 AND [ProcessorAffinity] = '               3'  THEN 'Affinity set'
			WHEN [ProcessorCount] = 4 AND [ProcessorAffinity] = '               f'  THEN 'Affinity set'
			WHEN [ProcessorCount] = 4 AND [ProcessorAffinity] = '0000000f'		    THEN 'Affinity set'
			WHEN [ProcessorCount] = 8 AND [ProcessorAffinity] = '000000ff'          THEN 'Affinity set'
			WHEN [ProcessorCount] = 8 AND [ProcessorAffinity] = '              ff'  THEN 'Affinity set'
			WHEN [ProcessorCount] = 1 AND [ProcessorAffinity] = ', 1)'              THEN 'Affinity set'
			WHEN [ProcessorCount] = 2 AND [ProcessorAffinity] = '00000003'          THEN 'Affinity set'
			WHEN [ProcessorCount] = 24 AND [ProcessorAffinity] = '          ffffff' THEN 'Affinity set'
			WHEN [ProcessorCount] = 16 AND [ProcessorAffinity] = '            ffff' THEN 'Affinity set'
			WHEN [ProcessorCount] = 16 AND [ProcessorAffinity] = '0000ffff'         THEN 'Affinity set'
			ELSE 'Processor Affinity not set' END AS Affinity_Review, 
	V.ProcessorType
FROM  AdminServer.HPS_Export_SQLServerVersion_Current AS V INNER JOIN AdminControl.DBServersAll AS S ON
V.ServerName = S.DBSAServerName
WHERE S.DBSAManaged = 1
ORDER BY S.DBSACustomerName, S.DBSAServerName




GO
/****** Object:  View [AdminServer].[HPS_Export_DBINFO_Information_Current]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Export_DBINFO_Information_Current]
AS
SELECT     TOP (100) PERCENT Date_Key, customer, server, sla, db, crdate, dbsize, comments, updated, [by]
FROM         AdminServer.DBINFO_Information INNER JOIN AdminControl.DBServersAll ON
AdminServer.DBINFO_Information.server = AdminControl.DBServersAll.DBSAServerName
WHERE  AdminControl.DBServersAll.DBSAManaged = 1 AND  (Date_Key =
                          (SELECT     MAX(Date_Key) AS Date_Key
                            FROM          AdminServer.DBINFO_Information AS Admin_Server_DBINFO_Information_1))
ORDER BY Date_Key, customer, server, db




GO
/****** Object:  Table [AdminServer].[Database_Capacity_Review]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[Database_Capacity_Review](
	[Date_Key] [datetime] NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[FileType] [nvarchar](3) NULL,
	[DatabaseName] [varchar](128) NOT NULL,
	[FileSizeMB] [int] NOT NULL,
	[LogicalFileName] [sysname] NOT NULL,
	[DiskDrive] [varchar](500) NULL,
	[PhysicalFileName] [nvarchar](520) NOT NULL,
	[Status] [sysname] NOT NULL,
	[Updateability] [sysname] NOT NULL,
	[RecoveryMode] [sysname] NOT NULL,
	[FreeSpaceMB] [int] NOT NULL,
	[FreeSpacePct] [varchar](7) NOT NULL,
	[PollDate] [datetime] NOT NULL,
	[Applications] [varchar](256) NULL,
	[FunctionalGroups] [varchar](256) NULL,
	[Owners] [varchar](256) NULL,
	[SortOrder] [int] NOT NULL
) ON [HPS]
GO
/****** Object:  View [AdminServer].[HPS_Admin_CapacityAnalysis_Detail]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [AdminServer].[HPS_Admin_CapacityAnalysis_Detail]
AS
SELECT TOP 100 PERCENT
	   CA.[Date_Key]
      ,CA.[ServerName]
      ,CA.[FileType]
      ,CA.[DatabaseName]
      ,CA.[FileSizeMB]
      ,CA.[LogicalFileName]
      ,CA.[DiskDrive]
      ,RTRIM(CA.[PhysicalFileName]) AS PhysicalFileName
      ,CA.[Status]
      ,CA.[Updateability]
      ,CA.[RecoveryMode]
      ,ISNULL(DB.[GrowthType],' ') AS GrowthType
      ,ISNULL(DB.[Growth],' ') AS Growth
      ,CA.[FreeSpaceMB]
      ,CA.[FreeSpacePct]
      ,CA.[SortOrder]
FROM [AdminServer].[Database_Capacity_Review] AS CA INNER JOIN AdminControl.DBServersAll AS M ON 
	CA.ServerName = M.DBSAServerName
LEFT JOIN [AdminServer].[HPS_Admin_Database_IO_Information_All_Current] AS DB ON
  CA.ServerName = DB.Server_Name AND 
  CA.PhysicalFileName = DB.Physical_File_Name 
WHERE M.DBSAManaged = 1 AND 
	  CA.Date_Key = 
	  (SELECT MAX(AdminServer.Database_Capacity_Review.Date_Key) 
        FROM AdminServer.Database_Capacity_Review) 
ORDER BY CA.ServerName,  CA.DiskDrive, CA.SortOrder, CA.PhysicalFileName
GO
/****** Object:  UserDefinedFunction [AdminControl].[GetEasterHolidays]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [AdminControl].[GetEasterHolidays](@year INT) 
RETURNS TABLE
WITH SCHEMABINDING
AS 
RETURN 
(
  WITH x AS 
  (
    SELECT [Date] = CONVERT(DATE, RTRIM(@year) + '0' + RTRIM([Month]) 
        + RIGHT('0' + RTRIM([Day]),2))
      FROM (SELECT [Month], [Day] = DaysToSunday + 28 - (31 * ([Month] / 4))
      FROM (SELECT [Month] = 3 + (DaysToSunday + 40) / 44, DaysToSunday
      FROM (SELECT DaysToSunday = paschal - ((@year + @year / 4 + paschal - 13) % 7)
      FROM (SELECT paschal = epact - (epact / 28)
      FROM (SELECT epact = (24 + 19 * (@year % 19)) % 30) 
        AS epact) AS paschal) AS dts) AS m) AS d
  )
  SELECT [Date], HolidayName = 'Easter Sunday' FROM x
    UNION ALL SELECT DATEADD(DAY,-2,[Date]), 'Good Friday'   FROM x
    UNION ALL SELECT DATEADD(DAY, 1,[Date]), 'Easter Monday' FROM x
);
GO
/****** Object:  UserDefinedFunction [dbo].[fnGetBackupHistory]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[fnGetBackupHistory] ( @Db		   VARCHAR(128)
										  ,@BackupMode VARCHAR(5) = NULL
										  ,@Date	   DATETIME	  = NULL
										  ,@Rank	   SMALLINT	  = NULL )
RETURNS TABLE
AS
	/*************************************************************************************************
	Purpose: This Function helps to pull the last backup history for input database which are on DISK.

	*************************************************************************************************
	Author           Date                 Version         Comments
	*************************************************************************************************
	Harsha Vasa     05/14/2015             1.0.0          Initial Draft
	
	
	Notes
	*************************************************************************************************
	eg : select * from fnGetBackupHistory('DBA','FULL',DateAdd(dd,-1,Getdate()),1)
	*************************************************************************************************/
	RETURN (
	WITH baseline
	AS (
		  SELECT
			  bs.backup_set_id
			 ,bs.server_name
			 ,bs.database_name
			 ,bs.backup_finish_date																					AS LastBackupDate
			 ,DATEDIFF( SECOND,bs.backup_start_date,bs.backup_finish_date )											AS [timeTaken(Sec)]
			 ,bs.[type]
			 ,CAST( (COALESCE( bs.compressed_backup_size,bs.backup_size ) * 1.0) / (1024 * 1024) AS NUMERIC(15,2) ) AS [bkSize(MB)]
			 ,CASE
				  WHEN bs.is_copy_only = 1 THEN 'Yes'
				  ELSE 'No'
			  END																									AS [Is_CopyOnly]
			 ,bmf.physical_device_name																				AS bkpath
			 ,bs.first_lsn
			 ,bs.last_lsn
			 ,bs.checkpoint_lsn
			 ,bs.database_backup_lsn
		  FROM msdb.dbo.backupset AS bs
		  INNER JOIN msdb.dbo.backupmediafamily AS bmf ON bmf.media_set_id = bs.media_set_id
		  WHERE bs.database_name = @Db
		  AND bs.backup_finish_date >=
									  CASE
										  WHEN @Date IS NOT NULL THEN @Date
										  ELSE CAST( '01/01/1900' AS DATETIME )
									  END
		  AND bs.backup_finish_date <= GETDATE()

		  AND bs.[type] LIKE CASE
			  WHEN @BackupMode = 'FULL' THEN 'D'
			  WHEN @BackupMode = 'DIFF' THEN 'I'
			  WHEN @BackupMode = 'LOG' THEN 'L'
			  ELSE '%'
		  END
		  AND bmf.device_type = 2 -- Disk

	),
	ranking
	AS (
		  SELECT
			  backup_set_id
			 ,server_name
			 ,database_name
			 ,F_Type.BackupType
			 ,LastBackupDate
			 ,bkpath
			 ,[timeTaken(Sec)]
			 ,[bkSize(MB)]
			 ,Is_CopyOnly
			 ,first_lsn
			 ,last_lsn
			 ,checkpoint_lsn
			 ,database_backup_lsn
			 ,DENSE_RANK() OVER (PARTITION BY database_name,[type] ORDER BY backup_set_id DESC) AS dr
		  FROM baseline
		  CROSS APPLY (SELECT BackupType = CASE [type] WHEN 'D' THEN 'Full' WHEN 'I' THEN 'Diff' WHEN 'L' THEN 'Log' ELSE NULL END) F_Type
	)

	SELECT
		backup_set_id
	   ,server_name
	   ,database_name
	   ,BackupType
	   ,LastBackupDate
	   ,bkpath
	   ,[timeTaken(Sec)]
	   ,[bkSize(MB)]
	   ,Is_CopyOnly
	   ,first_lsn
	   ,last_lsn
	   ,checkpoint_lsn
	   ,database_backup_lsn
	FROM ranking
	WHERE dr <= COALESCE( @Rank,999 )
	)
GO
/****** Object:  UserDefinedFunction [dbo].[fnGetIndexFragementationOfDatabase]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[fnGetIndexFragementationOfDatabase] (@db_name NVARCHAR(256) = NULL)
RETURNS TABLE
AS
	RETURN (
		  SELECT
			  DB_NAME( [dm_db_index_physical_stats].database_id )	  AS DatabaseName
			 ,schemas.[name]										  AS SchemaName
			 ,objects.[name]										  AS ObjectName
			 ,indexes.[name]										  AS IndexName
			 ,objects.type_desc										  AS ObjectType
			 ,indexes.type_desc										  AS IndexType
			 ,dm_db_index_physical_stats.partition_number			  AS PartitionNumber
			 ,dm_db_index_physical_stats.page_count					  AS [PageCount]
			 ,dm_db_index_physical_stats.avg_fragmentation_in_percent AS AvgFragmentationInPercent
		  FROM sys.dm_db_index_physical_stats( DB_ID( @db_name ),NULL,NULL,NULL,'LIMITED' ) [dm_db_index_physical_stats]
		  INNER JOIN sys.indexes [indexes] ON dm_db_index_physical_stats.[object_id] = indexes.[object_id] AND dm_db_index_physical_stats.index_id = indexes.index_id
		  INNER JOIN sys.objects [objects] ON indexes.[object_id] = objects.[object_id]
		  INNER JOIN sys.schemas [schemas] ON objects.[schema_id] = schemas.[schema_id]
		  WHERE objects.[type] IN ('U','V')
		  AND objects.is_ms_shipped = 0
		  AND indexes.[type] IN (1,2,3,4)
		  AND indexes.is_disabled = 0
		  AND indexes.is_hypothetical = 0
		  AND dm_db_index_physical_stats.alloc_unit_type_desc = 'IN_ROW_DATA'
		  AND dm_db_index_physical_stats.index_level = 0
		  AND dm_db_index_physical_stats.page_count >= 1000
	)
GO
/****** Object:  UserDefinedFunction [dbo].[fnGetSqlVersion]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[fnGetSqlVersion] ()
RETURNS TABLE
AS
	RETURN (
		  SELECT
			  SERVERPROPERTY( 'ServerName' )																AS ServerName
			 ,SERVERPROPERTY( 'MachineName' )																AS MachineName
			 ,SERVERPROPERTY( 'Edition' )																	AS Edition
			 ,COALESCE( SERVERPROPERTY( 'Instancename' ),'default - MS SQLServer' )							AS InstanceName
			 ,CASE CAST( PARSENAME( CAST( SERVERPROPERTY( 'ProductVersion' ) AS NVARCHAR(128) ),4 ) AS TINYINT )
			      WHEN 15 THEN '2019'
				  WHEN 14 THEN '2017'
				  WHEN 13 THEN '2016'
				  WHEN 12 THEN '2014'
				  WHEN 11 THEN '2012'
				  WHEN 10 THEN CASE
					  WHEN CAST( PARSENAME( CAST( SERVERPROPERTY( 'ProductVersion' ) AS NVARCHAR(128) ),3 ) AS TINYINT ) = 0 THEN '2008'
					  ELSE '2008R2'
				  END
				  WHEN 9 THEN '2005'
				  ELSE 'Unsupported Version'
			  END																							AS SqlVersion
			 ,CAST( PARSENAME( CAST( SERVERPROPERTY( 'ProductVersion' ) AS NVARCHAR(128) ),4 ) AS TINYINT ) AS MajorVersion
			 ,CAST( PARSENAME( CAST( SERVERPROPERTY( 'ProductVersion' ) AS NVARCHAR(128) ),3 ) AS TINYINT ) AS MinorVersion
			 ,SERVERPROPERTY( 'ProductVersion' )															AS VersionNumber
			 ,SERVERPROPERTY( 'ProductLevel' )																AS ServicePack
			 ,SERVERPROPERTY( 'ProcessId' )																	AS ProcessId
			 ,COALESCE( SERVERPROPERTY( 'ProductUpdatelevel' ),'NA' )										AS CU#
			 ,SERVERPROPERTY( 'ComputerNamePhysicalNetBIOS' )												AS ComputerName
	);
GO
/****** Object:  UserDefinedFunction [dbo].[fnParseDeadlockEvent]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[fnParseDeadlockEvent] ()
RETURNS TABLE
AS
	/***************************************************************************************************************************************
	
	Purpose: To retrieve deadlock count on the instance from Extended Event default session
	
	History:
	------------------------------------------------------------------------------------------------------------------------------------
	Author                                 Date Created                Comments
	------------------------------------------------------------------------------------------------------------------------------------
	Harsha vasa                              2016-07-07                 Baseline version
	
	
	***************************************************************************************************************************************/
	RETURN (
	WITH deadlock
	AS (
		  SELECT
			  DATEADD( mi,DATEDIFF( mi,GETUTCDATE(),GETDATE() ),xed.value( '@timestamp','datetime' ) ) AS EventDate
			 ,CAST( xed.value( '.','nvarchar(max)' ) AS XML )										   AS DeadLockXml
		  FROM (
				SELECT
					ca.xevent.query( '.' ) AS target_data
				FROM sys.dm_xe_session_targets AS xt
				INNER JOIN sys.dm_xe_sessions AS xs ON xs.[address] = xt.event_session_address
				CROSS APPLY (SELECT CAST( xt.target_data AS XML ) AS xevent) ca
				WHERE xs.name = N'system_health'
				AND xt.target_name = N'ring_buffer'
				AND ca.xevent.exist( 'RingBufferTarget/event[@name="xml_deadlock_report"]' ) = 1
		  ) AS XML_Data
		  CROSS APPLY target_data.nodes( 'RingBufferTarget/event[@name="xml_deadlock_report"]' ) AS XEventData (xed)

	)

	SELECT TOP 100 PERCENT
		EventDate
	   ,DeadLockXml.value( '(/deadlock/victim-list/victimProcess/@id)[1]','VARCHAR(MAX)' )														   AS VictimProcessId
	   ,DB_NAME( DeadLockXml.value( '(/deadlock/process-list/process/@currentdb)[1]','INT' ) )													   AS DatabaseName
		-- ,OBJECT_NAME( DeadLockXml.value( '(/deadlock/resource-list/keylock/@associatedObjectId)[1]','BIGINT' ),DeadLockXml.value( '(/deadlock/resource-list/keylock/@dbid)[1]','INT' ) ) AS ObjectName
	   ,DeadLockXml.value( '(/deadlock/process-list/process/@waitresource)[1]','VARCHAR(MAX)' )													   AS WaitResource
	   ,NULLIF( DeadLockXml.value( '(/deadlock/process-list/process/@transactionname)[1]','VARCHAR(MAX)' ),'' )									   AS TransactionName
	   ,DATEADD( mi,DATEDIFF( mi,GETUTCDATE(),GETDATE() ),DeadLockXml.value( '(/deadlock/process-list/process/@lasttranstarted)[1]','datetime' ) ) AS LastTransactionStartTime
	   ,DeadLockXml.value( '(/deadlock/process-list/process/@lockMode)[1]','VARCHAR(MAX)' )														   AS LockMode
	   ,DeadLockXml.value( '(/deadlock/process-list/process/@spid)[1]','INT' )																	   AS VictimSessionID
	   ,DeadLockXml.value( '(/deadlock/process-list/process/@clientapp)[1]','VARCHAR(MAX)' )													   AS ClientApplicationName
	   ,DeadLockXml.value( '(/deadlock/process-list/process/@hostname)[1]','VARCHAR(MAX)' )														   AS ClientHostName
	   ,DeadLockXml.value( '(/deadlock/process-list/process/@loginname)[1]','VARCHAR(MAX)' )													   AS LoginName
	   ,DeadLockXml.value( '(/deadlock/process-list/process/executionStack/frame/@sqlhandle)[1]','NVARCHAR(MAX)' )								   AS SqlHandle
	   ,DeadLockXml.value( '(/deadlock/process-list/process/inputbuf)[1]','NVARCHAR(MAX)' )														   AS InputBuffer
	   ,DeadLockXml																																   AS DeadLockXml
	FROM deadlock
	ORDER BY EventDate DESC
	)
	/*
	SELECT creation_date,EventXML,v.victimid,process.*,victim.*,rsc.*
	
	
			  --,OBJECT_NAME(EventXML.value('(/Object/@Id)[1]','INT'),EventXML.value('(/Database/@Id)[1]','INT')) AS obj_name
		FROM deadlock
		CROSS APPLY EventXML.nodes('/deadlock') AS t(c)
		CROSS APPLY (SELECT c.value('(victim-list/victimProcess/@id)[1]','varchar(1024)') AS victimid) AS v
		CROSS APPLY (SELECT c.value('(process-list/process/@id)[1]','varchar(1024)') AS Processid,
		                    c.value('(process-list/process/@waitresource)[1]','varchar(max)') AS ProcessWaitResource,
							--c.value('(process-list/process/@lockMode)[1]','varchar(24)') AS ProceessLockMode,
							c.value('(process-list/process/@hostname)[1]','varchar(1024)') AS ProcessHostName,
							c.value('(process-list/process/@loginname)[1]','varchar(1024)') AS ProcessLoginName,
							DB_NAME(c.value('(process-list/process/@currentdb)[1]','int')) AS ProcessDatabaseName,
							--c.value('(process-list/process/executionStack/frame/@sqlhandle)[1]','varbinary(max)') AS ProcessSQLHandle,
							c.value('(process-list/process/inputbuf)[1]','varchar(max)') AS ProcessSQLStatement
							) AS process
	    CROSS APPLY (SELECT c.value('(process-list/process/@id)[2]','varchar(1024)') AS Processid,
		                    c.value('(process-list/process/@waitresource)[2]','varchar(max)') AS ProcessWaitResource,
							--c.value('(process-list/process/@lockMode)[2]','varchar(24)') AS ProceessLockMode,
							c.value('(process-list/process/@hostname)[2]','varchar(1024)') AS ProcessHostName,
							c.value('(process-list/process/@loginname)[2]','varchar(1024)') AS ProcessLoginName,
							DB_NAME(c.value('(process-list/process/@currentdb)[2]','int')) AS ProcessDatabaseName,
							--c.value('(process-list/process/executionStack/frame/@sqlhandle)[2]','varbinary(max)') AS ProcessSQLHandle,
							c.value('(process-list/process/inputbuf)[2]','varchar(max)') AS ProcessSQLStatement
							) AS victim
	        CROSS APPLY (SELECT
								c.value('(resource-list/keylock/@hobtid)[1]','bigint') AS hobtid1,
								c.value('(resource-list/keylock/owner-list/owner/@id)[1]','varchar(1024)') AS ownerprocessid1,
								NULLIF(c.value('(resource-list/keylock/@objectname)[1]','varchar(1024)'),'') AS objname1,
								NULLIF(c.value('(resource-list/keylock/@indexname)[1]','varchar(1024)'),'') AS idxname1,
								c.value('(resource-list/keylock/owner-list/owner/@mode)[1]','varchar(1024)') AS ownerlockmode1,
								c.value('(resource-list/keylock/waiter-list/waiter/@id)[1]','varchar(1024)') AS waiterprocessid1,
								c.value('(resource-list/keylock/waiter-list/waiter/@mode)[1]','varchar(1024)') AS waiterlockmode1,
								c.value('(resource-list/keylock/@hobtid)[2]','bigint') AS hobtid2,
								c.value('(resource-list/keylock/owner-list/owner/@id)[2]','varchar(1024)') AS ownerprocessid2,
								NULLIF(c.value('(resource-list/keylock/@objectname)[2]','varchar(1024)'),'') AS objname2,
								NULLIF(c.value('(resource-list/keylock/@indexname)[2]','varchar(1024)'),'') AS idxname2,
								c.value('(resource-list/keylock/owner-list/owner/@mode)[2]','varchar(1024)') AS ownerlockmode2,
								c.value('(resource-list/keylock/waiter-list/waiter/@id)[2]','varchar(1024)') AS waiterprocessid2,
								c.value('(resource-list/keylock/waiter-list/waiter/@mode)[2]','varchar(1024)') AS waiterlockmode2
	
	
	
	
			) rsc
	*/
GO
/****** Object:  UserDefinedFunction [dbo].[fnUserSystemDbs]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[fnUserSystemDbs] ()
RETURNS TABLE
AS
	RETURN (
		  SELECT TOP 10
			  [name] COLLATE database_default AS [DatabaseName]
		  FROM sys.databases
		  WHERE [name] IN (DB_NAME(),'ReportServer','ReportServerTempDB','distribution')
		  ORDER BY database_id
	)
GO
/****** Object:  Table [AdminControl].[Backup_Audit_Tracking]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminControl].[Backup_Audit_Tracking](
	[BAT_KEY] [int] IDENTITY(1,1) NOT NULL,
	[BAT_CustomerName] [varchar](128) NOT NULL,
	[BAT_PRODServerName] [varchar](128) NOT NULL,
	[BAT_TargetServerName] [varchar](128) NULL,
	[BAT_Schedule] [varchar](80) NULL,
	[BAT_Last_Test_Date] [datetime] NULL,
	[BAT_Last_Test_Results] [varchar](256) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [AdminControl].[DateDim]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminControl].[DateDim](
	[DateKey] [int] IDENTITY(1,1) NOT NULL,
	[ActualDate] [datetime] NOT NULL,
	[Year] [int] NOT NULL,
	[Quarter] [int] NOT NULL,
	[Month] [int] NOT NULL,
	[Week] [int] NOT NULL,
	[DayofYear] [int] NOT NULL,
	[DayofMonth] [int] NOT NULL,
	[DayofWeek] [int] NOT NULL,
	[IsWeekend] [bit] NOT NULL,
	[IsHoliday] [bit] NOT NULL,
	[Comments] [varchar](20) NULL,
	[CalendarWeek] [int] NOT NULL,
	[BusinessYearWeek] [int] NOT NULL,
	[LeapYear] [tinyint] NOT NULL
) ON [HPS]
GO
/****** Object:  Table [AdminControl].[DateDimension]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminControl].[DateDimension](
	[DateKey] [int] NOT NULL,
	[Date] [date] NOT NULL,
	[Day] [tinyint] NOT NULL,
	[DaySuffix] [char](2) NOT NULL,
	[Weekday] [tinyint] NOT NULL,
	[WeekDayName] [varchar](10) NOT NULL,
	[IsWeekend] [bit] NOT NULL,
	[IsHoliday] [bit] NOT NULL,
	[HolidayText] [varchar](64) SPARSE  NULL,
	[DOWInMonth] [tinyint] NOT NULL,
	[DayOfYear] [smallint] NOT NULL,
	[WeekOfMonth] [tinyint] NOT NULL,
	[WeekOfYear] [tinyint] NOT NULL,
	[ISOWeekOfYear] [tinyint] NOT NULL,
	[Month] [tinyint] NOT NULL,
	[MonthName] [varchar](10) NOT NULL,
	[Quarter] [tinyint] NOT NULL,
	[QuarterName] [varchar](6) NOT NULL,
	[Year] [int] NOT NULL,
	[MMYYYY] [char](6) NOT NULL,
	[MonthYear] [char](7) NOT NULL,
	[FirstDayOfMonth] [date] NOT NULL,
	[LastDayOfMonth] [date] NOT NULL,
	[FirstDayOfQuarter] [date] NOT NULL,
	[LastDayOfQuarter] [date] NOT NULL,
	[FirstDayOfYear] [date] NOT NULL,
	[LastDayOfYear] [date] NOT NULL,
	[FirstDayOfNextMonth] [date] NOT NULL,
	[FirstDayOfNextYear] [date] NOT NULL,
	[LeapYear] [tinyint] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[DateKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [HPS]
) ON [HPS]
GO
/****** Object:  Table [AdminControl].[DBAAssignments]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminControl].[DBAAssignments](
	[Date_Key] [datetime] NOT NULL,
	[CustomerName] [varchar](128) NOT NULL,
	[ServerName] [varchar](128) NOT NULL,
	[ServerDBA_Primary] [varchar](50) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminControl].[DBServer]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminControl].[DBServer](
	[ID] [int] NULL,
	[SqlInstance] [varchar](50) NULL,
	[Status] [varchar](2) NULL,
	[HostName] [varchar](50) NULL,
	[Category] [varchar](10) NULL,
	[Application] [varchar](50) NULL,
	[AppContact] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [AdminControl].[DBServersAll_Decommed]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminControl].[DBServersAll_Decommed](
	[DBServersAllKEY] [int] NOT NULL,
	[DBSACustomerName] [varchar](128) NOT NULL,
	[DBSAServerName] [varchar](128) NOT NULL,
	[DBSAServerConnection] [varchar](128) NOT NULL,
	[DBSAServerConnectionMethod] [varchar](50) NULL,
	[DBSADomain] [varchar](80) NOT NULL,
	[DBSAServerType] [varchar](2) NOT NULL,
	[DBSAActive] [bit] NOT NULL,
	[DBSAManaged] [bit] NULL,
	[DBSAJobHistory] [bit] NOT NULL,
	[DBSABackupHistory] [bit] NOT NULL,
	[DBSATableLevel] [bit] NOT NULL,
	[DBSALoginsDetail] [bit] NOT NULL,
	[DBSADTSPackages] [bit] NOT NULL,
	[DBSAInstanceBilled] [char](2) NULL,
	[DBSAInstanceSupported] [char](2) NULL,
	[DBSADescription] [varchar](250) NULL,
	[DBSADiskCapacityAllocationMB] [int] NULL,
	[DBSALightSpeed] [bit] NOT NULL,
	[DBSAClustered] [bit] NOT NULL,
	[DBSASANAttached] [bit] NOT NULL,
	[DBSAProcessors] [int] NULL,
	[DBSAServerDBA_Primary] [varchar](50) NULL,
	[DBSAServerDBA_Secondary] [varchar](50) NULL,
	[DBSABackupRepository] [varchar](256) NULL,
	[DBSASANName] [varchar](50) NULL,
	[DBSAServerIPAddress] [varchar](25) NULL,
	[DBSAServerClusterdNode1IPAddress] [varchar](25) NULL,
	[DBSAServerClusterdNode2IPAddress] [varchar](25) NULL,
	[DBSAServerClusterdNode3IPAddress] [varchar](25) NULL,
	[DBSAServerClusterdNode4IPAddress] [varchar](25) NULL,
	[DBSAServerClusterdIPAddress] [varchar](25) NULL,
	[DBSASpotlightDayTimeMonitoring] [varchar](64) NULL,
	[DBSAServerClusterdVirtualName] [varchar](128) NULL,
	[DBSAServerClusterdNode1Name] [varchar](128) NULL,
	[DBSAServerClusterdNode2Name] [varchar](128) NULL,
	[DBSAServerClusterdNode3Name] [varchar](128) NULL,
	[DBSAServerClusterdNode4Name] [varchar](128) NULL,
	[DBSAServerIPAddress_NAT] [varchar](25) NULL,
	[DBSAInstallationType] [varchar](50) NULL,
	[DBSAVirtualMachine] [bit] NULL,
	[DBSAPortNumber] [int] NULL,
	[DBSAUpdateDate] [datetime] NULL,
	[DBSAUpdateBy] [varchar](25) NULL,
	[DBSAOffshoreAllowed] [char](2) NULL,
	[DBSAServerClusteredPreferredNode] [varchar](128) NULL,
	[DBSASLA] [varchar](2) NULL,
	[DBSAMaintSchedule] [varchar](128) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminControl].[DBServersAll_SpinOffMapping]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminControl].[DBServersAll_SpinOffMapping](
	[CompanyName] [varchar](128) NOT NULL,
	[CurrentDatabaseEnvironmentName] [varchar](128) NOT NULL,
	[TargetDatabaseEnvironmentName] [varchar](128) NOT NULL,
	[MigrationMethodology] [varchar](128) NULL,
	[MigrationType] [char](1) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminControl].[Environment_Diagram_Tracking]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminControl].[Environment_Diagram_Tracking](
	[DatabaseEnvironmentName] [nvarchar](50) NULL,
	[DiagramComplete] [datetime] NULL,
	[DiagramFileLocation] [nvarchar](500) NULL,
	[DiagramFileName] [nvarchar](500) NULL,
	[UploadedToGoogle] [bit] NULL,
	[UploadedToSharePoint] [bit] NULL
) ON [HPS]
GO
/****** Object:  Table [AdminControl].[Server_CPU_Core_Counts_Information]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminControl].[Server_CPU_Core_Counts_Information](
	[SCCCI_Location] [varchar](128) NOT NULL,
	[SCCCI_CustomerName] [varchar](128) NOT NULL,
	[SCCCI_MachineName] [varchar](128) NOT NULL,
	[SCCCI_DatabaseEnvironmentName] [varchar](128) NULL,
	[SCCCI_ProductVersion] [varchar](128) NULL,
	[SCCCI_Edition] [varchar](128) NULL,
	[SCCCI_ProductLevel] [varchar](128) NULL,
	[SCCCI_ServerType] [varchar](128) NULL,
	[SCCCI_ServerModel] [varchar](128) NULL,
	[SCCCI_ServerMake] [varchar](128) NULL,
	[SCCCI_Physical-VirtualCPUCount] [int] NULL,
	[SCCCI_LogicalCPUCount] [int] NULL,
	[SCCCI_CoreCount] [int] NULL,
	[SCCCI_LicenseCoresCount] [int] NULL,
	[SCCCI_ProcessorType] [varchar](128) NULL,
	[SCCCI_IsClustered] [varchar](50) NULL,
	[SCCCI_Hyperthreaded] [varchar](128) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminControl].[Wait_Type_Description]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminControl].[Wait_Type_Description](
	[Wait_type] [varchar](50) NOT NULL,
	[Wait_Type_desc] [varchar](8000) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [AdminLog].[DTSPackages]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[DTSPackages](
	[DTSPackagesKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminLog].[SSISPackages]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminLog].[SSISPackages](
	[SSISPackagesKey] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](255) NOT NULL,
	[RunDate] [datetime] NOT NULL,
	[RunResults] [nvarchar](255) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [AdminServer].[BestPractices_Repository]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[BestPractices_Repository](
	[Date_Key] [datetime] NOT NULL,
	[instance_name] [varchar](255) NULL,
	[best_practice_name] [varchar](255) NULL,
	[notes] [varchar](8000) NULL,
	[steps] [varchar](8000) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminServer].[Database_Owners_Information]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[Database_Owners_Information](
	[Date_Key] [datetime] NULL,
	[customer] [nvarchar](128) NULL,
	[server] [nvarchar](128) NULL,
	[SLA] [nvarchar](255) NULL,
	[db] [nvarchar](128) NULL,
	[crdate] [datetime] NULL,
	[dbsize] [float] NULL,
	[ProductName] [nvarchar](255) NULL,
	[ProductLevel] [nvarchar](255) NULL,
	[ProductVersion] [nvarchar](255) NULL,
	[updated] [datetime] NULL,
	[by] [nvarchar](255) NULL,
	[Application] [nvarchar](255) NULL,
	[Owners] [nvarchar](255) NULL,
	[Functional Group] [nvarchar](255) NULL,
	[VP] [nvarchar](255) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminServer].[Database_Role_Memberships]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[Database_Role_Memberships](
	[Date_Key] [datetime] NOT NULL,
	[ServerName] [varchar](128) NULL,
	[DatabaseName] [nvarchar](128) NULL,
	[UserName] [nvarchar](128) NULL,
	[DBRoleName] [nvarchar](128) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminServer].[Database_Roles]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[Database_Roles](
	[Date_Key] [datetime] NOT NULL,
	[ServerName] [varchar](128) NULL,
	[DBName] [nvarchar](128) NULL,
	[DBRole] [nvarchar](128) NOT NULL,
	[DBRoleMember] [nvarchar](128) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [AdminServer].[Disk_Space_Repository_MountPoints]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[Disk_Space_Repository_MountPoints](
	[Date_Key] [datetime] NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[MountPoint] [varchar](60) NOT NULL,
	[TotalDiskSpaceMB] [numeric](18, 0) NULL,
	[FreeDiskSpaceMB] [numeric](18, 0) NULL,
	[UsedDiskSpaceMB] [numeric](18, 0) NULL,
	[PercentageFree] [numeric](4, 2) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminServer].[IpAddress_TimeZone]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[IpAddress_TimeZone](
	[SqlInstance] [nvarchar](max) NULL,
	[MachineName] [nvarchar](max) NULL,
	[IPAddress] [nvarchar](max) NULL,
	[TimeZoneOffset] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [AdminServer].[JobInformation_Repository]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[JobInformation_Repository](
	[ServerName] [nvarchar](128) NOT NULL,
	[JobName] [nvarchar](128) NOT NULL,
	[Category] [nvarchar](128) NOT NULL,
	[JobEnabled] [nvarchar](3) NOT NULL,
	[IsScheduled] [nvarchar](3) NOT NULL,
	[StepNo] [int] NOT NULL,
	[StepName] [nvarchar](128) NOT NULL,
	[StepType] [nvarchar](128) NOT NULL,
	[RunAs] [nvarchar](128) NULL,
	[Database] [nvarchar](128) NULL,
	[ExecutableCommand] [nvarchar](max) NULL,
	[OnSuccessAction] [nvarchar](128) NOT NULL,
	[RetryAttempts] [int] NOT NULL,
	[RetryInterval (Minutes)] [int] NOT NULL,
	[OnFailureAction] [nvarchar](128) NOT NULL,
	[JobScheduleName] [nvarchar](128) NULL,
	[JobDeletionCriterion] [nvarchar](20) NOT NULL,
	[ScheduleEnabled] [nvarchar](3) NULL,
	[ScheduleType] [nvarchar](128) NULL,
	[Occurrence] [nvarchar](128) NULL,
	[Recurrence] [nvarchar](128) NULL,
	[Frequency] [nvarchar](128) NULL,
	[ScheduleUsageStartDate] [datetime] NULL,
	[ScheduleUsageEndDate] [datetime] NULL,
	[ScheduleCreatedOn] [datetime] NULL,
	[ScheduleLastModifiedOn] [datetime] NULL
) ON [HPS] TEXTIMAGE_ON [HPS]
GO
/****** Object:  Table [AdminServer].[Logins_Upload]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[Logins_Upload](
	[Country] [nvarchar](255) NULL,
	[State] [nvarchar](255) NULL,
	[City] [nvarchar](255) NULL,
	[Location] [nvarchar](255) NULL,
	[Full Name] [nvarchar](255) NULL,
	[Title] [nvarchar](255) NULL,
	[Division] [nvarchar](255) NULL,
	[Dept Cost Center] [nvarchar](255) NULL,
	[Employee ID] [nvarchar](255) NULL,
	[Category] [nvarchar](255) NULL,
	[Status] [nvarchar](255) NULL,
	[Network ID] [nvarchar](255) NULL,
	[EMail] [nvarchar](255) NULL,
	[Termination Date] [nvarchar](255) NULL,
	[Report Period] [nvarchar](255) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [AdminServer].[MSDN_Audit_AD_Group_Members]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[MSDN_Audit_AD_Group_Members](
	[account name] [nvarchar](128) NULL,
	[type] [nvarchar](50) NULL,
	[privilege] [nvarchar](128) NULL,
	[mapped login name] [nvarchar](128) NULL,
	[permission path] [nvarchar](128) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [AdminServer].[MSDN_Audit_AD_Import]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[MSDN_Audit_AD_Import](
	[division] [nvarchar](256) NULL,
	[department] [nvarchar](256) NULL,
	[physicalDeliveryOfficeName] [nvarchar](256) NULL,
	[mobile] [nvarchar](256) NULL,
	[telephoneNumber] [nvarchar](256) NULL,
	[mail] [nvarchar](256) NULL,
	[displayName] [nvarchar](256) NULL,
	[sAMAccountName] [nvarchar](259) NULL,
	[sn] [nvarchar](256) NULL,
	[givenName] [nvarchar](256) NULL,
	[employeeNumber] [nvarchar](256) NULL,
	[manager] [nvarchar](256) NULL,
	[userAccountControl] [int] NULL,
	[UAC_BIT2] [int] NULL,
	[Disabled] [varchar](3) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [AdminServer].[MSDN_Audit_Intranet_Import]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[MSDN_Audit_Intranet_Import](
	[Employee_ID] [varchar](20) NOT NULL,
	[Full_Name] [nvarchar](101) NULL,
	[Manager_ID] [varchar](20) NOT NULL,
	[Manager_Name] [nvarchar](101) NULL,
	[COST_CENTER] [varchar](75) NULL,
	[LOC_CODE] [varchar](10) NULL,
	[LOC_NAME] [varchar](50) NULL,
	[Manager_Title] [nvarchar](50) NULL,
	[Employee_Title] [nvarchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [AdminServer].[MSDN_Audit_Logins_SQLServer]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[MSDN_Audit_Logins_SQLServer](
	[Date_Key] [datetime] NULL,
	[Server] [nvarchar](128) NULL,
	[Login Name] [nvarchar](128) NULL,
	[Default Database] [nvarchar](128) NULL,
	[CreateDate] [datetime] NULL,
	[UpdateDate] [datetime] NULL,
	[AccDate] [datetime] NULL,
	[NT Name] [float] NULL,
	[NT Grp] [float] NULL,
	[NT User] [float] NULL,
	[Sys Adm] [float] NULL,
	[Sec Adm] [float] NULL,
	[Srvr Adm] [float] NULL,
	[Setup Adm] [float] NULL,
	[Proc Adm] [float] NULL,
	[Disk Adm] [float] NULL,
	[DB Creator] [float] NULL,
	[Bulk Adm] [float] NULL
) ON [HPS]
GO
/****** Object:  Table [AdminServer].[Server_Service_Information]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[Server_Service_Information](
	[Date_Key] [datetime] NULL,
	[Server_Name] [sysname] NULL,
	[ServiceName] [varchar](100) NULL,
	[ServiceOwner] [varchar](100) NULL,
	[ServiceStartTp] [varchar](100) NOT NULL,
	[ServiceBinary] [varchar](150) NULL
) ON [HPS]
GO
/****** Object:  Table [AdminServer].[ServerUpTime]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[ServerUpTime](
	[DateKey] [datetime2](7) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[WindowsBootTime] [datetime2](7) NULL,
	[SqlStartTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [AdminServer].[SQL_ErrorLog]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[SQL_ErrorLog](
	[LogID] [bigint] IDENTITY(1,1) NOT NULL,
	[LogDate] [datetime] NULL,
	[ProcessInfo] [nvarchar](50) NULL,
	[Text] [nvarchar](max) NULL,
	[Server] [sysname] NULL
) ON [HPS] TEXTIMAGE_ON [HPS]
GO
/****** Object:  Table [AdminServer].[SQLIO_Import]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[SQLIO_Import](
	[RowID] [int] IDENTITY(1,1) NOT NULL,
	[ParameterRowID] [int] NULL,
	[ResultText] [varchar](max) NULL,
 CONSTRAINT [PK_SQLIO_Import] PRIMARY KEY CLUSTERED 
(
	[RowID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [HPS]
) ON [HPS] TEXTIMAGE_ON [HPS]
GO
/****** Object:  Table [AdminServer].[SQLIO_TestPass]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[SQLIO_TestPass](
	[TestPassID] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[FileName] [nvarchar](126) NOT NULL,
	[DriveQty] [int] NOT NULL,
	[DriveRPM] [int] NOT NULL,
	[DriveRaidLevel] [nvarchar](10) NOT NULL,
	[TestDate] [datetime] NOT NULL,
	[SANmodel] [nvarchar](50) NOT NULL,
	[SANfirmware] [nvarchar](50) NULL,
	[PartitionOffset] [int] NULL,
	[Filesystem] [nvarchar](50) NULL,
	[FSClusterSizeBytes] [int] NULL,
	[SQLIO_Version] [nvarchar](20) NULL,
	[Threads] [int] NULL,
	[ReadOrWrite] [nchar](1) NULL,
	[DurationSeconds] [int] NULL,
	[SectorSizeKB] [int] NULL,
	[IOpattern] [nvarchar](50) NULL,
	[IOsOutstanding] [int] NULL,
	[Buffering] [nvarchar](50) NULL,
	[FileSizeMB] [int] NULL,
	[IOs_Sec] [decimal](18, 0) NULL,
	[MBs_Sec] [decimal](18, 0) NULL,
	[LatencyMS_Min] [int] NULL,
	[LatencyMS_Avg] [int] NULL,
	[LatencyMS_Max] [int] NULL,
 CONSTRAINT [PK_SQLIO_TestPass] PRIMARY KEY CLUSTERED 
(
	[TestPassID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [HPS]
) ON [HPS]
GO
/****** Object:  Table [AdminServer].[SSIS_Information]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [AdminServer].[SSIS_Information](
	[Date_Key] [datetime] NULL,
	[Server_Name] [sysname] NULL,
	[FileType] [varchar](10) NULL,
	[MountPoint] [varchar](60) NULL,
	[SSIS_Package_Name] [varchar](500) NOT NULL,
	[FileSizeInMB] [decimal](18, 2) NULL,
	[FileSizeInGB] [decimal](18, 2) NULL
) ON [HPS]
GO
/****** Object:  Table [Check_Server].[Database_State_After]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Check_Server].[Database_State_After](
	[Date_Key] [datetime] NULL,
	[ServerName] [varchar](128) NULL,
	[Database_Name] [varchar](255) NULL,
	[Database_Status_Desc] [varchar](80) NULL
) ON [HPS]
GO
/****** Object:  Table [Check_Server].[Database_State_Before]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Check_Server].[Database_State_Before](
	[Date_Key] [datetime] NULL,
	[ServerName] [varchar](128) NULL,
	[Database_Name] [varchar](255) NULL,
	[Database_Status_Desc] [varchar](80) NULL
) ON [HPS]
GO
/****** Object:  Table [Check_Server].[Mirror_State_After]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Check_Server].[Mirror_State_After](
	[Date_Key] [datetime] NULL,
	[ServerName] [varchar](128) NULL,
	[Database_Name] [varchar](255) NULL,
	[Recovery_Model] [varchar](80) NULL,
	[Mirroring_Status] [varchar](80) NULL
) ON [HPS]
GO
/****** Object:  Table [Check_Server].[Mirror_State_Before]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Check_Server].[Mirror_State_Before](
	[Date_Key] [datetime] NULL,
	[ServerName] [varchar](128) NULL,
	[Database_Name] [varchar](255) NULL,
	[Recovery_Model] [varchar](80) NULL,
	[Mirroring_Status] [varchar](80) NULL
) ON [HPS]
GO
/****** Object:  Table [Check_Server].[Server_State_After]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Check_Server].[Server_State_After](
	[Date_Key] [datetime] NULL,
	[ServerName] [varchar](128) NULL,
	[Last_Restart] [datetime] NULL,
	[Server_Status] [varchar](20) NULL,
	[Agent_Status] [varchar](20) NULL,
	[SSRS_Status] [varchar](20) NULL,
	[SSIS_Status] [varchar](20) NULL,
	[SSAS_Status] [varchar](20) NULL,
	[Browser_Status] [varchar](20) NULL,
	[FTS_Status] [varchar](20) NULL,
	[DTC_Status] [varchar](20) NULL,
	[Current_Node] [varchar](80) NULL
) ON [HPS]
GO
/****** Object:  Table [Check_Server].[Server_State_Before]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Check_Server].[Server_State_Before](
	[Date_Key] [datetime] NULL,
	[ServerName] [varchar](128) NULL,
	[Last_Restart] [datetime] NULL,
	[Server_Status] [varchar](20) NULL,
	[Agent_Status] [varchar](20) NULL,
	[SSRS_Status] [varchar](20) NULL,
	[SSIS_Status] [varchar](20) NULL,
	[SSAS_Status] [varchar](20) NULL,
	[Browser_Status] [varchar](20) NULL,
	[FTS_Status] [varchar](20) NULL,
	[DTC_Status] [varchar](20) NULL,
	[Current_Node] [varchar](80) NULL
) ON [HPS]
GO
/****** Object:  Table [Check_Server].[Status_Report]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Check_Server].[Status_Report](
	[ServerName] [varchar](255) NULL,
	[Status] [varchar](8000) NULL
) ON [HPS]
GO
/****** Object:  Table [Check_Server].[Up_time_after]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Check_Server].[Up_time_after](
	[servername] [varchar](128) NULL,
	[ComputerNamePhysicalNetBIOS] [varchar](200) NULL,
	[MachineName] [varchar](200) NULL,
	[InstanceName] [varchar](200) NULL,
	[IsClustered] [varchar](200) NULL,
	[ProcessID] [varchar](200) NULL,
	[ProductVersion] [varchar](200) NULL,
	[NodeNames] [varchar](200) NULL,
	[ServerUpTime] [varchar](200) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Check_Server].[Up_time_before]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Check_Server].[Up_time_before](
	[servername] [varchar](128) NULL,
	[ComputerNamePhysicalNetBIOS] [varchar](200) NULL,
	[MachineName] [varchar](200) NULL,
	[InstanceName] [varchar](200) NULL,
	[IsClustered] [varchar](200) NULL,
	[ProcessID] [varchar](200) NULL,
	[ProductVersion] [varchar](200) NULL,
	[NodeNames] [varchar](200) NULL,
	[ServerUpTime] [varchar](200) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Collection].[CollectionReport]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Collection].[CollectionReport](
	[RunID] [int] NULL,
	[Description] [varchar](50) NULL,
	[RecCreatedDate] [varchar](20) NULL,
	[Count] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AGReplica]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AGReplica](
	[ComputerName] [nvarchar](max) NULL,
	[InstanceName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[AvailabilityGroup] [nvarchar](max) NULL,
	[Replica] [nvarchar](max) NULL,
	[ReadonlyRoutingList] [nvarchar](max) NULL,
	[LoadBalancedReadOnlyRoutingList] [nvarchar](max) NULL,
	[LoadBalancedReadOnlyRoutingListDisplayString] [nvarchar](max) NULL,
	[IsSeedingModeSupported] [bit] NULL,
	[Parent] [nvarchar](max) NULL,
	[AvailabilityMode] [nvarchar](max) NULL,
	[BackupPriority] [int] NULL,
	[ConnectionModeInPrimaryRole] [nvarchar](max) NULL,
	[ConnectionModeInSecondaryRole] [nvarchar](max) NULL,
	[ConnectionState] [nvarchar](max) NULL,
	[CreateDate] [datetime2](7) NULL,
	[DateLastModified] [datetime2](7) NULL,
	[EndpointUrl] [nvarchar](max) NULL,
	[FailoverMode] [nvarchar](max) NULL,
	[JoinState] [nvarchar](max) NULL,
	[LastConnectErrorDescription] [nvarchar](max) NULL,
	[LastConnectErrorNumber] [int] NULL,
	[LastConnectErrorTimestamp] [datetime2](7) NULL,
	[MemberState] [nvarchar](max) NULL,
	[OperationalState] [nvarchar](max) NULL,
	[Owner] [nvarchar](max) NULL,
	[QuorumVoteCount] [int] NULL,
	[ReadonlyRoutingConnectionUrl] [nvarchar](max) NULL,
	[Role] [nvarchar](max) NULL,
	[RollupRecoveryState] [nvarchar](max) NULL,
	[RollupSynchronizationState] [nvarchar](max) NULL,
	[SeedingMode] [nvarchar](max) NULL,
	[SessionTimeout] [int] NULL,
	[UniqueId] [uniqueidentifier] NULL,
	[Name] [nvarchar](max) NULL,
	[ParentCollection] [nvarchar](max) NULL,
	[Urn] [nvarchar](max) NULL,
	[Properties] [nvarchar](max) NULL,
	[ServerVersion] [nvarchar](max) NULL,
	[DatabaseEngineType] [nvarchar](max) NULL,
	[DatabaseEngineEdition] [nvarchar](max) NULL,
	[ExecutionManager] [nvarchar](max) NULL,
	[UserData] [nvarchar](max) NULL,
	[State] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AllDBSrvStatus]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AllDBSrvStatus](
	[HostName] [nvarchar](max) NULL,
	[Comments] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AllSrvDbaService]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AllSrvDbaService](
	[DateKey] [datetime2](7) NULL,
	[PSComputerName] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[DisplayName] [nvarchar](max) NULL,
	[ServiceType] [nvarchar](max) NULL,
	[ServiceName] [nvarchar](max) NULL,
	[StartMode] [nvarchar](max) NULL,
	[State] [nvarchar](max) NULL,
	[StartName] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ALLSrvDiskSpace]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ALLSrvDiskSpace](
	[ComputerName] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Capacity] [bigint] NULL,
	[Free] [bigint] NULL,
	[PercentFree] [float] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AllUserDB]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AllUserDB](
	[DateKey] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Status] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[BackupInfo]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BackupInfo](
	[ServerName] [sysname] NOT NULL,
	[DatabaseName] [sysname] NOT NULL,
	[Last_Full] [datetime] NULL,
	[AG] [bit] NULL,
	[CollectionDate] [datetime] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[BackupInfoNP]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BackupInfoNP](
	[srv] [nvarchar](max) NULL,
	[Database] [nvarchar](max) NULL,
	[Recovery Model] [nvarchar](max) NULL,
	[Log Reuse Wait Desc] [nvarchar](max) NULL,
	[Last Full Backup] [datetime2](7) NULL,
	[Last Full Backup Location] [nvarchar](max) NULL,
	[Last Differential Backup] [datetime2](7) NULL,
	[Last Differential Backup Location] [nvarchar](max) NULL,
	[Last Log Backup] [datetime2](7) NULL,
	[Last Log Backup Location] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[BeforePatch]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BeforePatch](
	[Servername] [nvarchar](max) NULL,
	[servicename] [nvarchar](max) NULL,
	[status_desc] [nvarchar](max) NULL,
	[last_startup_time] [datetimeoffset](7) NULL,
	[service_account] [nvarchar](max) NULL,
	[ISClustered] [nvarchar](max) NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[BeforePatchCluster]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BeforePatchCluster](
	[Servername] [nvarchar](max) NULL,
	[NodeName] [nvarchar](max) NULL,
	[status] [int] NULL,
	[status_description] [nvarchar](max) NULL,
	[is_current_owner] [bit] NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[BeforePatchDrive]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BeforePatchDrive](
	[PSComputerName] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[BeforePatchOffline]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BeforePatchOffline](
	[Servername] [nvarchar](max) NULL,
	[Databasename] [nvarchar](max) NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CIM_Column]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CIM_Column](
	[srv] [nvarchar](max) NULL,
	[DBName] [nvarchar](max) NULL,
	[TABLE_NAME] [nvarchar](max) NULL,
	[column_name] [nvarchar](max) NULL,
	[data_type] [nvarchar](max) NULL,
	[character_maximum_length] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CLU]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CLU](
	[ID] [int] NULL,
	[Servername] [varchar](255) NULL,
	[servicename] [varchar](255) NULL,
	[status_desc] [varchar](255) NULL,
	[last_startup_time] [datetime] NULL,
	[service_account] [varchar](255) NULL,
	[ISClustered] [varchar](255) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[commandlog]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[commandlog](
	[Description] [nvarchar](max) NULL,
	[Status] [nvarchar](max) NULL,
	[Collectiontime] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[crAuditLogHistory]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[crAuditLogHistory](
	[EventTime] [smalldatetime] NOT NULL,
	[ServerInstance] [varchar](256) NOT NULL,
	[DatabaseName] [varchar](128) NOT NULL,
	[Schema_Name] [varchar](256) NOT NULL,
	[Object_Name] [varchar](256) NOT NULL,
	[Action_Name] [varchar](50) NULL,
	[SessionId] [int] NOT NULL,
	[Action_Class] [varchar](128) NOT NULL,
	[Server_Principal_Name] [varchar](128) NOT NULL,
	[Session_Principal_Name] [varchar](128) NOT NULL,
	[Statement] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Database_last_Used]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Database_last_Used](
	[Datekey] [datetime2](7) NULL,
	[Servername] [nvarchar](max) NULL,
	[DataBase] [nvarchar](max) NULL,
	[MaxLastUse] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DatabaseVersion]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DatabaseVersion](
	[VersionNumber] [varchar](50) NOT NULL,
	[DeploymentDate] [datetime] NOT NULL,
	[DeployedBy] [nvarchar](128) NOT NULL,
 CONSTRAINT [PK_DatabaseVersion] PRIMARY KEY CLUSTERED 
(
	[VersionNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaAGServer]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaAGServer](
	[ServerName] [varchar](50) NULL,
	[PreferredPrimary] [varchar](50) NULL,
	[AGName] [varchar](50) NULL,
	[PreferredReplicaServerName] [varchar](50) NULL,
	[CurrentPrimaryReplica] [varchar](50) NULL,
	[Status] [varchar](50) NULL,
	[Category] [varchar](50) NULL,
	[ListenerName] [nvarchar](16) NULL,
	[ListenerIP] [nvarchar](16) NULL,
	[Cluster_Name] [nvarchar](18) NULL,
	[Cluster_IP] [nvarchar](15) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaCPU]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaCPU](
	[ServerName] [nvarchar](max) NULL,
	[CPU Count] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaCPU_old]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaCPU_old](
	[ServerName] [nvarchar](max) NULL,
	[CPUCount] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaMaxMemory]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaMaxMemory](
	[ComputerName] [nvarchar](max) NULL,
	[InstanceName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Total] [int] NULL,
	[MaxValue] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaMaxMemory_old]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaMaxMemory_old](
	[ComputerName] [nvarchar](max) NULL,
	[InstanceName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Total] [int] NULL,
	[MaxValue] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaPort]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaPort](
	[SqlInstance] [nvarchar](max) NULL,
	[IPAddress] [nvarchar](max) NULL,
	[Port] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaService]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaService](
	[DateKey] [nvarchar](max) NULL,
	[PSComputerName] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[DisplayName] [nvarchar](max) NULL,
	[ServiceType] [nvarchar](max) NULL,
	[ServiceName] [nvarchar](max) NULL,
	[StartMode] [nvarchar](max) NULL,
	[State] [nvarchar](max) NULL,
	[StartName] [nvarchar](max) NULL,
	[ProcessId] [bigint] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaStats]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaStats](
	[DateKey] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[SizeMB] [float] NULL,
	[Compatibility] [nvarchar](max) NULL,
	[ServerVersion] [nvarchar](max) NULL,
	[Collation] [nvarchar](max) NULL,
	[Encrypted] [bit] NULL,
	[Owner] [nvarchar](max) NULL,
	[LastFullBackup] [datetime2](7) NULL,
	[LastGoodCheckDbTime] [datetime2](7) NULL,
	[DatabaseEngineEdition] [nvarchar](max) NULL,
	[LastRead] [nvarchar](max) NULL,
	[LastWrite] [nvarchar](max) NULL,
	[IsUpdateable] [bit] NULL,
	[AutoClose] [bit] NULL,
	[AutoShrink] [bit] NULL,
	[AutoUpdateStatisticsEnabled] [bit] NULL,
	[AvailabilityDatabaseSynchronizationState] [nvarchar](max) NULL,
	[AvailabilityGroupName] [nvarchar](max) NULL,
	[State] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaStats_Admin]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaStats_Admin](
	[ServerName] [nvarchar](128) NULL,
	[DatabaseName] [nvarchar](128) NULL,
	[TotalSizeMB] [float] NULL,
	[UsedSpaceMB] [float] NULL,
	[FreeSpaceMB] [float] NULL,
	[RecoveryModel] [nvarchar](128) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DBCountMain_V1]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DBCountMain_V1](
	[Domain] [varchar](100) NULL,
	[ServerName] [varchar](100) NOT NULL,
	[TotalDBCount] [int] NULL,
	[RecCreateDt] [smalldatetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ServerName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DBCountMain_V2]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DBCountMain_V2](
	[Domain] [varchar](100) NULL,
	[ServerName] [varchar](100) NOT NULL,
	[TotalDBCount] [int] NULL,
	[RecCreateDt] [smalldatetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ServerName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DBCountMain_V3]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DBCountMain_V3](
	[Domain] [varchar](100) NULL,
	[ServerName] [varchar](100) NOT NULL,
	[TotalDBCount] [int] NULL,
	[RecCreateDt] [smalldatetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ServerName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DBException]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DBException](
	[SqlInstance] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Status] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dbgrowth]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dbgrowth](
	[DateKey] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Database] [nvarchar](max) NULL,
	[File] [nvarchar](max) NULL,
	[FileName] [nvarchar](max) NULL,
	[GrowthType] [nvarchar](max) NULL,
	[GrowthMB] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DBServer]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DBServer](
	[SqlInstance] [varchar](50) NOT NULL,
	[Status] [varchar](2) NULL,
	[HostName] [varchar](50) NULL,
	[Category] [varchar](10) NULL,
	[Application] [varchar](50) NULL,
	[AppContact] [varchar](100) NULL,
	[MajorVersion] [varchar](50) NULL,
	[EmailAddress] [nvarchar](max) NULL,
	[BuildNumber] [varchar](25) NULL,
	[SPLevel] [nvarchar](20) NULL,
	[CULevel] [nvarchar](10) NULL,
	[IPAddress] [nvarchar](20) NULL,
	[Port] [nvarchar](10) NULL,
	[Edition] [varchar](60) NULL,
	[Comments] [nvarchar](max) NULL,
	[DC] [nvarchar](10) NULL,
	[HA] [bit] NULL,
	[ServiceAccount] [nvarchar](30) NULL,
	[HASecondary] [bit] NULL,
	[OSVersion] [nvarchar](max) NULL,
 CONSTRAINT [pk_SqlInstance] PRIMARY KEY CLUSTERED 
(
	[SqlInstance] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DBServer_old]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DBServer_old](
	[ID] [varchar](50) NULL,
	[ServerName] [varchar](50) NULL,
	[Status] [varchar](50) NULL,
	[HostName] [varchar](50) NULL,
	[Category] [nchar](10) NULL,
	[Application] [varchar](50) NULL,
	[AppContact] [nvarchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DBServerMain]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DBServerMain](
	[ID] [varchar](50) NULL,
	[Server Name] [varchar](50) NULL,
	[SQL Instance Name] [varchar](50) NULL,
	[Version] [varchar](50) NULL,
	[OS version] [varchar](50) NULL,
	[Environment] [varchar](50) NULL,
	[ServerStatus] [varchar](50) NULL,
	[DC] [varchar](50) NULL,
	[Application] [varchar](50) NULL,
	[POC] [varchar](50) NULL,
	[RAM] [varchar](50) NULL,
	[vCPU] [varchar](50) NULL,
	[Cores] [varchar](50) NULL,
	[Disk Size] [varchar](50) NULL,
	[DB size] [varchar](50) NULL,
	[DB count] [varchar](50) NULL,
	[DBStatus] [varchar](50) NULL,
	[IP address] [varchar](50) NULL,
	[Port Number] [varchar](50) NULL,
	[SQL Build] [varchar](50) NULL,
	[Upgraded SQL V ] [varchar](50) NULL,
	[Date Upg ] [varchar](50) NULL,
	[Upgrade Roadblocks] [varchar](50) NULL,
	[GCP Project] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DBserverMain_old]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DBserverMain_old](
	[ServerID] [float] NULL,
	[Servername] [nvarchar](255) NULL,
	[Status] [nvarchar](255) NULL,
	[ISHADR] [nvarchar](255) NULL,
	[Role] [nvarchar](255) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DiskInfo]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DiskInfo](
	[ServerName] [nchar](100) NULL,
	[Drive] [nchar](10) NULL,
	[DriveType] [nchar](10) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DiskSpace]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DiskSpace](
	[ComputerName] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Capacity] [bigint] NULL,
	[Free] [bigint] NULL,
	[PercentFree] [float] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DiskSpace_old]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DiskSpace_old](
	[ComputerName] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Capacity] [bigint] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DRReport_613]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DRReport_613](
	[InstanceID] [int] NULL,
	[SqlMessageID] [int] NULL,
	[Message] [nvarchar](max) NULL,
	[StepID] [int] NULL,
	[StepName] [nvarchar](max) NULL,
	[SqlSeverity] [int] NULL,
	[JobID] [uniqueidentifier] NULL,
	[JobName] [nvarchar](max) NULL,
	[RunStatus] [int] NULL,
	[RunDate] [datetime2](7) NULL,
	[RunDuration] [int] NULL,
	[OperatorEmailed] [nvarchar](max) NULL,
	[OperatorNetsent] [nvarchar](max) NULL,
	[OperatorPaged] [nvarchar](max) NULL,
	[RetriesAttempted] [int] NULL,
	[Server] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[endpoint]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[endpoint](
	[MachineName] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[InstanceName] [nvarchar](max) NULL,
	[FullName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Port] [int] NULL,
	[TcpConnected] [bit] NULL,
	[SqlConnected] [bit] NULL,
	[DnsResolution] [nvarchar](max) NULL,
	[Ping] [bit] NULL,
	[BrowseReply] [nvarchar](max) NULL,
	[Services] [nvarchar](max) NULL,
	[SystemServices] [nvarchar](max) NULL,
	[SPNs] [nvarchar](max) NULL,
	[PortsScanned] [nvarchar](max) NULL,
	[Availability] [nvarchar](max) NULL,
	[Confidence] [nvarchar](max) NULL,
	[ScanTypes] [nvarchar](max) NULL,
	[Timestamp] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[GCPServerInfo]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[GCPServerInfo](
	[GCPInstance] [varchar](50) NULL,
	[vCPU] [varchar](50) NULL,
	[MemoryinGb] [varchar](50) NULL,
	[TotalDisksSizeInGb] [varchar](50) NULL,
	[Notes] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[IpAddress]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[IpAddress](
	[ID] [nvarchar](50) NULL,
	[ComputerName] [nvarchar](50) NULL,
	[SqlInstance] [nvarchar](50) NULL,
	[IpAddress] [nvarchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[LastUsed_DB]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[LastUsed_DB](
	[BackupStatus] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[InstanceName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[LastRead] [datetime2](7) NULL,
	[LastWrite] [datetime2](7) NULL,
	[SizeMB] [float] NULL,
	[Compatibility] [nvarchar](max) NULL,
	[Encrypted] [bit] NULL,
	[LastFullBackup] [datetime2](7) NULL,
	[LastDiffBackup] [datetime2](7) NULL,
	[LastLogBackup] [datetime2](7) NULL,
	[LastIndexRead] [datetime2](7) NULL,
	[LastIndexWrite] [datetime2](7) NULL,
	[ExecutionManager] [nvarchar](max) NULL,
	[DatabaseEngineType] [nvarchar](max) NULL,
	[DatabaseEngineEdition] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[WarnOnRename] [bit] NULL,
	[DatabaseOwnershipChaining] [bit] NULL,
	[CatalogCollation] [nvarchar](max) NULL,
	[ExtendedProperties] [nvarchar](max) NULL,
	[DatabaseOptions] [nvarchar](max) NULL,
	[QueryStoreOptions] [nvarchar](max) NULL,
	[Synonyms] [nvarchar](max) NULL,
	[Sequences] [nvarchar](max) NULL,
	[Tables] [nvarchar](max) NULL,
	[SensitivityClassifications] [nvarchar](max) NULL,
	[DatabaseScopedCredentials] [nvarchar](max) NULL,
	[WorkloadManagementWorkloadClassifiers] [nvarchar](max) NULL,
	[StoredProcedures] [nvarchar](max) NULL,
	[Assemblies] [nvarchar](max) NULL,
	[ExternalLanguages] [nvarchar](max) NULL,
	[ExternalLibraries] [nvarchar](max) NULL,
	[UserDefinedTypes] [nvarchar](max) NULL,
	[UserDefinedAggregates] [nvarchar](max) NULL,
	[FullTextCatalogs] [nvarchar](max) NULL,
	[FullTextStopLists] [nvarchar](max) NULL,
	[SearchPropertyLists] [nvarchar](max) NULL,
	[SecurityPolicies] [nvarchar](max) NULL,
	[DatabaseScopedConfigurations] [nvarchar](max) NULL,
	[ExternalDataSources] [nvarchar](max) NULL,
	[ExternalFileFormats] [nvarchar](max) NULL,
	[ExternalStreams] [nvarchar](max) NULL,
	[ExternalStreamingJobs] [nvarchar](max) NULL,
	[Certificates] [nvarchar](max) NULL,
	[ColumnMasterKeys] [nvarchar](max) NULL,
	[ColumnEncryptionKeys] [nvarchar](max) NULL,
	[SymmetricKeys] [nvarchar](max) NULL,
	[AsymmetricKeys] [nvarchar](max) NULL,
	[DatabaseEncryptionKey] [nvarchar](max) NULL,
	[ExtendedStoredProcedures] [nvarchar](max) NULL,
	[UserDefinedFunctions] [nvarchar](max) NULL,
	[Views] [nvarchar](max) NULL,
	[Users] [nvarchar](max) NULL,
	[DatabaseAuditSpecifications] [nvarchar](max) NULL,
	[Schemas] [nvarchar](max) NULL,
	[Roles] [nvarchar](max) NULL,
	[ApplicationRoles] [nvarchar](max) NULL,
	[LogFiles] [nvarchar](max) NULL,
	[FileGroups] [nvarchar](max) NULL,
	[PlanGuides] [nvarchar](max) NULL,
	[Defaults] [nvarchar](max) NULL,
	[Rules] [nvarchar](max) NULL,
	[UserDefinedDataTypes] [nvarchar](max) NULL,
	[UserDefinedTableTypes] [nvarchar](max) NULL,
	[XmlSchemaCollections] [nvarchar](max) NULL,
	[PartitionFunctions] [nvarchar](max) NULL,
	[PartitionSchemes] [nvarchar](max) NULL,
	[MasterKey] [nvarchar](max) NULL,
	[Triggers] [nvarchar](max) NULL,
	[DefaultLanguage] [nvarchar](max) NULL,
	[DefaultFullTextLanguage] [nvarchar](max) NULL,
	[WorkloadManagementWorkloadGroups] [nvarchar](max) NULL,
	[ServiceBroker] [nvarchar](max) NULL,
	[MaxDop] [int] NULL,
	[MaxDopForSecondary] [nvarchar](max) NULL,
	[LegacyCardinalityEstimation] [nvarchar](max) NULL,
	[LegacyCardinalityEstimationForSecondary] [nvarchar](max) NULL,
	[ParameterSniffing] [nvarchar](max) NULL,
	[ParameterSniffingForSecondary] [nvarchar](max) NULL,
	[QueryOptimizerHotfixes] [nvarchar](max) NULL,
	[QueryOptimizerHotfixesForSecondary] [nvarchar](max) NULL,
	[IsVarDecimalStorageFormatSupported] [bit] NULL,
	[IsVarDecimalStorageFormatEnabled] [bit] NULL,
	[Parent] [nvarchar](max) NULL,
	[AcceleratedRecoveryEnabled] [bit] NULL,
	[ActiveConnections] [int] NULL,
	[AnsiNullDefault] [bit] NULL,
	[AnsiNullsEnabled] [bit] NULL,
	[AnsiPaddingEnabled] [bit] NULL,
	[AnsiWarningsEnabled] [bit] NULL,
	[ArithmeticAbortEnabled] [bit] NULL,
	[AutoClose] [bit] NULL,
	[AutoCreateIncrementalStatisticsEnabled] [bit] NULL,
	[AutoCreateStatisticsEnabled] [bit] NULL,
	[AutoShrink] [bit] NULL,
	[AutoUpdateStatisticsAsync] [bit] NULL,
	[AutoUpdateStatisticsEnabled] [bit] NULL,
	[AvailabilityDatabaseSynchronizationState] [nvarchar](max) NULL,
	[AvailabilityGroupName] [nvarchar](max) NULL,
	[BrokerEnabled] [bit] NULL,
	[CaseSensitive] [bit] NULL,
	[ChangeTrackingAutoCleanUp] [bit] NULL,
	[ChangeTrackingEnabled] [bit] NULL,
	[ChangeTrackingRetentionPeriod] [int] NULL,
	[ChangeTrackingRetentionPeriodUnits] [nvarchar](max) NULL,
	[CloseCursorsOnCommitEnabled] [bit] NULL,
	[Collation] [nvarchar](max) NULL,
	[CompatibilityLevel] [nvarchar](max) NULL,
	[ConcatenateNullYieldsNull] [bit] NULL,
	[ContainmentType] [nvarchar](max) NULL,
	[CreateDate] [datetime2](7) NULL,
	[DatabaseGuid] [uniqueidentifier] NULL,
	[DatabaseSnapshotBaseName] [nvarchar](max) NULL,
	[DataRetentionEnabled] [bit] NULL,
	[DataSpaceUsage] [float] NULL,
	[DateCorrelationOptimization] [bit] NULL,
	[DboLogin] [bit] NULL,
	[DefaultFileGroup] [nvarchar](max) NULL,
	[DefaultFileStreamFileGroup] [nvarchar](max) NULL,
	[DefaultFullTextCatalog] [nvarchar](max) NULL,
	[DefaultSchema] [nvarchar](max) NULL,
	[DelayedDurability] [nvarchar](max) NULL,
	[EncryptionEnabled] [bit] NULL,
	[FilestreamDirectoryName] [nvarchar](max) NULL,
	[FilestreamNonTransactedAccess] [nvarchar](max) NULL,
	[HasDatabaseEncryptionKey] [bit] NULL,
	[HasFileInCloud] [bit] NULL,
	[HasMemoryOptimizedObjects] [bit] NULL,
	[HonorBrokerPriority] [bit] NULL,
	[ID] [int] NULL,
	[IndexSpaceUsage] [float] NULL,
	[IsAccessible] [bit] NULL,
	[IsDatabaseSnapshot] [bit] NULL,
	[IsDatabaseSnapshotBase] [bit] NULL,
	[IsDbAccessAdmin] [bit] NULL,
	[IsDbBackupOperator] [bit] NULL,
	[IsDbDatareader] [bit] NULL,
	[IsDbDatawriter] [bit] NULL,
	[IsDbDdlAdmin] [bit] NULL,
	[IsDbDenyDatareader] [bit] NULL,
	[IsDbDenyDatawriter] [bit] NULL,
	[IsDbOwner] [bit] NULL,
	[IsDbSecurityAdmin] [bit] NULL,
	[IsFullTextEnabled] [bit] NULL,
	[IsLedger] [bit] NULL,
	[IsMailHost] [bit] NULL,
	[IsManagementDataWarehouse] [bit] NULL,
	[IsMirroringEnabled] [bit] NULL,
	[IsParameterizationForced] [bit] NULL,
	[IsReadCommittedSnapshotOn] [bit] NULL,
	[IsSqlDw] [bit] NULL,
	[IsSystemObject] [bit] NULL,
	[IsUpdateable] [bit] NULL,
	[LastBackupDate] [datetime2](7) NULL,
	[LastDifferentialBackupDate] [datetime2](7) NULL,
	[LastGoodCheckDbTime] [datetime2](7) NULL,
	[LastLogBackupDate] [datetime2](7) NULL,
	[LocalCursorsDefault] [bit] NULL,
	[LogReuseWaitStatus] [nvarchar](max) NULL,
	[MemoryAllocatedToMemoryOptimizedObjectsInKB] [float] NULL,
	[MemoryUsedByMemoryOptimizedObjectsInKB] [float] NULL,
	[MirroringFailoverLogSequenceNumber] [decimal](38, 5) NULL,
	[MirroringID] [uniqueidentifier] NULL,
	[MirroringPartner] [nvarchar](max) NULL,
	[MirroringPartnerInstance] [nvarchar](max) NULL,
	[MirroringRedoQueueMaxSize] [int] NULL,
	[MirroringRoleSequence] [int] NULL,
	[MirroringSafetyLevel] [nvarchar](max) NULL,
	[MirroringSafetySequence] [int] NULL,
	[MirroringStatus] [nvarchar](max) NULL,
	[MirroringTimeout] [int] NULL,
	[MirroringWitness] [nvarchar](max) NULL,
	[MirroringWitnessStatus] [nvarchar](max) NULL,
	[NestedTriggersEnabled] [bit] NULL,
	[NumericRoundAbortEnabled] [bit] NULL,
	[Owner] [nvarchar](max) NULL,
	[PageVerify] [nvarchar](max) NULL,
	[PersistentVersionStoreFileGroup] [nvarchar](max) NULL,
	[PersistentVersionStoreSizeKB] [bigint] NULL,
	[PrimaryFilePath] [nvarchar](max) NULL,
	[QuotedIdentifiersEnabled] [bit] NULL,
	[ReadOnly] [bit] NULL,
	[RecoveryForkGuid] [uniqueidentifier] NULL,
	[RecoveryModel] [nvarchar](max) NULL,
	[RecursiveTriggersEnabled] [bit] NULL,
	[RemoteDataArchiveCredential] [nvarchar](max) NULL,
	[RemoteDataArchiveEnabled] [bit] NULL,
	[RemoteDataArchiveEndpoint] [nvarchar](max) NULL,
	[RemoteDataArchiveLinkedServer] [nvarchar](max) NULL,
	[RemoteDataArchiveUseFederatedServiceAccount] [bit] NULL,
	[RemoteDatabaseName] [nvarchar](max) NULL,
	[ReplicationOptions] [nvarchar](max) NULL,
	[ServiceBrokerGuid] [uniqueidentifier] NULL,
	[Size] [float] NULL,
	[SnapshotIsolationState] [nvarchar](max) NULL,
	[SpaceAvailable] [float] NULL,
	[Status] [nvarchar](max) NULL,
	[TargetRecoveryTime] [int] NULL,
	[TransformNoiseWords] [bit] NULL,
	[Trustworthy] [bit] NULL,
	[TwoDigitYearCutoff] [int] NULL,
	[UserAccess] [nvarchar](max) NULL,
	[UserName] [nvarchar](max) NULL,
	[Version] [int] NULL,
	[AzureEdition] [nvarchar](max) NULL,
	[AzureServiceObjective] [nvarchar](max) NULL,
	[IsDbManager] [bit] NULL,
	[IsLoginManager] [bit] NULL,
	[IsMaxSizeApplicable] [bit] NULL,
	[IsSqlDwEdition] [bit] NULL,
	[MaxSizeInBytes] [float] NULL,
	[TemporalHistoryRetentionEnabled] [bit] NULL,
	[Events] [nvarchar](max) NULL,
	[ParentCollection] [nvarchar](max) NULL,
	[Urn] [nvarchar](max) NULL,
	[Properties] [nvarchar](max) NULL,
	[ServerVersion] [nvarchar](max) NULL,
	[UserData] [nvarchar](max) NULL,
	[State] [nvarchar](max) NULL,
	[IsDesignMode] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ManualPatching_OS]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ManualPatching_OS](
	[ServerName] [nvarchar](max) NULL,
	[AG] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Monthly_Release]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Monthly_Release](
	[MonthYY] [varchar](50) NULL,
	[CHG_Number] [varchar](50) NOT NULL,
	[CTask] [varchar](50) NULL,
	[CHG_Status] [varchar](15) NULL,
	[CodeReview_Status] [varchar](50) NULL,
	[PreDeploy] [varchar](3) NULL,
	[OnRelease] [varchar](3) NULL,
	[Scheduled_Time] [datetime2](7) NULL,
	[Description] [varchar](255) NULL,
	[Implementor] [varchar](100) NULL,
	[Validator] [varchar](100) NULL,
	[Actual_Exec_Mins] [decimal](10, 2) NULL,
	[Estimated_Mins] [decimal](10, 2) NULL,
	[CTask_Status] [nvarchar](15) NULL,
	[Start_Time] [decimal](10, 2) NULL,
	[End_Time] [decimal](10, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[CHG_Number] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Monthly_Release-old]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Monthly_Release-old](
	[MonthYY] [varchar](50) NULL,
	[CHG_Number] [varchar](50) NOT NULL,
	[CTask] [varchar](50) NULL,
	[Status] [varchar](50) NULL,
	[PreDeploy_Release] [varchar](50) NULL,
	[Scheduled_Time] [datetime2](7) NULL,
	[Description] [varchar](255) NULL,
	[Implementor] [varchar](100) NULL,
	[Validator] [varchar](100) NULL,
	[Dev_Estimation] [decimal](10, 2) NULL,
	[DBA_Estimation] [decimal](10, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[CHG_Number] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MSSQLVersion]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MSSQLVersion](
	[ComputerName] [nvarchar](max) NULL,
	[InstanceName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Version] [nvarchar](max) NULL,
	[Edition] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MySQL_Capacity]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MySQL_Capacity](
	[ServerName] [nvarchar](max) NULL,
	[Capacity] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MySQL_UserDBCnt]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MySQL_UserDBCnt](
	[ServerName] [nvarchar](max) NULL,
	[UserDbCount] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MySQL_UserDBName]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MySQL_UserDBName](
	[ServerName] [nvarchar](max) NULL,
	[DBName] [nvarchar](max) NULL,
	[Region] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MySQLMaster]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MySQLMaster](
	[ServerName] [nvarchar](100) NOT NULL,
	[MYSQLVersion] [varchar](100) NULL,
	[OSVersion] [varchar](100) NULL,
	[Region] [varchar](10) NULL,
	[Application] [varchar](50) NULL,
	[POC] [varchar](30) NULL,
	[IPAddress] [nvarchar](max) NULL,
	[Status] [nvarchar](2) NULL,
	[DC] [nvarchar](10) NULL,
	[Exception] [nvarchar](2) NULL,
	[Comments] [nvarchar](max) NULL,
	[ModifyDate] [nvarchar](20) NULL,
 CONSTRAINT [pk_ServerName] PRIMARY KEY CLUSTERED 
(
	[ServerName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[OSPatch2019]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OSPatch2019](
	[ComputerName] [nvarchar](max) NULL,
	[Date] [datetime2](7) NULL,
	[Title] [nvarchar](max) NULL,
	[Result] [nvarchar](max) NULL,
	[KB] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[OSVersion]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OSVersion](
	[ComputerName] [nvarchar](max) NULL,
	[Manufacturer] [nvarchar](max) NULL,
	[Organization] [nvarchar](max) NULL,
	[Architecture] [nvarchar](max) NULL,
	[Version] [nvarchar](max) NULL,
	[Build] [nvarchar](max) NULL,
	[OSVersion] [nvarchar](max) NULL,
	[SPVersion] [int] NULL,
	[InstallDate] [nvarchar](max) NULL,
	[LastBootTime] [nvarchar](max) NULL,
	[LocalDateTime] [nvarchar](max) NULL,
	[PowerShellVersion] [nvarchar](max) NULL,
	[TimeZone] [nvarchar](max) NULL,
	[TimeZoneStandard] [nvarchar](max) NULL,
	[TimeZoneDaylight] [nvarchar](max) NULL,
	[BootDevice] [nvarchar](max) NULL,
	[SystemDevice] [nvarchar](max) NULL,
	[SystemDrive] [nvarchar](max) NULL,
	[WindowsDirectory] [nvarchar](max) NULL,
	[PagingFileSize] [decimal](20, 0) NULL,
	[TotalVisibleMemory] [bigint] NULL,
	[FreePhysicalMemory] [bigint] NULL,
	[TotalVirtualMemory] [bigint] NULL,
	[FreeVirtualMemory] [bigint] NULL,
	[ActivePowerPlan] [nvarchar](max) NULL,
	[Status] [nvarchar](max) NULL,
	[Language] [nvarchar](max) NULL,
	[LanguageId] [int] NULL,
	[LanguageKeyboardLayoutId] [int] NULL,
	[LanguageTwoLetter] [nvarchar](max) NULL,
	[LanguageThreeLetter] [nvarchar](max) NULL,
	[LanguageAlias] [nvarchar](max) NULL,
	[LanguageNative] [nvarchar](max) NULL,
	[CodeSet] [nvarchar](max) NULL,
	[CountryCode] [nvarchar](max) NULL,
	[Locale] [nvarchar](max) NULL,
	[IsWsfc] [bit] NULL,
	[HostName] [nvarchar](30) NULL,
	[ASTATUS] [nvarchar](10) NULL,
	[DC] [nvarchar](10) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[OSVersion_old]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OSVersion_old](
	[ComputerName] [nvarchar](max) NULL,
	[Manufacturer] [nvarchar](max) NULL,
	[Organization] [nvarchar](max) NULL,
	[Architecture] [nvarchar](max) NULL,
	[Version] [nvarchar](max) NULL,
	[Build] [nvarchar](max) NULL,
	[OSVersion] [nvarchar](max) NULL,
	[SPVersion] [int] NULL,
	[InstallDate] [nvarchar](max) NULL,
	[LastBootTime] [nvarchar](max) NULL,
	[LocalDateTime] [nvarchar](max) NULL,
	[PowerShellVersion] [nvarchar](max) NULL,
	[TimeZone] [nvarchar](max) NULL,
	[TimeZoneStandard] [nvarchar](max) NULL,
	[TimeZoneDaylight] [nvarchar](max) NULL,
	[BootDevice] [nvarchar](max) NULL,
	[SystemDevice] [nvarchar](max) NULL,
	[SystemDrive] [nvarchar](max) NULL,
	[WindowsDirectory] [nvarchar](max) NULL,
	[PagingFileSize] [decimal](20, 0) NULL,
	[TotalVisibleMemory] [bigint] NULL,
	[FreePhysicalMemory] [bigint] NULL,
	[TotalVirtualMemory] [bigint] NULL,
	[FreeVirtualMemory] [bigint] NULL,
	[ActivePowerPlan] [nvarchar](max) NULL,
	[Status] [nvarchar](max) NULL,
	[Language] [nvarchar](max) NULL,
	[LanguageId] [int] NULL,
	[LanguageKeyboardLayoutId] [int] NULL,
	[LanguageTwoLetter] [nvarchar](max) NULL,
	[LanguageThreeLetter] [nvarchar](max) NULL,
	[LanguageAlias] [nvarchar](max) NULL,
	[LanguageNative] [nvarchar](max) NULL,
	[CodeSet] [nvarchar](max) NULL,
	[CountryCode] [nvarchar](max) NULL,
	[Locale] [nvarchar](max) NULL,
	[IsWsfc] [bit] NULL,
	[HostName] [nvarchar](25) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[OutputFileCleanup_0528]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OutputFileCleanup_0528](
	[SqlInstance] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[LastRunDate] [datetime2](7) NULL,
	[CreateDate] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[OutputFileCleanupJob]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OutputFileCleanupJob](
	[SqlInstance] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[LastRunDate] [datetime2](7) NULL,
	[CreateDate] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Patch_Compliant]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Patch_Compliant](
	[SqlInstance] [nvarchar](max) NULL,
	[NameLevel] [nvarchar](max) NULL,
	[BuildLevel] [nvarchar](max) NULL,
	[BuildTarget] [nvarchar](max) NULL,
	[CULevel] [nvarchar](max) NULL,
	[SPLevel] [nvarchar](max) NULL,
	[Compliant] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PatchCompliant]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PatchCompliant](
	[SqlInstance] [nvarchar](max) NULL,
	[BuildLevel] [nvarchar](max) NULL,
	[BuildTarget] [nvarchar](max) NULL,
	[Compliant] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PatchCompliant042324]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PatchCompliant042324](
	[SqlInstance] [nvarchar](max) NULL,
	[BuildLevel] [nvarchar](max) NULL,
	[BuildTarget] [nvarchar](max) NULL,
	[Compliant] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PrdDbaService]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PrdDbaService](
	[DateKey] [datetime2](7) NULL,
	[PSComputerName] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[DisplayName] [nvarchar](max) NULL,
	[ServiceType] [nvarchar](max) NULL,
	[ServiceName] [nvarchar](max) NULL,
	[StartMode] [nvarchar](max) NULL,
	[State] [nvarchar](max) NULL,
	[StartName] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PrdDBSrvStatus]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PrdDBSrvStatus](
	[HostName] [nvarchar](max) NULL,
	[Comments] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ProdBackupInfo]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProdBackupInfo](
	[SqlInstance] [nvarchar](max) NULL,
	[Database] [nvarchar](max) NULL,
	[LastFullBackup] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Queue]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Queue](
	[QueueID] [int] IDENTITY(1,1) NOT NULL,
	[SchemaName] [nvarchar](128) NOT NULL,
	[ObjectName] [nvarchar](128) NOT NULL,
	[Parameters] [nvarchar](max) NOT NULL,
	[QueueStartTime] [datetime] NULL,
	[SessionID] [smallint] NULL,
	[RequestID] [int] NULL,
	[RequestStartTime] [datetime] NULL,
 CONSTRAINT [PK_Queue] PRIMARY KEY CLUSTERED 
(
	[QueueID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[QueueDatabase]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QueueDatabase](
	[QueueID] [int] NOT NULL,
	[DatabaseName] [nvarchar](256) NOT NULL,
	[DatabaseOrder] [int] NULL,
	[DatabaseStartTime] [datetime] NULL,
	[DatabaseEndTime] [datetime] NULL,
	[SessionID] [smallint] NULL,
	[RequestID] [int] NULL,
	[RequestStartTime] [datetime] NULL,
 CONSTRAINT [PK_QueueDatabase] PRIMARY KEY CLUSTERED 
(
	[QueueID] ASC,
	[DatabaseName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Recon_Table]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Recon_Table](
	[ComputerName] [nvarchar](max) NULL,
	[InstanceName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Database] [nvarchar](max) NULL,
	[Indexes] [nvarchar](max) NULL,
	[Checks] [nvarchar](max) NULL,
	[EdgeConstraints] [nvarchar](max) NULL,
	[ResumableIndexes] [nvarchar](max) NULL,
	[OnlineHeapOperation] [bit] NULL,
	[LowPriorityMaxDuration] [int] NULL,
	[DataConsistencyCheck] [bit] NULL,
	[LowPriorityAbortAfterWait] [nvarchar](max) NULL,
	[MaximumDegreeOfParallelism] [int] NULL,
	[IsNode] [bit] NULL,
	[IsEdge] [bit] NULL,
	[ForeignKeys] [nvarchar](max) NULL,
	[PhysicalPartitions] [nvarchar](max) NULL,
	[PartitionSchemeParameters] [nvarchar](max) NULL,
	[RowCountAsDouble] [float] NULL,
	[IsVarDecimalStorageFormatEnabled] [bit] NULL,
	[Parent] [nvarchar](max) NULL,
	[AnsiNullsStatus] [bit] NULL,
	[ChangeTrackingEnabled] [bit] NULL,
	[CreateDate] [datetime2](7) NULL,
	[DataRetentionEnabled] [bit] NULL,
	[DataRetentionFilterColumnName] [nvarchar](max) NULL,
	[DataRetentionPeriod] [int] NULL,
	[DataRetentionPeriodUnit] [nvarchar](max) NULL,
	[DataSourceName] [nvarchar](max) NULL,
	[DataSpaceUsed] [float] NULL,
	[DateLastModified] [datetime2](7) NULL,
	[Durability] [nvarchar](max) NULL,
	[ExternalTableDistribution] [nvarchar](max) NULL,
	[FakeSystemTable] [bit] NULL,
	[FileFormatName] [nvarchar](max) NULL,
	[FileGroup] [nvarchar](max) NULL,
	[FileStreamFileGroup] [nvarchar](max) NULL,
	[FileStreamPartitionScheme] [nvarchar](max) NULL,
	[FileTableDirectoryName] [nvarchar](max) NULL,
	[FileTableNameColumnCollation] [nvarchar](max) NULL,
	[FileTableNamespaceEnabled] [bit] NULL,
	[HasAfterTrigger] [bit] NULL,
	[HasClassifiedColumn] [bit] NULL,
	[HasClusteredColumnStoreIndex] [bit] NULL,
	[HasClusteredIndex] [bit] NULL,
	[HasCompressedPartitions] [bit] NULL,
	[HasDeleteTrigger] [bit] NULL,
	[HasHeapIndex] [bit] NULL,
	[HasIndex] [bit] NULL,
	[HasInsertTrigger] [bit] NULL,
	[HasInsteadOfTrigger] [bit] NULL,
	[HasNonClusteredColumnStoreIndex] [bit] NULL,
	[HasNonClusteredIndex] [bit] NULL,
	[HasPrimaryClusteredIndex] [bit] NULL,
	[HasSparseColumn] [bit] NULL,
	[HasSpatialData] [bit] NULL,
	[HasSystemTimePeriod] [bit] NULL,
	[HasUpdateTrigger] [bit] NULL,
	[HasXmlCompressedPartitions] [bit] NULL,
	[HasXmlData] [bit] NULL,
	[HasXmlIndex] [bit] NULL,
	[HistoryTableID] [int] NULL,
	[HistoryTableName] [nvarchar](max) NULL,
	[HistoryTableSchema] [nvarchar](max) NULL,
	[ID] [int] NULL,
	[IndexSpaceUsed] [float] NULL,
	[IsDroppedLedgerTable] [bit] NULL,
	[IsExternal] [bit] NULL,
	[IsFileTable] [bit] NULL,
	[IsIndexable] [bit] NULL,
	[IsLedger] [bit] NULL,
	[IsMemoryOptimized] [bit] NULL,
	[IsPartitioned] [bit] NULL,
	[IsSchemaOwned] [bit] NULL,
	[IsSystemObject] [bit] NULL,
	[IsSystemVersioned] [bit] NULL,
	[LedgerType] [nvarchar](max) NULL,
	[LedgerViewName] [nvarchar](max) NULL,
	[LedgerViewOperationTypeColumnName] [nvarchar](max) NULL,
	[LedgerViewOperationTypeDescColumnName] [nvarchar](max) NULL,
	[LedgerViewSchema] [nvarchar](max) NULL,
	[LedgerViewSequenceNumberColumnName] [nvarchar](max) NULL,
	[LedgerViewTransactionIdColumnName] [nvarchar](max) NULL,
	[Location] [nvarchar](max) NULL,
	[LockEscalation] [nvarchar](max) NULL,
	[Owner] [nvarchar](max) NULL,
	[PartitionScheme] [nvarchar](max) NULL,
	[QuotedIdentifierStatus] [bit] NULL,
	[RejectSampleValue] [float] NULL,
	[RejectType] [nvarchar](max) NULL,
	[RejectValue] [float] NULL,
	[RemoteDataArchiveDataMigrationState] [nvarchar](max) NULL,
	[RemoteDataArchiveEnabled] [bit] NULL,
	[RemoteDataArchiveFilterPredicate] [nvarchar](max) NULL,
	[RemoteObjectName] [nvarchar](max) NULL,
	[RemoteSchemaName] [nvarchar](max) NULL,
	[RemoteTableName] [nvarchar](max) NULL,
	[RemoteTableProvisioned] [bit] NULL,
	[Replicated] [bit] NULL,
	[RowCount] [bigint] NULL,
	[ShardingColumnName] [nvarchar](max) NULL,
	[SystemTimePeriodEndColumn] [nvarchar](max) NULL,
	[SystemTimePeriodStartColumn] [nvarchar](max) NULL,
	[TemporalType] [nvarchar](max) NULL,
	[TextFileGroup] [nvarchar](max) NULL,
	[TrackColumnsUpdatedEnabled] [bit] NULL,
	[FileFormatNameOd] [nvarchar](max) NULL,
	[HistoryRetentionPeriod] [int] NULL,
	[HistoryRetentionPeriodUnit] [nvarchar](max) NULL,
	[LocationOd] [nvarchar](max) NULL,
	[DwTableDistribution] [nvarchar](max) NULL,
	[RejectedRowLocation] [nvarchar](max) NULL,
	[Events] [nvarchar](max) NULL,
	[Triggers] [nvarchar](max) NULL,
	[Statistics] [nvarchar](max) NULL,
	[FullTextIndex] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Schema] [nvarchar](max) NULL,
	[ExtendedProperties] [nvarchar](max) NULL,
	[Columns] [nvarchar](max) NULL,
	[ParentCollection] [nvarchar](max) NULL,
	[Urn] [nvarchar](max) NULL,
	[Properties] [nvarchar](max) NULL,
	[ServerVersion] [nvarchar](max) NULL,
	[DatabaseEngineType] [nvarchar](max) NULL,
	[DatabaseEngineEdition] [nvarchar](max) NULL,
	[ExecutionManager] [nvarchar](max) NULL,
	[UserData] [nvarchar](max) NULL,
	[State] [nvarchar](max) NULL,
	[IsDesignMode] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ReplicaAGSync]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ReplicaAGSync](
	[ComputerName] [nvarchar](max) NULL,
	[InstanceName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[AvailabilityGroup] [nvarchar](max) NULL,
	[Replica] [nvarchar](max) NULL,
	[Parent] [nvarchar](max) NULL,
	[AvailabilityMode] [nvarchar](max) NULL,
	[BackupPriority] [int] NULL,
	[ConnectionModeInPrimaryRole] [nvarchar](max) NULL,
	[ConnectionModeInSecondaryRole] [nvarchar](max) NULL,
	[ConnectionState] [nvarchar](max) NULL,
	[CreateDate] [datetime2](7) NULL,
	[DateLastModified] [datetime2](7) NULL,
	[EndpointUrl] [nvarchar](max) NULL,
	[FailoverMode] [nvarchar](max) NULL,
	[JoinState] [nvarchar](max) NULL,
	[LastConnectErrorDescription] [nvarchar](max) NULL,
	[LastConnectErrorNumber] [int] NULL,
	[LastConnectErrorTimestamp] [datetime2](7) NULL,
	[MemberState] [nvarchar](max) NULL,
	[OperationalState] [nvarchar](max) NULL,
	[Owner] [nvarchar](max) NULL,
	[QuorumVoteCount] [int] NULL,
	[ReadonlyRoutingConnectionUrl] [nvarchar](max) NULL,
	[Role] [nvarchar](max) NULL,
	[RollupRecoveryState] [nvarchar](max) NULL,
	[RollupSynchronizationState] [nvarchar](max) NULL,
	[SeedingMode] [nvarchar](max) NULL,
	[SessionTimeout] [int] NULL,
	[UniqueId] [uniqueidentifier] NULL,
	[ReadonlyRoutingList] [nvarchar](max) NULL,
	[LoadBalancedReadOnlyRoutingList] [nvarchar](max) NULL,
	[LoadBalancedReadOnlyRoutingListDisplayString] [nvarchar](max) NULL,
	[IsSeedingModeSupported] [bit] NULL,
	[Name] [nvarchar](max) NULL,
	[Urn] [nvarchar](max) NULL,
	[Properties] [nvarchar](max) NULL,
	[DatabaseEngineType] [nvarchar](max) NULL,
	[DatabaseEngineEdition] [nvarchar](max) NULL,
	[ExecutionManager] [nvarchar](max) NULL,
	[UserData] [nvarchar](max) NULL,
	[State] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SecurityAudit_temp]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SecurityAudit_temp](
	[DomainName] [nvarchar](max) NULL,
	[ServerName] [nvarchar](max) NULL,
	[loginname] [nvarchar](max) NULL,
	[createdate] [datetime2](7) NULL,
	[RecCreatedDate] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SecurityAudit1]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SecurityAudit1](
	[CurrentWeek] [int] NULL,
	[RecCreatedDate] [nvarchar](max) NULL,
	[DomainName] [nvarchar](max) NULL,
	[ServerName] [nvarchar](max) NULL,
	[loginname] [nvarchar](max) NULL,
	[createdate] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SecurityAudit2]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SecurityAudit2](
	[DomainName] [nvarchar](max) NULL,
	[ServerName] [nvarchar](max) NULL,
	[loginname] [nvarchar](max) NULL,
	[createdate] [datetime2](7) NULL,
	[RecCreatedDate] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Server_AppName]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Server_AppName](
	[ID] [varchar](50) NULL,
	[MachineName] [varchar](50) NULL,
	[Application] [varchar](50) NULL,
	[DC] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Server_IPAddress]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Server_IPAddress](
	[ComputerName] [nvarchar](max) NULL,
	[IPAddress] [nvarchar](max) NULL,
	[DomainName] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ServerStatus]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ServerStatus](
	[ID] [nvarchar](50) NULL,
	[DomainName] [nvarchar](50) NULL,
	[ServerInstance] [nvarchar](50) NULL,
	[Status] [nvarchar](50) NULL,
	[Category] [nvarchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SQLBuild]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SQLBuild](
	[SqlInstance] [nvarchar](max) NULL,
	[BuildLevel] [nvarchar](max) NULL,
	[SPLevel] [nvarchar](max) NULL,
	[CULevel] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SQLMaintJobFailed]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SQLMaintJobFailed](
	[Srv] [nvarchar](128) NULL,
	[job_name] [nvarchar](256) NULL,
	[date_time] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SQLPatch2012Version]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SQLPatch2012Version](
	[SqlInstance] [nvarchar](max) NULL,
	[BuildLevel] [nvarchar](max) NULL,
	[BuildTarget] [nvarchar](max) NULL,
	[Compliant] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SQLPatch2014Version]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SQLPatch2014Version](
	[SqlInstance] [nvarchar](max) NULL,
	[BuildLevel] [nvarchar](max) NULL,
	[BuildTarget] [nvarchar](max) NULL,
	[Compliant] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SQLPatch2016Version]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SQLPatch2016Version](
	[SqlInstance] [nvarchar](max) NULL,
	[BuildLevel] [nvarchar](max) NULL,
	[BuildTarget] [nvarchar](max) NULL,
	[Compliant] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SQLPatch2017Version]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SQLPatch2017Version](
	[SqlInstance] [nvarchar](max) NULL,
	[BuildLevel] [nvarchar](max) NULL,
	[BuildTarget] [nvarchar](max) NULL,
	[Compliant] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SQLPatch2019Version]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SQLPatch2019Version](
	[SqlInstance] [nvarchar](max) NULL,
	[BuildLevel] [nvarchar](max) NULL,
	[BuildTarget] [nvarchar](max) NULL,
	[Compliant] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[sqlSERVICE]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[sqlSERVICE](
	[Column1] [nvarchar](max) NULL,
	[servicename] [nvarchar](max) NULL,
	[status_desc] [nvarchar](max) NULL,
	[last_startup_time] [datetimeoffset](7) NULL,
	[service_account] [nvarchar](max) NULL,
	[is_clustered] [nvarchar](max) NULL,
	[cluster_nodename] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[status_12]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[status_12](
	[MachineName] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[InstanceName] [nvarchar](max) NULL,
	[FullName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Port] [int] NULL,
	[TcpConnected] [bit] NULL,
	[SqlConnected] [bit] NULL,
	[DnsResolution] [nvarchar](max) NULL,
	[Ping] [bit] NULL,
	[BrowseReply] [nvarchar](max) NULL,
	[Services] [nvarchar](max) NULL,
	[SystemServices] [nvarchar](max) NULL,
	[SPNs] [nvarchar](max) NULL,
	[PortsScanned] [nvarchar](max) NULL,
	[Availability] [nvarchar](max) NULL,
	[Confidence] [nvarchar](max) NULL,
	[ScanTypes] [nvarchar](max) NULL,
	[Timestamp] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TblAfterPatch]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TblAfterPatch](
	[Servername] [nvarchar](max) NULL,
	[servicename] [nvarchar](max) NULL,
	[status_desc] [nvarchar](max) NULL,
	[last_startup_time] [datetimeoffset](7) NULL,
	[service_account] [nvarchar](max) NULL,
	[ISClustered] [nvarchar](max) NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TblAfterPatchCluster]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TblAfterPatchCluster](
	[Servername] [nvarchar](max) NULL,
	[NodeName] [nvarchar](max) NULL,
	[status] [int] NULL,
	[status_description] [nvarchar](max) NULL,
	[is_current_owner] [bit] NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TblAfterPatchOffline]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TblAfterPatchOffline](
	[Servername] [nvarchar](max) NULL,
	[Databasename] [nvarchar](max) NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TblBeforeDrive]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TblBeforeDrive](
	[volume_mount_point] [nvarchar](max) NULL,
	[srv] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TblBeforePatch]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TblBeforePatch](
	[Servername] [nvarchar](max) NULL,
	[servicename] [nvarchar](max) NULL,
	[status_desc] [nvarchar](max) NULL,
	[last_startup_time] [datetimeoffset](7) NULL,
	[service_account] [nvarchar](max) NULL,
	[ISClustered] [nvarchar](max) NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TblBeforePatchCluster]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TblBeforePatchCluster](
	[Servername] [nvarchar](max) NULL,
	[NodeName] [nvarchar](max) NULL,
	[status] [int] NULL,
	[status_description] [nvarchar](max) NULL,
	[is_current_owner] [bit] NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TblBeforePatchOffline]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TblBeforePatchOffline](
	[Servername] [nvarchar](max) NULL,
	[Databasename] [nvarchar](max) NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TblbkpBeforePatch]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TblbkpBeforePatch](
	[Servername] [nvarchar](max) NULL,
	[servicename] [nvarchar](max) NULL,
	[status_desc] [nvarchar](max) NULL,
	[last_startup_time] [datetimeoffset](7) NULL,
	[service_account] [nvarchar](max) NULL,
	[ISClustered] [nvarchar](max) NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TblbkpBeforePatchCluster]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TblbkpBeforePatchCluster](
	[Servername] [nvarchar](max) NULL,
	[NodeName] [nvarchar](max) NULL,
	[status] [int] NULL,
	[status_description] [nvarchar](max) NULL,
	[is_current_owner] [bit] NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TblbkpTblBeforePatchOffline]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TblbkpTblBeforePatchOffline](
	[Servername] [nvarchar](max) NULL,
	[Databasename] [nvarchar](max) NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TblDiskinfo]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TblDiskinfo](
	[SystemName] [nvarchar](max) NULL,
	[DeviceID] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TblLongrunningQuery]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TblLongrunningQuery](
	[Servername] [nvarchar](max) NULL,
	[session_id] [smallint] NULL,
	[start_time] [datetime2](7) NULL,
	[total_elapsed_time] [int] NULL,
	[wait_type] [nvarchar](max) NULL,
	[wait_time] [int] NULL,
	[cpu_time] [int] NULL,
	[blocked_by_session] [nvarchar](max) NULL,
	[text] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tDBBackup]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tDBBackup](
	[LogId] [int] IDENTITY(1,1) NOT NULL,
	[dbid] [smallint] NULL,
	[DatabaseName] [varchar](256) NOT NULL,
	[EventType] [varchar](50) NOT NULL,
	[SqlCommand] [varchar](4000) NOT NULL,
	[LoginName] [varchar](256) NOT NULL,
	[BackupGrp] [smallint] NULL,
	[TranGrp] [smallint] NULL,
	[EventDate] [datetime] NOT NULL,
	[Deleted] [bit] NOT NULL,
	[ModDate] [datetime] NULL,
	[Retention] [smallint] NULL,
	[LastBackup] [datetime] NULL,
	[SkipIndexDefrag] [char](1) NULL,
	[SkipIntegrityCheck] [char](1) NULL,
	[SkipDbBackup] [char](1) NULL,
 CONSTRAINT [PK_tDBBackup] PRIMARY KEY CLUSTERED 
(
	[LogId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tDBUDPOverrides]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tDBUDPOverrides](
	[UDP_Path] [varchar](2000) NULL,
	[UDP_Compression] [tinyint] NULL,
	[UDP_Stripes] [tinyint] NULL,
	[UDP_Numbufs] [tinyint] NULL,
	[UDP_Media_Server] [varchar](70) NULL,
	[UDP_Maxtransfersize] [tinyint] NULL,
	[UDP_Blocksize] [tinyint] NULL,
	[UDP_Batchsize] [tinyint] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TempBefDrives]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TempBefDrives](
	[ComputerName] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TempBefOffline]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TempBefOffline](
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Status] [nvarchar](max) NULL,
	[DateKey] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TempBefPatch]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TempBefPatch](
	[Servername] [nvarchar](max) NULL,
	[servicename] [nvarchar](max) NULL,
	[status_desc] [nvarchar](max) NULL,
	[last_startup_time] [datetimeoffset](7) NULL,
	[service_account] [nvarchar](max) NULL,
	[ISClustered] [nvarchar](max) NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Tempclunodes]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Tempclunodes](
	[Servername] [nvarchar](max) NULL,
	[NodeName] [nvarchar](max) NULL,
	[status] [int] NULL,
	[status_description] [nvarchar](max) NULL,
	[is_current_owner] [bit] NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TempDrives]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TempDrives](
	[PSComputerName] [nvarchar](max) NULL,
	[DeviceID] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TempOffline]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TempOffline](
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Status] [nvarchar](max) NULL,
	[DateKey] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TempPostclunodes]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TempPostclunodes](
	[Servername] [nvarchar](max) NULL,
	[NodeName] [nvarchar](max) NULL,
	[status] [int] NULL,
	[status_description] [nvarchar](max) NULL,
	[is_current_owner] [bit] NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TempPostDrives]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TempPostDrives](
	[PSComputerName] [nvarchar](max) NULL,
	[DeviceID] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TempPostOffline]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TempPostOffline](
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Status] [nvarchar](max) NULL,
	[DateKey] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TempPostPatch]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TempPostPatch](
	[Servername] [nvarchar](max) NULL,
	[servicename] [nvarchar](max) NULL,
	[status_desc] [nvarchar](max) NULL,
	[last_startup_time] [datetimeoffset](7) NULL,
	[service_account] [nvarchar](max) NULL,
	[ISClustered] [nvarchar](max) NULL,
	[CollectionDateTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TlogLargerthanData]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TlogLargerthanData](
	[ComputerName] [nvarchar](max) NULL,
	[InstanceName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Database] [nvarchar](max) NULL,
	[FileName] [nvarchar](max) NULL,
	[FileGroup] [nvarchar](max) NULL,
	[PhysicalName] [nvarchar](max) NULL,
	[FileType] [nvarchar](max) NULL,
	[UsedSpace] [bigint] NULL,
	[FreeSpace] [bigint] NULL,
	[FileSize] [bigint] NULL,
	[PercentUsed] [float] NULL,
	[AutoGrowth] [bigint] NULL,
	[AutoGrowType] [nvarchar](max) NULL,
	[SpaceUntilMaxSize] [bigint] NULL,
	[AutoGrowthPossible] [bigint] NULL,
	[UnusableSpace] [bigint] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserDB]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserDB](
	[DateKey] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserDB_old]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserDB_old](
	[SqlInstance] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[WatchDbLogins]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[WatchDbLogins](
	[ComputerName] [nvarchar](max) NULL,
	[InstanceName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[LoginTime] [datetime2](7) NULL,
	[Login] [nvarchar](max) NULL,
	[Host] [nvarchar](max) NULL,
	[Program] [nvarchar](max) NULL,
	[DatabaseId] [smallint] NULL,
	[Database] [nvarchar](max) NULL,
	[IsSystem] [bit] NULL,
	[CaptureTime] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [eva].[Assessment]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [eva].[Assessment](
	[run_date] [smalldatetime] NOT NULL,
	[policy_name] [varchar](128) NULL,
	[obj_name] [varchar](256) NULL,
	[key_name] [varchar](256) NOT NULL,
	[result] [varchar](8) NULL,
	[config_value] [varchar](256) NULL,
	[running_value] [varchar](256) NULL,
	[autofix_command] [nvarchar](4000) NULL,
	[sql_exec_outcome] [varchar](8) NULL,
	[error_msg] [varchar](4000) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [eva].[Exceptions]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [eva].[Exceptions](
	[policy_id] [smallint] NOT NULL,
	[obj_name] [varchar](256) NULL,
	[key_name] [varchar](256) NULL,
	[value] [varchar](256) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [eva].[PolicyCatalog]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [eva].[PolicyCatalog](
	[id] [smallint] NOT NULL,
	[policy_name] [varchar](128) NOT NULL,
	[is_active] [bit] NOT NULL,
	[autofix] [bit] NULL,
	[description] [varchar](512) NULL,
	[lastrundate] [datetime] NULL,
	[executed_by] [varchar](256) NULL,
 CONSTRAINT [PK_PolicyCatalog] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [eva].[zDataPurgeFeed]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [eva].[zDataPurgeFeed](
	[database_name] [varchar](128) NOT NULL,
	[schema_name] [varchar](50) NULL,
	[table_name] [varchar](256) NOT NULL,
	[column_name] [varchar](256) NULL,
	[append_where_predicate] [varchar](2048) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [eva].[zFileCleanupPathFeed]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [eva].[zFileCleanupPathFeed](
	[path] [varchar](256) NOT NULL,
	[extension] [varchar](128) NULL,
	[path_type] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Maint].[MaintenanceParameters]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Maint].[MaintenanceParameters](
	[MaintType] [varchar](64) NOT NULL,
	[ParameterName] [varchar](256) NOT NULL,
	[DefaultValue] [varchar](256) NULL,
	[ConfigValue] [varchar](256) NULL,
	[AvailableValue] [varchar](512) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Security].[InValidLogin]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Security].[InValidLogin](
	[SID] [varbinary](max) NULL,
	[NT Login] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [Security].[InValidLogin_1]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Security].[InValidLogin_1](
	[SID] [varbinary](max) NULL,
	[NT Login] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [Security].[SecurityAudit]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Security].[SecurityAudit](
	[DomainName] [nvarchar](max) NULL,
	[ServerName] [nvarchar](max) NULL,
	[loginname] [nvarchar](max) NULL,
	[createdate] [datetime2](7) NULL,
	[RecCreatedDate] [nvarchar](max) NULL,
	[RunID] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [Security].[SecurityAudit_1]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Security].[SecurityAudit_1](
	[DomainName] [nvarchar](max) NULL,
	[ServerName] [nvarchar](max) NULL,
	[loginname] [nvarchar](max) NULL,
	[createdate] [datetime2](7) NULL,
	[RecCreatedDate] [nvarchar](max) NULL,
	[RunID] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [Security].[SecurityAudit_exemptions_1]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Security].[SecurityAudit_exemptions_1](
	[loginname] [nvarchar](max) NULL,
	[comments] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [Security].[SecurityAudit_old]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Security].[SecurityAudit_old](
	[DomainName] [nvarchar](max) NULL,
	[ServerName] [nvarchar](max) NULL,
	[loginname] [nvarchar](max) NULL,
	[createdate] [datetime2](7) NULL,
	[RecCreatedDate] [nvarchar](max) NULL,
	[RunID] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [stg].[DbaDatabase]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stg].[DbaDatabase](
	[DateKey] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[ServerVersion] [nvarchar](max) NULL,
	[ID] [int] NULL,
	[Name] [nvarchar](max) NULL,
	[SizeMB] [float] NULL,
	[CreateDate] [datetime2](7) NULL,
	[LastFullBackup] [datetime2](7) NULL,
	[LastDiffBackup] [datetime2](7) NULL,
	[LastLogBackup] [datetime2](7) NULL,
	[DatabaseEngineType] [nvarchar](max) NULL,
	[DatabaseEngineEdition] [nvarchar](max) NULL,
	[AutoClose] [bit] NULL,
	[AutoShrink] [bit] NULL,
	[BrokerEnabled] [bit] NULL,
	[Collation] [nvarchar](max) NULL,
	[CompatibilityLevel] [nvarchar](max) NULL,
	[DataSpaceUsage] [float] NULL,
	[EncryptionEnabled] [bit] NULL,
	[LastGoodCheckDbTime] [nvarchar](max) NULL,
	[LogReuseWaitStatus] [nvarchar](max) NULL,
	[Owner] [nvarchar](max) NULL,
	[RecoveryModel] [nvarchar](max) NULL,
	[Size] [float] NULL,
	[SpaceAvailable] [float] NULL,
	[Status] [nvarchar](max) NULL,
	[State] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [stg].[DbaDbLogSpace]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stg].[DbaDbLogSpace](
	[DateKey] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Database] [nvarchar](max) NULL,
	[LogSize] [bigint] NULL,
	[LogSpaceUsed] [bigint] NULL,
	[LogSpaceUsedPercent] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [stg].[DbaDiskSpace]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stg].[DbaDiskSpace](
	[DateKey] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Label] [nvarchar](max) NULL,
	[Capacity] [bigint] NULL,
	[Free] [bigint] NULL,
	[PercentFree] [float] NULL,
	[BlockSize] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [stg].[DbaMaxMemory]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stg].[DbaMaxMemory](
	[DateKey] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Total] [int] NULL,
	[MaxValue] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [stg].[DbaService]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stg].[DbaService](
	[DateKey] [nvarchar](max) NULL,
	[PSComputerName] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[DisplayName] [nvarchar](max) NULL,
	[ServiceType] [nvarchar](max) NULL,
	[ServiceName] [nvarchar](max) NULL,
	[StartMode] [nvarchar](max) NULL,
	[State] [nvarchar](max) NULL,
	[StartName] [nvarchar](max) NULL,
	[ProcessId] [bigint] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [svc].[svc_acct]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [svc].[svc_acct](
	[svc_name] [nvarchar](15) NOT NULL,
	[pwd] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  View [AdminServer].[HPS_Admin_Backup_Failed_Report]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Admin_Backup_Failed_Report]
AS
SELECT TOP 100 PERCENT
       [Server]
      ,[LogDate]
      ,[ProcessInfo]
      ,[Text]
  FROM [DBA].[AdminServer].[SQL_ErrorLog]
WHERE DATEDIFF(HH, LogDate, GETDATE()) < 24
AND TEXT LIKE '%Cannot open backup device%'
UNION ALL
SELECT TOP 100 PERCENT
       [Server]
      ,[LogDate]
      ,[ProcessInfo]
      ,[Text]
  FROM [DBA].[AdminServer].[SQL_ErrorLog]
WHERE DATEDIFF(HH, LogDate, GETDATE()) < 24
AND TEXT LIKE '%BACKUP failed to complete%'
UNION ALL
SELECT TOP 100 PERCENT
       [Server]
      ,[LogDate]
      ,[ProcessInfo]
      ,[Text]
  FROM [DBA].[AdminServer].[SQL_ErrorLog]
WHERE DATEDIFF(HH, LogDate, GETDATE()) < 24
AND TEXT LIKE '%995(The I/O operation%'
UNION ALL
SELECT TOP 100 PERCENT
       [Server]
      ,[LogDate]
      ,[ProcessInfo]
      ,[Text]
  FROM [DBA].[AdminServer].[SQL_ErrorLog]
WHERE DATEDIFF(HH, LogDate, GETDATE()) < 24
AND TEXT LIKE '%BackupMedium::ReportIoError: write failure on backup device%'
ORDER BY Server, LogDate desC








GO
/****** Object:  View [AdminServer].[HPS_Admin_BestPractices_Current]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [AdminServer].[HPS_Admin_BestPractices_Current]
AS
/****** Script for SelectTopNRows command from SSMS  ******/
SELECT R.[Date_Key]
      ,R.[instance_name]
      ,R.[best_practice_name]
      ,R.[notes]
      ,R.[steps]
	  ,M.DBSAServerType AS [SLA]
  FROM [DBA].[AdminServer].[BestPractices_Repository] AS R INNER JOIN [DBA].[AdminControl].[DBServersAll] AS M ON
   R.instance_name = M.DBSAServerName
  WHERE [Date_Key] = (SELECT MAX([Date_Key]) FROM [DBA].[AdminServer].[BestPractices_Repository])


GO
/****** Object:  View [AdminServer].[HPS_Admin_Dataabse_Role_Information]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [AdminServer].[HPS_Admin_Dataabse_Role_Information]
AS
SELECT TOP 100 PERCENT 
	   [Date_Key]
      ,[ServerName]
      ,[DatabaseName]
      ,[UserName]
      ,[DBRoleName]
  FROM [DBA].[AdminServer].[Database_Role_Memberships] 
  WHERE Date_Key = (
  SELECT MAX(Date_Key) FROM [DBA].[AdminServer].[Database_Role_Memberships])
  ORDER BY [ServerName], [DatabaseName], [UserName]





GO
/****** Object:  View [AdminServer].[HPS_Admin_Database_Information_Bowne]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Admin_Database_Information_Bowne]
AS
SELECT TOP 100 PERCENT
	   S.[CustomerName]
      ,S.[ServerName]
      ,D.[DBSAServerType]
      ,D.[DatabaseName]
      ,SUM(D.[FileSizeMB]) AS TotalDBSizeMB
FROM [ENSONODBA].[AdminServer].[HPS_Admin_Server_Information_Bowne] AS S LEFT JOIN [ENSONODBA].[AdminServer].[HPS_Admin_Database_Information_All] AS D ON
S.ServerName = D.DBSAServerName 
GROUP BY S.CustomerName, S.ServerName, D.DBSAServerType, D.DatabaseName
ORDER BY S.CustomerName, S.ServerName, D.DBSAServerType, D.DatabaseName





GO
/****** Object:  View [AdminServer].[HPS_Admin_Database_Information_Over_30000_MB]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [AdminServer].[HPS_Admin_Database_Information_Over_30000_MB]
AS
SELECT TOP 100 PERCENT [Date_Key]
      ,[DBSACustomerName] AS CustomerName
      ,S1.[DBSAServerName] AS ServerName
      ,[DBSADomain] AS Domain
      ,CASE WHEN [DBSAServerType] = 'P' THEN 'Production'
			WHEN [DBSAServerType] = 'T' THEN 'Test'
			WHEN [DBSAServerType] = 'S' THEN 'Stage'
			WHEN [DBSAServerType] = 'D' THEN 'Development'
			WHEN [DBSAServerType] = 'B' THEN 'Disaster Recovery'
			ELSE 'Undefined Type' END AS ServerType
      ,S1.[DatabaseName]
      ,[FileSizeMB]
      ,[LogicalFileName]
      ,[PhysicalFileName]
      ,[RecoveryMode]
      ,[FreeSpaceMB]
      ,[FreeSpacePct]
  FROM [ENSONODBA].[AdminServer].[HPS_Admin_Database_Information_All] AS S1 INNER JOIN (
  SELECT DISTINCT [DBSAServerName],[DatabaseName] FROM [ENSONODBA].[AdminServer].[HPS_Admin_Database_Information_All]
  WHERE CONVERT(int,FileSizeMB) > 30000) AS L ON S1.DBSAServerName = L.DBSAServerName AND S1.DatabaseName = L.DatabaseName
  WHERE RIGHT(S1.[PhysicalFileName],3) <> 'LDF'
  ORDER BY S1.DBSAServerName, S1.DatabaseName, S1.LogicalFileName
  





GO
/****** Object:  View [AdminServer].[HPS_Admin_Database_OWNER_Exceptions]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





CREATE VIEW [AdminServer].[HPS_Admin_Database_OWNER_Exceptions]
AS
SELECT TOP 100 percent [Date_Key]
      ,[ServerName]
      ,[name]
      ,[create_date]
      ,[Database_Owner]
      ,CASE WHEN [Database_Owner] <> 'sa' THEN 'Database Owner not set to Standard (sa)'
		    ELSE 'Database Owner Set to Standard' END AS DBOwner_Review
	  ,[DBSAServerDBA_Primary] AS DBA_Primary
  FROM [DBA].[AdminServer].[SQLServerDatabaseProperties_Repository] INNER JOIN [DBA].[AdminControl].[DBServersAll] ON
  [DBA].[AdminServer].[SQLServerDatabaseProperties_Repository].[ServerName] = [DBA].[AdminControl].[DBServersAll].[DBSAServerName]
WHERE [Date_Key] = (SELECT MAX(Date_Key) AS Date_Key FROM [DBA].[AdminServer].[SQLServerDatabaseProperties_Repository])
	AND [state_desc] = 'ONLINE'
	AND [Database_Owner] <> 'sa'
ORDER BY [ServerName], [name]
  
  




GO
/****** Object:  View [AdminServer].[HPS_Admin_Database_Properties_Encrypted]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO








CREATE VIEW [AdminServer].[HPS_Admin_Database_Properties_Encrypted]
AS
SELECT TOP 100 PERCENT [Date_Key]
      ,[ServerName]
      ,[name] AS DataabseName
      ,[create_date] AS CreateDate
      ,[compatibility_level] AS CompatabilityLevel
      ,CASE WHEN [is_encrypted] = 1 THEN 'Encrypted' ELSE 'Not Encrypted' END AS Encrypted
  FROM [DBA].[AdminServer].[SQLServerDatabaseProperties_Repository] 
  WHERE Date_Key = (SELECT MAX(Date_Key) FROM [DBA].[AdminServer].[SQLServerDatabaseProperties_Repository]) AND [is_encrypted] <> 0
  ORDER BY [ServerName], [name]
  
  






GO
/****** Object:  View [AdminServer].[HPS_Admin_Database_Properties_Exceptions]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO







CREATE VIEW [AdminServer].[HPS_Admin_Database_Properties_Exceptions]
AS
SELECT TOP 100 percent [Date_Key]
      ,[ServerName]
      ,[name]
      ,[create_date]
      ,[is_auto_close_on]
      ,[is_auto_shrink_on]
      ,[is_auto_update_stats_on]
      ,CASE WHEN [is_auto_close_on] = 1 THEN 'Auto Close not set to standard'
			ELSE 'Auto close set to standard' END AS AutoClose_Review
      ,CASE WHEN [is_auto_shrink_on] = 1 THEN 'Auto Shrink not set to standard'
			ELSE 'Auto Shrink set to standard' END AS AutoShrink_Review
      ,CASE WHEN [is_auto_update_stats_on] = 0 THEN 'Auto Update Stats not set to standard'
			ELSE 'Auto Update Stats set to standard' END AS AutoUpdateStats_Review
	  ,[DBSAServerDBA_Primary] AS DBA_Primary
  FROM [DBA].[AdminServer].[SQLServerDatabaseProperties_Repository] INNER JOIN DBA.AdminControl.DBServersAll ON
  [DBA].[AdminServer].[SQLServerDatabaseProperties_Repository].[ServerName] = DBA.AdminControl.DBServersAll.DBSAServerName
WHERE [DBA].[AdminServer].[SQLServerDatabaseProperties_Repository].[Date_Key] = (SELECT MAX(Date_Key) FROM [DBA].[AdminServer].[SQLServerDatabaseProperties_Repository])
	AND [state_desc] = 'ONLINE'
	AND name NOT IN ('DBA','master','model','msdb','tempdb')
	AND (is_auto_close_on = 1 OR is_auto_shrink_on = 1 OR is_auto_update_stats_on = 0)
ORDER BY [ServerName], [name]
  
  






GO
/****** Object:  View [AdminServer].[HPS_Admin_Database_RECOVERY_Model_Exceptions]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO








CREATE VIEW [AdminServer].[HPS_Admin_Database_RECOVERY_Model_Exceptions]
AS
SELECT TOP 100 percent [Date_Key]
      ,[ServerName]
      ,[name]
      ,[create_date]
      ,[recovery_model_desc]
      ,CASE WHEN (DBA.AdminControl.DBServersAll.DBSAServerType = 'P' and [recovery_model_desc] <> 'FULL') THEN
			'Standard for Production is FULL RecoveryModel'
			WHEN (DBA.AdminControl.DBServersAll.DBSAServerType NOT IN ('P', 'B') AND [recovery_model_desc] <> 'SIMPLE') THEN
			'Standard for Non-Production is SIMPLE RecoveryModel'
			ELSE 'Not Defined' END AS RecoveryModel_Review
	  ,[DBSAServerDBA_Primary] AS DBA_Primary
  FROM [DBA].[AdminServer].[SQLServerDatabaseProperties_Repository] INNER JOIN DBA.AdminControl.DBServersAll ON
  [DBA].[AdminServer].[SQLServerDatabaseProperties_Repository].[ServerName] = DBA.AdminControl.DBServersAll.DBSAServerName
WHERE Date_Key = (SELECT Max(Date_Key) FROM [DBA].[AdminServer].[SQLServerDatabaseProperties_Repository])
	AND [state_desc] = 'ONLINE'
	AND name NOT IN ('DBA','master','model','msdb','tempdb','distribution')
	AND ((DBA.AdminControl.DBServersAll.DBSAServerType = 'P' and [recovery_model_desc] <> 'FULL')
	OR (DBA.AdminControl.DBServersAll.DBSAServerType NOT IN ('P', 'B') AND [recovery_model_desc] <> 'SIMPLE'))
ORDER BY [ServerName], [name]
  
  







GO
/****** Object:  View [AdminServer].[HPS_Admin_Database_TempDB_Standards_Review]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO








CREATE VIEW [AdminServer].[HPS_Admin_Database_TempDB_Standards_Review]
AS
SELECT TOP 100 PERCENT
	 M.DBSACustomerName AS CustomerName
	,S1.[Server_Name]
	,S1.[Database_Name]
	,S1.[ProcessorCount] 
	,S1.[DataFileCount] 
	,CASE WHEN S1.ProcessorCount = S1.DataFileCount		THEN '1-To-1 Ration Standard'
	      WHEN S1.ProcessorCount/4 = S1.DataFileCount	THEN '4-To-1 Ration Standard'
		  WHEN S1.ProcessorCount/2 = S1.DataFileCount	THEN '2-To-1 Ration Standard'
		  ELSE 'TempDB Not set to Standards' END AS TempDB_Review
FROM
(
SELECT TOP 100 percent
       [Server_Name]
      ,[Database_Name]
      ,[ProcessorCount]
      ,COUNT([File_Type]) AS DataFileCount
  FROM [ENSONODBA].[AdminServer].[HPS_Admin_Database_IO_Information_All_Current]
  WHERE Database_Name = 'TempDB' AND File_Type IN ('MDF','NDF')
  GROUP BY [Server_Name],[Database_Name],[ProcessorCount]) AS S1 INNER JOIN [ENSONODBA].[AdminControl].[DBServersAll] AS M ON
  S1.Server_Name = M.DBSAServerName
  ORDER BY S1.[Server_Name],S1.[Database_Name],S1.[ProcessorCount]




GO
/****** Object:  View [AdminServer].[HPS_Admin_JobInformation_EXCEPTIONS]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [AdminServer].[HPS_Admin_JobInformation_EXCEPTIONS]
AS
SELECT TOP 100 PERCENT [ServerName]
      ,[JobName]
      ,[Category]
      ,[JobEnabled]
      ,[IsScheduled]
      ,[StepNo]
      ,[StepName]
      ,[StepType]
      ,[RunAs]
      ,[Database]
      ,[ExecutableCommand]
      ,[OnSuccessAction]
      ,[RetryAttempts]
      ,[RetryInterval (Minutes)]
      ,[OnFailureAction]
      ,[JobScheduleName]
      ,[JobDeletionCriterion]
      ,[ScheduleEnabled]
      ,[ScheduleType]
      ,[Occurrence]
      ,[Recurrence]
      ,[Frequency]
      ,[ScheduleUsageStartDate]
      ,[ScheduleUsageEndDate]
      ,[ScheduleCreatedOn]
      ,[ScheduleLastModifiedOn]
  FROM [DBA].[AdminServer].[JobInformation_Repository]
  WHERE StepNo = 1 AND ((JobEnabled = 'No') OR
		(JobEnabled = 'Yes' and IsScheduled = 'No'))
  ORDER BY [ServerName], [JobName], [JobScheduleName]


GO
/****** Object:  View [AdminServer].[HPS_Admin_Server_Information_Bowne]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Admin_Server_Information_Bowne]
AS
/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP 100 PERCENT
       [DBSACustomerName] AS CustomerName
      ,[DBSAServerName] AS ServerName
	  ,CASE WHEN [DBSASpotlightDayTimeMonitoring] = 'DG' THEN 'Downers Grove' 
		    WHEN [DBSASpotlightDayTimeMonitoring] = 'EGV' THEN 'Elk Grove Village'
		    WHEN [DBSASpotlightDayTimeMonitoring] = 'CWY' THEN 'Comway'
		    ELSE [DBSASpotlightDayTimeMonitoring] END AS EnvironmentLocation
      ,[DBSADomain] AS Domain
      ,CASE WHEN DBSAServerType = 'P' THEN 'Production'
		 WHEN DBSAServerType = 'T' THEN 'Test'
		 WHEN DBSAServerType = 'S' THEN 'Staging'
		 WHEN DBSAServerType = 'D' THEN 'Development'
		 WHEN DBSAServerType = 'B' THEN 'Disaster Recovery'
		 ELSE 'Undefined' END AS ServerType
      ,[DBSADescription] AS Description
      ,[DBSADiskCapacityAllocationMB]
      ,CASE WHEN [DBSAClustered] = 1 THEN 'Yes'
            ELSE 'NO' END AS [Clustered]
      ,CASE WHEN [DBSAVirtualMachine] = 1 THEN 'Yes'
            ELSE 'No' END AS VirtualMachine
      ,[DBSAProcessors] AS Processors
      ,[DBSADiskCapacityAllocationMB] AS CapacityAllocationMB
      ,[DBSAServerDBA_Primary] AS ServerDBA_Primary
      ,[DBSAServerDBA_Secondary] AS ServerDBA_Secondary
      ,[DBSABackupRepository] AS BackupRepository
      ,[DBSAServerIPAddress] AS ServerIPAddress
      ,[DBSAServerClusterdNode1IPAddress] AS ServerClusterdNode1IPAddress
      ,[DBSAServerClusterdNode2IPAddress] AS ServerClusterdNode2IPAddress
      ,[DBSAServerClusterdNode3IPAddress] AS ServerClusterdNode3IPAddress
      ,[DBSAServerClusterdNode4IPAddress] AS ServerClusterdNode4IPAddress
      ,[DBSAServerClusterdIPAddress] AS ServerClusterdIPAddress
      ,[DBSAServerClusterdVirtualName] AS ServerClusterdVirtualName
      ,[DBSAServerClusterdNode1Name] AS ServerClusterdNode1Name 
      ,[DBSAServerClusterdNode2Name] AS ServerClusterdNode2Name
      ,[DBSAServerClusterdNode3Name] AS ServerClusterdNode3Name
      ,[DBSAServerClusterdNode4Name] AS ServerClusterdNode4Name
      ,[DBSAInstanceBilled] AS InstanceBilled
      ,[DBSAInstanceSupported] AS InstanceSupported
      ,[DBSAInstallationType] AS InstanceType
      ,[DBSAPortNumber] AS PortNumber
  FROM [DBA].[AdminControl].[DBServersAll]
  WHERE [DBSADescription] LIKE 'Bowne%'
  ORDER BY DBSAServerName
  
  



GO
/****** Object:  View [AdminServer].[HPS_Admin_Server_Information_EOL]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [AdminServer].[HPS_Admin_Server_Information_EOL]
AS
/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP 100 PERCENT
       [DBSACustomerName] AS CustomerName
      ,[DBSAServerName] AS ServerName
	  ,CASE WHEN [DBSASpotlightDayTimeMonitoring] = 'DG' THEN 'Downers Grove' 
		    WHEN [DBSASpotlightDayTimeMonitoring] = 'EGV' THEN 'Elk Grove Village'
		    WHEN [DBSASpotlightDayTimeMonitoring] = 'CWY' THEN 'Comway'
		    ELSE [DBSASpotlightDayTimeMonitoring] END AS EnvironmentLocation
      ,[DBSADomain] AS Domain
      ,CASE WHEN DBSAServerType = 'P' THEN 'Production'
		 WHEN DBSAServerType = 'T' THEN 'Test'
		 WHEN DBSAServerType = 'S' THEN 'Staging'
		 WHEN DBSAServerType = 'D' THEN 'Development'
		 WHEN DBSAServerType = 'B' THEN 'Disaster Recovery'
		 ELSE 'Undefined' END AS ServerType
      ,[DBSADescription] AS Description
      ,[DBSADiskCapacityAllocationMB]
      ,CASE WHEN [DBSAClustered] = 1 THEN 'Yes'
            ELSE 'NO' END AS [Clustered]
      ,CASE WHEN [DBSAVirtualMachine] = 1 THEN 'Yes'
            ELSE 'No' END AS VirtualMachine
      ,[DBSAProcessors] AS Processors
      ,[DBSADiskCapacityAllocationMB] AS CapacityAllocationMB
      ,[DBSAServerDBA_Primary] AS ServerDBA_Primary
      ,[DBSAServerDBA_Secondary] AS ServerDBA_Secondary
      ,[DBSABackupRepository] AS BackupRepository
      ,[DBSAServerIPAddress] AS ServerIPAddress
      ,[DBSAServerClusterdNode1IPAddress] AS ServerClusterdNode1IPAddress
      ,[DBSAServerClusterdNode2IPAddress] AS ServerClusterdNode2IPAddress
      ,[DBSAServerClusterdNode3IPAddress] AS ServerClusterdNode3IPAddress
      ,[DBSAServerClusterdNode4IPAddress] AS ServerClusterdNode4IPAddress
      ,[DBSAServerClusterdIPAddress] AS ServerClusterdIPAddress
      ,[DBSAServerClusterdVirtualName] AS ServerClusterdVirtualName
      ,[DBSAServerClusterdNode1Name] AS ServerClusterdNode1Name 
      ,[DBSAServerClusterdNode2Name] AS ServerClusterdNode2Name
      ,[DBSAServerClusterdNode3Name] AS ServerClusterdNode3Name
      ,[DBSAServerClusterdNode4Name] AS ServerClusterdNode4Name
      ,[DBSAInstanceBilled] AS InstanceBilled
      ,[DBSAInstanceSupported] AS InstanceSupported
      ,[DBSAInstallationType] AS InstanceType
      ,[DBSAPortNumber] AS PortNumber
  FROM [DBA].[AdminControl].[DBServersAll]
  WHERE [DBSADescription] LIKE 'EOL%'
  ORDER BY DBSAServerName
  
  




GO
/****** Object:  View [AdminServer].[HPS_Admin_Server_Information_PreferredOwner]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO







CREATE VIEW [AdminServer].[HPS_Admin_Server_Information_PreferredOwner]
AS
SELECT TOP 100 PERCENT   
	   [DBSAServerName] AS DatabaseEnvironment
      ,[DBSADomain] AS Domain
	  ,CASE WHEN DBSAServerType = 'P' THEN 'Production'
		 WHEN DBSAServerType = 'T' THEN 'Test'
		 WHEN DBSAServerType = 'S' THEN 'Staging'
		 WHEN DBSAServerType = 'D' THEN 'Development'
		 WHEN DBSAServerType = 'B' THEN 'Disaster Recovery'
		 ELSE 'Undefined' END AS Server_Type
 	  ,CASE WHEN DBSASpotlightDayTimeMonitoring = 'EGV' THEN 'Elk Grove Village'
		 WHEN DBSASpotlightDayTimeMonitoring = 'CWY' THEN 'Conway'
		 WHEN DBSASpotlightDayTimeMonitoring = 'DG' THEN 'Downers Grove'
		 ELSE 'Unassigned' END AS EnvironmentLocation
	  ,CASE WHEN DBSAClustered = 1 THEN 'Clustered'
	        WHEN DBSAClustered = 0 THEN 'Not Clustered'
	        ELSE 'Not Set' END AS IsClustered
	  ,[DBSAMaintSchedule] AS Maintenance_Schedule
      ,[DBSAServerClusteredPreferredNode] AS PreferredNode
      ,[DBSAServerClusterdNode1Name] AS Node1_Name
      ,[DBSAServerClusterdNode2Name] AS Node2_Name
      ,[DBSAServerClusterdNode3Name] AS Node3_Name
  FROM [DBA].[AdminControl].[DBServersAll]
  WHERE DBSAServerType <> 'B' AND DBSAInstanceSupported = 'Y'
  UNION ALL
  SELECT TOP 100 PERCENT  
	   [DBSAServerName] AS DatabaseEnvironment
      ,[DBSADomain] AS Domain
	  ,CASE WHEN DBSAServerType = 'P' THEN 'Production'
		 WHEN DBSAServerType = 'T' THEN 'Test'
		 WHEN DBSAServerType = 'S' THEN 'Staging'
		 WHEN DBSAServerType = 'D' THEN 'Development'
		 WHEN DBSAServerType = 'B' THEN 'Disaster Recovery'
		 ELSE 'Undefined' END AS Server_Type
 	  ,CASE WHEN DBSASpotlightDayTimeMonitoring = 'EGV' THEN 'Elk Grove Village'
		 WHEN DBSASpotlightDayTimeMonitoring = 'CWY' THEN 'Conway'
		 WHEN DBSASpotlightDayTimeMonitoring = 'DG' THEN 'Downers Grove'
		 ELSE 'Unassigned' END AS EnvironmentLocation
	  ,CASE WHEN DBSAClustered = 1 THEN 'Clustered'
	        WHEN DBSAClustered = 0 THEN 'Not Clustered'
	        ELSE 'Not Set' END AS IsClustered
	  ,[DBSAMaintSchedule] AS Maintenance_Schedule
      ,[DBSAServerClusteredPreferredNode] AS PreferredNode
      ,[DBSAServerClusterdNode1Name] AS Node1_Name
      ,[DBSAServerClusterdNode2Name] AS Node2_Name
      ,[DBSAServerClusterdNode3Name] AS Node3_Name
  FROM [DBA].[AdminControl].[DBServersAll]
  WHERE DBSAServerType = 'B'  AND DBSAInstanceSupported = 'Y'
  
  








GO
/****** Object:  View [AdminServer].[HPS_Admin_Server_Obsolete_Logins]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [AdminServer].[HPS_Admin_Server_Obsolete_Logins]
AS
/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP 100 percent L.[Date_Key]
      ,L.[Server]
      ,M.DBSAServerDBA_Primary as DBA_Primary
      ,L.[Login Name]
      ,L.[Default Database]
      ,L.[CreateDate]
      ,L.[UpdateDate]
      ,L.[AccDate]
      ,L.[NT Name]
      ,L.[NT Grp]
      ,L.[NT User]
      ,L.[Sys Adm]
      ,L.[Sec Adm]
      ,L.[Srvr Adm]
      ,L.[Setup Adm]
      ,L.[Proc Adm]
      ,L.[Disk Adm]
      ,L.[DB Creator]
      ,L.[Bulk Adm]
  FROM [DBA].[AdminServer].[Logins] AS L INNER JOIN DBA.AdminControl.DBServersAll AS M ON
  L.[Server] = M.DBSAServerName
  INNER JOIN 
  DBA.AdminServer.Database_Role_Memberships AS RM ON
  L.Date_Key = RM.Date_Key AND
  L.Server = RM.ServerName AND
  L.[Login Name] = RM.UserName
  WHERE L.[Date_Key] = 
	    (SELECT MAX(Date_Key) as Date_Key FROM [DBA].[AdminServer].[Logins])
 		 AND RM.[DBRoleName] IS NULL 
		 AND L.[Login Name] NOT LIKE '##%'
		 AND L.[Login Name] NOT LIKE '%$%'
		 AND L.[Sys Adm] <> 1
		 AND L.[Login Name] NOT LIKE 'NT SER%'



 




GO
/****** Object:  View [AdminServer].[HPS_Export_DBServersAll_Current]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [AdminServer].[HPS_Export_DBServersAll_Current]
AS
SELECT [DBServersAllKEY]
      ,[DBSACustomerName]
      ,[DBSAServerName]
      ,[DBSAServerConnection]
      ,[DBSAServerConnectionMethod]
      ,[DBSADomain]
      ,[DBSAServerType]
      ,[DBSAActive]
      ,[DBSAManaged]
      ,[DBSAJobHistory]
      ,[DBSABackupHistory]
      ,[DBSATableLevel]
      ,[DBSALoginsDetail]
      ,[DBSADTSPackages]
      ,[DBSAInstanceBilled]
      ,[DBSAInstanceSupported]
      ,[DBSADescription]
      ,[DBSADiskCapacityAllocationMB]
      ,[DBSALightSpeed]
      ,[DBSAClustered]
      ,[DBSASANAttached]
      ,[DBSAProcessors]
      ,[DBSAServerDBA_Primary]
      ,[DBSAServerDBA_Secondary]
      ,[DBSABackupRepository]
      ,[DBSASANName]
      ,[DBSAServerIPAddress]
      ,[DBSAServerClusterdNode1IPAddress]
      ,[DBSAServerClusterdNode2IPAddress]
      ,[DBSAServerClusterdNode3IPAddress]
      ,[DBSAServerClusterdNode4IPAddress]
      ,[DBSAServerClusterdIPAddress]
      ,[DBSASpotlightDayTimeMonitoring]
      ,[DBSAServerClusterdVirtualName]
      ,[DBSAServerClusterdNode1Name]
      ,[DBSAServerClusterdNode2Name]
      ,[DBSAServerClusterdNode3Name]
      ,[DBSAServerClusterdNode4Name]
      ,[DBSAServerIPAddress_NAT]
      ,[DBSAInstallationType]
      ,[DBSAVirtualMachine]
      ,[DBSAPortNumber]
      ,[DBSAUpdateDate]
      ,[DBSAUpdateBy]
      ,[DBSAOffshoreAllowed]
      ,[DBSAServerClusteredPreferredNode]
	  ,[DBSASLA]
      ,[DBSAMaintSchedule]
  FROM [DBA].[AdminControl].[DBServersAll]






GO
/****** Object:  View [AdminServer].[HPS_Export_JobInformation_Current]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Export_JobInformation_Current]
AS
SELECT TOP 100 PERCENT [ServerName]
      ,[JobName]
      ,[Category]
      ,[JobEnabled]
      ,[IsScheduled]
      ,[StepNo]
      ,[StepName]
      ,[StepType]
      ,[RunAs]
      ,[Database]
      ,[ExecutableCommand]
      ,[OnSuccessAction]
      ,[RetryAttempts]
      ,[RetryInterval (Minutes)]
      ,[OnFailureAction]
      ,[JobScheduleName]
      ,[JobDeletionCriterion]
      ,[ScheduleEnabled]
      ,[ScheduleType]
      ,[Occurrence]
      ,[Recurrence]
      ,[Frequency]
      ,[ScheduleUsageStartDate]
      ,[ScheduleUsageEndDate]
      ,[ScheduleCreatedOn]
      ,[ScheduleLastModifiedOn]
  FROM [DBA].[AdminServer].[JobInformation_Repository]
  ORDER BY [ServerName], [JobName], [JobScheduleName], [StepNo]


GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_CustomerDataBases_All_CASD]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [AdminServer].[HPS_Inventory_Server_CustomerDataBases_All_CASD]
AS
SELECT     TOP 100 percent 
	Tenant, 
	Client, 
	SUBSTRING(RTRIM(Name), 1, CHARINDEX(':', RTRIM(Name), 1) - 1) AS DatabaseName, 
	SUBSTRING(RTRIM(Name), CHARINDEX(':', RTRIM(Name), 1 + CHARINDEX(':', RTRIM(Name), 1)) + 1, CHARINDEX(':', REVERSE(RTRIM(Name)), 1 + CHARINDEX(':', REVERSE(RTRIM(Name)), 1)) - 2) AS ServerName, 
	SUBSTRING(RTRIM(Name), CHARINDEX(':', RTRIM(Name), 1) + 1, CHARINDEX(':', REVERSE(RTRIM(Name)), 1 + CHARINDEX(':', REVERSE(RTRIM(Name)), 1)) - CHARINDEX(':', REVERSE(RTRIM(Name)), 1) - 1) AS ServerInstance, 
	CASE WHEN	substring(RTRIM(Name), charindex(':', RTRIM(Name), 1 + charindex(':', RTRIM(Name), 1)) + 1, charindex(':', REVERSE(RTRIM(Name)), 1 + charindex(':', REVERSE(RTRIM(Name)), 1)) - 2) = 
				substring(RTRIM(Name), charindex(':', RTRIM(Name), 1) + 1, charindex(':', REVERSE(RTRIM(Name)), 1 + charindex(':', REVERSE(RTRIM(Name)), 1)) - charindex(':', REVERSE(RTRIM(Name)), 1) - 1) 
		 THEN substring(RTRIM(Name), charindex(':', RTRIM(Name), 1 + charindex(':', RTRIM(Name), 1)) + 1, charindex(':', REVERSE(RTRIM(Name)), 1 + charindex(':', REVERSE(RTRIM(Name)), 1)) - 2) 
		 WHEN SUBSTRING(RTRIM(Name), CHARINDEX(':', RTRIM(Name), 1) + 1, CHARINDEX(':', REVERSE(RTRIM(Name)), 1 + CHARINDEX(':', REVERSE(RTRIM(Name)), 1)) - CHARINDEX(':', REVERSE(RTRIM(Name)), 1) - 1) = ' ' 
		 THEN substring(RTRIM(Name), charindex(':', RTRIM(Name), 1 + charindex(':', RTRIM(Name), 1)) + 1, charindex(':', REVERSE(RTRIM(Name)), 1 + charindex(':', REVERSE(RTRIM(Name)), 1)) - 2)
		 ELSE substring(RTRIM(Name), charindex(':', RTRIM(Name), 1 + charindex(':', RTRIM(Name), 1)) + 1, charindex(':', REVERSE(RTRIM(Name)), 1 + charindex(':', REVERSE(RTRIM(Name)), 1)) - 2) + '\' + substring(RTRIM(Name), charindex(':', RTRIM(Name), 1) + 1, charindex(':', 
                      REVERSE(RTRIM(Name)), 1 + charindex(':', REVERSE(RTRIM(Name)), 1)) - charindex(':', REVERSE(RTRIM(Name)), 1) - 1) 
            END AS DatabaseEnvironment, 
    Name,
	Family, 
	Class, 
	CI_Status, 
    Impact, 
    Resource_Contact, 
    Engineering_Group, 
    Problem_Group, 
    Change_Support_Group, 
    Security_Group, 
    [CI Approval Group1], 
    [CI Approval Group2], 
    [CI Approval Group3], 
    [CI Approval Group4], 
    [CI Approval Group5], 
    [CI Approval Group6], 
    [CI Approval Group7], 
    [CI Cross Jurisdiction Group], 
    [CI Notification Group1], 
    [CI Notification Group2], 
    [CI Notification Group3], 
    [CI Notification Group4], 
    Backup_Group, 
    Operations_Group, 
    Portfolio_or_Cluster_Name, 
    Environment, 
    Version, 
    Billing_Info_or_Invoice, 
    Contract_Number, 
    Support_Type, 
    Support_Start_Date, 
    Support_End_Date
FROM  AdminServer.DBINFO_Information_CASD
GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_General_Information]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO













CREATE VIEW [AdminServer].[HPS_Inventory_Server_General_Information]
AS
SELECT TOP 100 percent
       [DBSAUpdateDate] AS EnvironmentBuildDate
      ,[DBSAUpdateBy] AS EnvironmentBuiltBy
      ,[DBSAServerDBA_Primary] AS DBA_Primary
      ,[DBSAServerDBA_Secondary] AS DBA_Secondary
      ,[DBSACustomerName] AS CustomerName
      ,[DBSAServerName] AS ServerName
      ,[DBSAServerConnection] AS FQDatabaseConnection
	  ,CASE WHEN [DBSAClustered] = 1 and [DBSAInstallationType] <> 'Default' 
                  THEN [DBSAServerClusterdVirtualName] + '.' + [DBSADomain]
            WHEN [DBSAClustered] = 1 and [DBSAInstallationType] = 'Default' 
                  THEN [DBSAServerClusterdVirtualName] + '.' + [DBSADomain]
            WHEN [DBSAInstallationType] <> 'Default' THEN [DBSAServerClusterdNode1Name] + '.' + [DBSADomain] 
            ELSE [DBSAServerName] + '.' + [DBSADomain] END AS [ServerFQDN]   
      ,CASE WHEN [DBSASpotlightDayTimeMonitoring] = 'CWY' THEN 'Conway'
			WHEN [DBSASpotlightDayTimeMonitoring] = 'DG'  THEN 'Downers Grove'
			WHEN [DBSASpotlightDayTimeMonitoring] = 'EGV' THEN 'Elk Grove Village'
			ELSE 'Incorrect Setting' END AS EnvironmentLocation
	  ,CASE WHEN S2.SLA IS NULL AND [DBSAServerType] = 'B' THEN 'DR Environment'
			WHEN S2.SLA IS NULL AND DBSAServerName like '%OLAP%' THEN 'OLAP Not Supported'
			ELSE S2.SLA END AS EnvironmentSLA
	  ,CASE WHEN [DBSAManaged] = 1 THEN 'Ensono DBA Managed'
			ELSE 'LSC DBA Managed' END AS ManagedDBA
	  ,CASE WHEN S4.ManagedBy IS NULL AND DBSAVirtualMachine = 1 THEN 'LSC OS Managed'
			WHEN S4.ManagedBy IS NULL AND DBSAVirtualMachine = 0 THEN 'Ensono OS Managed'
			WHEN S4.ManagedBy = 'Ensono' THEN 'Ensono OS Managed'
			WHEN S4.ManagedBy = 'LSC'    THEN 'LSC OS Managed'
			ELSE S4.ManagedBy END AS ManagedOS
      ,CASE WHEN [DBSAInstanceBilled] = 'Y' THEN 'Billed'
			WHEN [DBSAInstanceBilled] = 'N' THEN 'Not Billed'
			ELSE 'Incorrect Setting' END AS InstanceBilled
      ,CASE WHEN [DBSAInstanceSupported] = 'Y' THEN 'Supported'
			WHEN [DBSAInstanceSupported] = 'N' THEN 'Not Supported'
			ELSE 'Incorrect Setting' END AS InstanceSupported
	  ,CASE WHEN S5.SDRI_DRServerName IS NULL THEN 'No DR Requirement'
			ELSE S5.SDRI_DRServerName END AS DR_Server_Name
	  ,S5.SDRI_DRType AS DR_Replication
	  ,S5.SDRI_ConsistencyGroups AS ConcsistencyGroup
	  ,S2.ProductName AS ProductName
	  ,S6.Edition AS ProductEdition
	  ,S2.ProductLevel AS ProductLevel
	  ,S2.ProductVersion AS ProductVersion
      ,[DBSADomain] AS Domain
      ,CASE WHEN [DBSAServerType] = 'P' THEN 'Production'
			WHEN [DBSAServerType] = 'B' THEN 'Disaster Recovery'
			WHEN [DBSAServerType] = 'T' THEN 'Test'
			WHEN [DBSAServerType] = 'S' THEN 'Stage'
			WHEN [DBSAServerType] = 'D' THEN 'Development'
			ELSE 'Undefined' END as ServerType
      ,CASE WHEN [DBSAActive] = 1 THEN 'Active'
			ELSE 'Inactive' END AS Active
      ,CASE WHEN [DBSAVirtualMachine] = 1 THEN 'Virtual Machine'
			WHEN [DBSAVirtualMachine] = 0 THEN 'Physical Machine'
			ELSE 'Incorrect Setting' END AS MachineType 
	  ,CASE WHEN [DBSAClustered] = 1 THEN 'Clustered'
			ELSE 'Not Clustered' END AS [Clustered]
      ,[DBSADescription] AS Description
      ,[DBSAMaintSchedule] AS MaintenanceSchedule
      ,[DBSABackupRepository] AS BackupMethodType
      ,S3.[DiagramFileLocation] AS DiagramFileLocation
      ,S3.[DiagramFileName] AS DiagramFileName
      ,[DBSAProcessors] AS LogicalProcessorCount
      ,[DBSAServerIPAddress] AS ServerIPAddress
      ,[DBSAServerClusterdNode1IPAddress] AS ClusterNode1IPAddress
      ,[DBSAServerClusterdNode2IPAddress] AS ClusterNode2IPAddress
      ,[DBSAServerClusterdNode3IPAddress] AS ClusterNode3IPAddress
      ,[DBSAServerClusterdNode4IPAddress] AS ClusterNode4IPAddress
      ,[DBSAServerClusterdIPAddress] AS ClusterIPAddress
      ,[DBSAServerClusterdVirtualName] AS ClusterVirtualName
      ,[DBSAServerClusterdNode1Name] AS ClusterNode1Name
      ,[DBSAServerClusterdNode2Name] AS ClusterNode2Name
      ,[DBSAServerClusterdNode3Name] AS ClusterNode3Name
      ,[DBSAServerClusterdNode4Name] AS ClusterNode4Name
      ,[DBSAServerClusteredPreferredNode] AS ClusteredPreferredNode
      ,[DBSAInstallationType] AS InstallationType
      ,[DBSAPortNumber] AS PortNumber
      ,[DBSADiskCapacityAllocationMB] AS TotalDiskAllocation
	  ,S2.DatabaseCount AS DatabaseCount
	  ,S2.Database_Total_MB AS Database_Total_MB
  FROM [ENSONODBA].[AdminControl].[DBServersAll] 
	LEFT JOIN (
	SELECT TOP 100 percent [customer]
      ,[server]
      ,[SLA]
      ,[DatabaseCount]
      ,[Server_Total_MB] AS  Database_Total_MB
      ,[ProductName]
      ,[ProductLevel]
      ,[ProductVersion]
  FROM [ENSONODBA].[AdminServer].[HPS_Inventory_Server_Totals_All]) AS S2 ON
	[ENSONODBA].[AdminControl].[DBServersAll].DBSAServerName = S2.Server
	LEFT JOIN (
	SELECT TOP 100 percent 
	   [DatabaseEnvironmentName]
      ,[DiagramComplete]
      ,[DiagramFileLocation]
      ,[DiagramFileName]
      ,[UploadedToGoogle]
      ,[UploadedToSharePoint]
  FROM [ENSONODBA].[AdminControl].[Environment_Diagram_Tracking]) AS S3 ON
	[ENSONODBA].[AdminControl].[DBServersAll].DBSAServerName = S3.DatabaseEnvironmentName
	LEFT JOIN (
	SELECT TOP 100 percent
       [ServerName]
      ,[ManagedBy]
  FROM [ENSONODBA].[AdminServer].[HPS_Admin_SQLServerUpTimeAnalysis]) AS S4 ON
	[ENSONODBA].[AdminControl].[DBServersAll].DBSAServerName = S4.ServerName
	LEFT JOIN
	[ENSONODBA].[AdminControl].[Server_DR_Information] AS S5 ON
	DBSAServerName = S5.SDRI_PRODServerName
	LEFT JOIN (
    SELECT TOP 100 percent
       [ServerName]
      ,[Edition]
  FROM [ENSONODBA].[AdminServer].[HPS_Admin_SQLServerProperties_Current]) AS S6 ON
	[ENSONODBA].[AdminControl].[DBServersAll].DBSAServerName = S6.ServerName










GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_General_Information_SpinOff]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
















CREATE VIEW [AdminServer].[HPS_Inventory_Server_General_Information_SpinOff]
AS
SELECT TOP 100 percent
       [DBSAUpdateDate] AS EnvironmentBuildDate
      ,[DBSAUpdateBy] AS EnvironmentBuiltBy
      ,[DBSAServerDBA_Primary] AS DBA_Primary
      ,[DBSAServerDBA_Secondary] AS DBA_Secondary
	  ,CASE WHEN [DBSADomain] = 'FINCOAD.com' THEN 'FinCo'
            WHEN [DBSADomain] = 'PRSCOAD.com' THEN 'PrsCo'
            WHEN [DBSADomain] = 'EOLCORPORATE.com' THEN 'FinCo'
            WHEN [DBSADomain] = 'rrdxcelerate.com' THEN 'FinCo'
            ELSE 'CmCo' END AS NewCustomerName    
      ,[DBSACustomerName] AS CustomerName
      ,[DBSAServerName] AS ServerName
      ,[DBSAServerConnection] AS FQDatabaseConnection
	  ,MAP.[CompanyName] AS MigrationCompanyName
	  ,MAP.[TargetDatabaseEnvironmentName]
	  ,CASE WHEN [DBSADomain] = 'FINCOAD.com' AND MAP.CurrentDatabaseEnvironmentName IS NULL THEN 'Migration or Copy Target'
			WHEN [DBSADomain] = 'PRSCOAD.com' AND MAP.CurrentDatabaseEnvironmentName IS NULL THEN 'Migration or Copy Target'
			WHEN [DBSAServerName] = 'ACWIN-SQLPVAPI\SQL001'  THEN 'Migrate Target'
			WHEN [DBSAServerName] = 'ACWIN-SQLPVALRT\SQL002'  THEN 'Migrate Target'
			WHEN [DBSAServerName] = 'ACWIN-SQLPVSECU\SQL001'  THEN 'Migrate Target'
			WHEN [DBSAServerName] = 'ACWIN-SQLPVMINR\SQL002'  THEN 'Migrate Target'
			WHEN MAP.CurrentDatabaseEnvironmentName IS NULL THEN 'No Migrations Planned'
			ELSE MAP.[MigrationMethodology] END AS [MigrationMethodology]
	  ,CASE WHEN [DBSAClustered] = 1 and [DBSAInstallationType] <> 'Default' 
                  THEN [DBSAServerClusterdVirtualName] + '.' + [DBSADomain]
            WHEN [DBSAClustered] = 1 and [DBSAInstallationType] = 'Default' 
                  THEN [DBSAServerClusterdVirtualName] + '.' + [DBSADomain]
            WHEN [DBSAInstallationType] <> 'Default' THEN [DBSAServerClusterdNode1Name] + '.' + [DBSADomain] 
            ELSE [DBSAServerName] + '.' + [DBSADomain] END AS [ServerFQDN]   
      ,CASE WHEN [DBSASpotlightDayTimeMonitoring] = 'CWY' THEN 'Conway'
			WHEN [DBSASpotlightDayTimeMonitoring] = 'DG'  THEN 'Downers Grove'
			WHEN [DBSASpotlightDayTimeMonitoring] = 'EGV' THEN 'Elk Grove Village'
			ELSE 'Incorrect Setting' END AS EnvironmentLocation
	  ,CASE WHEN S2.SLA IS NULL AND [DBSAServerType] = 'B' THEN 'DR Environment'
			WHEN S2.SLA IS NULL AND DBSAServerName like '%OLAP%' THEN 'OLAP Not Supported'
			ELSE S2.SLA END AS EnvironmentSLA
	  ,CASE WHEN [DBSAManaged] = 1 THEN 'HPS DBA Managed'
			ELSE 'RRD DBA Managed' END AS ManagedDBA
	  ,CASE WHEN S4.ManagedBy IS NULL AND DBSAVirtualMachine = 1 THEN 'RRD OS Managed'
			WHEN S4.ManagedBy IS NULL AND DBSAVirtualMachine = 0 THEN 'HPS OS Managed'
			WHEN S4.ManagedBy = 'HPS' THEN 'HPS OS Managed'
			WHEN S4.ManagedBy = 'RRD'    THEN 'RRD OS Managed'
			ELSE S4.ManagedBy END AS ManagedOS
      ,CASE WHEN [DBSAInstanceBilled] = 'Y' THEN 'Billed'
			WHEN [DBSAInstanceBilled] = 'N' THEN 'Not Billed'
			ELSE 'Incorrect Setting' END AS InstanceBilled
      ,CASE WHEN [DBSAInstanceSupported] = 'Y' THEN 'Supported'
			WHEN [DBSAInstanceSupported] = 'N' THEN 'Not Supported'
			ELSE 'Incorrect Setting' END AS InstanceSupported
	  ,CASE WHEN S5.SDRI_DRServerName IS NULL THEN 'No DR Requirement'
			ELSE S5.SDRI_DRServerName END AS DR_Server_Name
	  ,S5.SDRI_DRType AS DR_Replication
	  ,S5.SDRI_ConsistencyGroups AS ConcsistencyGroup
	  ,S2.ProductName AS ProductName
	  ,S6.Edition AS ProductEdition
	  ,S2.ProductLevel AS ProductLevel
	  ,S2.ProductVersion AS ProductVersion
      ,[DBSADomain] AS Domain
      ,CASE WHEN [DBSAServerType] = 'P' THEN 'Production'
			WHEN [DBSAServerType] = 'B' THEN 'Disaster Recovery'
			WHEN [DBSAServerType] = 'T' THEN 'Test'
			WHEN [DBSAServerType] = 'S' THEN 'Stage'
			WHEN [DBSAServerType] = 'D' THEN 'Development'
			ELSE 'Undefined' END as ServerType
      ,CASE WHEN [DBSAActive] = 1 THEN 'Active'
			ELSE 'Inactive' END AS Active
      ,CASE WHEN [DBSAVirtualMachine] = 1 THEN 'Virtual Machine'
			WHEN [DBSAVirtualMachine] = 0 THEN 'Physical Machine'
			ELSE 'Incorrect Setting' END AS MachineType 
	  ,CASE WHEN [DBSAClustered] = 1 THEN 'Clustered'
			ELSE 'Not Clustered' END AS [Clustered]
      ,[DBSADescription] AS Description
      ,[DBSAMaintSchedule] AS MaintenanceSchedule
      ,[DBSABackupRepository] AS BackupMethodType
      ,S3.[DiagramFileLocation] AS DiagramFileLocation
      ,S3.[DiagramFileName] AS DiagramFileName
      ,[DBSAProcessors] AS LogicalProcessorCount
      ,[DBSAServerIPAddress] AS ServerIPAddress
      ,[DBSAServerClusterdNode1IPAddress] AS ClusterNode1IPAddress
      ,[DBSAServerClusterdNode2IPAddress] AS ClusterNode2IPAddress
      ,[DBSAServerClusterdNode3IPAddress] AS ClusterNode3IPAddress
      ,[DBSAServerClusterdNode4IPAddress] AS ClusterNode4IPAddress
      ,[DBSAServerClusterdIPAddress] AS ClusterIPAddress
      ,[DBSAServerClusterdVirtualName] AS ClusterVirtualName
      ,[DBSAServerClusterdNode1Name] AS ClusterNode1Name
      ,[DBSAServerClusterdNode2Name] AS ClusterNode2Name
      ,[DBSAServerClusterdNode3Name] AS ClusterNode3Name
      ,[DBSAServerClusterdNode4Name] AS ClusterNode4Name
      ,[DBSAServerClusteredPreferredNode] AS ClusteredPreferredNode
      ,[DBSAInstallationType] AS InstallationType
      ,[DBSAPortNumber] AS PortNumber
      ,[DBSADiskCapacityAllocationMB] AS TotalDiskAllocation
	  ,S2.DatabaseCount AS DatabaseCount
	  ,S2.Database_Total_MB AS Database_Total_MB
  FROM [ENSONODBA].[AdminControl].[DBServersAll] 
	LEFT JOIN (
	SELECT TOP 100 percent [customer]
      ,[server]
      ,[SLA]
      ,[DatabaseCount]
      ,[Server_Total_MB] AS  Database_Total_MB
      ,[ProductName]
      ,[ProductLevel]
      ,[ProductVersion]
  FROM [ENSONODBA].[AdminServer].[HPS_Inventory_Server_Totals_All]) AS S2 ON
	[ENSONODBA].[AdminControl].[DBServersAll].DBSAServerName = S2.Server
	LEFT JOIN (
	SELECT TOP 100 percent 
	   [DatabaseEnvironmentName]
      ,[DiagramComplete]
      ,[DiagramFileLocation]
      ,[DiagramFileName]
      ,[UploadedToGoogle]
      ,[UploadedToSharePoint]
  FROM [ENSONODBA].[AdminControl].[Environment_Diagram_Tracking]) AS S3 ON
	[ENSONODBA].[AdminControl].[DBServersAll].DBSAServerName = S3.DatabaseEnvironmentName
	LEFT JOIN (
	SELECT TOP 100 percent
       [ServerName]
      ,[ManagedBy]
  FROM [ENSONODBA].[AdminServer].[HPS_Admin_SQLServerUpTimeAnalysis]) AS S4 ON
	[ENSONODBA].[AdminControl].[DBServersAll].DBSAServerName = S4.ServerName
	LEFT JOIN
	[ENSONODBA].[AdminControl].[Server_DR_Information] AS S5 ON
	DBSAServerName = S5.SDRI_PRODServerName
	LEFT JOIN (
    SELECT TOP 100 percent
       [ServerName]
      ,[Edition]
  FROM [ENSONODBA].[AdminServer].[HPS_Admin_SQLServerProperties_Current]) AS S6 ON
	[ENSONODBA].[AdminControl].[DBServersAll].DBSAServerName = S6.ServerName
	LEFT JOIN (
    SELECT [CompanyName]
          ,[CurrentDatabaseEnvironmentName]
          ,[TargetDatabaseEnvironmentName]
		  ,[MigrationMethodology]
  FROM [ENSONODBA].[AdminControl].[DBServersAll_SpinOffMapping]
--  WHERE [CurrentDatabaseEnvironmentName] <> [TargetDatabaseEnvironmentName]	
	)	
	 AS MAP ON
	[ENSONODBA].[AdminControl].[DBServersAll].DBSAServerName = MAP.CurrentDatabaseEnvironmentName
ORDER BY NewCustomerName,DBSAServerName



















GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_General_Information_SpinOff_Databases]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO









CREATE VIEW [AdminServer].[HPS_Inventory_Server_General_Information_SpinOff_Databases]
AS
SELECT TOP 100 PERCENT 
 	   M.[CompanyName]
      ,M.[CurrentDatabaseEnvironmentName]
      ,M.[TargetDatabaseEnvironmentName]
	  ,CASE WHEN M.MigrationMethodology = 'Move' AND M.CompanyName = 'FinCo' THEN 'FINCOAD.COM'
			WHEN M.MigrationMethodology = 'Move' AND M.CompanyName = 'PrsCo' THEN 'PRSCOAD.COM'
			ELSE AL.DBSADomain END AS TargetDoamin
      ,M.[MigrationMethodology]
	  ,DBC.[db] AS SourceDatabaseName
	  ,DBC.dbsize AS SourceDatabaseSizeMB
	  ,DBT.[db] AS TargetDatabaseName
	  ,DBT.dbsize AS TargetDatabaseSizeMB
	  ,AL.DBSADescription AS TargetDescription
  FROM [ENSONODBA].[AdminControl].[DBServersAll_SpinOffMapping] AS M INNER JOIN [ENSONODBA].[AdminServer].[HPS_Export_DBINFO_Information_Current] AS DBC ON
  M.CurrentDatabaseEnvironmentName = DBC.server LEFT JOIN [ENSONODBA].[AdminControl].[DBServersAll] AS AL ON
  M.TargetDatabaseEnvironmentName = AL.DBSAServername
  LEFT JOIN [ENSONODBA].[AdminServer].[HPS_Export_DBINFO_Information_Current] AS DBT ON
  M.TargetDatabaseEnvironmentName = DBT.server AND DBC.[db] = DBT.[db] 
  WHERE DBC.[db] NOT IN ('System DBs','DBA','distribution') AND M.MigrationMethodology = 'Move DAO' AND DBC.[db] = 'DAO'
UNION ALL 
SELECT TOP 100 PERCENT 
 	   M.[CompanyName]
      ,M.[CurrentDatabaseEnvironmentName]
      ,M.[TargetDatabaseEnvironmentName]
	  ,CASE WHEN M.MigrationMethodology = 'Move' AND M.CompanyName = 'FinCo' THEN 'FINCOAD.COM'
			WHEN M.MigrationMethodology = 'Move' AND M.CompanyName = 'PrsCo' THEN 'PRSCOAD.COM'
			ELSE AL.DBSADomain END AS TargetDoamin
      ,M.[MigrationMethodology]
	  ,DBC.[db] AS SourceDatabaseName
	  ,DBC.dbsize AS SourceDatabaseSizeMB
	  ,DBT.[db] AS TargetDatabaseName
	  ,DBT.dbsize AS TargetDatabaseSizeMB
	  ,AL.DBSADescription AS TargetDescription
  FROM [ENSONODBA].[AdminControl].[DBServersAll_SpinOffMapping] AS M INNER JOIN [ENSONODBA].[AdminServer].[HPS_Export_DBINFO_Information_Current] AS DBC ON
  M.CurrentDatabaseEnvironmentName = DBC.server LEFT JOIN [ENSONODBA].[AdminControl].[DBServersAll] AS AL ON
  M.TargetDatabaseEnvironmentName = AL.DBSAServername
  LEFT JOIN [ENSONODBA].[AdminServer].[HPS_Export_DBINFO_Information_Current] AS DBT ON
  M.TargetDatabaseEnvironmentName = DBT.server AND DBC.[db] = DBT.[db] 
  WHERE DBC.[db] NOT IN ('System DBs','DBA','distribution') AND M.MigrationMethodology = 'Move OLaughlin' AND DBC.[db] = 'MSBounceLog'
  UNION ALL 
SELECT TOP 100 PERCENT 
 	   M.[CompanyName]
      ,M.[CurrentDatabaseEnvironmentName]
      ,M.[TargetDatabaseEnvironmentName]
	  ,CASE WHEN M.MigrationMethodology = 'Move' AND M.CompanyName = 'FinCo' THEN 'FINCOAD.COM'
			WHEN M.MigrationMethodology = 'Move' AND M.CompanyName = 'PrsCo' THEN 'PRSCOAD.COM'
			ELSE AL.DBSADomain END AS TargetDoamin
      ,M.[MigrationMethodology]
	  ,DBC.[db] AS SourceDatabaseName
	  ,DBC.dbsize AS SourceDatabaseSizeMB
	  ,DBT.[db] AS TargetDatabaseName
	  ,DBT.dbsize AS TargetDatabaseSizeMB
	  ,AL.DBSADescription AS TargetDescription
  FROM [ENSONODBA].[AdminControl].[DBServersAll_SpinOffMapping] AS M INNER JOIN [ENSONODBA].[AdminServer].[HPS_Export_DBINFO_Information_Current] AS DBC ON
  M.CurrentDatabaseEnvironmentName = DBC.server LEFT JOIN [ENSONODBA].[AdminControl].[DBServersAll] AS AL ON
  M.TargetDatabaseEnvironmentName = AL.DBSAServername
  LEFT JOIN [ENSONODBA].[AdminServer].[HPS_Export_DBINFO_Information_Current] AS DBT ON
  M.TargetDatabaseEnvironmentName = DBT.server AND DBC.[db] = DBT.[db] 
  WHERE DBC.[db] NOT IN ('System DBs','DBA','distribution') AND M.MigrationMethodology = 'Move Wade Green' AND DBC.[db] NOT IN ('DAO','MSBounceLog')
UNION ALL 
SELECT TOP 100 PERCENT 
 	   M.[CompanyName]
      ,M.[CurrentDatabaseEnvironmentName]
      ,M.[TargetDatabaseEnvironmentName]
	  ,CASE WHEN M.MigrationMethodology = 'Move' AND M.CompanyName = 'FinCo' THEN 'FINCOAD.COM'
			WHEN M.MigrationMethodology = 'Move' AND M.CompanyName = 'PrsCo' THEN 'PRSCOAD.COM'
			ELSE AL.DBSADomain END AS TargetDoamin
      ,M.[MigrationMethodology]
	  ,DBC.[db] AS SourceDatabaseName
	  ,DBC.dbsize AS SourceDatabaseSizeMB
	  ,DBT.[db] AS TargetDatabaseName
	  ,DBT.dbsize AS TargetDatabaseSizeMB
	  ,AL.DBSADescription AS TargetDescription
  FROM [ENSONODBA].[AdminControl].[DBServersAll_SpinOffMapping] AS M INNER JOIN [ENSONODBA].[AdminServer].[HPS_Export_DBINFO_Information_Current] AS DBC ON
  M.CurrentDatabaseEnvironmentName = DBC.server LEFT JOIN [ENSONODBA].[AdminControl].[DBServersAll] AS AL ON
  M.TargetDatabaseEnvironmentName = AL.DBSAServername
  LEFT JOIN [ENSONODBA].[AdminServer].[HPS_Export_DBINFO_Information_Current] AS DBT ON
  M.TargetDatabaseEnvironmentName = DBT.server AND DBC.[db] = DBT.[db] 
  WHERE DBC.[db] NOT IN ('System DBs','DBA','distribution') AND M.MigrationMethodology NOT IN ('Move DAO','Move Wade Green','Move OLaughlin')
  Order by M.CompanyName, M.CurrentDatabaseEnvironmentName,DBC.db

  







GO
/****** Object:  View [AdminServer].[HPS_Inventory_Server_Totals_All_Review]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





CREATE VIEW [AdminServer].[HPS_Inventory_Server_Totals_All_Review]
AS
/****** Script for SelectTopNRows command from SSMS  ******/
--Will Select where Servers are equal and compare Database Counts
SELECT TOP 100 PERCENT 
	   C.[Date_Key] AS Current_Date_Key
      ,C.[customer] AS Current_Customer
      ,C.[server] AS Current_Server
      ,C.[SLA] AS Current_SLA
      ,C.[DatabaseCount] AS Current_DatabaseCount
      ,C.[Server_Total_MB] AS Current_Server_Total_MB
	  ,CASE WHEN C.[DatabaseCount] < P.[DatabaseCount] THEN 'Database Drop'
			WHEN C.[DatabaseCount] > P.[DatabaseCount] THEN 'Database Add'
			ELSE 'No CHANGE' END AS Review
	  ,P.[Date_Key] AS Previous_Date_Key
      ,P.[customer] AS Previous_Customer
      ,P.[server] AS Previous_Server
      ,P.[SLA] AS Previous_SLA
      ,P.[DatabaseCount] AS Previous_DatabaseCount
      ,P.[Server_Total_MB] AS Previous_Server_Total_MB
  FROM [ENSONODBA].[AdminServer].[HPS_Inventory_Server_Totals_All_Current] AS C INNER JOIN [ENSONODBA].[AdminServer].[HPS_Inventory_Server_Totals_All_Previous] AS P ON
   C.[customer] = P.[customer] AND
   C.[server] = P.[server] 
   UNION
   /****** Script for SelectTopNRows command from SSMS  ******/
-- Will select from Current and where not in Previous for Server Adds
SELECT TOP 100 PERCENT 
	   C.[Date_Key] AS Current_Date_Key
      ,C.[customer] AS Current_Customer
      ,C.[server] AS Current_Server
      ,C.[SLA] AS Current_SLA
      ,C.[DatabaseCount] AS Current_DatabaseCount
      ,C.[Server_Total_MB] AS Current_Server_Total_MB
	  ,'Server Add' AS Review
	  ,P.[Date_Key] AS Previous_Date_Key
      ,P.[customer] AS Previous_Customer
      ,P.[server] AS Previous_Server
      ,P.[SLA] AS Previous_SLA
      ,P.[DatabaseCount] AS Previous_DatabaseCount
      ,P.[Server_Total_MB] AS Previous_Server_Total_MB
  FROM [ENSONODBA].[AdminServer].[HPS_Inventory_Server_Totals_All_Current] AS C LEFT JOIN [ENSONODBA].[AdminServer].[HPS_Inventory_Server_Totals_All_Previous] AS P ON
   C.[customer] = P.[customer] AND
   C.[server] = P.[server] 
WHERE P.[server] IS NULL
   UNION
   /****** Script for SelectTopNRows command from SSMS  ******/
-- Will select from Previous and where not in Current for Server decommission
SELECT TOP 100 PERCENT 
	   C.[Date_Key] AS Current_Date_Key
      ,C.[customer] AS Current_Customer
      ,C.[server] AS Current_Server
      ,C.[SLA] AS Current_SLA
      ,C.[DatabaseCount] AS Current_DatabaseCount
      ,C.[Server_Total_MB] AS Current_Server_Total_MB
	  ,'Server Decommission' AS Review
	  ,P.[Date_Key] AS Previous_Date_Key
      ,P.[customer] AS Previous_Customer
      ,P.[server] AS Previous_Server
      ,P.[SLA] AS Previous_SLA
      ,P.[DatabaseCount] AS Previous_DatabaseCount
      ,P.[Server_Total_MB] AS Previous_Server_Total_MB
  FROM [ENSONODBA].[AdminServer].[HPS_Inventory_Server_Totals_All_Current] AS C RIGHT JOIN [ENSONODBA].[AdminServer].[HPS_Inventory_Server_Totals_All_Previous] AS P ON
   C.[customer] = P.[customer] AND
   C.[server] = P.[server] 
WHERE C.[server] IS NULL
ORDER BY C.[server]







GO
/****** Object:  View [AdminServer].[HPS_Server_MSDB_SSIS_Information]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [AdminServer].[HPS_Server_MSDB_SSIS_Information]
AS
SELECT     TOP (100) PERCENT 
	RTRIM(j.name) AS [Job Name], 
	s.step_id, 
	RTRIM(j.description) AS Description,
	CASE j.enabled WHEN 1 THEN 'ACTIVE' ELSE 'IN-ACTIVE' END AS Status, 
	RTRIM(c.name) AS Category, 
	RTRIM(s.step_name) AS [Step Name], 
	RTRIM(s.command) AS [Step Command], 
	c.name AS [Category Name], 
	s.subsystem AS [Job SubSystem] 
FROM msdb.dbo.sysjobs AS j INNER JOIN msdb.dbo.sysjobsteps AS s ON 
	j.job_id = s.job_id AND 
	s.subsystem = 'SSIS' 
	INNER JOIN msdb.dbo.syscategories AS c ON 
	j.category_id = c.category_id 
WHERE     (s.subsystem = 'SSIS')
ORDER BY Category, [Job Name]




GO
/****** Object:  View [AdminServer].[HPS_Server_Service_Information]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [AdminServer].[HPS_Server_Service_Information]
AS
SELECT [Date_Key]
      ,[Server_Name]
      ,[ServiceName]
      ,[ServiceOwner]
      ,[ServiceStartTp]
      ,[ServiceBinary]
  FROM [DBA].[AdminServer].[Server_Service_Information]
  WHERE Date_Key = (SELECT MAX(Date_Key) FROM [DBA].[AdminServer].[Server_Service_Information])





GO
/****** Object:  View [AdminServer].[HPS_Server_Service_Information_Installed]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [AdminServer].[HPS_Server_Service_Information_Installed]
AS
/****** Script for SelectTopNRows command from SSMS  ******/
SELECT DISTINCT TOP 100 PERCENT [Date_Key]
      ,Services.[Server_Name]
	  ,CASE WHEN RS.SSRS IS NULL THEN 'No SSRS'
	  ELSE 'SSRS Installed' END AS SSRS
	  ,CASE WHEN SAS.SSAS IS NULL THEN 'No SSAS'
	  ELSE 'SSAS Installed' END AS SSAS
	  ,CASE WHEN SIS.SSIS IS NULL THEN 'No SSIS'
	  ELSE 'SSIS Installed' END AS SSIS
FROM [ENSONODBA].[AdminServer].[HPS_Server_Service_Information] AS Services LEFT JOIN 
(
SELECT 
	   [Server_Name]
       ,[ServiceName] AS SSRS
  FROM [ENSONODBA].[AdminServer].[HPS_Server_Service_Information]
  WHERE ServiceName LIKE 'ReportServer%') AS RS ON 
  Services.Server_Name = RS.Server_Name
LEFT JOIN
(
SELECT 
	   [Server_Name]
      ,[ServiceName] AS SSAS
  FROM [ENSONODBA].[AdminServer].[HPS_Server_Service_Information]
  WHERE ServiceName = 'MSSQLServerOLAPService') AS SAS ON
Services.Server_Name = SAS.Server_Name
LEFT JOIN
(
SELECT 
	   [Server_Name]
      ,[ServiceName] AS SSIS
  FROM [ENSONODBA].[AdminServer].[HPS_Server_Service_Information]
  WHERE ServiceName LIKE 'MsDtsServer%') SIS ON
Services.Server_Name = SIS.Server_Name
ORDER BY Services.[Server_Name]








GO
/****** Object:  View [AdminServer].[HPS_Server_SSISPackages]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [AdminServer].[HPS_Server_SSISPackages]
AS
SELECT TOP 100 percent  [Date_Key]
      ,[Server_Name]
      ,[FileType]
      ,[MountPoint]
      ,[SSIS_Package_Name]
      ,[FileSizeInMB]
      ,[FileSizeInGB]
  FROM [DBA].[AdminServer].[SSIS_Information]
  WHERE Date_Key = (SELECT MAX(Date_Key) FROM [DBA].[AdminServer].[SSIS_Information])



GO
/****** Object:  View [AdminServer].[HPS_Server_Virtual_Address_Summary]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- virtual address space summary view 
-- generates a list of SQL Server regions 
-- showing number of reserved and free regions of a given size  
CREATE VIEW [AdminServer].[HPS_Server_Virtual_Address_Summary] AS 
SELECT 
    Size = VaDump.Size, 
    Reserved =  SUM(CASE(CONVERT(INT, VaDump.Base)^0) 
    WHEN 0 THEN 0 ELSE 1 END), 
    Free = SUM(CASE(CONVERT(INT, VaDump.Base)^0) 
    WHEN 0 THEN 1 ELSE 0 END) 
FROM 
( 
    --- combine all allocation according with allocation base, don't take into 
    --- account allocations with zero allocation_base 
    SELECT  
        CONVERT(VARBINARY, SUM(region_size_in_bytes)) 
        AS Size,  
        region_allocation_base_address AS Base 
    FROM sys.dm_os_virtual_address_dump  
    WHERE region_allocation_base_address <> 0x0 
    GROUP BY region_allocation_base_address  
 UNION   
       --- we shouldnt be grouping allocations with ero allocation base 
       --- just get them as is 
    SELECT CONVERT(VARBINARY, region_size_in_bytes), 
 region_allocation_base_address 
    FROM sys.dm_os_virtual_address_dump 
    WHERE region_allocation_base_address  = 0x0 
) 
AS VaDump 
GROUP BY Size



GO
/****** Object:  View [eva].[vAttributeKeyNameMappings]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [eva].[vAttributeKeyNameMappings]
AS
	SELECT
	    b.policy_id
	   ,b.[key_name]
	   ,b.ref_key_name
	FROM (VALUES(1,N'sql_error_logs',N'NumErrorLogs')
			   ,(1,N'xp_cmdshell',N'xp_cmdshell')
			   ,(1,N'ole_automation_procedures',N'Ole Automation Procedures')
			   ,(1,N'adhoc_distributed_queries',N'Ad Hoc Distributed Queries')
			   ,(1,N'cost_threshold_of_parallelism',N'cost threshold for parallelism')
			   ,(1,N'optimize_for_adhoc_workloads',N'optimize for ad hoc workloads')
			   ,(1,N'database_mail',N'Database Mail XPs')
			   ,(1,N'agent_xp',N'Agent XPs')
			   ,(1,N'job_history_maxrows',N'JobHistoryMaxRows')
			   ,(1,N'job_history_maxrows_perjob',N'JobHistoryMaxRowsPerJob')
			   ,(1,N'backup_compression_default',N'backup compression default')) b ([policy_id],[key_name],[ref_key_name])
GO
ALTER TABLE [AdminControl].[DateDim] ADD  CONSTRAINT [DF_DateDim_IsWeekend_2__13]  DEFAULT ((0)) FOR [IsWeekend]
GO
ALTER TABLE [AdminControl].[DateDim] ADD  CONSTRAINT [DF_DateDim_IsHoliday_1__13]  DEFAULT ((0)) FOR [IsHoliday]
GO
ALTER TABLE [AdminControl].[DateDim] ADD  CONSTRAINT [DF_DateDim_LeapYear_3__20]  DEFAULT ((0)) FOR [LeapYear]
GO
ALTER TABLE [AdminControl].[DBServersAll] ADD  CONSTRAINT [DF_DBServersAll_DBSAManaged]  DEFAULT ((1)) FOR [DBSAManaged]
GO
ALTER TABLE [AdminLog].[BestPractices] ADD  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[CapacityReview] ADD  CONSTRAINT [CapacityReview___RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[DailyBackupAudit] ADD  CONSTRAINT [DF_DailyBackupAudit_RunDate]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[DBINFO] ADD  CONSTRAINT [DF__Admin_Ser__RunDa__5F141958]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[DBInformation] ADD  CONSTRAINT [DF__Admin_Ser__RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[DBInformation_IO] ADD  CONSTRAINT [DBIO__Admin_Ser__RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[DiskSpace] ADD  CONSTRAINT [DF__DiskSpace__RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[DTSPackages] ADD  CONSTRAINT [DF__DTSPackages__RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[ErrorLogs] ADD  CONSTRAINT [DF__ErrorLogs__RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[JobHistory] ADD  CONSTRAINT [DF__JobHistory__RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[JobInformation] ADD  CONSTRAINT [JobInformation___RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[LoginsDetail] ADD  CONSTRAINT [DF__LoginsDetail__RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[MountPoints] ADD  CONSTRAINT [DF__MountPoints__RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[ServerService] ADD  CONSTRAINT [DF__ServerService__RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[SQLServerDatabaseProperties] ADD  CONSTRAINT [DF__SQLServerDatabaseProperties__RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[SQLServerDatabaseProperties_2005] ADD  CONSTRAINT [DF__SQLServerDatabaseProperties_2005__RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[SQLServerProperties] ADD  CONSTRAINT [DF__SQLServerProperties__RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[SQLServerVersion] ADD  CONSTRAINT [DF__SQLServerVersion__RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[SSISPackages] ADD  CONSTRAINT [DF__SSISPackages__RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminLog].[UpTimeAnalysis] ADD  CONSTRAINT [DF__UpTimeAnalysis__RunDa__5D2BD0E6]  DEFAULT (getdate()) FOR [RunDate]
GO
ALTER TABLE [AdminServer].[LastBackupAudit] ADD  DEFAULT ('D') FOR [backup_type]
GO
ALTER TABLE [dbo].[BackupInfo] ADD  DEFAULT (getdate()) FOR [CollectionDate]
GO
ALTER TABLE [dbo].[crProcess] ADD  CONSTRAINT [DF_crProcess_Enteredby]  DEFAULT (suser_sname()) FOR [Enteredby]
GO
ALTER TABLE [dbo].[crProcess] ADD  CONSTRAINT [DF_crProcess_LoggedTime]  DEFAULT (CONVERT([smalldatetime],getdate(),(0))) FOR [LoggedTime]
GO
ALTER TABLE [dbo].[crProcess] ADD  CONSTRAINT [DF_crProcess_Reminder]  DEFAULT ((0)) FOR [Reminder]
GO
ALTER TABLE [dbo].[crProcessDetails] ADD  CONSTRAINT [DF_CRTracker_updatetime]  DEFAULT (getdate()) FOR [UpdateTime]
GO
ALTER TABLE [dbo].[DatabaseVersion] ADD  CONSTRAINT [DF_DatabaseVersion_DeploymentDate]  DEFAULT (getdate()) FOR [DeploymentDate]
GO
ALTER TABLE [dbo].[DatabaseVersion] ADD  CONSTRAINT [DF_DatabaseVersion_DeployedBy]  DEFAULT (suser_sname()) FOR [DeployedBy]
GO
ALTER TABLE [dbo].[tDBBackup] ADD  CONSTRAINT [DF_tDBBackup_BackupGrp2]  DEFAULT ((1)) FOR [BackupGrp]
GO
ALTER TABLE [dbo].[tDBBackup] ADD  CONSTRAINT [DF_tDBBackup_TranGrp2]  DEFAULT ((1)) FOR [TranGrp]
GO
ALTER TABLE [dbo].[tDBBackup] ADD  CONSTRAINT [DF_tDBBackup_EventDate2]  DEFAULT (getdate()) FOR [EventDate]
GO
ALTER TABLE [dbo].[tDBBackup] ADD  CONSTRAINT [DF_tDBBackup_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO
ALTER TABLE [dbo].[tDBBackup] ADD  CONSTRAINT [DF_tDBBackup_Retention]  DEFAULT ((2)) FOR [Retention]
GO
ALTER TABLE [dbo].[tDBBackup] ADD  DEFAULT ('N') FOR [SkipIndexDefrag]
GO
ALTER TABLE [dbo].[tDBBackup] ADD  DEFAULT ('N') FOR [SkipIntegrityCheck]
GO
ALTER TABLE [dbo].[tDBBackup] ADD  DEFAULT ('N') FOR [SkipDbBackup]
GO
ALTER TABLE [dbo].[tDBUDPOverrides] ADD  DEFAULT ((4)) FOR [UDP_Batchsize]
GO
ALTER TABLE [eva].[Assessment] ADD  CONSTRAINT [DF_Assessment_run_date]  DEFAULT (getdate()) FOR [run_date]
GO
ALTER TABLE [eva].[PolicyCatalog] ADD  CONSTRAINT [DF_PolicyCatalog_autofix]  DEFAULT ((0)) FOR [autofix]
GO
ALTER TABLE [eva].[PolicyCatalog] ADD  DEFAULT (suser_sname()) FOR [executed_by]
GO
ALTER TABLE [eva].[ServerDetail] ADD  CONSTRAINT [DF_zServerDetail_date_key]  DEFAULT (getdate()) FOR [date_key]
GO
ALTER TABLE [eva].[ServerDetail] ADD  CONSTRAINT [DF_zServerDetail_servername]  DEFAULT (@@servername) FOR [servername]
GO
ALTER TABLE [eva].[ServerDetail] ADD  CONSTRAINT [DF_zServerDetail_is_ag]  DEFAULT ((0)) FOR [is_ag]
GO
ALTER TABLE [eva].[ServerDetail] ADD  CONSTRAINT [DF_zServerDetail_is_logshipping]  DEFAULT ((0)) FOR [is_logshipping]
GO
ALTER TABLE [eva].[ServerDetail] ADD  CONSTRAINT [DF_zServerDetail_is_replication]  DEFAULT ((0)) FOR [is_replication]
GO
ALTER TABLE [eva].[ServerDetail] ADD  CONSTRAINT [DF_zServerDetail_is_mirroring]  DEFAULT ((0)) FOR [is_mirroring]
GO
ALTER TABLE [eva].[ServerDetail] ADD  DEFAULT ('name') FOR [netbackup_sort_by]
GO
ALTER TABLE [eva].[zDataPurgeFeed] ADD  DEFAULT ('dbo') FOR [schema_name]
GO
ALTER TABLE [dbo].[crProcessDetails]  WITH CHECK ADD  CONSTRAINT [FK_crProcessDetails_crProcess_crid] FOREIGN KEY([crid])
REFERENCES [dbo].[crProcess] ([crid])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[crProcessDetails] CHECK CONSTRAINT [FK_crProcessDetails_crProcess_crid]
GO
ALTER TABLE [dbo].[QueueDatabase]  WITH CHECK ADD  CONSTRAINT [FK_QueueDatabase_Queue] FOREIGN KEY([QueueID])
REFERENCES [dbo].[Queue] ([QueueID])
GO
ALTER TABLE [dbo].[QueueDatabase] CHECK CONSTRAINT [FK_QueueDatabase_Queue]
GO
ALTER TABLE [eva].[Categories]  WITH CHECK ADD  CONSTRAINT [FK_Categories_parent_cat_id] FOREIGN KEY([parent_category_id])
REFERENCES [eva].[Categories] ([id])
GO
ALTER TABLE [eva].[Categories] CHECK CONSTRAINT [FK_Categories_parent_cat_id]
GO
ALTER TABLE [eva].[Exceptions]  WITH CHECK ADD  CONSTRAINT [FK_Exceptions_PolicyCatalog_policy_id] FOREIGN KEY([policy_id])
REFERENCES [eva].[PolicyCatalog] ([id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [eva].[Exceptions] CHECK CONSTRAINT [FK_Exceptions_PolicyCatalog_policy_id]
GO
ALTER TABLE [eva].[PolicyAttributes]  WITH CHECK ADD  CONSTRAINT [FK_zPolicyAttributes_Categories] FOREIGN KEY([category_id])
REFERENCES [eva].[Categories] ([id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [eva].[PolicyAttributes] CHECK CONSTRAINT [FK_zPolicyAttributes_Categories]
GO
ALTER TABLE [eva].[PolicyAttributes]  WITH CHECK ADD  CONSTRAINT [FK_zPolicyAttributes_PolicyCatalog] FOREIGN KEY([policy_id])
REFERENCES [eva].[PolicyCatalog] ([id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [eva].[PolicyAttributes] CHECK CONSTRAINT [FK_zPolicyAttributes_PolicyCatalog]
GO
/****** Object:  StoredProcedure [dbo].[GenerateDRReport]    Script Date: 11/4/2025 9:51:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[GenerateDRReport]  
AS  
  
SET NOCOUNT ON  
  
DECLARE  @WindowsVerison   varchar(128)  
   ,@PhysicalCPUCount  tinyint  
   ,@LogicalCPUCount  smallint  
   ,@PhysicalMemory  int  
   ,@Drive     char(1)  
   ,@FreeSpace    int  
   ,@ApproxStartDate  datetime  
   ,@CharValue       nvarchar(1024)  
   ,@SQLPath    varchar(256)  
   ,@BackupPath   varchar(256)  
   ,@DefaultDataPath  varchar(256)  
   ,@DefaultLogPath  varchar(256)  
   ,@Command    nvarchar(4000)  
   ,@ReturnValue   int  
   ,@IPAddress    varchar(256)  
   ,@DetailDomainName  varchar(128)     
   ,@LoginMode       varchar(25)  
      ,@AuditLevel      varchar(25)  
      ,@Domain       varchar(128)  
      ,@Proxy        varchar(128)  
      ,@ServiceAccount     varchar(256)   
      ,@Key        varchar(256)   
            ,@NumValue    int  
      ,@DynamicPort      varchar(128)  
      ,@TCPPort       varchar(128)  
            ,@XP              varchar(128)  
      ,@DLL                 varchar(256)  
            ,@DbName       varchar(128)  
   ,@Type           varchar(15)  
   ,@BackupFile         varchar(1024)  
   ,@PrevDbName         varchar(128)  
   ,@PrevType          varchar(15)  
   ,@SQL           varchar(2048)  
   ,@Move           varchar(max)  
   ,@CrLf           char(2)  
   ,@BackupSetId         int  
   ,@BackupStart         datetime  
   ,@Logical          varchar(256)  
   ,@Physical          varchar(512)  
   ,@FileSize          money  
   ,@PriorDB          varchar(128)  
   ,@Message               varchar(1024)  
   ,@PrevBackupSetId     int  
   ,@Sequence              int  
   ,@Position              int  
   ,@PrevPosition          int  
   ,@Description           varchar(512)  
   ,@DeviceType            tinyint  
   ,@DisplayName   varchar(256)  
            ,@UninstallKey          varchar(128)  
            ,@Publisher             varchar(128)   
            ,@TempDbDir             varchar(256)  
            ,@TempDbLogDir          varchar(256) 
,@LogShip  VARCHAR(5)	   ,@DbMirror VARCHAR(5)	   ,@Repl	  VARCHAR(5)	,@AG	  VARCHAR(5) 
  
SET @CrLf = CHAR(13) + CHAR(10)  
  
  
PRINT REPLICATE('*', 80)  
PRINT '*' + SPACE(78) + '*'  
PRINT '*' + SPACE(35) + 'DR REPORT' + REPLICATE(' ', 34) + '*'  
PRINT '*' + SPACE(26) + CONVERT(varchar(30), GETDATE(), 109) + REPLICATE(' ', 26) + '*'  
PRINT '*' + SPACE(78) + '*'  
PRINT REPLICATE('*', 80)  
PRINT ''  
  
     
CREATE TABLE #ServerInfo  
(  
 Id     int  
 ,Name    varchar(256)  
 ,InternalValue  int  
 ,Character_Value varchar(2000)  
)  
  
INSERT INTO #ServerInfo  
EXECUTE master.dbo.xp_msver   
  
  
SELECT  @WindowsVerison = ISNULL(Character_Value, '')  
FROM  #ServerInfo  
WHERE  Name = 'WindowsVersion'  
  
SELECT  @PhysicalCPUCount = cpu_count / hyperthread_ratio   
FROM    sys.dm_os_sys_info;  
  
  
SELECT  @LogicalCPUCount = cpu_count  
FROM    sys.dm_os_sys_info;  
  
SELECT  @PhysicalMemory = ISNULL(InternalValue, '')  
FROM  #ServerInfo  
WHERE  Name = 'PhysicalMemory'  
  
SELECT  @ApproxStartDate = crdate  
FROM  master.dbo.sysdatabases  
WHERE  name = 'tempdb'  
  
PRINT  'BEGIN SQL SERVER INFORMATION'   
PRINT  '    Machine Name:       ' + CAST(ISNULL(SERVERPROPERTY('MachineName'), 'NULL') AS varchar(128))  
  
SET @DetailDomainName = NULL  
  
EXEC master.dbo.xp_regread 'HKEY_LOCAL_MACHINE'  
       ,'SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'  
       ,'Domain'  
       ,@DetailDomainName OUTPUT  
  
PRINT  '    Domain:             ' +  ISNULL(@DetailDomainName, 'Unable to retrieve Domain Info')  
  
  
  
PRINT ''  
PRINT  '    Windows Version:    ' +  @WindowsVerison  
PRINT  '    Physical CPU:       ' +  CAST(@PhysicalCPUCount AS varchar(128))  
PRINT  '    Logical CPU:        ' +  CAST(@LogicalCPUCount AS varchar(128))  
PRINT  '    Physical Memory:    ' +  CAST(@PhysicalMemory AS varchar(128))  
PRINT ''   
  
CREATE TABLE #DriveInfo  
(  
 Drive  char(1)  
 ,FreeSpace int  
)  
  
INSERT INTO #DriveInfo  
EXECUTE sys.xp_fixeddrives  
  
DECLARE CURSOR_DRIVES CURSOR FAST_FORWARD  
FOR  
 SELECT  Drive  
    ,FreeSpace  
 FROM  #DriveInfo  
  
OPEN CURSOR_DRIVES  
  
FETCH NEXT FROM CURSOR_DRIVES  
INTO @Drive, @FreeSpace  
  
PRINT  '    Drives:          '  
  
WHILE @@FETCH_STATUS = 0  
BEGIN  
 PRINT  '       ' + @Drive + ':               ' + CAST(@FreeSpace AS varchar(25)) + ' MB of Free Space'  
 FETCH NEXT FROM CURSOR_DRIVES  
 INTO @Drive, @FreeSpace  
END  
  
CLOSE CURSOR_DRIVES  
DEALLOCATE CURSOR_DRIVES  
  
DROP TABLE #DriveInfo  
  
PRINT ''  
PRINT '    SQL Server:         ' + CAST(ISNULL(SERVERPROPERTY('ServerName'), 'NULL') AS varchar(128))  
PRINT '    Instance Name:      ' + CAST(ISNULL(SERVERPROPERTY('InstanceName'), 'Default') AS varchar(128))  
PRINT '    Approx Start Date:  ' + CONVERT(varchar(35), @ApproxStartDate, 109)  
PRINT '    SQL Edition:        ' + CAST(ISNULL(SERVERPROPERTY('Edition'), 'NULL') AS varchar(128))  
PRINT '    Product Version:    ' + CAST(ISNULL(SERVERPROPERTY('ProductVersion'), 'NULL') AS varchar(128))  
PRINT '    Product Level:      ' + CAST(ISNULL(SERVERPROPERTY('ProductLevel'), 'NULL') AS varchar(128))  
PRINT '    Collation:          ' + CAST(ISNULL(SERVERPROPERTY('Collation'), 'NULL') AS varchar(128))  
PRINT '    Character Set:      ' + CAST(ISNULL(SERVERPROPERTY('SqlCharSetName'), 'NULL') AS varchar(128))  
PRINT '    Sort Order:         ' + CAST(ISNULL(SERVERPROPERTY('SqlSortOrderName'), 'NULL') AS varchar(128))  
PRINT '    Is Clustered:       ' + CASE WHEN CAST(SERVERPROPERTY('IsClustered')AS varchar(128)) = 0 THEN 'No' ELSE 'Yes' END  
  
SELECT      @ReturnValue = CAST(value AS int)  
FROM        sys.configurations   
WHERE       name = 'filestream access level'   
  
  
-- CHECKS THE SERVERPROPERTY TO SEE IF ITS TRULY CONFIGURED CORRECTLY.  BASICALLY SHOWS WHAT SETUP IN CONFIGURATION MANAGER  
PRINT '    Filestream Setup:   ' + CASE CAST(SERVERPROPERTY('FilestreamConfiguredLevel') AS int)   
          WHEN 0 THEN '0 - Disabled'  
          WHEN 1 THEN '*** 1 - Enable FILESTREAM for Transact-SQL access'  
          WHEN 2 THEN '*** 2 - Enable FILESTREAM for file I/O streaming access'  
          WHEN 3 THEN '*** 3 - Allow remote clients to have streaming access to FILESTREAM data'  
          ELSE '*** ' +  CAST(SERVERPROPERTY('FilestreamConfiguredLevel') AS varchar(25)) + ' - Unknown'  
           END + ' - (SQL Server Configuration Manager FILESTREAM tab setup)'  
  
PRINT '    Filestream Share:   ' + CAST(SERVERPROPERTY('FilestreamShareName') AS varchar(256))   
  
-- THIS JUST CHECKS IF ITS CONFIGURED TO USE FILESTREAM, RUNNING VALUE COULD BE DISABLED.  THERE  
-- ARE OTHER STEPS YOU HAVE TO TAKE TO ENABLE THIS FEATURE.  YOU HAVE TO GO TO CONFIGURATION   
-- MANAGER TO COMPLETE THE FILESTREAM SETUP  
PRINT '    Filestream Config:  ' + CASE @ReturnValue  
          WHEN 0 THEN '0 - Disabled'  
          WHEN 1 THEN '*** 1 - Transact-SQL access enabled (T-SQL Access)'  
          WHEN 2 THEN '*** 2 - Full access enabled (T-SQL & Win32 Streaming Access)'  
          ELSE '*** ' +  CAST(@ReturnValue AS varchar(25)) + ' - Unknown'  
           END + ' - (sp_configure ''filestream access level'')'  
                        
PRINT ''   
  
SET @CharValue = NULL  
  
EXECUTE master.dbo.xp_instance_regread 'HKEY_LOCAL_MACHINE'  
          ,'SOFTWARE\Microsoft\MSSQLServer\Setup\'  
          ,'FeatureList'  
          ,@CharValue OUTPUT  
          ,'no_output'  
            
PRINT  '    Feature List:       ' + ISNULL(@CharValue, '')  
  
PRINT ''  
  
PRINT  '    Install Info:'  
  
IF OBJECT_ID('tempdb..#UninstallKeys') IS NOT NULL  
    DROP TABLE #UninstallKeys  
  
CREATE TABLE #UninstallKeys  
(  
    KeyName     varchar(128)  
)      
  
IF OBJECT_ID('tempdb..#KeyValues') IS NOT NULL  
    DROP TABLE #KeyValues  
  
CREATE TABLE #KeyValues  
(  
    Value       nvarchar(128)  
    ,Data       nvarchar(1024)  
)      
  
IF OBJECT_ID('tempdb..#Report') IS NOT NULL  
    DROP TABLE #Report  
  
CREATE TABLE #Report  
(  
    Value       nvarchar(128)  
)      
  
SET @UninstallKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'  
  
INSERT INTO #UninstallKeys  
EXECUTE sys.xp_regenumkeys 'HKEY_LOCAL_MACHINE', @UninstallKey  
  
DECLARE CURSOR_UNINSTALL_KEYS CURSOR FAST_FORWARD  
FOR  
    SELECT      KeyName  
    FROM        #UninstallKeys  
    WHERE       KeyName LIKE '{____________________________________}'  
       OR       KeyName LIKE 'KB%'  
  
OPEN CURSOR_UNINSTALL_KEYS  
  
FETCH NEXT FROM CURSOR_UNINSTALL_KEYS   
INTO @Key  
  
WHILE @@FETCH_STATUS = 0  
BEGIN  
    TRUNCATE TABLE #KeyValues  
      
    SET @UninstallKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\' + @Key  
  
    INSERT INTO #KeyValues  
    EXECUTE sys.xp_regenumvalues 'HKEY_LOCAL_MACHINE', @UninstallKey  
  
    SET @DisplayName = NULL  
    SET @Publisher = NULL  
  
    SELECT      @DisplayName = Data  
    FROM        #KeyValues  
    WHERE       Value = 'DisplayName'  
      AND       Data LIKE '%SQL%'  
        
    SELECT      @Publisher = Data  
    FROM        #KeyValues  
    WHERE       Value = 'Publisher'  
      AND       Data = 'Microsoft Corporation'  
              
    IF @Publisher IS NOT NULL  
        IF @DisplayName IS NOT NULL  
            INSERT INTO #Report VALUES (@DisplayName)  
  
    FETCH NEXT FROM CURSOR_UNINSTALL_KEYS   
    INTO @Key      
END  
  
CLOSE CURSOR_UNINSTALL_KEYS   
DEALLOCATE CURSOR_UNINSTALL_KEYS   
  
  
DECLARE CUSROR_SQLINSTALL_REPORT CURSOR FAST_FORWARD  
FOR   
    SELECT      DISTINCT Value  
    FROM        #Report  
    ORDER BY    Value  
      
OPEN CUSROR_SQLINSTALL_REPORT  
  
FETCH NEXT FROM CUSROR_SQLINSTALL_REPORT  
INTO @DisplayName  
  
WHILE @@FETCH_STATUS = 0  
BEGIN  
    PRINT  '                        ' + @DisplayName  
  
    FETCH NEXT FROM CUSROR_SQLINSTALL_REPORT  
    INTO @DisplayName  
END  
  
  
CLOSE CUSROR_SQLINSTALL_REPORT  
DEALLOCATE CUSROR_SQLINSTALL_REPORT  
  
DROP TABLE #UninstallKeys  
DROP TABLE #KeyValues  
DROP TABLE #Report  
  
PRINT ''   
  
SET @CharValue = NULL  
  
EXECUTE master.dbo.xp_instance_regread 'HKEY_LOCAL_MACHINE'  
          ,'SOFTWARE\Microsoft\MSSQLServer\Setup\'  
          ,'SQLProgramDir'  
          ,@CharValue OUTPUT  
          ,'no_output'  
            
PRINT  '    Instance Root Dir:  ' + ISNULL(@CharValue, '')  
  
SET @CharValue = NULL  
  
EXECUTE master.dbo.xp_instance_regread 'HKEY_LOCAL_MACHINE'  
          ,'SOFTWARE\Microsoft\MSSQLServer\Setup\'  
          ,'SQLPath'  
          ,@CharValue OUTPUT  
          ,'no_output'  
            
PRINT  '    SQL Path:           ' + ISNULL(@CharValue, '')  
  
SET @CharValue = NULL  
  
EXECUTE master.dbo.xp_instance_regread 'HKEY_LOCAL_MACHINE'  
          ,'SOFTWARE\Microsoft\MSSQLServer\Setup\'  
          ,'SQLBinRoot'  
          ,@CharValue OUTPUT  
          ,'no_output'  
            
PRINT  '    SQL Binary Dir:     ' + ISNULL(@CharValue, '')  
  
SET @CharValue = NULL  
  
EXECUTE master.dbo.xp_instance_regread 'HKEY_LOCAL_MACHINE'  
          ,'SOFTWARE\Microsoft\MSSQLServer\Setup\'  
          ,'SQLDataRoot'  
          ,@CharValue OUTPUT  
          ,'no_output'  
            
PRINT  '    Data Root Dir:      ' + ISNULL(@CharValue, '')  
  
SET @CharValue = NULL  
  
EXECUTE master.dbo.xp_instance_regread 'HKEY_LOCAL_MACHINE'  
          ,'SOFTWARE\Microsoft\MSSQLServer\Setup\'  
          ,'FullTextDefaultPath'  
          ,@CharValue OUTPUT  
          ,'no_output'  
            
PRINT  '    FullText Def Path:  ' + ISNULL(@CharValue, '')  
  
PRINT ''   
  
SET @SQLPath = NULL  
SET @DefaultDataPath = NULL  
SET @DefaultLogPath = NULL  
SET @BackupPath = NULL  
  
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE'  
         ,N'SOFTWARE\Microsoft\MSSQLServer\Setup'  
         ,N'SQLPath'  
         ,@SQLPath OUTPUT  
  
  
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE'  
         ,N'Software\Microsoft\MSSQLServer\MSSQLServer'  
         ,N'BackupDirectory'  
         ,@BackupPath OUTPUT  
  
  
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE'  
         ,N'Software\Microsoft\MSSQLServer\MSSQLServer'  
         ,N'DefaultData'  
         ,@DefaultDataPath OUTPUT  
         ,NO_OUTPUT  
  
  
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE'  
         ,N'Software\Microsoft\MSSQLServer\MSSQLServer'  
         ,N'DefaultLog'  
         ,@DefaultLogPath OUTPUT  
         ,NO_OUTPUT  
  
IF RIGHT(@SQLPath, 1) <> '\'  
 SET @SQLPath = @SQLPath + '\'  
  
  
SET @SQLPath = @SQLPath  
SET @DefaultDataPath = ISNULL(@DefaultDataPath, @SQLPath + 'DATA\')  
SET @DefaultLogPath = ISNULL(@DefaultLogPath, @SQLPath + 'DATA\')  
  
PRINT  '    Backup Dir:         ' + @BackupPath  
PRINT  '    User Db Dir:        ' + @DefaultDataPath  
PRINT  '    User Db Log Dir:    ' + @DefaultLogPath  
  
SELECT      @TempDbDir = MIN(physical_name)  
FROM        sys.master_files  
WHERE       database_id = DB_ID('tempdb')  
  AND       type_desc = 'ROWS'  
  
SET @TempDbDir = LEFT(@TempDbDir, LEN(@TempDbDir) - CHARINDEX('\', REVERSE(@TempDbDir)) + 1)  
    
SELECT      @TempDbLogDir = MIN(physical_name)  
FROM        sys.master_files  
WHERE       database_id = DB_ID('tempdb')  
  AND       type_desc = 'LOG'  
  
SET @TempDbLogDir = LEFT(@TempDbLogDir, LEN(@TempDbLogDir) - CHARINDEX('\', REVERSE(@TempDbLogDir)) + 1)  
    
PRINT  '    Temp Db Dir:        ' + @TempDbDir  
PRINT  '    Temp Db Log Dir:    ' + @TempDbLogDir  
    
  
PRINT  'END SQL SERVER INFORMATION'   
PRINT ''  
  
DROP TABLE #ServerInfo  
  
-- SECURITY INFO  
PRINT 'BEGIN SECURITY INFO '  
  
CREATE TABLE #Info  
(  
 Name  varchar(128)  
 ,value  varchar(256)  
)  
  
INSERT INTO #Info  
EXECUTE sys.xp_loginconfig  
  
SELECT  @LoginMode = value  
FROM  #Info   
WHERE  Name = 'login mode'  
  
SELECT  @AuditLevel = value  
FROM  #Info   
WHERE  Name = 'audit level'  
  
SELECT  @Domain = value  
FROM  #Info   
WHERE  Name = 'default domain'  
  
DROP TABLE #Info   
  
PRINT '    Domain:             ' + @Domain  
PRINT '    Authentication:     ' + @LoginMode  
PRINT '    Audit Level:        ' + CASE @AuditLevel   
          WHEN 'none' THEN '*** '   
          WHEN 'success' THEN '*** '  
          ELSE ''  
              END + @AuditLevel  
  
SELECT  @Proxy = credential_identity   
FROM  sys.credentials  
WHERE  name = '##xp_cmdshell_proxy_account##'  
  
PRINT '    Server Proxy:       ' + ISNULL(@Proxy, '')    
  
SET @ServiceAccount = NULL  
SET @Key = 'SYSTEM\CurrentControlSet\Services\' + CASE WHEN UPPER(CAST(ISNULL(SERVERPROPERTY('InstanceName'), 'Default') AS varchar(128))) IN ('DEFAULT', 'MSSQLSERVER') THEN 'MSSQLSERVER' ELSE 'MSSQL$' + CAST(SERVERPROPERTY('InstanceName') AS varchar(128)
) END  
  
EXECUTE xp_instance_regread N'HKEY_LOCAL_MACHINE'  
       ,@Key  
       ,N'ObjectName'  
       ,@ServiceAccount OUTPUT  
       ,'NO_OUTPUT'  
  
PRINT '    SQL Service Acct:   ' + ISNULL(@ServiceAccount, '')    
  
SET @ServiceAccount = NULL  
SET @Key = 'SYSTEM\CurrentControlSet\Services\' + CASE WHEN UPPER(CAST(ISNULL(SERVERPROPERTY('InstanceName'), 'Default') AS varchar(128))) IN ('DEFAULT', 'MSSQLSERVER') THEN 'SQLSERVERAGENT' ELSE 'SQLAgent$' + CAST(SERVERPROPERTY('InstanceName') AS varchar(128)) END  
  
EXECUTE xp_instance_regread N'HKEY_LOCAL_MACHINE'  
       ,@Key  
       ,N'ObjectName'  
       ,@ServiceAccount OUTPUT  
       ,'NO_OUTPUT'  
  
PRINT '    SQL Agent Acct:     ' + ISNULL(@ServiceAccount, '')    
  
  
PRINT 'END SECURITY INFO '  
PRINT ''  
  
-- NETWORK CONFIGURATIONS   
PRINT 'BEGIN NETWORK CONFIGURATIONS '  
  
SET @DynamicPort = NULL  
SET @TCPPort = NULL  
  
EXECUTE xp_instance_regread 'HKEY_LOCAL_MACHINE'   
       ,'SOFTWARE\Microsoft\Microsoft SQL Server\MSSQLServer\SuperSocketNetLib\Tcp\IPAll\'  
       ,'TcpDynamicPorts'  
       ,@DynamicPort OUTPUT  
       ,'NO_OUTPUT'  
   
EXECUTE xp_instance_regread 'HKEY_LOCAL_MACHINE'  
       ,'SOFTWARE\Microsoft\Microsoft SQL Server\MSSQLServer\SuperSocketNetLib\Tcp\IPAll\'  
       ,'TcpPort'  
       ,@TCPPort OUTPUT  
       ,'NO_OUTPUT'      
  
SET @NumValue = NULL  
  
EXECUTE xp_instance_regread N'HKEY_LOCAL_MACHINE'  
       ,N'Software\Microsoft\MSSQLServer\MSSQLServer\SuperSocketNetLib\Tcp\'  
       ,N'Enabled'  
       ,@NumValue OUTPUT  
       ,'NO_OUTPUT'  
  
PRINT '    TCP/IP:             ' + CASE WHEN @NumValue = 0 THEN '*** Disabled' ELSE 'Enabled' END  
  
IF @NumValue <> 0  
 BEGIN  
  PRINT '       Static Port:    ' + ISNULL(@TCPPort, '')   
  PRINT '        Dynamic Port:   ' + CASE WHEN LTRIM(ISNULL(@DynamicPort, '')) = '' THEN '' ELSE '*** ' END + ISNULL(@DynamicPort, '')   
 END  
  
SET @NumValue = NULL  
   
EXECUTE xp_instance_regread N'HKEY_LOCAL_MACHINE'  
       ,N'Software\Microsoft\MSSQLServer\MSSQLServer\SuperSocketNetLib\'  
       ,N'ForceEncryption'  
       ,@NumValue OUTPUT  
       ,'NO_OUTPUT'  
  
PRINT '    Force Protocol:     ' + CASE WHEN @NumValue = 0 THEN 'Disabled' ELSE 'Enabled' END  
         
SET @NumValue = NULL  
  
EXECUTE xp_instance_regread N'HKEY_LOCAL_MACHINE'  
       ,N'Software\Microsoft\MSSQLServer\MSSQLServer\SuperSocketNetLib\Np\'  
       ,N'Enabled'  
       ,@NumValue OUTPUT  
       ,'NO_OUTPUT'  
  
PRINT '    Named Pipes:        ' + CASE WHEN @NumValue = 1 THEN '*** Enabled' ELSE 'Disabled' END  
  
SET @NumValue = NULL  
  
EXECUTE xp_instance_regread N'HKEY_LOCAL_MACHINE'  
       ,N'Software\Microsoft\MSSQLServer\MSSQLServer\SuperSocketNetLib\Sm\'  
       ,N'Enabled'  
       ,@NumValue OUTPUT  
       ,'NO_OUTPUT'  
  
PRINT '    Shared Memory:      ' + CASE WHEN @NumValue = 1 THEN 'Enabled' ELSE '*** Disabled' END  
  
SET @NumValue = NULL  
  
EXECUTE xp_instance_regread N'HKEY_LOCAL_MACHINE'  
       ,N'Software\Microsoft\MSSQLServer\MSSQLServer\SuperSocketNetLib\Via\'  
       ,N'Enabled'  
       ,@NumValue OUTPUT  
       ,'NO_OUTPUT'  
  
PRINT '    VIA:                ' + CASE WHEN @NumValue = 1 THEN '*** Enabled' ELSE 'Disabled' END  
  
PRINT 'END NETWORK CONFIGURATIONS '  
PRINT ''  
  
PRINT 'BEGIN NON MS SHIPPED PROCEDURES '  
      
DECLARE CURSOR_XP CURSOR FAST_FORWARD FOR  
 SELECT  A.name  
    ,A.dll_name  
    FROM  master.sys.extended_procedures A  
 WHERE  A.type = 'X'  
   AND  A.is_ms_shipped = 0  
  
OPEN CURSOR_XP  
  
FETCH NEXT FROM CURSOR_XP  
INTO @XP, @DLL  
  
IF @@FETCH_STATUS <> 0  
 PRINT '    No Extended Procedures Found'  
ELSE  
 BEGIN  
  WHILE @@FETCH_STATUS = 0  
  BEGIN  
   PRINT '    * ' + @XP + ' (' + @DLL + ')'   
  
   FETCH NEXT FROM CURSOR_XP  
   INTO @XP, @DLL  
  END  
 END  
  
CLOSE CURSOR_XP  
DEALLOCATE CURSOR_XP  
   
PRINT 'END NON MS SHIPPED EXTENDED PROCEDURES '  
PRINT ''  
  
--HA INFO
PRINT 'BEGIN SQL Server HA INFO ' 

IF (EXISTS (SELECT 1 FROM [msdb].[dbo].[log_shipping_primary_databases])
OR EXISTS (SELECT 1 FROM [msdb].[dbo].[log_shipping_secondary_databases])
)
SET @LogShip='Yes'
	PRINT 'LogShipping Enabled:    ' + ISNULL(@LogShip, 'No') 

IF EXISTS (SELECT 1 FROM sys.databases WHERE is_distributor = 1 OR is_published = 1 OR is_subscribed = 1)
	SET @Repl='Yes'
	PRINT 'Replication Enabled:    ' + ISNULL(@Repl, 'No')    

IF EXISTS (SELECT 1 FROM sys.database_mirroring WHERE mirroring_role IS NOT NULL)
	SET @DbMirror='Yes'
	PRINT 'DBMirroring Enabled:    ' + ISNULL(@DbMirror, 'No')  
	
IF CAST( PARSENAME( CAST( SERVERPROPERTY( 'ProductVersion' ) AS NVARCHAR(128) ),4 ) AS TINYINT ) >= 11 AND SERVERPROPERTY('IsHadrEnabled') = 1
	SET @AG='Yes'
	PRINT 'AlwaysON Enabled:    ' + ISNULL(@AG, 'No')
	
PRINT 'END SQL Server HA INFO '    
-- DATABASE LOCATION INFO   
PRINT 'BEGIN DATABASE LOCATION INFO '  
  
DECLARE CURSOR_DBFILES CURSOR FAST_FORWARD  
FOR  
 SELECT  A.name     AS [Database]  
    ,B.type_desc   AS [Type]  
    ,B.name     AS [LogicalName]  
    ,B.physical_name  AS [PhysicalName]  
    ,(B.Size * 8) /1024.0   AS [FileSize_MB]  
 FROM  sys.databases    A   
     JOIN sys.master_files B  ON A.database_id = B.database_id  
 ORDER BY A.name  
    ,B.type_desc DESC  
  
OPEN CURSOR_DBFILES  
  
FETCH NEXT FROM CURSOR_DBFILES  
INTO @DbName, @Type, @Logical, @Physical, @FileSize  
  
SET @PriorDB = ''  
  
WHILE @@FETCH_STATUS = 0  
BEGIN  
 IF @PriorDB <> @DbName  
  PRINT '    ' + QUOTENAME(@DbName)  
  
 PRINT '        ' + @Type + ' - ' + @Logical + ' (' + @Physical + ' - ' + CAST(@FileSize AS varchar(25)) + ' MB)'  
  
 SET @PriorDB = @DbName   
  
 FETCH NEXT FROM CURSOR_DBFILES  
 INTO @DbName, @Type, @Logical, @Physical, @FileSize  
END  
  
CLOSE CURSOR_DBFILES  
DEALLOCATE CURSOR_DBFILES  
  
PRINT 'END DATABASE LOCATION INFO '  
PRINT ''  

DECLARE CURSOR_RESTOREINFO CURSOR FAST_FORWARD  
FOR  
 WITH LatestFullBackup  
 AS  
 (  
 SELECT  D.name AS database_name  
    ,F.physical_device_name   
    ,S.backup_set_id  
    ,S.backup_start_date  
    ,S.checkpoint_lsn   
    ,S.type    
       ,F.family_sequence_number  
       ,S.position  
       ,S.description  
       ,F.device_type  
 FROM  master.sys.databases    D  
     JOIN msdb.dbo.backupset   S ON D.name    = S.database_name  
     JOIN msdb.dbo.backupmediafamily F ON S.media_set_id  = F.media_set_id  
     JOIN (  
       SELECT  D.name AS DbName  
          ,MAX(S.backup_start_date) AS backup_start_date , S.type 
       FROM  master.sys.databases    D  
           JOIN msdb.dbo.backupset   S ON D.name    = S.database_name
		   JOIN msdb.dbo.backupmediafamily F ON S.media_set_id  = F.media_set_id  
       WHERE  S.is_copy_only = 0  
         AND  S.backup_finish_date IS NOT NULL  
         AND  S.type in ('D' ,'I') 
       GROUP BY S.Type, D.name   
      ) LastFullBackup   ON S.database_name  = LastFullBackup.DbName  
               AND S.backup_start_date = LastFullBackup.backup_start_date  
 )  
 SELECT  database_name  
    ,type   
    ,physical_device_name  
    ,backup_set_id  
    ,family_sequence_number  
    ,position  
    ,description  
    ,device_type  
 FROM  LatestFullBackup  
 UNION  
 SELECT  A.database_name  
    ,A.type  
    ,C.physical_device_name  
    ,A.backup_set_id  
    ,C.family_sequence_number  
    ,A.position  
    ,A.description  
    ,C.device_type  
 FROM  msdb.dbo.backupset A  
     JOIN LatestFullBackup B ON A.database_name  = B.database_name  
             AND A.database_backup_lsn = B.checkpoint_lsn  
             AND A.backup_start_date   >= B.backup_start_date                   
     JOIN msdb.dbo.backupmediafamily C ON A.media_set_id  = C.media_set_id  
 WHERE  A.type = 'L' 
    ORDER BY database_name  
       ,backup_set_id  
       ,family_sequence_number  
         
OPEN CURSOR_RESTOREINFO  
  
FETCH NEXT FROM CURSOR_RESTOREINFO  
INTO @DbName, @Type, @BackupFile, @BackupSetId, @Sequence, @Position, @Description, @DeviceType  
    
IF @@FETCH_STATUS <> 0  
 PRINT CONVERT(varchar(30), GETDATE(), 109)+ '     *** NO FILES TO RESTORE'  
ELSE  
 BEGIN   
  WHILE @@FETCH_STATUS = 0  
  BEGIN    
          
               IF @Sequence = 1  
                BEGIN   
                    IF @Type = 'D'  
                        BEGIN  
                         PRINT '-- FULL BEING RESTORED FOR DATABASE ' + QUOTENAME(UPPER(@DbName))  
                           
                         SELECT  @Move = @Move + '        MOVE N''' + logical_name + ''' TO N''' + physical_name + ''',' + @CrLf  
                         FROM  msdb.dbo.backupfile  
                         WHERE  backup_set_id = @BackupSetId  
                           
                         PRINT 'RESTORE DATABASE ' + QUOTENAME(@DbName)         
                        END  
                       
                          IF @Type = 'I'   
                                    PRINT 'RESTORE DATABASE ' + QUOTENAME(@DbName)   
  
                          IF @Type = 'L'   
                                    PRINT 'RESTORE LOG ' + QUOTENAME(@DbName)   
  
                       PRINT 'FROM DISK = N''' + @BackupFile + ''''  
                         
                         END--sequence
          
                SET @PrevType = @Type  
                        SET @PrevBackupSetId = @BackupSetId 
						SET @PrevPosition = @Position        
               FETCH NEXT FROM CURSOR_RESTOREINFO  
INTO @DbName, @Type, @BackupFile, @BackupSetId, @Sequence, @Position, @Description, @DeviceType  
           
                                       
                        IF @BackupSetId <> @PrevBackupSetId OR @@FETCH_STATUS <> 0  
                            BEGIN  
                    PRINT 'WITH    FILE = ' + CAST(@PrevPosition AS varchar(20)) + ', '  
                      
                                IF @PrevType = 'D'  
                                    BEGIN  
                         PRINT @Move  
                         PRINT '        REPLACE,'        
                                   END   
                       
                                PRINT '        STATS = 10,'        
                                  
                                IF @Type = 'D' OR @@FETCH_STATUS <> 0               
                                    BEGIN  
                         PRINT '        RECOVERY'   
                         PRINT ''  
                                    END  
                             ELSE                          
                                    BEGIN  
                         PRINT '        NORECOVERY'   
                         PRINT ''  
                                    END                          
                    
                       SET @Move = '' 
					    END
                END  
 END
   
CLOSE CURSOR_RESTOREINFO  
DEALLOCATE CURSOR_RESTOREINFO  
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Displays the object class eg., TABLE,STORED PROC..' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'crAuditLogHistory', @level2type=N'COLUMN',@level2name=N'Object_Name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Displays the action eg., CREATE,UPDATE,DROP..' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'crAuditLogHistory', @level2type=N'COLUMN',@level2name=N'Action_Class'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Displays the user name who performed the action' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'crAuditLogHistory', @level2type=N'COLUMN',@level2name=N'Server_Principal_Name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'This table stores the audit information details on the user action performed during the code-rollout window' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'crAuditLogHistory'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Displays the servername where the code-rollout is enabled' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'crProcess', @level2type=N'COLUMN',@level2name=N'ServerName'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'This column stores customer''s service now change ticket number' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'crProcess', @level2type=N'COLUMN',@level2name=N'CTNumber'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'This column stores Ensono CASD number' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'crProcess', @level2type=N'COLUMN',@level2name=N'CasdNum'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Displays the password details to be used to connec the instance' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'crProcess', @level2type=N'COLUMN',@level2name=N'Accpwd'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'This column serves as a flag to check if remainder notification has been sent 15 mins prior to the start time' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'crProcess', @level2type=N'COLUMN',@level2name=N'Reminder'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'This table stores the code-rollout CR process information' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'crProcess'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Displays the database name enabled for the code-rollouts ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'crProcessDetails', @level2type=N'COLUMN',@level2name=N'DatabaseName'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Displays the start time of code-rollouts' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'crProcessDetails', @level2type=N'COLUMN',@level2name=N'StartTime'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Displays the end time of code-rollouts' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'crProcessDetails', @level2type=N'COLUMN',@level2name=N'EndTime'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'This table stores the code-rollout process details which includes database list and begin/end timings' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'crProcessDetails'
GO
EXEC sys.sp_addextendedproperty @name=N'value', @value=N'DBA database version tracking history. Format in <x.x.x>' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'DatabaseVersion', @level2type=N'COLUMN',@level2name=N'VersionNumber'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'This table stores the versioning history of DBA rollouts' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'DatabaseVersion'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'stores user databases under the instance' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'tDBBackup', @level2type=N'COLUMN',@level2name=N'DatabaseName'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'name of the user who creates the database' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'tDBBackup', @level2type=N'COLUMN',@level2name=N'LoginName'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'default 2. backup verify job refers to this value to determine the missed backups' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'tDBBackup', @level2type=N'COLUMN',@level2name=N'Retention'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'This table stores database list along with group defaults for Ensono maintenance jobs to run.Used as a control table which is being referred and used in several other places in the procedures' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'tDBBackup'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'path where the .bch file to be stored' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'tDBUDPOverrides', @level2type=N'COLUMN',@level2name=N'UDP_Path'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'define the client netbackup media server' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'tDBUDPOverrides', @level2type=N'COLUMN',@level2name=N'UDP_Media_Server'
GO
EXEC sys.sp_addextendedproperty @name=N'Ms_Description', @value=N'This table contains value only if the server is configured to use Netbackup appliance for running backups' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'tDBUDPOverrides'
GO
EXEC sys.sp_addextendedproperty @name=N'Purpose', @value=N'This table stores Netbackup media server,path details' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'tDBUDPOverrides'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Tells if the current instance participates in Always On Topology' , @level0type=N'SCHEMA',@level0name=N'eva', @level1type=N'TABLE',@level1name=N'ServerDetail', @level2type=N'COLUMN',@level2name=N'is_ag'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Tells if the current instance participates in Log Shipping Topology' , @level0type=N'SCHEMA',@level0name=N'eva', @level1type=N'TABLE',@level1name=N'ServerDetail', @level2type=N'COLUMN',@level2name=N'is_logshipping'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'This table stores instance attributes like environment type,HA solution' , @level0type=N'SCHEMA',@level0name=N'eva', @level1type=N'TABLE',@level1name=N'ServerDetail'
GO
