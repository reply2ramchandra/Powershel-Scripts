USE [msdb]
GO
if (SELECT CHARINDEX('P',@@SERVERNAME,4)) =4--if prod
BEGIN
/****** Object:  Operator [SQLAdmin_ICT]    Script Date: 12/7/2023 2:26:50 PM ******/
EXEC msdb.dbo.sp_add_operator @name=N'ICT_SQL', 
		@enabled=1, 
		@weekday_pager_start_time=90000, 
		@weekday_pager_end_time=180000, 
		@saturday_pager_start_time=90000, 
		@saturday_pager_end_time=180000, 
		@sunday_pager_start_time=90000, 
		@sunday_pager_end_time=180000, 
		@pager_days=0, 
		--@email_address=N'ict-whps1@wipro.com;WHPS-MSSQL-Admins@wipro.com',
		@email_address=N'ict-whps1@wipro.com;WHPS-MSSQL-Admins@wipro.com', 
		@category_name=N'[Uncategorized]'
END


