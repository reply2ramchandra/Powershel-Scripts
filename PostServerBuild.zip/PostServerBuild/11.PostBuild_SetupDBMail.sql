BEGIN
DECLARE @servername			VARCHAR(100) = REPLACE( @@servername,'\','_' )
			   ,@display_name		VARCHAR(100)
			   ,@smtp_server		VARCHAR(50)
			   ,@smtp_email_address VARCHAR(50)
			   ,@MailProfile        VARCHAR(128);

SET @smtp_server='smtprelay.healthplan.com'
SET @smtp_email_address='no-reply@healthplan.com'

/*
		######################################################################
							Setting Up Database Mail
		######################################################################
		*/

		IF ((
			  SELECT
				  CONVERT( VARCHAR(128),[value] )
			  FROM sys.configurations
			  WHERE name = 'Database Mail XPs'
		) != '1')
		BEGIN
		exec sp_configure 'show advanced options', 1; RECONFIGURE;  
		exec sp_configure 'Database Mail XPs',1; RECONFIGURE WITH OVERRIDE
			--EXEC dbo.usp_configure_options @key	  = N'Database Mail XPs'  ,@value = '1';
                END    

		IF ((
			  SELECT
				  CONVERT( VARCHAR(128),[value] )
			  FROM sys.configurations
			  WHERE name = 'Agent XPs'
		) != '1')
		BEGIN
		exec sp_configure 'show advanced options', 1; RECONFIGURE; 
		exec SP_CONFIGURE 'AGENT XPs',1; RECONFIGURE WITH OVERRIDE
		--EXEC dbo.usp_configure_options @key	  = N'Agent XPs' ,@value = '1';
END
               

		SET @display_name = @servername;

		IF EXISTS (SELECT * FROM msdb.dbo.sysmail_profile)
			PRINT 'DB mail already configured'
		ELSE
			BEGIN

					
				--Create database mail account.
				EXEC msdb.dbo.sysmail_add_account_sp @account_name	  = @servername
													,@description	  = 'SQL Server Service Database Mail Account'
													,@display_name	  = @display_name
													,@mailserver_name = @smtp_server
													,@email_address	  = @smtp_email_address
													,@replyto_address = '';

				--Create global mail profile.
				EXEC msdb.dbo.sysmail_add_profile_sp @profile_name = 'SQL DBA Admins'
													,@description  = 'This is the default profile that will be created for SQL Server environments.'

				--Add the account to the profile.
				EXEC msdb.dbo.sysmail_add_profileaccount_sp @profile_name	 = 'SQL DBA Admins'
														   ,@account_name	 = @servername
														   ,@sequence_number = 1

				--grant access to the profile to all users in the msdb database
				EXEC msdb.dbo.sysmail_add_principalprofile_sp @profile_name	  = 'SQL DBA Admins'
															 ,@principal_name = 'public'
															 ,@is_default	  = 1
				END
				
			
		/*
		######################################################################
							Setting Up SQL Agent Mail
		######################################################################
		*/

		PRINT '##################################################################'
		PRINT 'Enabling SQL Agent notification - THIS REQUIRES RESTART SQL AGENT'
		PRINT '##################################################################'

		-- Enabling SQL Agent notification
        SELECT @MailProfile = COALESCE(sp.[name],'') 
        FROM msdb.dbo.sysmail_profile AS sp 

        EXEC msdb.dbo.sp_set_sqlagent_properties 
									@email_save_in_sent_folder=1, 
                                    @databasemail_profile=@MailProfile, 
                                    @use_databasemail=1

		--EXEC master.dbo.xp_instance_regwrite N'HKEY_LOCAL_MACHINE'
		--									,N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent'
		--									,N'UseDatabaseMail'
		--									,N'REG_DWORD'
		--									,1
		--EXEC master.dbo.xp_instance_regwrite N'HKEY_LOCAL_MACHINE'
		--									,N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent'
		--									,N'DatabaseMailProfile'
		--									,N'REG_SZ'
		--									,N'SQLMail Profile'

			
END