
use Admin;
DECLARE @schedulename NVARCHAR(128)
	   ,@JobOwner	  NVARCHAR(128) = SUSER_SNAME( 0x01 )
	   ,@start_time	  INT
	   ,@utc          INT -- Add +5 HOURS when server time zone in UTC
	   ;

IF (DATEDIFF(MINUTE,GETUTCDATE(),CURRENT_TIMESTAMP)) = 0 
SET @utc = 50000
ELSE SET @utc = 0




	/*
	Available Job Schedules:
					DatabaseBackup - SYSTEM_DATABASES - FULL  : 12 AM DAILY
					DatabaseBackup - USER_DATABASES - FULL : 6 PM WEEKLY
					DatabaseBackup - USER_DATABASES - DIFF : M-F 9 PM
					DatabaseBackup - USER_DATABASES - LOG  : EVERY 10 MINS
					IndexOptimize - USER_DATABASES : 6 AM SUNDAY
					DatabaseIntegrityCheck - USER_DATABASES :  6 AM SATURDAY
					DatabaseIntegrityCheck - SYSTEM_DATABASES : M-F 2 AM
					Output File Cleanup : BI-WEEKLY
					sp_delete_backuphistory : BI-WEEKLY
					sp_purge_jobhistory : BI-WEEKLY
					CommandLog Cleanup : BI-WEEKLY

	Servers in UTC time zone are scheduled to start at +5:00 HOURS 				
	*/

	SET @schedulename = '6 PM WEEKLY';

	--IF NOT EXISTS (SELECT 1 FROM msdb.dbo.[sysschedules] AS [s] WHERE [s].[name] = @schedulename)
		 BEGIN

			 SET @start_time = 180000 + @utc;

			 EXEC msdb.dbo.sp_add_schedule @schedule_name		   = @schedulename
										  ,@enabled				   = 1
										  ,@freq_type			   = 8
										  ,@freq_interval		   = 1
										  ,@freq_recurrence_factor = 1
										  ,@active_start_time	   = @start_time
										  ,@active_end_time		   = 235959
										  ,@active_end_date		   = 99991231
										  ,@owner_login_name	   = @JobOwner;
		 END
	--//

	
	SET @schedulename = '12 AM DAILY';

	--IF NOT EXISTS (SELECT 1 FROM msdb.dbo.[sysschedules] AS [s] WHERE [s].[name] = @schedulename)
		 BEGIN
			 EXEC msdb.dbo.sp_add_schedule @schedule_name		 = @schedulename
										  ,@enabled				 = 1
										  ,@freq_type			 = 4
										  ,@freq_interval		 = 1
										  ,@freq_subday_type	 = 8
										  ,@freq_subday_interval = 6
										  ,@active_start_time	 = 0
										  ,@active_end_time		 = 235959
										  ,@active_end_date		 = 99991231
										  ,@owner_login_name	 = @JobOwner;
		 END
	--//

	SET @schedulename = 'EVERY 10 MINS';

	--IF NOT EXISTS (SELECT 1 FROM msdb.dbo.[sysschedules] AS [s] WHERE [s].[name] = @schedulename)
	    BEGIN
		EXEC msdb.dbo.sp_add_schedule @schedule_name		= @schedulename
									 ,@enabled				= 1
									 ,@freq_type			= 4
									 ,@freq_interval		= 1
									 ,@freq_subday_type		= 4
									 ,@freq_subday_interval = 10
									 ,@active_start_time	= 0    -- 12:00AM
									 ,@active_end_time		= 235959
									 ,@active_end_date		= 99991231
									 ,@owner_login_name		= @JobOwner;
        END        

	SET @schedulename = '6 AM SUNDAY';

	--IF NOT EXISTS (SELECT 1 FROM msdb.dbo.[sysschedules] AS [s] WHERE [s].[name] = @schedulename)
		 BEGIN
			 SET @start_time = 60000 + @utc;
             IF @start_time > 240000 SET @start_time -= 240000;
			 
			 EXEC msdb.dbo.sp_add_schedule @schedule_name		   = @schedulename
										  ,@enabled				   = 1
										  ,@freq_type			   = 8
										  ,@freq_interval		   = 1
										  ,@freq_recurrence_factor = 1
										  ,@active_start_time	   = @start_time
										  ,@active_end_time		   = 235959
										  ,@active_end_date		   = 99991231
										  ,@owner_login_name	   = @JobOwner;

		 END
	--//

	SET @schedulename = '6 AM SATURDAY';

	--IF NOT EXISTS (SELECT 1 FROM msdb.dbo.[sysschedules] AS [s] WHERE [s].[name] = @schedulename)
		 BEGIN
			 SET @start_time = 60000 + @utc;
             IF @start_time > 240000 SET @start_time -= 240000;

			 EXEC msdb.dbo.sp_add_schedule @schedule_name		   = @schedulename
										  ,@enabled				   = 1
										  ,@freq_type			   = 8
										  ,@freq_interval		   = 62
										  ,@freq_subday_type	   = 1
										  ,@freq_recurrence_factor = 1
										  ,@active_start_time	   = @start_time
										  ,@active_end_time		   = 235959
										  ,@active_end_date		   = 99991231
										  ,@owner_login_name	   = @JobOwner;

		 END
	--//

	SET @schedulename = 'BI-WEEKLY';

	--IF NOT EXISTS (SELECT 1 FROM msdb.dbo.[sysschedules] AS [s] WHERE [s].[name] = @schedulename)
		 BEGIN
			 SET @start_time = 60000 + @utc;
			 EXEC msdb.dbo.sp_add_schedule @schedule_name		   = @schedulename
										  ,@enabled				   = 1
										  ,@freq_type			   = 8
										  ,@freq_interval		   = 1
										  ,@freq_subday_interval   = 6
										  ,@freq_subday_type=1
										  ,@freq_recurrence_factor = 2
										  ,@active_start_time	   = @start_time
										  ,@active_end_time		   = 235959
										  ,@active_end_date		   = 99991231
										  ,@owner_login_name	   = @JobOwner;
		 END
	--//
	SET @schedulename = 'M-F 2 AM';

	--IF NOT EXISTS (SELECT 1 FROM msdb.dbo.[sysschedules] AS [s] WHERE [s].[name] = @schedulename)
		 BEGIN
			 SET @start_time = 20000 + @utc;
             IF @start_time > 240000 SET @start_time -= 240000;

			 EXEC msdb.dbo.sp_add_schedule @schedule_name		   = @schedulename
										  ,@enabled				   = 1
										  ,@freq_type			   = 8
										  ,@freq_interval=62
										  ,@freq_subday_type	   = 1
										  ,@freq_recurrence_factor = 1
										  ,@active_start_time	   = @start_time
										  ,@active_end_time		   = 235959
										  ,@active_end_date		   = 99991231
										  ,@owner_login_name	   = @JobOwner;
		 END
--//

SET @schedulename = 'M-F 9 PM';

	--IF NOT EXISTS (SELECT 1 FROM msdb.dbo.[sysschedules] AS [s] WHERE [s].[name] = @schedulename)
		 BEGIN
			 SET @start_time = 210000 + @utc;
             IF @start_time > 240000 SET @start_time -= 240000;

			 EXEC msdb.dbo.sp_add_schedule @schedule_name		   = @schedulename
										  ,@enabled				   = 1
										  ,@freq_type			   = 8
										  ,@freq_interval		   = 62
										  ,@freq_subday_type	   = 1
										  ,@freq_recurrence_factor = 1
										  ,@active_start_time	   = @start_time
										  ,@active_end_time		   = 235959
										  ,@active_end_date		   = 99991231
										  ,@owner_login_name	   = @JobOwner;
		 END
		 
--//

--Add schedule and attach		

--EXEC msdb.dbo.sp_add_jobschedule  @job_name=N'CommandLog Cleanup',@name=N'BI-WEEKLY',@enabled=1
EXEC msdb.dbo.sp_attach_schedule @job_name=N'CommandLog Cleanup', @schedule_name=N'BI-WEEKLY'
GO	
--EXEC msdb.dbo.sp_add_jobschedule @job_name=N'sp_purge_jobhistory', @name=N'BI-WEEKLY',@enabled=1
EXEC msdb.dbo.sp_attach_schedule @job_name=N'sp_purge_jobhistory', @schedule_name=N'BI-WEEKLY'
GO
--EXEC msdb.dbo.sp_add_jobschedule @job_name=N'DatabaseBackup - SYSTEM_DATABASES - FULL', @name=N'2 AM DAILY',@enabled=1
EXEC msdb.dbo.sp_attach_schedule @job_name=N'DatabaseBackup - SYSTEM_DATABASES - FULL', @schedule_name=N'12 AM DAILY'
GO
--EXEC msdb.dbo.sp_add_jobschedule  @job_name=N'sp_delete_backuphistory',@name=N'BI-WEEKLY',@enabled=1
EXEC msdb.dbo.sp_attach_schedule @job_name=N'sp_delete_backuphistory', @schedule_name=N'BI-WEEKLY'
GO	
--EXEC msdb.dbo.sp_add_jobschedule  @job_name=N'Output File Cleanup',@name=N'BI-WEEKLY',@enabled=1
EXEC msdb.dbo.sp_attach_schedule @job_name=N'Output File Cleanup', @schedule_name=N'BI-WEEKLY'
GO	
--EXEC msdb.dbo.sp_add_jobschedule  @job_name=N'DatabaseIntegrityCheck - SYSTEM_DATABASES',@name=N'M-F 2 AM',@enabled=1
EXEC msdb.dbo.sp_attach_schedule @job_name=N'DatabaseIntegrityCheck - SYSTEM_DATABASES', @schedule_name=N'M-F 2 AM'
GO	
--EXEC msdb.dbo.sp_add_jobschedule  @job_name=N'DatabaseIntegrityCheck - USER_DATABASES',@name=N'6 AM SATURDAY',@enabled=1 
EXEC msdb.dbo.sp_attach_schedule @job_name=N'DatabaseIntegrityCheck - USER_DATABASES', @schedule_name=N'6 AM SATURDAY'
GO	
--EXEC msdb.dbo.sp_add_jobschedule  @job_name=N'IndexOptimize - USER_DATABASES',@name=N'6 AM SUNDAY',@enabled=1
EXEC msdb.dbo.sp_attach_schedule @job_name=N'IndexOptimize - USER_DATABASES', @schedule_name=N'6 AM SUNDAY'
GO
--EXEC msdb.dbo.sp_add_jobschedule  @job_name=N'DatabaseBackup - USER_DATABASES - FULL',@name=N'6 PM WEEKLY',@enabled=1
EXEC msdb.dbo.sp_attach_schedule @job_name=N'DatabaseBackup - USER_DATABASES - FULL', @schedule_name=N'6 PM WEEKLY'
GO	
--EXEC msdb.dbo.sp_add_jobschedule  @job_name=N'DatabaseBackup - USER_DATABASES - DIFF',@name=N'M-F 9 PM',@enabled=1
EXEC msdb.dbo.sp_attach_schedule @job_name=N'DatabaseBackup - USER_DATABASES - DIFF', @schedule_name=N'M-F 9 PM'
GO	
--EXEC msdb.dbo.sp_add_jobschedule  @job_name=N'DatabaseBackup - USER_DATABASES - LOG',@name=N'EVERY 10 MINS',@enabled=1
EXEC msdb.dbo.sp_attach_schedule @job_name=N'DatabaseBackup - USER_DATABASES - LOG', @schedule_name=N'EVERY 10 MINS'
GO	

if (SELECT CHARINDEX('P',@@SERVERNAME,4)) =4--if prod
BEGIN
EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseBackup - SYSTEM_DATABASES - FULL', 
		@notify_level_eventlog=2, 
		@notify_level_email=0		
EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseBackup - SYSTEM_DATABASES - FULL', 
		@notify_level_email=2, 
		@notify_level_page=2, 
		@notify_email_operator_name=N'ICT_SQL'	


EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseBackup - USER_DATABASES - DIFF', 
		@notify_level_eventlog=2, 
		@notify_level_email=0		 
			
EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseBackup - USER_DATABASES - DIFF', 
		@notify_level_email=2, 
		@notify_level_page=2, 
		@notify_email_operator_name=N'ICT_SQL'	

EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseBackup - USER_DATABASES - LOG', 
		@notify_level_eventlog=2, 
		@notify_level_email=0 		 
EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseBackup - USER_DATABASES - LOG', 
		@notify_level_email=2, 
		@notify_level_page=2, 
		@notify_email_operator_name=N'ICT_SQL'		

EXEC msdb.dbo.sp_update_job @job_name=N'IndexOptimize - USER_DATABASES', 
		@notify_level_eventlog=2, 
		@notify_level_email=0
EXEC msdb.dbo.sp_update_job @job_name=N'IndexOptimize - USER_DATABASES', 
		@notify_level_email=2, 
		@notify_level_page=2, 
		@notify_email_operator_name=N'ICT_SQL'	

EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseIntegrityCheck - SYSTEM_DATABASES', 
		@notify_level_eventlog=2, 
		@notify_level_email=0
EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseIntegrityCheck - SYSTEM_DATABASES', 
		@notify_level_email=2, 
		@notify_level_page=2, 
		@notify_email_operator_name=N'ICT_SQL'

EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseIntegrityCheck - USER_DATABASES', 
		@notify_level_eventlog=2, 
		@notify_level_email=0
EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseIntegrityCheck - USER_DATABASES', 
		@notify_level_email=2, 
		@notify_level_page=2, 
		@notify_email_operator_name=N'ICT_SQL'

EXEC msdb.dbo.sp_update_job @job_name=N'Output File Cleanup', 
		@notify_level_eventlog=2, 
		@notify_level_email=0	 

EXEC msdb.dbo.sp_update_job @job_name=N'sp_purge_jobhistory', 
		@notify_level_eventlog=2, 
		@notify_level_email=0		 
	
EXEC msdb.dbo.sp_update_job @job_name=N'sp_delete_backuphistory', 
		@notify_level_eventlog=2, 
		@notify_level_email=0
	
EXEC msdb.dbo.sp_update_job @job_name=N'CommandLog Cleanup', 
		@notify_level_eventlog=2, 
		@notify_level_email=0		 

END