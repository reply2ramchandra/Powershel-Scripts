IF NOT EXISTS( select name from sys.databases where name='Admin')
BEGIN 
create database Admin;
END