Use master
GO
sp_configure N'remote admin connections', 1
GO
RECONFIGURE WITH OVERRIDE
GO