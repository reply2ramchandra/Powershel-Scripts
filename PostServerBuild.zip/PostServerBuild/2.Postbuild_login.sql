USE [master]
GO

/****** Object:  Login [HPS\SG-MSSQL-ADM-PROD]    Script Date: 12/8/2023 12:43:46 PM ******/
IF NOT EXISTS( select name from sys.server_principals where name='HPS\SG-MSSQL-ADM-PROD')
BEGIN 
CREATE LOGIN [HPS\SG-MSSQL-ADM-PROD] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
ALTER SERVER ROLE [sysadmin] ADD MEMBER [HPS\SG-MSSQL-ADM-PROD]
END

