﻿#info
#quick saturday morning script
#assumes running local on single computer
#improvements welcome

Function StartWindowsUpdateService{
    #GPO may have service disabled

    #Set-Service -Name wuauserv -StartupType Manual
    if( (Get-Service -Name wuauserv ).StartType -eq 'Disabled'){Set-Service -Name wuauserv -StartupType Manual}

    #Start-Service -Name wuauserv
    if( (Get-Service -Name wuauserv ).Status -ne 'Running'){Start-Service -Name wuauserv}

}




Function GetPatchInfo {
param ([datetime]$BaselineDate)
    StartWindowsUpdateService
    #Only Software with KB
    $RawPatchList = Get-WindowsUpdate -UpdateType Software
    $KBList = @()

    Foreach ($Row in $RawPatchList){
        $PatchDateCriteria = $false

        if (($BaselineDate -ge $Row.LastDeploymentChangeTime) -and ($Row.KB -like "KB*")){
            $PatchDateCriteria = $true
            $KBList += $Row.KB
        }

        write-host "$($Row.ComputerName) $($Row.Status) $($Row.KB) $($Row.LastDeploymentChangeTime.ToString("yyyy-MM-dd")) $PatchDateCriteria $($Row.Title)"
     
    }

    #KBList to install
    Return $KBList

}

[datetime]$BaselineDate = "2021-jun-08"
$KBsToPatch = GetPatchInfo $BaselineDate

Get-WindowsUpdate -KBArticleID $KBsToPatch -Download -Install -AcceptAll -WhatIf 