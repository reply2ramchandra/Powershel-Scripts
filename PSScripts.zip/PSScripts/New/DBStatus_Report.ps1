
$Header = @"
<style>
TABLE {border-width: 1px; border-style: solid; border-color: green; border-collapse: collapse;}
TD {border-width: 1px; padding: 3px; border-style: solid; border-color: black;}
</style>
"@

     $dbstatusinfo= Get-DbaDatabase -SqlInstance tpapwdwsql004 | Where-Object -FilterScript { $_.Status -ne 'Normal' } | select ComputerName,Name,Status

     $dbstatusinfo | ConvertTo-Html -Head $Header | Out-File -FilePath \\tpapwmssql002\Reports\dbstatusreport.html

             if($dbstatusinfo.ComputerName.Count -gt 0)
             {
              Write-host 'Some dbs are not online. Hence sending mail' -ForegroundColor RED

             $body = Get-Content \\tpapwmssql002\Common\Reports\dbstatusreport.html

              Send-MailMessage -From 'DBStatus_Report@Healthplan.com'  -To 'sathiyaneethi.mani@wipro.com' -Subject 'DB status Alerts' -SmtpServer smtp.gmail.com  -Body "$body" ` -BodyAsHtml

               Invoke-Item \\tpapwmssql002\Reports\dbstatusreport.html

             }
             else
             {
             Write-host 'All dbs online' -ForegroundColor green
             }