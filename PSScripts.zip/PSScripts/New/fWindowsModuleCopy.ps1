﻿Import-Module PSWindowsUpdate

#$targets=@("TPAPWSQLFTPA01","TPAPWSQLFTPB01","TPAPWPESQL001","TPAPWPESQL002","TPAPWSQLHHA01","TPAPWSQLHHB01","TPADWSQLGNXTA01","TPADWSQLGNXTB01","TPATWSQLHHA01","TPATWSQLHHB01","TPAPWSQLGNRA01","TPAPWSQLGNRB01","TPATWSQLMHCA01","TPATWSQLMHCB01")
$targets=@("TPAPWPESQL001","TPAPWPESQL002")
#$targets=@("TPAPWPESQL002")
#Checking ping of the servers
Test-Connection -ComputerName $targets -Count 1


#Copy PSWindowsUpdate to all the servers where the refresh is planned for..
foreach($target in $targets)
{
    if(!(Test-Path "\\$target\C$\Program Files\WindowsPowerShell\Modules\PSWindowsUpdate"))
        {
            Write-host 'PSWindowsUpdate module not there in ' $target 'hence copying ' -ForegroundColor Cyan
       
   
   Copy-item 'C:\Program Files\WindowsPowerShell\Modules\PSWindowsUpdate' "\\$target\C$\Program Files\WindowsPowerShell\Modules" -Recurse
   }
   
    if(Test-Path "\\$target\C$\Program Files\WindowsPowerShell\Modules\PSWindowsUpdate")
        {
            Write-host 'PSWindowsUpdate module copied in ' $target 'on modules folder ' -ForegroundColor Green
        }
        else
        {
            Write-host 'PSWindowsUpdate module not copied in ' $target '. Check the reason ' -ForegroundColor Cyan
        }
}
