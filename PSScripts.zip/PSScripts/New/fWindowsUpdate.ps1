Import-Module PSWindowsUpdate

$targets=@("TPAPWSQLALFB01","TPAPWSQLALFA01")

#Checking ping of the servers
Test-Connection -ComputerName $targets -Count 1


#Copy PSWindowsUpdate to all the servers where the refresh is planned for..
foreach($target in $targets)
{
    if(!(Test-Path "\\$target\C$\Program Files\WindowsPowerShell\Modules\PSWindowsUpdate"))
        {
            Write-host 'PSWindowsUpdate module not there in ' $target 'hence copying ' -ForegroundColor Cyan
       
   
   Copy-item 'C:\Program Files\WindowsPowerShell\Modules\PSWindowsUpdate' "\\$target\C$\Program Files\WindowsPowerShell\Modules" -Recurse
   }
   
    if(Test-Path "\\$target\C$\Program Files\WindowsPowerShell\Modules\PSWindowsUpdate")
        {
            Write-host 'PSWindowsUpdate module copied in ' $target 'on modules folder ' -ForegroundColor Green
        }
        else
        {
            Write-host 'PSWindowsUpdate module not copied in ' $target '. Check the reason ' -ForegroundColor Cyan
        }
}



#Inorder to manage updates on the remote computers , you need to add hostnames to your winrm trusted host list in source server (celadmindb1 in our case).

foreach($target in $targets)
{
Write-host 'Setting trusted server list for' $target  -ForegroundColor Cyan
Set-Item WSMan:\localhost\Client\TrustedHosts -Value $target -Force
Write-host 'Added to trusted list ' $target  -ForegroundColor Green
}



#Set Execution policy to Remote signed and Importing the PSWINDOWSUPDATE moldule to all computers.
#You might get some WinRM errors but that can be ignored.

foreach($target in $targets)
{
Write-host 'Setting Execution policy and enabling WURemoting for' $target -ForegroundColor Cyan
Invoke-Command -ComputerName $target -ScriptBlock {Set-ExecutionPolicy RemoteSigned -Force}
Invoke-Command -ComputerName $target -ScriptBlock {Import-module PSWindowsUpdate;Enable-WURemoting}
Write-host 'Exec policy and enabling WURemoting set for ' $target  -ForegroundColor GREEN
}


#Get the list of updates available in the server.
Write-host 'Getting the list of updates to be installed' -ForegroundColor Yellow

Get-WUList -ComputerName $targets | Out-file "C:\temp1\Log\WindowsUpdate\$(get-date -Format yyyy-MM-ddhhmmss)WinUpdate.csv"
Get-WUList -ComputerName $targets | FT -AutoSize
#Get-WindowsUpdate -ComputerName $targets


#Initiate the updates as jobs
Invoke-WUJob -ComputerName $targets -Script {ipmo PSWindowsUpdate; Install-WindowsUpdate -AcceptAll -AutoReboot  | Out-File C:\Windows\PSWindowsUpdate.log } -RunNow -Confirm:$false -Verbose -ErrorAction Continue


#Check the jobs.
Get-WUJob -ComputerName $targets


#Wait for 10 mins. Chances are there the file might create after some time.
#Check the status of installation from the log files in each server
foreach($target in $targets)
{
Get-Content  "\\$target\C$\Windows\PSWindowsUpdate.log"
}


#Count of Accepted Downloaded and Installed

'Server'+','+'Accepted'+','+'Downloaded'+','+'Installed'
foreach($target in $targets)
{
$Acceptedcnt=(Get-Content  "\\$target\C$\Windows\PSWindowsUpdate.log" | select-string -pattern "Accepted").length
$Downloadcnt=(Get-Content  "\\$target\C$\Windows\PSWindowsUpdate.log" | select-string -pattern "Downloaded").length
$InstalledCnt=(Get-Content  "\\$target\C$\Windows\PSWindowsUpdate.log" | select-string -pattern "Installed").length

 $target +','+$Acceptedcnt+','+ $Downloadcnt+','+ $InstalledCnt
}


#Get-DbaUptime
Get-DbaUptime -SqlInstance $targets| select ComputerName,SinceSqlStart,SinceWindowsBoot

#Check SQL server version
Get-DbaBuildReference -SqlInstance $targets | ft

#Status of SQL Services
Get-DbaService -SqlInstance $targets | ft


#Restart any pending servers that require reboot
$serverstorestart=@('VM1')
Restart-Computer -ComputerName $serverstorestart -Force # -Wait -For PowerShell -Timeout 300 -delay 2
 
 #Checking ping of the servers
Test-Connection -ComputerName $targets -Count 1


 #clear the task scheduler jobs in the destination computers.
Clear-WUJob -ComputerName $targets

#Check for pending reboots
Get-WURebootStatus -ComputerName $targets

#Check Last reboot time
Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $targets | select csname,LastBootUpTime
