<#
Monitors currently running SQL Server Agent job steps within a recent window.
Alerts when CURRENT duration > (Average of last N runs * ThresholdMultiplier).

Filters:
 -WindowHours (default 24)
 -TodayOnly (optional)
 -PruneZombie (optional) removes rows older than WindowHours * 2 even if still flagged running.

Compatible with legacy Windows PowerShell (no modern operators).
#>

param(
    [string]$SqlInstance = "TPAPWDWSQL004",
    [string]$MailFrom    = "noreply@healthplan.com",
    [string]$MailTo      = "sathiyaneethi.mani@wipro.com",
    [string]$SmtpServer  = "smtprelay.healthplan.com",
    [string]$SubjectPrefix = "[SQL Job Step Monitor]",
    [int]$LookbackRuns = 2,
    [double]$ThresholdMultiplier = 1.0,
    [int]$WindowHours = 24,
    [switch]$TodayOnly,
    [switch]$SendAlways,
    [switch]$UseHtml = $true,
    [switch]$PruneZombie,
    [int]$SmtpPort = 25,
    [switch]$EnableSsl,
    [pscredential]$SmtpCredential
)

function Invoke-JobQuery {
    param(
        [string]$SqlInstance,
        [int]$LookbackRuns,
        [int]$WindowHours,
        [bool]$TodayOnly
    )

    $todayClause = ""
    if ($TodayOnly) {
        $todayClause = "AND CONVERT(date, ja.start_execution_date) = CONVERT(date, SYSDATETIME())"
    }

    $tsql = @"
;WITH ja_filtered AS (
    SELECT ja.*,
           ROW_NUMBER() OVER (PARTITION BY ja.job_id ORDER BY ja.start_execution_date DESC, ja.session_id DESC) AS rn
    FROM msdb.dbo.sysjobactivity ja
    WHERE ja.start_execution_date IS NOT NULL
      AND ja.stop_execution_date IS NULL
      AND ja.start_execution_date >= DATEADD(HOUR, -$WindowHours, SYSDATETIME())
      $todayClause
),
running_jobs AS (
    SELECT  ja.job_id,
            j.name AS JOB_NAME,
            ja.start_execution_date AS JOB_START_DATETIME,
            ja.last_executed_step_id,
            ja.last_executed_step_date,
            CASE WHEN ja.last_executed_step_id IS NULL THEN 1 ELSE ja.last_executed_step_id + 1 END AS CURRENT_STEP_ID
    FROM ja_filtered ja
    INNER JOIN msdb.dbo.sysjobs j ON j.job_id = ja.job_id
    WHERE ja.rn = 1
),
current_steps AS (
    SELECT r.*,
           CASE
             WHEN r.last_executed_step_id IS NULL THEN r.JOB_START_DATETIME
             ELSE r.last_executed_step_date
           END AS CURRENT_STEP_START_DATE
    FROM running_jobs r
),
hist AS (
    SELECT  h.job_id,
            h.step_id,
            h.run_status,
            h.instance_id,
            ((h.run_duration / 10000) * 3600) +
            (((h.run_duration % 10000) / 100) * 60) +
            (h.run_duration % 100) AS duration_seconds,
            ROW_NUMBER() OVER (PARTITION BY h.job_id, h.step_id ORDER BY h.instance_id DESC) AS rn
    FROM msdb.dbo.sysjobhistory h
    WHERE h.step_id > 0
      AND h.run_status = 1
),
avgN AS (
    SELECT job_id,
           step_id,
           AVG(CAST(duration_seconds AS float)) AS avg_duration_seconds
    FROM hist
    WHERE rn <= $LookbackRuns
    GROUP BY job_id, step_id
)
SELECT  cs.JOB_NAME,
        cs.CURRENT_STEP_ID AS STEP_ID,
        s.step_name AS STEP_NAME,
        cs.JOB_START_DATETIME,
        cs.CURRENT_STEP_START_DATE,
        DATEDIFF(SECOND, cs.CURRENT_STEP_START_DATE, SYSDATETIME()) AS CURRENT_STEP_EXECUTION_DURATION_SECONDS,
        a.avg_duration_seconds AS AVG_LAST_RUN_DURATION_SECONDS
FROM current_steps cs
INNER JOIN msdb.dbo.sysjobsteps s
    ON s.job_id = cs.job_id
   AND s.step_id = cs.CURRENT_STEP_ID
LEFT JOIN avgN a
    ON a.job_id = cs.job_id
   AND a.step_id = cs.CURRENT_STEP_ID
ORDER BY cs.JOB_NAME, cs.CURRENT_STEP_ID;
"@

    if (Get-Command Invoke-Sqlcmd -ErrorAction SilentlyContinue) {
        Invoke-Sqlcmd -ServerInstance $SqlInstance -Database msdb -Query $tsql -ErrorAction Stop -TrustServerCertificate
    } else {
        $cs = "Server=$SqlInstance;Database=msdb;Integrated Security=SSPI;TrustServerCertificate=True"
        $conn = New-Object System.Data.SqlClient.SqlConnection $cs
        $cmd  = $conn.CreateCommand(); $cmd.CommandText = $tsql
        $dt = New-Object System.Data.DataTable
        try { $conn.Open(); $r = $cmd.ExecuteReader(); $dt.Load($r); $r.Close() } finally { $conn.Close() }
        $dt
    }
}

function Format-Seconds([int]$Seconds) {
    if ($Seconds -lt 0 -or $null -eq $Seconds) { return $null }
    ([TimeSpan]::FromSeconds($Seconds)).ToString("hh\:mm\:ss")
}

function Convert-ToIntRounded {
    param($Value)
    if ($null -eq $Value -or $Value -is [System.DBNull] -or ([string]::IsNullOrWhiteSpace("$Value"))) { return $null }
    try { [int]([double]$Value + 0.5) } catch { $null }
}

function Get-RecipientList {
    param([string]$List)
    if (-not $List) { return @() }
    $List -split '[,;]' | ForEach-Object {
        $t = $_.Trim()
        if ($t) { $t }
    }
}

$body = ""
$subject = ""
$sendEmail = $false
$isHtml = $UseHtml
$result = $null

try {
    $rows = Invoke-JobQuery -SqlInstance $SqlInstance -LookbackRuns $LookbackRuns -WindowHours $WindowHours -TodayOnly ($TodayOnly.IsPresent)

    # Defensive filtering (PowerShell layer)
    $now = Get-Date
    $windowStart = $now.AddHours(-$WindowHours)
    $filtered = @()
    foreach ($r in $rows) {
        $start = [datetime]$r.JOB_START_DATETIME
        if ($start -lt $windowStart) { continue }
        if ($TodayOnly.IsPresent -and $start.Date -ne $now.Date) { continue }
        $filtered += $r
    }
    if ($PruneZombie) {
        $zombieCutoff = $now.AddHours(-($WindowHours * 2))
        $filtered = $filtered | Where-Object { ([datetime]$_.JOB_START_DATETIME) -ge $zombieCutoff }
    }
    $rows = $filtered

    if (-not $rows -or $rows.Count -eq 0) {
        $suffixToday = ""
        if ($TodayOnly.IsPresent) { $suffixToday = " (today only)" }
        $consoleMsg = "No currently running job steps in last $WindowHours hour(s)$suffixToday."
        Write-Host $consoleMsg
        if ($SendAlways) {
            $body = "$consoleMsg Timestamp: $(Get-Date -Format o)"
            $subject = "$SubjectPrefix No running steps"
            $sendEmail = $true
        } else {
            return
        }
    } else {
        # Dedupe by JOB_NAME + STEP_ID
        $rows = $rows | Sort-Object JOB_NAME, STEP_ID, CURRENT_STEP_START_DATE -Descending |
            Group-Object JOB_NAME, STEP_ID | ForEach-Object { $_.Group | Select-Object -First 1 }

        $result = $rows | ForEach-Object {
            $avgSec = Convert-ToIntRounded $_.AVG_LAST_RUN_DURATION_SECONDS
            $currSec = $_.CURRENT_STEP_EXECUTION_DURATION_SECONDS
            $threshold = $null
            $exceeds = $false
            if ($avgSec -ne $null) {
                $threshold = [int]([double]$avgSec * $ThresholdMultiplier + 0.5)
                if ($currSec -gt $threshold) { $exceeds = $true }
            }
            [pscustomobject]@{
                JOB_NAME = $_.JOB_NAME
                STEP_ID  = $_.STEP_ID
                STEP_NAME= $_.STEP_NAME
                JOB_START_DATETIME = ([datetime]$_.JOB_START_DATETIME).ToLocalTime()
                CURRENT_STEP_START_DATE = ([datetime]$_.CURRENT_STEP_START_DATE).ToLocalTime()
                CURRENT_STEP_EXECUTION_DURATION = Format-Seconds $currSec
                AVG_LAST_RUN_DURATION = if ($avgSec -ne $null) { Format-Seconds $avgSec } else { $null }
                CURRENT_STEP_EXECUTION_DURATION_SECONDS = $currSec
                AVG_LAST_RUN_DURATION_SECONDS = $avgSec
                THRESHOLD_SECONDS = $threshold
                EXCEEDS_AVG = $exceeds
            }
        }

        $breaches = $result | Where-Object { $_.EXCEEDS_AVG }

        if (-not $breaches -and -not $SendAlways) {
            Write-Host "No breaches (Window=$WindowHours h, TodayOnly=$($TodayOnly.IsPresent))."
            return
        }

        # Build window label
        $windowText = "Last $WindowHours hour(s)"
        if ($TodayOnly.IsPresent) { $windowText += " (today only)" }
        if ($PruneZombie) { $windowText += " | Zombie pruned" }

        if ($UseHtml) {
            $style = @"
<style>
table { border-collapse: collapse; font-family: Segoe UI, Arial, sans-serif; font-size:12px; }
th,td { border:1px solid #ccc; padding:4px 6px; }
th { background:#f0f0f0; }
tr.exceed { background:#ffe4e4; }
</style>
"@
            $rowsHtml = ($result | Sort-Object JOB_NAME, STEP_ID | ForEach-Object {
                $cls = ""
                if ($_.EXCEEDS_AVG) { $cls = "exceed" }
                $avg = "&nbsp;"
                if ($_.AVG_LAST_RUN_DURATION) { $avg = $_.AVG_LAST_RUN_DURATION }
                $thr = "&nbsp;"
                if ($_.THRESHOLD_SECONDS) { $thr = $_.THRESHOLD_SECONDS }
                "<tr class='$cls'><td>$($_.JOB_NAME)</td><td>$($_.STEP_ID)</td><td>$($_.STEP_NAME)</td><td>$($_.JOB_START_DATETIME)</td><td>$($_.CURRENT_STEP_START_DATE)</td><td>$($_.CURRENT_STEP_EXECUTION_DURATION)</td><td>$avg</td><td>$thr</td><td>$($_.EXCEEDS_AVG)</td></tr>"
            }) -join "`r`n"

            $body = @"
$style
<h3>SQL Agent Job Step Duration Monitor ($SqlInstance)</h3>
<p>Generated: $(Get-Date) (Local)</p>
<p>Window: $windowText | Rows: $($result.Count) | Breaches: $($breaches.Count)</p>
<p>Threshold: current &gt; avg * $ThresholdMultiplier (last $LookbackRuns runs)</p>
<table>
<thead>
<tr>
<th>JOB_NAME</th><th>STEP_ID</th><th>STEP_NAME</th><th>JOB_START_DATETIME</th><th>CURRENT_STEP_START_DATE</th><th>CURRENT_DURATION</th><th>AVG_LAST_RUN</th><th>THRESHOLD_SEC</th><th>BREACH</th>
</tr>
</thead>
<tbody>
$rowsHtml
</tbody>
</table>
"@
            $isHtml = $true
        } else {
            $header = "JOB_NAME|STEP_ID|STEP_NAME|JOB_START|CUR_STEP_START|CURR_DUR|AVG_DUR|THR_SEC|BREACH"
            $lines = $result | Sort-Object JOB_NAME, STEP_ID | ForEach-Object {
                $avg = ""
                if ($_.AVG_LAST_RUN_DURATION) { $avg = $_.AVG_LAST_RUN_DURATION }
                $thr = ""
                if ($_.THRESHOLD_SECONDS) { $thr = $_.THRESHOLD_SECONDS }
                ($_.JOB_NAME) + "|" +
                $_.STEP_ID + "|" +
                $_.STEP_NAME + "|" +
                $_.JOB_START_DATETIME + "|" +
                $_.CURRENT_STEP_START_DATE + "|" +
                $_.CURRENT_STEP_EXECUTION_DURATION + "|" +
                $avg + "|" +
                $thr + "|" +
                $_.EXCEEDS_AVG
            }
            $body = @"
SQL Agent Job Step Duration Monitor ($SqlInstance)
Generated: $(Get-Date) (Local)
Window: $windowText
Rows: $($result.Count) | Breaches: $($breaches.Count)
Threshold: current > avg * $ThresholdMultiplier (last $LookbackRuns runs)

$header
$($lines -join "`r`n")
"@
            $isHtml = $false
        }

        if ($breaches.Count -gt 0) {
            $subject = "$SubjectPrefix BREACH ($($breaches.Count)) on $SqlInstance"
        } else {
            $subject = "$SubjectPrefix OK on $SqlInstance"
        }
        $sendEmail = $true
    }

    if ($sendEmail) {
        try {
            $recipients = Get-RecipientList -List $MailTo
            if ($recipients -and $recipients.Count -gt 0) {
                $params = @{
                    From       = $MailFrom
                    To         = $recipients
                    Subject    = $subject
                    Body       = $body
                    SmtpServer = $SmtpServer
                    Port       = $SmtpPort
                }
                if ($isHtml) { $params['BodyAsHtml'] = $true }
                if ($EnableSsl) { $params['UseSsl'] = $true }
                if ($SmtpCredential) { $params['Credential'] = $SmtpCredential }
                Send-MailMessage @params
                Write-Host "Email sent (rows=$($result.Count), breaches=$($result | Where-Object EXCEEDS_AVG | Measure-Object | Select -ExpandProperty Count))"
            } else {
                Write-Warning "No valid recipients."
            }
        } catch {
            Write-Warning "Failed to send email: $($_.Exception.Message)"
            if ($_.Exception.InnerException) { Write-Warning "Inner: $($_.Exception.InnerException.Message)" }
            Write-Host "Body preview:"
            Write-Host $body
        }
    }

    if ($result) { $result }
}
catch {
    Write-Error $_
    exit 1
}