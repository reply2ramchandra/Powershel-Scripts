﻿Import-Module dbatools -EA SilentlyContinue
$ErrorLogs = Get-DbaWindowsLog -SqlInstance TPAPWSQLGNXTB01 | Where-Object ErrorNumber -eq 35250 
$check=$ErrorLogs | Where-Object Timestamp -gt (Get-date).AddHours(-1)
if($check)
{Send-MailMessage -From 'tpapwsqlgnxtb01@Healthplan.com'  -To 'WHPS-MSSQL-Admins@wipro.com' -Subject 'Test Ignore: Error No: 35250 -GetNext AG Cluster Issue ' -SmtpServer smtprelay.healthplan.com -body "ATTENTION: Please take look at cluster AG Error ASAP"}
else { write-Host " Do nothing " -BackgroundColor Cyan}






