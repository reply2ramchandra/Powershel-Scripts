﻿#$Begin = Get-Date -Date '1/17/2019 08:00:00'
#$End = Get-Date -Date '1/17/2019 17:00:00'
Clear-Content "D:\PSScripts\DailyDBAReportingUsingPowershell\clustererror.txt"
$Begin =(Get-date).AddHours(-1)
$End = (Get-date).AddHours(0)
$chk=Get-EventLog  -ComputerName TPAPWSQLGNXTB01 -LogName System -EntryType Error -InstanceId 1069 -After $Begin -Before $End 
$chk.TimeGenerated  | Out-File -FilePath D:\PSScripts\DailyDBAReportingUsingPowershell\clustererror.txt -append
$chk.Message | Out-File -FilePath D:\PSScripts\DailyDBAReportingUsingPowershell\clustererror.txt -append
$attfile= get-content "D:\PSScripts\DailyDBAReportingUsingPowershell\clustererror.txt" 
if($chk){Send-MailMessage -From 'tpapwsqlgnxtb01@Healthplan.com'  -To 'sathiyaneethi.mani@wipro.com' -Subject 'Attention: Error No: 1069 | GetNext AG Cluster Issue ' -SmtpServer smtprelay.healthplan.com -body "ATTENTION: Please take a look at GetNext Cluster AG Error ASAP." -Attachment $attfile}
#Send-MailMessage -From 'tpapwsqlgnxtb01@Healthplan.com'  -To 'WHPS-MSSQL-Admins@wipro.com' -Subject 'Attention: Error No: 1069 | GetNext AG Cluster Issue ' -SmtpServer smtprelay.healthplan.com -body "ATTENTION: Please take a look at GetNext Cluster AG Error ASAP." -Attachment $attfile}
else { write-Host " Do nothing " -BackgroundColor Cyan}