﻿Import-Module dbatools -EA SilentlyContinue -Force
$collectionSql = 'localhost'
$collectionDb = 'CMS'
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "IF EXISTS( SELECT * from SYS.TABLES where NAME='ProdBackupinfo' ) DROP TABLE ProdBackupinfo;" -TrustServerCertificate 
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] WHERE Status='Y' and Category='PROD' and HASecondary IS NULL AND HostName<>'TPAPWSQLSSRS-03';" -TrustServerCertificate 
foreach($instance in $servers.SqlInstance)
{
$backupinfo= Get-DbaLastBackup -SqlInstance $instance | Where-Object -FilterScript { $_.LastFullBackup.Date -lt (Get-Date).AddDays(-8) } | select SqlInstance, Database, LastFullBackup 
if($backupinfo) {Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'ProdBackupInfo' -InputObject $backupinfo  -AutoCreateTable -KeepNulls} else { }
}
Start-Sleep -Seconds 5
$backupinfoe=Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query " SELECT * from dbo.ProdBackupInfo order by SqlInstance; " -TrustServerCertificate |  Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors
$backupinfoe | ConvertTo-Html -Head $Header  | Out-File -FilePath \\tpapwmssql002\Reports\backupreport.htm 
       

             if($backupinfoe.Count -gt 0)
             {
                  Write-host 'Sending mail as we have backups missed for more than 8 days' -ForegroundColor Green
     
                  $body = Get-Content \\tpapwmssql002\Reports\backupreport.htm
                  Send-MailMessage -From 'DBA_Report@Healthplan.com'  -To 'sathiyaneethi.mani@wipro.com' -Subject 'PROD MSSQL DB Backup Alerts - Not Happended in Last 8 Days' -SmtpServer smtprelay.healthplan.com -BodyAsHtml:$true -Body "$body" 

                  #Invoke-Item \\tpapwmssql002\Reports\backupreport.html
                 
             }
             else
             {
              Write-host 'Not sending mail as we dont have any backups missed for more than 8 days' -ForegroundColor green
             }