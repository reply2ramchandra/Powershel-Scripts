﻿[CmdletBinding()]
param(
    [string]$CollectorInstance = 'tpapwmssql002',
    [string]$CollectorDatabase = 'CMS',
    [string]$InstanceListPath  = 'T:\Test\100924.txt',
    [string]$QueryFile         = 'X:\SQLPostBuild\SQL_Maint_Job_Failed.sql',
    [string]$ReportShare       = '\\tpapwmssql002\Reports',
    [string[]]$ExcludeInstances = @('HPSSQL03'),

    [string]$From     = 'DBA_Report@Healthplan.com',
    [string[]]$To     = @('WHPS-MSSQL-Admins@wipro.com'),
    [string]$Subject  = 'MSSQL Maintenance Job Failure Report',
    [string]$SmtpServer = 'smtprelay.healthplan.com',

    [switch]$WhatIfOnly,              # Collect but do not insert / email
    [switch]$ReportOnly,              # Skip collection, build report only
    [switch]$DropAndRecreateStaging,  # Force staging table recreate
    [string[]]$DebugInstances         # One or more instance names to emit deep diagnostics
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-Info { param([string]$m) Write-Host "[INFO ] $m" -ForegroundColor Cyan }
function Write-Warn { param([string]$m) Write-Warning $m }
function Write-Err  { param([string]$m) Write-Host "[ERROR] $m" -ForegroundColor Red }

if (-not (Test-Path $ReportShare)) { Throw "Report share path not found: $ReportShare" }
$LogFolder = Join-Path $ReportShare 'Logs'
if (-not (Test-Path $LogFolder)) { New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null }
$TranscriptFile = Join-Path $LogFolder ("SqlMaintJobFailed_{0:yyyyMMdd_HHmmss}.log" -f (Get-Date))
try { Start-Transcript -Path $TranscriptFile -ErrorAction Stop | Out-Null } catch {}

# ------------ Helpers ------------
function Remove-HiddenChars {
    param([string]$Text)
    if (-not $Text) { return $Text }
    $Text -replace '[\u200B-\u200D\uFEFF]', '' -replace '[\x00-\x08\x0B\x0C\x0E-\x1F]', ''
}

function Get-Instances {
    param([string]$Path, [string[]]$Exclude)
    if (-not (Test-Path $Path)) { Throw "Instance list file not found: $Path" }
    Get-Content $Path -ErrorAction Stop |
        ForEach-Object {
            $_ = $_.Trim()
            if ($_ -match '^(#|$)') { return }
            if ($_ -match '^(.*?)(\s+#.+)$') { $_ = $Matches[1].Trim() }
            $_ = Remove-HiddenChars -Text $_
            if ($_) { $_ }
        } |
        Sort-Object -Unique |
        Where-Object { $Exclude -notcontains $_ }
}

function Test-DataSourceLength {
    param([string]$Instance)
    if ($Instance.Length -le 128) { return $true }
    Write-Warn ("Skipping {0}: length {1} > 128" -f $Instance, $Instance.Length)
    return $false
}

function Ensure-StagingTable {
    param([string]$Server,[string]$Database,[switch]$ForceDrop)
    $drop = "IF OBJECT_ID('dbo.SQLMaintJobFailed','U') IS NOT NULL DROP TABLE dbo.SQLMaintJobFailed;"
    $ddl  = @"
IF OBJECT_ID('dbo.SQLMaintJobFailed','U') IS NULL
BEGIN
    CREATE TABLE dbo.SQLMaintJobFailed
    (
        Srv       NVARCHAR(128) NULL,
        job_name  NVARCHAR(256) NULL,
        date_time DATETIME      NULL
    );
END
"@
    if ($ForceDrop) { Invoke-Sqlcmd -ServerInstance $Server -Database $Database -Query $drop }
    Invoke-Sqlcmd -ServerInstance $Server -Database $Database -Query $ddl
}

function Insert-Rows {
    param(
        [System.Collections.IEnumerable]$Rows,
        [string]$CollectorInstance,
        [string]$CollectorDatabase
    )
    if (-not $Rows) { return }
    $connString = "Data Source=$CollectorInstance;Initial Catalog=$CollectorDatabase;Integrated Security=SSPI;Application Name=SqlMaintJobFailedCollector"
    $conn = [System.Data.SqlClient.SqlConnection]::new($connString)
    $conn.Open()
    try {
        $cmd = $conn.CreateCommand()
        $cmd.CommandText = "INSERT INTO dbo.SQLMaintJobFailed (Srv, job_name, date_time) VALUES (@Srv,@job_name,@date_time);"
        $null = $cmd.Parameters.Add('@Srv',[System.Data.SqlDbType]::NVarChar,128)
        $null = $cmd.Parameters.Add('@job_name',[System.Data.SqlDbType]::NVarChar,256)
        $null = $cmd.Parameters.Add('@date_time',[System.Data.SqlDbType]::DateTime)
        $i = 0
        foreach ($r in $Rows) {
            $cmd.Parameters['@Srv'].Value       = $r.Srv
            $cmd.Parameters['@job_name'].Value  = $r.job_name
            $cmd.Parameters['@date_time'].Value = $r.date_time
            $cmd.ExecuteNonQuery() | Out-Null
            $i++
        }
        Write-Verbose "Inserted $i rows"
    } finally {
        $conn.Close()
        $conn.Dispose()
    }
}

function Get-ColumnNames {
    param($Result)
    if (-not $Result) { return @() }
    if ($Result -is [System.Data.DataTable]) {
        return @($Result.Columns | ForEach-Object ColumnName)
    }
    # Could be a collection or single object
    $first = $Result | Select-Object -First 1
    if (-not $first) { return @() }
    $names = ($first | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name)
    if (-not $names -or $names.Count -eq 0) {
        return @()  # treat scalar / no properties as no columns
    }
    return @($names)
}

$ReportAggregationQuery = @"
SELECT  Srv,
        job_name,
        MAX(date_time) AS run_date
FROM dbo.SQLMaintJobFailed
GROUP BY Srv, job_name
ORDER BY Srv, job_name;
"@

$TotalRows = 0
$Failures  = [System.Collections.Generic.List[object]]::new()

# -------- Collection Phase --------
if (-not $ReportOnly) {
    if (-not (Test-Path $QueryFile)) { Throw "Query file not found: $QueryFile" }
    Ensure-StagingTable -Server $CollectorInstance -Database $CollectorDatabase -ForceDrop:$DropAndRecreateStaging

    $Instances = Get-Instances -Path $InstanceListPath -Exclude $ExcludeInstances
    if (-not $Instances) {
        Write-Warn "No instances to process."
    } else {
        Write-Info ("Instances: {0}" -f ($Instances -join ', '))
    }

    # Inject SET NOCOUNT ON defensively to avoid extra rowcount-only result sets
    $FileContent = Get-Content -Path $QueryFile -Raw
    if ($FileContent -notmatch 'SET\s+NOCOUNT\s+ON' ) {
        $QueryText = "SET NOCOUNT ON;`r`n$FileContent"
    } else {
        $QueryText = $FileContent
    }

    $idx = 0; $count = $Instances.Count
    foreach ($Instance in $Instances) {
        $idx++
        Write-Progress -Activity "Collecting failures" -Status "$Instance ($idx of $count)" -PercentComplete (($idx / [math]::Max($count,1)) * 100)

        if (-not (Test-DataSourceLength -Instance $Instance)) {
            $Failures.Add([pscustomobject]@{Instance=$Instance; Error='Name too long'; Rows=0})
            continue
        }

        try {
            Write-Info "Querying $Instance"
            $rows = Invoke-Sqlcmd -ServerInstance $Instance -Query $QueryText -ErrorAction Stop

            # Row count detection
            $rowCount = 0
            if ($rows) {
                if ($rows -is [System.Data.DataTable]) { $rowCount = $rows.Rows.Count }
                else { $rowCount = ($rows | Measure-Object).Count }
            }

            if ($DebugInstances -and ($DebugInstances -contains $Instance)) {
                $typeName = if ($rows) { ($rows.GetType().FullName) } else { '<null>' }
                Write-Host "[DEBUG] Instance=$Instance ResultType=$typeName RowCount=$rowCount" -ForegroundColor Yellow
                if ($rows -and -not ($rows -is [System.Data.DataTable])) {
                    $first = $rows | Select-Object -First 1
                    Write-Host "[DEBUG] First object type: $($first.GetType().FullName)" -ForegroundColor Yellow
                    $props = ($first | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name)
                    Write-Host "[DEBUG] First object properties: $($props -join ', ')" -ForegroundColor Yellow
                }
            }

            if ($rowCount -eq 0) {
                Write-Info "No failures for $Instance"
                continue
            }

            $cols = Get-ColumnNames -Result $rows
            if (-not $cols -or $cols.Count -eq 0) {
                Write-Info "Non-tabular or scalar result for $Instance (treating as no failures)"
                continue
            }

            $expected   = @('Srv','job_name','date_time')
            $missing    = $expected | Where-Object { $cols -notcontains $_ }
            $unexpected = $cols     | Where-Object { $expected -notcontains $_ }

            if ($missing.Count -gt 0 -or $unexpected.Count -gt 0) {
                Write-Warn ("Unexpected column set from {0}. Missing: {1}; Extra: {2} - skipping" -f $Instance, ($missing -join '|'), ($unexpected -join '|'))
                continue
            }

            $TotalRows += $rowCount

            if ($WhatIfOnly) {
                Write-Info "WhatIfOnly: collected $rowCount rows (not inserted)"
                continue
            }

            Insert-Rows -Rows $rows -CollectorInstance $CollectorInstance -CollectorDatabase $CollectorDatabase
            Write-Info "Inserted $rowCount rows for $Instance"
        }
        catch {
            $msg = $_.Exception.Message
            Write-Err "Failed $Instance : $msg"
            $Failures.Add([pscustomobject]@{Instance=$Instance; Error=$msg; Rows=0})
            continue
        }
    }

    Write-Progress -Activity "Collecting failures" -Completed
}

Write-Info "Total rows collected: $TotalRows"

# ---- Failures Export ----
if ($Failures.Count -gt 0) {
    $failFile = Join-Path $LogFolder ("Failures_{0:yyyyMMdd_HHmmss}.csv" -f (Get-Date))
    $Failures | Export-Csv -Path $failFile -NoTypeInformation -Encoding UTF8
    Write-Warn "Failures logged: $failFile"
}

if ($WhatIfOnly) {
    Write-Info "WhatIfOnly specified: skipping report & email."
    try { Stop-Transcript | Out-Null } catch {}
    return
}

# ---- Report ----
Write-Info "Building report..."
$ReportAggregationQuery = @"
SELECT  Srv,
        job_name,
        MAX(date_time) AS run_date
FROM dbo.SQLMaintJobFailed
GROUP BY Srv, job_name
ORDER BY Srv, job_name;
"@
$summary = Invoke-Sqlcmd -ServerInstance $CollectorInstance -Database $CollectorDatabase -Query $ReportAggregationQuery -ErrorAction Stop
$RowCount = if ($summary) { $summary.Count } else { 0 }
Write-Info "Distinct failures to report: $RowCount"

$RunStamp   = Get-Date -Format yyyyMMdd_HHmmss
$ReportFile = Join-Path $ReportShare ("sqljobfailed_{0}.html" -f $RunStamp)

$Css = @"
<style>
body { font-family: Verdana, Arial, sans-serif; font-size: 12px; }
table { border-collapse: collapse; width: 100%; }
th, td { border: 1px solid #444; padding: 6px 8px; text-align: left; }
th { background-color: #D6EEEE; }
tr:nth-child(even) { background-color: rgba(150,212,212,0.35); }
caption { font-weight: bold; font-size: 14px; margin: 8px 0; }
</style>
"@
$PreContent = @"
<h3 style='color:#004080;'>SQL Server Maintenance Job Failures (Recent)</h3>
<p>Failed maintenance jobs detected in the recent window.</p>
"@
$PostContent = @"
<p style='color:green;'>Generated on $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz')</p>
"@

$summary |
  Sort-Object Srv, job_name |
  ConvertTo-Html -Property Srv, job_name, run_date -Head $Css -Title "SQL Maintenance Job Failure Report" -PreContent $PreContent -PostContent $PostContent |
  Out-File -FilePath $ReportFile -Encoding UTF8 -Force

Write-Info "Report written: $ReportFile"

if ($RowCount -gt 0) {
    Write-Info "Sending email..."
    try {
        $body = Get-Content -Path $ReportFile -Raw
        Send-MailMessage -From $From -To $To -Subject $Subject -SmtpServer $SmtpServer -Body $body -BodyAsHtml
    } catch {
        Write-Err "Email failed: $($_.Exception.Message)"
    }
} else {
    Write-Info "No failures found; email suppressed."
}

Write-Info "Completed $(Get-Date -Format o)"
try { Stop-Transcript | Out-Null } catch {}