﻿clear
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$serviceflag = $false
$serverflag = $false
Import-Module dbatools -EA SilentlyContinue
Import-Module SQLServer -EA SilentlyContinue
Set-DbatoolsInsecureConnection -SessionOnly
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "DROP TABLE IF EXISTS [CMS].[dbo].[AllSrvDbaService];" -TrustServerCertificate
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "DELETE FROM [CMS].[dbo].[AllDBSrvStatus];" -TrustServerCertificate
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT DISTINCT trim([HostName]) as HostName FROM [CMS].[dbo].[DBServer] Where [Status] in ('Y','R') and HostName Not in('TPAPWSQLSSRS-03','localhost','PCIPWSQL001') "  -TrustServerCertificate 
$total=$servers.count
# Actual Script to collect services status from all Active servers.
foreach($SQL_server in $servers.HostName)
{
	
$AllSrvDbaService =  Get-DbaService -ComputerName $SQL_server | Where-Object {$_.ServiceType -eq 'Engine' -OR $_.ServiceType -eq 'Agent' }  | Select @{n='DateKey';e={(Get-Date).GetDateTimeFormats()[46]}},PSComputerName,ComputerName,DisplayName,ServiceType,ServiceName,StartMode,State,StartName
IF($AllSrvDbaService -ne $null){
Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'AllSrvDbaService' -InputObject $AllSrvDbaService  -AutoCreateTable -KeepNulls}
ELSE { Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "INSERT INTO  [CMS].[dbo].[AllDBSrvStatus] (HostName,Comments) VALUES('$SQL_server','Unreachable')"  -TrustServerCertificate }

}

 $css = @"
<style>
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid black; padding: 8px; text-align: left; }
    th { background-color: #D6EEEE; }
    tr:nth-child(even) {
  background-color: rgba(150, 212, 212, 0.4);}
</style>
"@

$runDateTime = (Get-Date -Format yyyyddMM) 
 $preContent = @"
<h3><font face=verdana color=blue>ALL DB Server DB Service Report</font></h3>
<p>This report contains the list of Servers where DB Service(s) is\are not running nor Server is unreachable.</p>
"@
$preContent1 = @"
<h3><font face=verdana color=blue>ALL DB Server DB Service Report</font></h3>
<p>This report contains the list of Servers DB Engine and Agent Service Status.</p>
"@

$postContent = @"
<p><font face=verdana color=green>Generated on $(Get-Date). Please review and take action as Required.</font></p>
"@
$totalins=Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query "SELECT DISTINCT Count([ComputerName]) Total FROM  [CMS].[dbo].[AllSrvDbaService] WHERE [ServiceType]='Engine';" -TrustServerCertificate |  Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors
$tco=$totalins.Total
$Dbservicestat = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "
 SELECT DISTINCT [DateKey],[ComputerName],[DisplayName],[ServiceType],[ServiceName],[StartMode],[State]
 FROM  [CMS].[dbo].[AllSrvDbaService];
" -TrustServerCertificate | Select * -ExcludeProperty ItemArray,Table,RowError,RowState,HasErrors

# Use .html consistently
$statFile      = "\\tpapwmssql002\Reports\AllDbservicestat$runDateTime.html"
$statFileColor = "\\tpapwmssql002\Reports\AllDbservicestatC$runDateTime.html"
$downFile      = "\\tpapwmssql002\Reports\AllDbservicereport$runDateTime.html"

$Dbservicestat |
  ConvertTo-Html -Property DateKey,ComputerName,DisplayName,ServiceType,ServiceName,StartMode,State `
    -Head $css -Title "ALL DB Server DB Service Report" `
    -PreContent $preContent1 -PostContent  $postContent |
  Out-File -FilePath $statFile -Encoding UTF8

$dbserviceinfo = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "
 SELECT [DateKey],[ComputerName],[DisplayName],[ServiceType],[ServiceName],[StartMode],[State]
 FROM  [CMS].[dbo].[AllSrvDbaService]
 WHERE State <> 'Running';
" -TrustServerCertificate | Select * -ExcludeProperty ItemArray,Table,RowError,RowState,HasErrors

if ($dbserviceinfo.Count -gt 0) {
    $dbserviceinfo |
      ConvertTo-Html -Property DateKey,ComputerName,DisplayName,ServiceType,ServiceName,StartMode,State `
        -Head $css -Title "ALL DB Server DB Service Down Report" `
        -PreContent $preContent -PostContent $postContent |
      Out-File -FilePath $downFile -Encoding UTF8
    $serviceflag = $true
}

$dbsrvinfo = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "
 SELECT [HostName],[Comments] FROM [CMS].[dbo].[AllDBSrvStatus];
" -TrustServerCertificate | Select * -ExcludeProperty ItemArray,Table,RowError,RowState,HasErrors

if ($dbsrvinfo.Count -gt 0) {
    $dbsrvinfo |
      ConvertTo-Html -Property HostName,Comments -Head $css -Title "DB Server Unreachable Report" `
        -PreContent $preContent -PostContent $postContent |
      Out-File -FilePath $downFile -Append -Encoding UTF8
    $serverflag = $true
}

# Only now (after all base tables built) color the main table BEFORE adding totals
if ($serviceflag) {
    . "D:\PSScripts\DailyDBAReporting\Set-CellColor.ps1"
    Get-Content $statFile -Encoding UTF8 |
      Set-CellColor State Yellow -Filter "State -ne 'Running'" |
      Out-File $statFileColor -Encoding UTF8
} else {
    # No non-running services; still create a colored copy for consistency
    Copy-Item $statFile $statFileColor -Force
}

# Append totals AFTER coloring so Set-CellColor does not see an extra table
$totalins = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "
 SELECT Count([ComputerName]) AS Total
 FROM [CMS].[dbo].[AllSrvDbaService]
 WHERE [ServiceType] = 'Engine';
" -TrustServerCertificate | Select -ExpandProperty Total

$totalServers = $servers.Count
"<table><tr><th>Total_Server_To_Check</th><td bgcolor='#F0FF33'>$totalServers</td><th>Total_Instance_Checked</th><td bgcolor='#F0FF33'>$totalins</td></tr></table>" |
  Out-File -FilePath $statFileColor -Append -Encoding UTF8  ### appended to colored file

if ($dbserviceinfo.Count -gt 0 -or $dbsrvinfo.Count -gt 0) {
    Write-Host "Sending mail of All SQL Servers Service Info"
    $bodyN     = if (Test-Path $downFile) { Get-Content $downFile -Raw -Encoding UTF8 } else { "<p>No down/unreachable servers section generated.</p>" }
    $attachfil = $statFileColor
    Send-MailMessage -From 'DBA_Report@Healthplan.com' `
                     -To 'WHPS-MSSQL-Admins@wipro.com' `
                     -Subject 'Alert: SQL Server Service Down Report' `
                     -SmtpServer smtprelay.healthplan.com `
                     -BodyAsHtml:$true -Body $bodyN -Attachments $attachfil
} else {
    Write-Host "Sending mail: all services running"
    $attachfile = $statFileColor
    Send-MailMessage -From 'DBA_Report@Healthplan.com' `
                     -To 'WHPS-MSSQL-Admins@wipro.com' `
                     -Subject 'ALL DB Server Service Report' `
                     -SmtpServer smtprelay.healthplan.com `
                     -Attachments $attachfile `
                     -BodyAsHtml:$true `
                     -Body "<h4><font face=verdana color=green>All SQL Server DB Services are up and running. Refer to the attached.</font></h4>"
}