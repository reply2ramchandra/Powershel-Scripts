﻿clear
Get-date
#HPSSQL03 excluded as its HPSSQL03
#Clear-Content \\tpapwmssql002\Reports\backupreport.htm
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -EA SilentlyContinue 
Import-Module dbatools -EA SilentlyContinue
Set-DbatoolsInsecureConnection -SessionOnly
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "DROP TABLE IF EXISTS [CMS].[dbo].BackupInfo;" -TrustServerCertificate 
$dbscript= Get-ChildItem X:\SQLPostBuild\DBBackup
$dbscript=$dbscript.FullName
$instances=get-content "T:\Test\100924.txt" # check if all sql servers are active
foreach($instance in $instances)
{
$BackupInfo=$instance | Invoke-DbaQuery -File $dbscript
if($BackupInfo){Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'BackupInfo' -InputObject $BackupInfo  -AutoCreateTable -KeepNulls}
}
Get-date
Start-Sleep -Seconds 2

 $css = @"
<style>
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid black; padding: 8px; text-align: left; }
    th { background-color: #D6EEEE; }
    tr:nth-child(even) {
  background-color: rgba(150, 212, 212, 0.4);}
</style>
"@

$runDateTime = (Get-Date -Format yyyyddMM) 
 $preContent = @"
<h3><font face=verdana color=blue>PROD MSSQL DB Backup Alert - NO FULL Backup in the Last 8 Day</font></h3>
<p>This report contains the list of Server's where DB FULL Backup was not successful.</p>
"@

$postContent = @"
<p><font face=verdana color=green>Generated on $(Get-Date). Please review and take action as Required.</font></p>
"@

$htmlParams = @{
  Title = "PROD MSSQL DB Backup Report"
  PreContent = "<P> <font color= 'Blue'> PROD MSSQL DB Backup Alert - NO FULL Backup in the Last 8 Days</P><br><P> <font color= 'Blue'> Generated on $runDateTime.</P></br>"
    PostContent = "<font color= 'Green'><br><br>Please Review the Report and Take Action as Required."
  }
$backupinfoe=Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query " SELECT [ServerName],[DatabaseName],[Last_Full],[AG] FROM [CMS].[dbo].[BackupInfo] where [AG]<>1 order by [ServerName]; " -TrustServerCertificate |  Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors
$backupinfoe | ConvertTo-Html -Property ServerName, DatabaseName, Last_Full,AG -Head $css -Title "PROD Server Missing Backup Report" -PreContent $preContent  -PostContent  $postContent  | Out-File -FilePath \\tpapwmssql002\Reports\backupreport$runDateTime.htm 
       

             if($backupinfoe.Count -gt 0)
             {
                  Write-host 'Sending mail as we have backups missed for more than 8 days' -ForegroundColor Green
     
                  $body = Get-Content \\tpapwmssql002\Reports\backupreport$runDateTime.htm
                  Send-MailMessage -From 'DBA_Report@Healthplan.com'  -To 'WHPS-MSSQL-Admins@wipro.com' -Subject 'PROD MSSQL DB Backup Alert - NO FULL Backup in the Last 8 Days' -SmtpServer smtprelay.healthplan.com -BodyAsHtml:$true -Body "$body" 

                  #Invoke-Item \\tpapwmssql002\Reports\backupreport.html
                 
             }
             else
             {
              Write-host 'Not sending mail as we dont have any backups missed for more than 8 days' -ForegroundColor Yellow
             }
get-date
