﻿# Module loading (SQL Agent may not load user scope modules)
#Install-Module dbatools -Scope AllUsers -Force
Import-Module dbatools -ErrorAction Stop
Import-Module SQLServer -ErrorAction Stop
Set-DbatoolsInsecureConnection -SessionOnly
#Set-DbatoolsConfig -Name Import.SqlpsCheck -Value $false -PassThru |   Register-DbatoolsConfig
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] where Status IN ('Y','R') and  HostName NOT IN('TPAPWSQLSSRS-03','TPATWSQLSSRS02');" -TrustServerCertificate
foreach($SQL in $servers.SqlInstance)
{
$patch = Invoke-DbaQuery -SqlInstance $SQL -Database master -Query "SELECT CONVERT(varchar(9), SERVERPROPERTY('productversion')) as BuildNumber,CONVERT(varchar(9), SERVERPROPERTY('productlevel')) as SPLevel, CONVERT(varchar(9), SERVERPROPERTY('ProductUpdateLevel')) as CULevel" 
$build=$patch.BuildNumber
$sp=$patch.SPLevel
$cu=$patch.CULevel
Invoke-DbaQuery -SqlInstance $collectionSql -Database $collectionDb -Query "Update dbo.DBServer SET BuildNumber='$build',SPLevel='$sp', CULevel='$cu' where SqlInstance='$SQL'" 
}