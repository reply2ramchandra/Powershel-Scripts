﻿# Requires: PowerShell 5+ (tested) / dbatools
param(
    [string]$ModuleName      = 'dbatools',
    [string]$CollectionSql   = 'tpapwmssql002',
    [string]$CollectionDb    = 'CMS',
    [switch]$SkipModuleMgmt,          # Use if module lifecycle handled externally
    [switch]$WhatIfUpdates            # Dry-run update phase
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Import-Module -Name dbatools -Force -ErrorAction Stop | Out-Null
Set-DbatoolsInsecureConnection -SessionOnly

# Get target column lengths (defensive: tolerate missing table/cols)
$columnNames = 'BuildNumber','SPLevel','CULevel'
$lengths = @{}
try {
    $colMeta = Invoke-DbaQuery -SqlInstance $CollectionSql -Database $CollectionDb -Query @"
SELECT c.name,
       CASE WHEN t.name IN ('nchar','nvarchar') THEN c.max_length / 2 ELSE c.max_length END AS MaxChars
FROM sys.columns c
JOIN sys.types t ON c.user_type_id = t.user_type_id
WHERE c.object_id = OBJECT_ID('dbo.DBServer')
  AND c.name IN ('$(($columnNames -join "','"))');
"@ -EnableException
    foreach ($row in $colMeta) { $lengths[$row.name] = [int]$row.MaxChars }
} catch {
    Write-Warning "Could not read column metadata: $($_.Exception.Message)"
}

# Retrieve candidate instances
$instances = @()
try {
    $instances = Invoke-DbaQuery -SqlInstance $CollectionSql -Database $CollectionDb -Query @"
SELECT DISTINCT LTRIM(RTRIM(SqlInstance)) AS SqlInstance
FROM dbo.DBServer
WHERE Status IN ('Y','R')
  AND HostName NOT IN ('TPAPWSQLSSRS-03','TPATWSQLSSRS02')
  AND NULLIF(LTRIM(RTRIM(SqlInstance)),'') IS NOT NULL;
"@ -EnableException | Select-Object -ExpandProperty SqlInstance
} catch {
    Write-Error "Failed to pull instance list: $($_.Exception.Message)"
    return
}

if (-not $instances) {
    Write-Warning "No instances returned. Exiting."
    return
}

# Collect build information (use SERVERPROPERTY; ProductUpdateLevel may be null on older versions)
$results = foreach ($inst in $instances) {
    try {
        $row = Invoke-DbaQuery -SqlInstance $inst -Database master -Query @"
SELECT
  CONVERT(varchar(50), SERVERPROPERTY('ProductVersion'))     AS BuildNumber,
  CONVERT(varchar(50), SERVERPROPERTY('ProductLevel'))       AS SPLevel,
  CONVERT(varchar(50), SERVERPROPERTY('ProductUpdateLevel')) AS CULevel
"@ -EnableException

        if ($row) {
            [pscustomobject]@{
                SqlInstance = $inst
                BuildNumber = ([string]$row.BuildNumber).Trim()
                SPLevel     = ([string]$row.SPLevel).Trim()
                CULevel     = ([string]$row.CULevel).Trim()
            }
        }
    } catch {
        Write-Warning "Version query failed for [$inst]: $($_.Exception.Message)"
    }
}

if (-not $results) {
    Write-Warning "No version data collected. Exiting."
    return
}

# Length validation
$toUpdate = New-Object System.Collections.Generic.List[object]
$skipped  = New-Object System.Collections.Generic.List[object]
foreach ($r in $results) {
    $violations = @()
    foreach ($col in $columnNames) {
        if ($lengths.ContainsKey($col)) {
            # Cast to string so $null becomes ''
            $val = [string]($r.$col)
            if ($val.Length -gt $lengths[$col]) {
                $violations += "$col ($($val.Length)>$($lengths[$col]))"
            }
        }
    }

    if ($violations.Count) {
        Write-Warning "Skipping $($r.SqlInstance) length violations: $($violations -join ', ')"
        $skipped.Add($r) | Out-Null
    }
    else {
        $toUpdate.Add($r) | Out-Null
    }
}

if (-not $toUpdate.Count) {
    Write-Warning "All rows skipped due to validation. Exiting."
    return
}

# Perform idempotent updates (only when something changes)
$updated = 0
foreach ($r in $toUpdate) {
    $params = @{
        Build    = $r.BuildNumber
        SP       = $r.SPLevel
        CU       = $r.CULevel
        Instance = $r.SqlInstance
    }

    $updateSql = @"
SET NOCOUNT ON;
UPDATE dbo.DBServer
   SET BuildNumber = @Build,
       SPLevel     = @SP,
       CULevel     = @CU
 WHERE SqlInstance = @Instance
   AND (ISNULL(BuildNumber,'') <> @Build
     OR ISNULL(SPLevel,'')     <> @SP
     OR ISNULL(CULevel,'')     <> @CU);
SELECT @@ROWCOUNT AS RowsAffected;
"@

    if ($WhatIfUpdates) {
        Write-Host "[WhatIf] Would update $($r.SqlInstance) -> Build=$($r.BuildNumber) SP=$($r.SPLevel) CU=$($r.CULevel)"
        continue
    }

    try {
        $result = Invoke-DbaQuery -SqlInstance $CollectionSql -Database $CollectionDb -Query $updateSql -SqlParameters $params -EnableException
        $rowsAffected = 0
        if ($result) {
            # Invoke-DbaQuery returns an array of PSObjects for the SELECT
            $rowsAffected = [int]($result | Select-Object -First 1 -ExpandProperty RowsAffected)
        }
        if ($rowsAffected -gt 0) {
            $updated++
        }
    } catch {
        Write-Warning "Update failed for [$($r.SqlInstance)]: $($_.Exception.Message)"
    }
}

Write-Host "Updated $updated instance(s). Skipped validation: $($skipped.Count). No-change rows: $(($toUpdate.Count - $updated))."

# Return structured summary (useful if dot-sourced)
[pscustomobject]@{
    Attempted = $toUpdate.Count
    Updated   = $updated
    Skipped   = $skipped.Count
    Timestamp = (Get-Date)
}