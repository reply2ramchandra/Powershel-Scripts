﻿clear
Import-Module dbatools -ErrorAction SilentlyContinue
$tableinfo=Get-Content "T:\Test\table2.txt"
foreach($table in $tableinfo){
Copy-DbaDbTableData -SqlInstance TPAPWSQLDL001 -Destination TPAPWSQLDL005 -Database HPS_STAGE -DestinationDatabase HPS_FDP -Table $table -KeepIdentity -AutoCreateTable}

###Script out view

$viewinfo=Get-Content "T:\Test\view.txt"
foreach($view in $viewinfo){
Get-DbaDbView -SqlInstance TPAPWDWSQL004 -Database HPS_ODS -View $view | Export-DbaScript  -FilePath T:\test\export004_vw.sql -Append}

##script out SP's

$uspinfo=Get-Content "T:\Test\usp.txt"
foreach($usp in $uspinfo){
Get-DbaDbStoredProcedure -SqlInstance TPAPWDWSQL004 -Database HPS_ODS -Name $usp | Export-DbaScript  -FilePath T:\test\export004_sp.sql -Append }

###script out job
$jobinfo=Get-Content "T:\Test\job.txt"
foreach($job in $jobinfo){
Get-DbaAgentJob -SqlInstance TPAPWDWSQL004 -job $job | Export-DbaScript  -FilePath T:\test\export004_job.sql -Append}

##Other
clear
Import-Module dbatools -ErrorAction SilentlyContinue
$tableinfo=Get-Content "T:\Test\table3.txt"
foreach($table in $tableinfo){
Copy-DbaDbTableData -SqlInstance TPAPWDWSQLA05 -Destination TPAPWSQLDLR005 -Database HPS_ODS -DestinationDatabase HPS_FDP -Table $table -KeepIdentity -AutoCreateTable}
#Copy-DbaDbTableData -SqlInstance TPAPWDWSQLA05 -Destination TPAPWSQLDLR005 -Database HPS_ODS -DestinationDatabase HPS_FDP -Table $table -KeepIdentity -AutoCreateTable


$viewinfo=Get-Content "T:\Test\view1.txt"
foreach($view in $viewinfo){
Get-DbaDbView -SqlInstance TPAPWDWSQLA05 -Database HPS_ODS -View $view | Export-DbaScript  -FilePath T:\test\exporta05_vw.sql -Append}
