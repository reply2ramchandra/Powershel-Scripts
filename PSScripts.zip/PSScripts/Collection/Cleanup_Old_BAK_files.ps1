﻿<#
TPAPWPEDSQL001
TPAPWNICESQL001
TPAPWSP16SQL001
TPAPWDWSQLB05
TPAPWSQLARCH01
PRODWMSSPGN2-01
TPAPWSQLHHA01
TPAPWSQLHHB01
TPAPWSQLGNXTA01
TPAPWSQLDL001
TPAPWSQLGNXTB01
TPAPWDWSQLA05
TPAPWDWSQL004
#>
<#
Get-ChildItem "\\tpadd9300.healthplan.com\SQLBackupsprod\TPAPWSQLHH01`$HH_AG" -Recurse -Force -Filter *.BAK -ErrorAction SilentlyContinue | Where-Object { ($_.CreationTime -lt $(Get-Date).AddDays( - 32))} | Remove-Item -force -Recurse -ErrorAction SilentlyContinue -Verbose
Get-ChildItem "\\tpadd9300.healthplan.com\SQLBackupsprod\TPAPWSQLHH01`$HH_AG" -Recurse -Force -Filter *.trn -ErrorAction SilentlyContinue | Where-Object { ($_.CreationTime -lt $(Get-Date).AddDays( - 32))} | Remove-Item -force -Recurse -ErrorAction SilentlyContinue -Verbose

Get-ChildItem "\\tpadd9300.healthplan.com\SQLBackupsprod\TPAPWSQLGNXT01`$GN_AG" -Recurse -Force -Filter *.BAK -ErrorAction SilentlyContinue | Where-Object { ($_.CreationTime -lt $(Get-Date).AddDays( - 32))} | Remove-Item -force -Recurse -ErrorAction SilentlyContinue -Verbose
Get-ChildItem "\\tpadd9300.healthplan.com\SQLBackupsprod\TPAPWSQLGNXT01`$GN_AG" -Recurse -Force -Filter *.trn -ErrorAction SilentlyContinue | Where-Object { ($_.CreationTime -lt $(Get-Date).AddDays( - 32))} | Remove-Item -force -Recurse -ErrorAction SilentlyContinue -Verbose

Get-ChildItem "\\tpadd9300.healthplan.com\SQLBackupsprod\TPATWSQLHH001`$AG_HH" -Recurse -Force -Filter *.BAK -ErrorAction SilentlyContinue | Where-Object { ($_.CreationTime -lt $(Get-Date).AddDays( - 32))} | Remove-Item -force -Recurse -ErrorAction SilentlyContinue -Verbose
Get-ChildItem "\\tpadd9300.healthplan.com\SQLBackupsprod\TPAPWSQLHH001`$AG_HH" -Recurse -Force -Filter *.trn -ErrorAction SilentlyContinue | Where-Object { ($_.CreationTime -lt $(Get-Date).AddDays( - 32))} | Remove-Item -force -Recurse -ErrorAction SilentlyContinue -Verbose

#>
#\\hps-tpa-vast.hps.hph.ad\SqlProd
Get-ChildItem "P:\TPAPWNICESQL001" -Recurse -Force -Filter *.BAK -ErrorAction SilentlyContinue | Where-Object { ($_.CreationTime -lt $(Get-Date).AddDays( - 32))} | Remove-Item -force -Recurse -ErrorAction SilentlyContinue -Verbose
Get-ChildItem "P:\TPAPWNICESQL001" -Recurse -Force -Filter *.trn -ErrorAction SilentlyContinue | Where-Object { ($_.CreationTime -lt $(Get-Date).AddDays( - 32))} | Remove-Item -force -Recurse -ErrorAction SilentlyContinue -Verbose

