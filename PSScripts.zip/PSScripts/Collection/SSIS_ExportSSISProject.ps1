﻿# RDP to Server and run as PS Admin
$Instance = "TPAPWSQLDL001"
$OutputDir = "D:\SSIS"

if (-not (Test-Path $OutputDir)) {
    Write-Output "Error - invalid path specified in OutputDir"
    return
}

$testQuery = "SELECT COUNT(*) AS Result FROM sys.databases WHERE name = 'SSISDB'"
try {
    $result = (Invoke-Sqlcmd -ServerInstance $Instance -Query $testQuery -ConnectionTimeout 5 -QueryTimeout 5 -ErrorAction Stop).Result
    if ($result -eq 0) {
        Write-Output "Error - no SSISDB present on instance."
        return
    }
} catch {
    Write-Output "Error - failure connecting to instance"
    return
}


[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Management.IntegrationServices") | Out-Null
 
$connString = "Data Source=$Instance;Initial Catalog=master;Integrated Security=SSPI;"
$sqlConn = New-Object System.Data.SqlClient.SqlConnection $connString
$ssis = New-Object Microsoft.SqlServer.Management.IntegrationServices.IntegrationServices $sqlConn

$catalog = $ssis.Catalogs["SSISDB"]

foreach ($folder in $catalog.Folders) {
    $folderPath = Join-Path $OutputDir $folder.Name
    if (-not (Test-Path $folderPath)) {
        New-Item -ItemType Directory -Path $folderPath | Out-Null
    }

    $projects = $folder.Projects
    if ($projects.Count -gt 0) {
        foreach ($project in $projects) {
            $projectPath = Join-Path $folderPath ("{0}.ispac" -f $project.Name)
            try {
                Write-Host "Exporting $($project.Name) to $projectPath ..."
                [System.IO.File]::WriteAllBytes($projectPath, $project.GetProjectBytes())
            } catch {
                Write-Warning "Failed to export $($project.Name): $_"
            }
        }
    } else {
        Write-Host "No projects found in folder $($folder.Name)."
    }
}

Write-Host "Export completed."