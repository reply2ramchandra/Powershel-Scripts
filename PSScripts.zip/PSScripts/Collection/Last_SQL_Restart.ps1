﻿clear
Import-Module dbatools -EA SilentlyContinue
Get-DbaUptime -SqlInstance TPATWSQLMHCB01 | select ComputerName,SinceSqlStart,SinceWindowsBoot


#sqlinstance to read
clear
Import-Module dbatools -EA SilentlyContinue
#Get-Content "T:\Test\522.txt" | Get-DbaUptime 