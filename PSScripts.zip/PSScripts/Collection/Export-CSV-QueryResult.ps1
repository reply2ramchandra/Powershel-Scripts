﻿clear
$collectionSql = 'tpapwsqlhh005'
$collectionDb = 'MHC_Provider'
Import-Module dbatools -EA SilentlyContinue
Import-Module SQLServer -EA SilentlyContinue
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "select * from [MHC_Provider].[pnf].[ProviderNetworkFile];" -TrustServerCertificate | Export-Csv T:\Test\NetworkProviderFile.csv