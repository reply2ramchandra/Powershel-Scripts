﻿clear-host
$server='TPAPWSQLSTEL003'
 Invoke-Command -ComputerName $server -ScriptBlock {
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = "Low")]
    param (
       
        [parameter(Mandatory = $false)]
        [bool]$InstallAzureDataStudio = $false,

        [parameter(Mandatory = $false)]
        [bool]$WriteLog = $false,

        [parameter(Mandatory = $false)]
        [bool]$RemoveDownload = $true             
    )



    $outFile = "C:\patch\SSMS-Setup-ENU-20.2.exe"

    $argList = @()
    $argList += "/install /quiet /norestart"
    $filter = 'Microsoft SQL Server Management Studio'
    $uninstall32 = Get-ChildItem "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall" | ForEach-Object { Get-ItemProperty $_.PSPath } | Where-Object { $_ -match $filter } | Select-Object DisplayVersion
    $uninstall64 = Get-ChildItem "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" | ForEach-Object { Get-ItemProperty $_.PSPath } | Where-Object { $_ -match $filter } | Select-Object DisplayVersion

    if ($uninstall64) {
        $isInstalled = $true
        $installedVersion = $uninstall64.DisplayVersion
    }
    if ($uninstall32) {
        $isInstalled = $true
        $installedVersion = $uninstall32.DisplayVersion
    }

    if ($isInstalled -eq $true) {
        Write-Output "Version $installedVersion was detected on your system!"
            }

    

    
    if ($InstallAzureDataStudio -eq $false) {
        $argList += "DoNotInstallAzureDataStudio=1"
    }

    if ($WriteLog -eq $true) {
        $logFile = "$temp\SSMS_$(Get-Date -Format `"yyyyMMddHHmm`").txt"
        $argList += "/log $logFile"
        Write-Output "InstallationLog: $logFile"
    }

    # Start the install
    if ($PSCmdlet.ShouldProcess($env:COMPUTERNAME, "Installing latest SSMS from $outFile")) {
        # Closing running SSMS processes
        if (Get-Process 'Ssms' -ErrorAction SilentlyContinue) {
            Stop-Process -Name Ssms -Force -ErrorAction SilentlyContinue
        }

        # Install silently
        if (Test-Path $outFile) {
            if ($outFile.EndsWith("exe")) {
                Write-Output "Performing silent install..."
                $process = Start-Process -FilePath $outFile -ArgumentList $argList -Wait -Verb RunAs -PassThru

                if ($process.ExitCode -ne 0) {
                    Write-Output "$_ exited with status code $($process.ExitCode). Check the error code here: https://docs.microsoft.com/en-us/windows/win32/msi/error-codes"
                }
                else {
                    Write-Output "Instalation was sucessfull!"
                }
            }
        }
        else {
            Write-Output "$outFile does not exist. Probably the copy failed."
        }
    }

    # Cleanup
    if ($RemoveDownload -eq $true) {
        if ($PSCmdlet.ShouldProcess($env:COMPUTERNAME, "Removing the installation file $outFile")) {
            Remove-Item $outFile -Force -ErrorAction SilentlyContinue
        }
    }
}