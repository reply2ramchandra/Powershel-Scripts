﻿clear
Import-Module dbatools -EA SilentlyContinue
$collectionSql='tpapwmssql002'
$collectionDb='cms'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [HostName] FROM [CMS].[dbo].[DBServer] WHERE Status IN('Y','R') and HostName<>'PCIPWSQL001';" -TrustServerCertificate
foreach($hostname in $servers.HostName)
{
$OsVersion=Get-DbaOperatingSystem -ComputerName $hostname | Select OSVersion
$OsVersion=$OsVersion.OSVersion
Invoke-DbaQuery -SqlInstance TPAPWMSSQL002 -Database CMS -Query "Update dbo.DBServer SET OSVersion='$OsVersion' where HostName='$hostname'" }