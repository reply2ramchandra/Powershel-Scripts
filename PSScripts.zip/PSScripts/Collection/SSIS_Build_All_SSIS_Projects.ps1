﻿#SSIS_Build_All_SSIS_Projects

<#

To work in Visual Studio, you must:
1.	Create a new SSIS project in Visual Studio.
2.	Add the extracted .dtsx files to the new project manually.
3.	Recreate any project-level parameters, connection managers, and configurations as needed.

#>
# Set the path where your SSIS projects are located
$ssisPath = "C:\Path\To\Your\SSIS\Projects"

# Set the path to MSBuild.exe (adjust for your Visual Studio version)
$msbuildPath = "C:\Program Files\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\MSBuild.exe"

# Find all .dtproj files (SSIS project files) in the directory and subdirectories
$dtprojFiles = Get-ChildItem -Path $ssisPath -Recurse -Filter *.dtproj

foreach ($dtproj in $dtprojFiles) {
    Write-Host "Building project: $($dtproj.FullName)"
    & $msbuildPath $dtproj.FullName /p:Configuration=Development /t:Build
}