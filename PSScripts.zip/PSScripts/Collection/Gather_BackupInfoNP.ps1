﻿clear
Get-date
Clear-Content \\tpapwmssql002\Reports\backupreport.htm
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -EA SilentlyContinue 
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "IF EXISTS( SELECT * from SYS.TABLES where NAME='BackupInfoNP' ) DROP TABLE BackupInfoNP;" -TrustServerCertificate 
$dbscript= Get-ChildItem X:\SQLPostBuild\DBBackup
$dbscript=$dbscript.FullName
$instances=get-content "T:\Test\nonprod.txt"
foreach($instance in $instances)
{
$BackupInfoNP=$instance | Invoke-DbaQuery -File $dbscript
if($BackupInfoNP){Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'BackupInfoNP' -InputObject $BackupInfoNP  -AutoCreateTable -KeepNulls}
}