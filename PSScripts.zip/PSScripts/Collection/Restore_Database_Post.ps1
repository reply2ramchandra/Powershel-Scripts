﻿Import-Module dbatools 
Get-DbaLogin -SqlInstance sql2016 | Out-GridView -Passthru | Copy-DbaLogin -Destination sql2017
Copy-DbaLinkedServer -Source sqlserver2014a -Destination sqlcluster
Copy-DbaAgentOperator -Source sqlserver2014a -Destination sqlcluster

Get-DbaAgentJob -SqlInstance sqlserver2014a | Where-Object Category -eq "Report Server" | Copy-DbaAgentJob -Destination sqlserver2014b -DisableOnDestination
Copy-DbaAgentJob -Source sqlserver2014a -Destination sqlcluster  -DisableOnDestination
Get-DbaAgentSchedule -SqlInstance sql2016 | Out-GridView -Passthru | Copy-DbaAgentSchedule -Destination sqlcluster


Copy-DbaDbMail -Source sqlserver2014a -Destination sqlcluster -EnableException
#run it on target upgraded instance as required
Get-DbaDatabase -SqlInstance sql2016 | Out-GridView -Passthru | Invoke-DbaDbUpgrade

Copy-DbaSsisCatalog -Source sqlserver2014a -Destination sqlcluster

Copy-DbaSpConfigure -Source sqlserver2014a -Destination sqlcluster -WhatIf



