﻿ Import-Module dbatools -EA SilentlyContinue
 $computer='tpapwidesql001'
 $instance = Find-DbaInstance -ComputerName $computer | Select-Object SqlInstance 
 $server= Connect-DbaInstance -SqlInstance $instance.SqlInstance 
            $totalMemory = $server.PhysicalMemory

            # Some servers under-report by 1.
            if (($totalMemory % 1024) -ne 0) {
                $totalMemory = $totalMemory + 1
            }

            [PSCustomObject]@{
                ComputerName = $server.ComputerName
                InstanceName = $server.ServiceName
                SqlInstance  = $server.DomainInstanceName
                Total        = [int]$totalMemory
                MaxValue     = [int]$server.Configuration.MaxServerMemory.ConfigValue
                Server       = $server # This will allowing piping a non-connected object
            } | Select-Object -Property ComputerName, InstanceName, SqlInstance, Total, MaxValue

            <#
 Import-Module dbatools -EA SilentlyContinue
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] Where [Status]='Y'" -TrustServerCertificate
foreach($SQL_server in $servers.SqlInstance)
{
$server= Connect-DbaInstance -SqlInstance $SQL_server  
            $totalMemory = $server.PhysicalMemory

            # Some servers under-report by 1.
            if (($totalMemory % 1024) -ne 0) {
                $totalMemory = $totalMemory + 1
            }

            [PSCustomObject]@{
                ComputerName = $server.ComputerName
                InstanceName = $server.ServiceName
                SqlInstance  = $server.DomainInstanceName
                Total        = [int]$totalMemory
                MaxValue     = [int]$server.Configuration.MaxServerMemory.ConfigValue
                Server       = $server # This will allowing piping a non-connected object
            } | Select-Object -Property ComputerName, InstanceName, SqlInstance, Total, MaxValue | Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'DbaMaxMemory'  -AutoCreateTable -KeepNulls
}
            #>
        