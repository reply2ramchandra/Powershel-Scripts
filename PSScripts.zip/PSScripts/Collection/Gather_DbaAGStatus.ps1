﻿Import-Module dbatools -EA SilentlyContinue 
Import-Module dbatools -EA SilentlyContinue
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "DROP TABLE IF EXISTS [CMS].[dbo].DbaAGStatus" -TrustServerCertificate 
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [ServerName] FROM [CMS].[dbo].[DbaAGServer]" -TrustServerCertificate 
foreach($AG in $servers.ServerName)
{
$primary=Get-DbaAvailabilityGroup -SqlInstance $AG | select PrimaryReplicaServerName
if($primary.PrimaryReplicaServerName -eq $AG)
{
$AGReplica=Get-DbaAgReplica -SqlInstance $AG #| Select sqlInstance,AvailabilityGroup,Name,Role,RollupSynchronizationState
Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'DbaAGStatus' -InputObject $AGReplica  -AutoCreateTable -KeepNulls
} 

}

Start-Sleep -Seconds 2

  $css = @"
<style>
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid black; padding: 8px; text-align: left; }
    th { background-color: #f2f2f2; }
</style>
"@

$runDateTime = (Get-Date -Format yyyyddMM) 
 $preContent = @"
<h3><font face=verdana color=blue>SQL AG REPLICA - SYNC Status</font></h3>
<p>This report contains the list of AG Server's Sync Status.</p>
"@

$postContent = @"
<p><font face=verdana color=green>Generated on $(Get-Date). Please review and take action as Required.</font></p>
"@
$rpt=Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [Replica],[AvailabilityGroup],[Role],[RollupSynchronizationState]  FROM [CMS].[dbo].[DbaAGStatus]" -TrustServerCertificate  | Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors
$rpt | ConvertTo-Html  -Property Replica, AvailabilityGroup, Role,RollupSynchronizationState -Head $css -Title "SQL AG REPLICA - SYNC Status" -PreContent $preContent  -PostContent  $postContent  | Out-File -FilePath \\tpapwmssql002\Reports\AGStatus$runDateTime.htm 
       

             if($rpt.Count -gt 0)
             {
                  Write-host 'Sending mail' -ForegroundColor Green
     
                  $body = Get-Content \\tpapwmssql002\Reports\AGStatus$runDateTime.htm
                  Send-MailMessage -From 'DBA_Report@Healthplan.com'  -To 'WHPS-MSSQL-Admins@wipro.com' -Subject 'SQL AG REPLICA - SYNC Status' -SmtpServer smtprelay.healthplan.com -BodyAsHtml:$true -Body "$body" 

                  #Invoke-Item \\tpapwmssql002\Reports\backupreport.html
                 
             }
             else
             {
              Write-host 'Not sending mail as we dont have anything' -ForegroundColor Yellow
             }
get-date
#To = "WHPS-MSSQL-Admins@wipro.com","kishore.chittampalli@wipro.com","khaled.sardouk@wipro.com","gitta.amulya@wipro.com","ramchandraiah.maddineni1@wipro.com","sathiyaneethi.mani@wipro.com"