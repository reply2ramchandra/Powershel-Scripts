﻿clear
Import-Module dbatools -EA SilentlyContinue 
Get-DbaErrorLog -SqlInstance TPATWSQLMHCA01 -LogNumber 1,1 -Text "SQL Server" 
Get-DbaErrorLog -SqlInstance TPADWSQLMHCA01 -After '2025-07-10 00:01:00' -Text "stopped"
#Get-DbaErrorLog -SqlInstance TPAPWDWSQL004 -Before '2024-01-19 00:00:00'

