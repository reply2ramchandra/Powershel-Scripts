﻿
Install-WindowsFeature -Name Failover-Clustering –IncludeManagementTools
Get-Module -ListAvailable
import-module failoverclusters 
#Test-Cluster -Node "TPADWSQLGNXTA01","TPADWSQLGNXTB01"
Import-Module FailoverClusters
New-Cluster -Name TPATWSQLMHC001 -Node TPATWSQLMHCA01,TPATWSQLMHCB01

Get-ClusterQuorum

Set-ClusterQuorum -NodeAndFileShareMajority \\tpa-islstr-01\SQLBackupsFinance\GetNext_Quorum\TPAPWSQLGNXT01
Test-Cluster ##works on cluster node