﻿#$servers = Get-DbaRegServer -SqlInstance TPAPWMSSQL002
#$servers=@('GCPSWDWSQL005','GCPSWDWSQL004','TPAPWSQLETA01')
Import-Module dbatools -DisableNameChecking 
$os = Get-DbaOperatingSystem -ComputerName $servers
$os = Get-DbaOperatingSystem -ComputerName $servers.Name
$excelFile = 'D:\PSScripts\Excel\OSVersionInfo.xlsx'
$osProps = 'ComputerName','Architecture','Version','Build','OSVersion', 'SPVersion', 'InstallDate','LastBootTime', 'ActivePowerPlan'
$osExcel = @{
	Path = $excelFile
	WorksheetName = 'OSVersions'
	AutoSize = $true
	TableName = 'OSVersion'
	IncludePivotTable = $true
	PivotRows = 'OSVersion'
	PivotData = @{OSVersion='Count'}
	IncludePivotChart = $true
	ChartType = 'ColumnClustered'
}
 
$os | Select-Object $osProps | export-excel @osExcel