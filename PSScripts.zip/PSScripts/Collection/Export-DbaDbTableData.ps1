﻿Import-Module dbatools -ErrorAction SilentlyContinue
Get-DbaDbTable -SqlInstance TEST-WMSSDGN2-01\IHGN2D01 -Database Recon | Export-DbaDbTableData -Path X:\scripts\recon -Append
