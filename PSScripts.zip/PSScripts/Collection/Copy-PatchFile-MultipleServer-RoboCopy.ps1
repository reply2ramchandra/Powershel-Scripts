﻿Clear-Host

Write-Host "Key your Password" -ForegroundColor Green
$user = [Environment]::username
$cred = Get-Credential $user

# Define local and remote paths
$localPath = "X:\SQLISO\CU\2022"  # Update this to your actual source path
$remotePath = "C:\Patch"          # Update this to your actual target path
$servers = Get-Content "T:\Test\HA_Prod.txt"

# Define log file paths
$logFile = "D:\PSScripts\Logs\FileCopy.log"
$errorLogFile = "D:\PSScripts\Logs\FileCopyErrors.log"

# Ensure log directory exists
if (-not (Test-Path "D:\PSScripts\Logs")) {
    New-Item -Path "D:\PSScripts\Logs" -ItemType Directory -Force
}

foreach ($remoteHost in $servers) {
    try {
        # Check and create remote path if it doesn't exist
        Invoke-Command -ComputerName $remoteHost -Credential $cred -ScriptBlock {
            param($remotePath)
            if (-not (Test-Path $remotePath)) {
                New-Item -Path $remotePath -ItemType Directory -Force
                Write-Host "Created remote path: $remotePath"
            } else {
                Write-Host "Remote path already exists: $remotePath"
            }
        } -ArgumentList $remotePath

        # Convert remote path to UNC format for robocopy
        $remoteUNC = "\\$remoteHost\$($remotePath.Substring(0, 1))$" + $remotePath.Substring(2)

        # Use robocopy for fast copying
        $robocopyCmd = "robocopy `"$localPath`" `"$remoteUNC`" /MIR /Z /NP /R:2 /W:5"
        Start-Process -FilePath "cmd.exe" -ArgumentList "/c $robocopyCmd" -Wait -NoNewWindow -RedirectStandardOutput $logFile -RedirectStandardError $errorLogFile

        Write-Host "File copy completed for $remoteHost." -ForegroundColor Cyan
    } catch {
        # Log errors to the error log file
        $errorMessage = "Error on ${remoteHost}: $_"

        Write-Host $errorMessage -ForegroundColor Red
        Add-Content -Path $errorLogFile -Value $errorMessage
    }
}