﻿$folderPath = "C:\Program Files (x86)\Taniu\Tanium Client\Downloads"
if (Test-Path -Path $folderPath) {
# Get the current date and time
$currentTime = Get-Date

# Get the last modification time of the folder
$lastModifiedTime = (Get-Item $folderPath).LastWriteTime

# Calculate the time span between the current time and the last modification time
$timeDifference = $currentTime - $lastModifiedTime

if ($timeDifference.Days -gt 2)
{
Write-Output "Uninstalling Tanium"
#stop-service "Tanium Client"
#Start-Process -FilePath "C:\Program Files (x86)\Tanium\Tanium Client\uninst.exe" -ArgumentList "/S"
}
else
{
Write-Output "No Need"
}
# Output the result in a human-readable format
Write-Host "The folder was modified approximately $($timeDifference.Days) days, $($timeDifference.Hours) hours, $($timeDifference.Minutes) minutes, and $($timeDifference.Seconds) seconds ago."
} 




