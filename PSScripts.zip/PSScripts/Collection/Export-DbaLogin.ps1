﻿Import-Module dbatools -DisableNameChecking 
Export-DbaLogin -SqlInstance TPAPWDWSQLA05 -Login HPS\sk87333 -Path D:\PSScripts\login\sk87333
Export-DbaLogin -SqlInstance TPAPWDWSQLB05 -Login HPS\sk87333 -Path D:\PSScripts\login\sk87333
Export-DbaLogin -SqlInstance TPAPWSQLDL001 -Login HPS\sk87333 -Path D:\PSScripts\login\sk87333
Export-DbaLogin -SqlInstance TPAPWDWSQL004 -Login HPS\sk87333 -Path D:\PSScripts\login\sk87333
#Remove-DbaLogin -SqlInstance TPAPWDWSQL004 -Login hps\sk87333
#Stop-DbaProcess -SqlInstance TPAPWDWSQLA05 -Login hps\ar95954,
#Set-DbaLogin -SqlInstance TPAPWDWSQLB05 -Login hps\jv67475 -Disable
#Set-DbaLogin -SqlInstance TPAPWDWSQLB05 -Login hps\jv67475 -Enable
#New-DbaDbRole -SqlInstance TPAPWDWSQLA05 -Database db1 -Role 'dbExecuter'
#Remove-DbaDbRole -SqlInstance TPAPWDWSQLA05 -Role dbExecuter
#New-DbaDbRole -SqlInstance TPAPWDWSQLB05,TPAPWSQLDL001,TPAPWDWSQL004 -ExcludeDatabase master,msdb,model,tempdb -Role 'db_Executer'
#Add-DbaDbRoleMember -SqlInstance TPAPWDWSQLB05 -Role "SQLAgentReaderRole ","SQLAgentUserRole" -User HPS\SQLEDWPRW -Database msdb
#Add-DbaDbRoleMember -SqlInstance TPAPWDWSQLA05,TPAPWDWSQLB05,TPAPWSQLDL001,TPAPWDWSQL004 -Role db_Executer -User HPS\SQLEDWPRW
