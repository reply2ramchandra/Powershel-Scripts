﻿clear
$server='TPAPWSQLDL001'
 Invoke-Command -ComputerName $server -ScriptBlock {
$regpath="HKLM:\SOFTWARE\WOW6432Node\MySQL AB\MySQL Connector NET" 
$DotNetMySQL=Get-ItemProperty -Path $regpath -ErrorAction Ignore
$ver=$DotNetMySQL.Version
if($ver){
Write-Host "Existing MySQL Connector Version-" $ver -ForegroundColor Green -NoNewline
write-host " " -ForegroundColor Green -NoNewline }
Else { write-host "NO MySQL Connector UPDATE is Required " -ForegroundColor Yellow -NoNewline }
hostname }
