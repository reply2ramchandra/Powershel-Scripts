﻿Import-Module dbatools -DisableNameChecking
Clear-DbaPlanCache -SqlInstance sql2017 -Threshold 200
