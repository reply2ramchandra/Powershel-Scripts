﻿clear-host
get-date
#powershell.exe -command "& 'C:\Program Files\Azure Data Studio\unins001.exe' /SILENT"} #for newer version uninstall 1.51.1
$servers=get-content "T:\Test\ADS_1.txt"
foreach($server in $servers)
{
Invoke-Command -ComputerName $server -ScriptBlock {
powershell.exe -command "& 'C:\Program Files\Azure Data Studio\unins000.exe' /SILENT"} }
get-date