﻿<#
clear-host
$server='GCPSWDWSQL004'
 Invoke-Command -ComputerName $server -ScriptBlock {
$regpath="HKLM:\SOFTWARE\ODBC\ODBCINST.INI\ODBC Drivers"
$MySQLODBC=Get-ItemProperty -Path $regpath -ErrorAction Ignore
$MySQLODBC
 }
 #>
<#
clear
Import-Module dbatools -EA SilentlyContinue 
$servers=get-content "T:\Test\111524.txt"
foreach($srv in $servers)
{
Invoke-Command -ComputerName $srv -ScriptBlock {
$regpath="HKLM:\SOFTWARE\ODBC\ODBCINST.INI\ODBC Drivers"
$MySQLODBC=Get-ItemProperty -Path $regpath -ErrorAction Ignore
$MySQLODBC
 }
}
#>
clear
$servers = @("gcpswbiapp001","gcpswbiweb001","gcpswdwsql004","gcpuwbiapp001","gcpuwbiapp002","gcpuwbiweb001","tpaqwdwsql004","tpatwbiapp001")

foreach ($server in $servers)
{
    Invoke-Command -ComputerName $server -ScriptBlock {
    Powershell.exe -command "hostname"
    Powershell.exe -command "& wmic product where 'Name like ''%MySQL%ODBC%''' get Name"}
   }
