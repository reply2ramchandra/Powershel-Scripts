﻿Import-Module dbatools -DisableNameChecking 
# Creates a schedule with a daily frequency every day. It assumes default values for the start date, start time, end date and end time due to -Force.
$schedule=New-DbaAgentSchedule -SqlInstance tpapwmssql002 -Schedule daily -FrequencyType Daily -FrequencyInterval Everyday -Force
#Create an agent job that runs the powershell Command
$command = @"
Powershell.exe -ExecutionPolicy Bypass -File "D:\PSScripts\DailyReportingUsingPowershell\Backup_Morethan_3Days_Report.ps1"
"@
New-DbaAgentJob -Schedule $schedule -SqlInstance tpapwmssql002 -Job Backup_Failure_report_DBA
New-DbaAgentJobStep -SqlInstance tpapwmssql002 -StepName Backup_Failure_report_DBA_step -Command $command -Job Backup_Failure_report_DBA -Subsystem CmdExec