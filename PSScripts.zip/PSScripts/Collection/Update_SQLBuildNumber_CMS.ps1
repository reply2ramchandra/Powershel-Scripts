﻿Import-Module dbatools -EA SilentlyContinue
$server='TPAPWSQL001'
Start-Sleep -Seconds 5
$SQL=Find-DbaInstance -ComputerName $server | Select SqlInstance
$SQL=$SQL.SqlInstance
if($SQL){
$patch = Invoke-DbaQuery -SqlInstance $SQL -Database master -Query "SELECT CONVERT(varchar(9), SERVERPROPERTY('productversion')) as BuildNumber,CONVERT(varchar(9), SERVERPROPERTY('productlevel')) as SPLevel, CONVERT(varchar(9), SERVERPROPERTY('ProductUpdateLevel')) as CULevel" 
$build=$patch.BuildNumber
$sp=$patch.SPLevel
$cu=$patch.CULevel
Invoke-DbaQuery -SqlInstance TPAPWMSSQL002 -Database CMS -Query "Update dbo.DBServer SET BuildNumber='$build',SPLevel='$sp', CULevel='$cu' where SqlInstance='$SQL'" 
Invoke-DbaQuery -SqlInstance TPAPWMSSQL002 -Database CMS -Query "Update dbo.DBServer SET MajorVersion='SQL Server 2022' where SqlInstance='$SQL'" }
else { write-host ' CHECK if SQL Server is up and running fine ' -ForegroundColor Yellow}

 if($build -like "16.0*")
 {
#cleanup binary
    Invoke-Command -ComputerName $Server -ScriptBlock { 
       $path='D:\SQL\Software'
       Remove-Item -Path $path -Recurse -Force -Verbose
       write-host ' SQL Binary Cleanup is Done! ' -ForegroundColor Yellow
       } }