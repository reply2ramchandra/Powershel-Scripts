﻿$DsnArray = Get-OdbcDsn -DsnType "System" -Platform "All"
  write-host  $DsnArray

  ##to collect Remotely

  $servers = @("TPADWSQLDL001","TPAPWDWSQL004")

foreach ($server in $servers)
{
    Invoke-Command -computername $server -command {
      Get-ODBCDSN -DsnType "System" -Platform "All" | 
        Select Name, DsnType, @{n='Description';e={$_.Attribute.server}}
    }
    Write-Output $results | sort name, dsntype
  }

  <#

  Invoke-Command -computername TPAPWSQLDL001 -command {
      Get-ODBCDSN -DsnType "System" -Platform "All" | 
        Select Name, DsnType, @{n='Description';e={$_.Attribute.server}}
    }
    #>
   