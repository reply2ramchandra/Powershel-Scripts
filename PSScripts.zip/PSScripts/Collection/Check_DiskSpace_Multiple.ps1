﻿clear
Import-Module dbatools -EA SilentlyContinue
$servers=get-content "T:\Test\localsrc.txt"
foreach($server in $servers)
{
 Get-DbaDiskSpace $server  | where {$_.Name -ne "C:\" } }