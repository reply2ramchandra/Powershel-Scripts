﻿setspn -S MSSQLSvc/TPAPWSQLALFA01.HPS.HPH.AD:MSSQLSERVER hps\svc_hpssql
setspn -S MSSQLSvc/TPAPWSQLALFA01.HPS.HPH.AD:1433 hps\svc_hpssql

setspn -L hps\svc_hpssql