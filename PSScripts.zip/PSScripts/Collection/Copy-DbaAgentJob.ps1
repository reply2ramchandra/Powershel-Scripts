﻿#make sure dependent operators exist
Import-Module dbatools -EA SilentlyContinue
Get-DbaAgentJob -SqlInstance TPASWSQLDL001 -ExcludeCategory "DataBase Maintenance" | Export-DbaScript -Path "X:\Scripts\s01_job" 
Import-Module dbatools -EA SilentlyContinue
Get-DbaAgentJob -SqlInstance TPASWSQLDL002 -ExcludeCategory "DataBase Maintenance" | Copy-DbaAgentJob -Destination TPAUWSQLDL002 -DisableOnDestination
Get-DbaAgentJob -SqlInstance TPAPWETRSQL002 -Job "Restore ET for Read-Only Reporting" | Copy-DbaAgentJob -Destination TPAPWSQLETB01
Get-DbaAgentJob -SqlInstance TPAPWMSSQL002 -Job "Maint - Generate DR Report" | Copy-DbaAgentJob -Destination TPAPWSQLMHC005,TPAPWSQLMHC004,TPAPWSQLDL006,TPAPWSQLDLR006
Import-Module dbatools -EA SilentlyContinue
$jobs=get-content "T:\Test\sit_01_jobs.txt"
foreach($job in $jobs)
{
Get-DbaAgentJob -SqlInstance TPAPWSQLDL001 | Where-Object Name -eq "$job" | Export-DbaScript -Path "D:\PSScripts\Scripts\sit_01_job"}

#Get-DbaAgentJob -SqlInstance TPAPWDWSQL004 -ExcludeCategory "DataBase Maintenance" | Out-GridView -Passthru | Copy-DbaAgentJob -Destination TPASWSQLDL001 -DisableOnDestination

