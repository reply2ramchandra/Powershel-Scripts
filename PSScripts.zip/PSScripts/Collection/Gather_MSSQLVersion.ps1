﻿$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -EA SilentlyContinue 
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT trim([HostName])  FROM [CMS].[dbo].[DBServer] Where [Status]='Y'"
foreach($SQL_server in $servers.HostName)
{
$MSSQLVersion=Get-DbaProductKey -ComputerName $SQL_server |  Select-Object ComputerName,InstanceName,SqlInstance,Version,Edition

Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'MSSQLVersion' -InputObject $MSSQLVersion  -AutoCreateTable -KeepNulls
}