﻿Get-DbaDatabase -SqlInstance TPAPWSQLMHA001 -Database Harrington_Gateway_WIP | Get-DbaHelpIndex
Import-Module dbatools -EA SilentlyContinue
Get-DbaHelpIndex -SqlInstance TPAPWSQLMHA001 -Database Harrington_Gateway_WIP -IncludeFragmentation


