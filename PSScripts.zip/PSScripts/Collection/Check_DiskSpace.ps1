﻿Import-Module dbatools -EA SilentlyContinue
 $server='TPAPWSP16SQL001'
  #check drive allocation Unit
 Get-DbaDiskSpace $server | where {$_.Name -eq "C:\"}
  $srv='TPATWSQLCLU04'
   #Get-DbaDiskSpace $srv 
  #check drive allocation Unit
 Get-DbaDiskSpace $srv | where {$_.Name -eq "D:\"}
 get-date | select DateTime

