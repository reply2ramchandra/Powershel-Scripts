﻿Import-Module dbatools -DisableNameChecking 
Set-DbaLogin -SqlInstance HPSSQL13\SQL13 ,PRODSQL2K802\PRODSQL2K802 , PROD-BECUBICDB1  -Login HPS\a-scolson, HPS\scolson -Disable
# HPSSQL03\SQL03, HPSSQL06\LCS,

Set-DbaLogin -SqlInstance HPSSQL04\SQL04  -Login ascolson, scolson -Disable

Remove-DbaLogin -SqlInstance TPAPWSQLGNXTA01  -Login HPS\vv12128, HPS\a-vv12128


