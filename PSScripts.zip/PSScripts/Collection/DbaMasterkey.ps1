﻿Import-Module dbatools -EA SilentlyContinue
Get-DbaDbMasterKey -SqlInstance TPADWSQLDL001 -Database SSISDB

Backup-DbaDbMasterKey -SqlInstance TPADWSQLDL001 -Database SSISDB -Path \\tpadd9300.healthplan.com\SQLBackups\TPATWSQL004\SSISDB\FULL

