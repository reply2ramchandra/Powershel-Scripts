﻿Get-Process -ComputerName TPATWSQLSSRS01 |  Where-Object {$_.name -like '*microsoft*'} 
Get-Process -ComputerName TPAPWSQLSSRS-03 |  Where-Object {$_.name -like '*report*'} 