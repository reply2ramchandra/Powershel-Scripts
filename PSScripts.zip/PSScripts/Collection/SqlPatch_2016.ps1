﻿##https://sqlserverbuilds.blogspot.com/
#refer Get-DbaAgentJob to start the DIFF Backup job
$server='PRODSQL2K804'
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="D:\patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}


#copy patch file

$patchfile= Get-ChildItem X:\SQLISO\CU -Filter '*2016*' 
$source=$patchfile.FullName  
$target="D:\patch"
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $source -Destination $target -ToSession $s


#verify if file exist

Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="D:\patch"
# check if folder exist
$patchfile= Get-ChildItem $targetpatchfolder -Filter '*2016*'
if($patchfile)
{
Write-Host " Patch file Copied successfully! " -ForegroundColor Green
}
Else { Write-Host " Patch file missing " -ForegroundColor Yellow}
}


#create temp folder
$folder='CHG0073934'
$targetbackuppath='\\tpadd9300\SQLBackups'
$targetbackuppath='\\tpadd9300\SQLBackupsprod'
New-Item -ItemType Directory -Path $targetbackuppath\$folder\$server -ErrorAction stop
# Take DB backup
Import-Module dbatools -DisableNameChecking 
Backup-DbaDatabase -SqlInstance $server -Path $targetbackuppath\$folder\$server -ExcludeDatabase master,model,msdb  -Type Diff -CompressBackup -CreateFolder
Start-Sleep -Seconds 5

#reboot the machine before SQL Patch
$server='PRODSQL2K804'
Restart-Computer -ComputerName $server -Force
Start-Sleep -seconds 300
##wait for server be online
$server='PRODSQL2K804'
$check=Test-NetConnection -ComputerName $server | select PingSucceeded
$check=$check.PingSucceeded
if($check -eq $True){write-host "ALL ok. You may start the activity" -ForegroundColor Green}
Import-Module dbatools -EA SilentlyContinue
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -KB 5029187 -Restart -Path $target -Confirm:$false

# -ArgumentList "/SkipRules=RebootRequiredCheck
# -Version CU24