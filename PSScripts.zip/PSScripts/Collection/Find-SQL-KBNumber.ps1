﻿function Get-KBNumber {
     param (
        [string]$SqlInstance
    )
$query = @"
    SELECT 
        SUBSTRING(@@VERSION, 
                  PATINDEX('%KB[0-9]%', @@VERSION) + 2, 
                  CHARINDEX(')', @@VERSION, PATINDEX('%KB[0-9]%', @@VERSION)) - PATINDEX('%KB[0-9]%', @@VERSION) - 2
        ) AS KB_Number
"@

    Invoke-DbaQuery -SqlInstance $SqlInstance -Database master -Query $query
}

Get-KBNumber 'TPATWSQLALTR001'
