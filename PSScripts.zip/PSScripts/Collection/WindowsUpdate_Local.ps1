﻿(Get-CimInstance Win32_OperatingSystem -ComputerName localhost) | Select-Object Caption, Version
Import-Module PSWindowsUpdate
Install-WindowsUpdate -AcceptAll -AutoReboot -Confirm:$false -Verbose | Out-File C:\Windows\PSWindowsUpdate.log 
 #Install-WindowsUpdate –AcceptAll -KBArticleID KB5046612 -AutoReboot -Confirm:$false -Verbose
 #ipmo PSWindowsUpdate; Install-WindowsUpdate –Computername TPAPWSQLALFB01 –AcceptAll -KBArticleID KB5055519
#Invoke-WUJob -ComputerName localhost -Script {ipmo PSWindowsUpdate; Install-WindowsUpdate -AcceptAll -AutoReboot | Out-File C:\Windows\PSWindowsUpdate.log } -Confirm:$false -Verbose –RunNow