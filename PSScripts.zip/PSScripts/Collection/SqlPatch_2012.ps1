﻿#refer Get-DbaAgentJob to start the DIFF Backup job
$server='TPAXWSQLET001'
Import-Module dbatools -EA SilentlyContinue 
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -KB 5021123 -Restart -Path C:\patch -Confirm:$false