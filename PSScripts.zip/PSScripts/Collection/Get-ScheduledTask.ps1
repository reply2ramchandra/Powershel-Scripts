﻿Get-ScheduledTask | Where {$_.TaskName -Like '*1135*'} | Select-Object * 
Get-EventLog -LogName System -InstanceId 1135 -Newest 5
#Start-ScheduledTask -TaskName "ScanSoftware"
#Stop-ScheduledTask -TaskName "ScanSoftware"
#Get-ScheduledTask -TaskPath "\UpdateTasks\" | Stop-ScheduledTask