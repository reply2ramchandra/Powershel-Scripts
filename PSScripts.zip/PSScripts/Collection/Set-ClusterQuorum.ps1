﻿Import-Module FailoverClusters
Get-ClusterQuorum -Cluster TPADWSQLMHCC01
Set-ClusterQuorum -NodeAndFileShareMajority \\tpa-islstr-01\SQLBackupsFinance\GetNext_Quorum\TPAPWSQLGNXT01
#Set-ClusterQuorum -NodeAndFileShareMajority \\tpadd9300.healthplan.com\SQLQuoram\TPAPWSQLGNXTC02
#Set-ClusterQuorum -NodeAndFileShareMajority \\tpadd9300.healthplan.com\SQLQuoram\TPAPWSQLET01
#Set-ClusterQuorum -NodeAndFileShareMajority \\hpa-tpa-vast\SQLQuoram\TPAPWSQLFLC01
#Set-ClusterQuorum -NodeAndDiskMajority "Cluster Disk 7"
#Set-ClusterQuorum -NodeMajority
##Force start cluster on node Node1##  
Start-ClusterNode –Node Node1 –FQ
## Start locally on Node ##
Net Start ClusSvc /FQ
## Start the Cluster service with the quorum prevented on node NOde1 ##
Start-ClusterNode –Node Node1 –PQ
###Start locally on Node###
Net Start ClusSvc /PQ

##Assigned Node weight

Import-Module FailoverClusters  
$node = "TPAPWSQLALFB01" #nodename
(Get-ClusterNode $node).NodeWeight = 1  # set value  
$cluster = (Get-ClusterNode $node).Cluster  
$nodes = Get-ClusterNode -Cluster $cluster   
$nodes | Format-Table -property NodeName, State, NodeWeight