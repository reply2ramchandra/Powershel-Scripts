﻿$server='HPSSQL05'
Invoke-Command -ComputerName $server -ScriptBlock {
 $filepath= Get-ChildItem -path C:\Patch -Filter "*SSMS*20.2*.exe" 
 $filepath=$filepath.FullName
write-host "Beginning SSMS install..." -nonewline
$Parms = " /Install /Quiet /Norestart /Logs D:\SQL\log.txt"
$Prms = $Parms.Split(" ")
& "$filepath" $Prms | Out-Null
Write-Host "SSMS installation complete. " -ForegroundColor Yellow -NoNewline
hostname
 }