﻿##OLEDB
###https://msrc.microsoft.com/update-guide/en-US/advisory/CVE-2024-28906
#Microsoft OLE DB Driver 19 for SQL Server version 19.3.3.0
#Microsoft OLE DB Driver 18 for SQL Server version 18.7.4.0

clear-host
$servers=get-Content "T:\Test\620.txt"
foreach($server in $servers)
{
$server
 Invoke-Command -ComputerName $server -ScriptBlock {
$regpath="HKLM:\SOFTWARE\Microsoft\MSOLEDBSQL" 
$oledbversion=Get-ItemProperty -Path $regpath -ErrorAction Ignore
$ver=$oledbversion.InstalledVersion
if($ver){
Write-Host "Existing OLEDB Version" $ver -ForegroundColor Green -NoNewline
write-host " " -ForegroundColor Green -NoNewline }
Else { write-host "NO OLEDB18 UPDATE is Required " -ForegroundColor Yellow -NoNewline }
hostname
<#
if($ver -ne "18.6.7.0")
{ 
Write-Host "Server Name:"
hostname
Write-Host "Need a OLEDB update " -ForegroundColor Red
}
#>

$regpath="HKLM:\SOFTWARE\Microsoft\MSOLEDBSQL19" 
$oledbversion=Get-ItemProperty -Path $regpath -ErrorAction Ignore
$ver19=$oledbversion.InstalledVersion
if($ver19){
Write-Host "Existing OLEDB19 Version" $ver19 -ForegroundColor Green -NoNewline
write-host " " -ForegroundColor Green -NoNewline }
Else { write-host "NO OLEDB19 UPDATE is Required as it does not exist " -ForegroundColor Yellow -NoNewline }
hostname
}
}

#CREATE A FOLDER ON SERVER

$servers=get-Content "T:\Test\5724.txt"
foreach($server in $servers)
{
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="C:\patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}}


#copy OLEDB 18 file as required
$targetpatchfolder="c:\patch"
$patchfile= Get-ChildItem D:\OLEDB_ODBC -Filter '*oledb*18.*.msi' 
$source=$patchfile.FullName 
$servers=get-Content "T:\Test\5724.txt"
foreach($server in $servers)
{
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $source -Destination $targetpatchfolder -ToSession $s }


#update the OLEDB
$servers=get-Content "T:\Test\5724.txt"
foreach($server in $servers)
{
Invoke-Command -ComputerName $server -ScriptBlock {
powershell.exe -command "& msiexec /quiet /passive /qn /i C:\patch\msoledbsql-18.7.2.msi IACCEPTMSOLEDBSQLLICENSETERMS=YES"
 }}


