﻿$Drive = Get-CimInstance -ClassName Win32_Volume  -Filter "DriveLetter = 'L:'"
$Drive | Set-CimInstance -Property @{DriveLetter = 'O:'; Label = 'SQLData'}


$Drive = Get-CimInstance -ClassName Win32_Volume  -Filter "DriveLetter = 'M:'"
$Drive | Set-CimInstance -Property @{DriveLetter = 'L:'; Label = 'SQLLog'}

$Drive = Get-CimInstance -ClassName Win32_Volume  -Filter "DriveLetter = 'O:'"
$Drive | Set-CimInstance -Property @{DriveLetter = 'M:'; Label = 'SQLData'}