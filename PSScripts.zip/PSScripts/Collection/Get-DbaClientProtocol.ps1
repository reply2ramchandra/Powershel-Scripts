﻿Import-Module dbatools -EA SilentlyContinue
Get-DbaClientProtocol -ComputerName TPAPWSQLGNXTA01 | Out-GridView
Get-DbaInstanceProtocol -ComputerName TPAPWANALYTIC01

(Get-DbaClientProtocol -ComputerName TPAPWANALYTIC01 | Where-Object { $_.DisplayName -eq 'Named Pipes' }).Disable()
(Get-DbaClientProtocol -ComputerName TPAPWANALYTIC01 | Where-Object { $_.DisplayName -eq 'TCP/IP' }).Enable()
