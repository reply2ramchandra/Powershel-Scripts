﻿clear
Import-Module dbatools -ErrorAction SilentlyContinue
Invoke-DbaDbPiiScan -SqlInstance TPATWSQLHHA01 -Database ASO_Reporting -CountryCode US | Write-DbaDataTable -SqlInstance TPADWSQLARCH01 -Database Admin -Schema 'dbo' -Table 'ASO_Reporting_PII' -AutoCreateTable
