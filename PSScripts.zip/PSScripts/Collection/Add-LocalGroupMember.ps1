﻿Get-LocalGroupMember -Group "Administrators"
Add-LocalGroupMember -Group "Administrators" -Member "HPS\Domain Admins"
Add-LocalGroupMember -Group "Administrators" -Member "HPS\SG_WIndowsServerAdmins"
Add-LocalGroupMember -Group "Administrators" -Member "HPS\TPAPWSQLSSRS-03$"

