﻿#change the servername and VSTA version to be uninstalled as required
Invoke-Command -ComputerName TPAPWSQLDL006 -ScriptBlock {
    $pattern = '*Visual Studio Tools for Applications 2019*'
    $entries = Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*,
                                HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* -ErrorAction SilentlyContinue |
               Where-Object DisplayName -like $pattern
    if (-not $entries) { Write-Host 'Nothing left.'; return }

    foreach ($e in $entries) {
        $u = $e.UninstallString
        Write-Host "Processing: $($e.DisplayName)"
        if (-not $u) { Write-Host ' No UninstallString, skipping'; continue }

        # Normalize
        $exe = $null; $args = ''
        if ($u -match '^\s*"([^"]+)"\s*(.*)$') {
            $exe  = $matches[1]; $args = $matches[2]
        } elseif ($u -match '^\s*(\S+)\s*(.*)$') {
            $exe  = $matches[1]; $args = $matches[2]
        }

        if (-not (Test-Path $exe)) {
            Write-Host " Executable not found: $exe (will still try start)"; 
        }

        # msiexec path (GUID based)
        if ($u -match 'msiexec' -and $u -match '{[0-9A-Fa-f-]{36}}') {
            $guid = ($u | Select-String '{[0-9A-Fa-f-]{36}}').Matches[0].Value
            $cmdFile = 'msiexec.exe'
            $cmdArgs = "/x $guid /qn /norestart"
        }
        else {
            # Bootstrapper (vsta_setup.exe)
            if ($args -notmatch '/uninstall') { $args += ' /uninstall' }
            if ($args -notmatch '/quiet')     { $args += ' /quiet' }
            if ($args -notmatch '/norestart') { $args += ' /norestart' }
            $cmdFile = $exe
            $cmdArgs = $args.Trim()
        }

        Write-Host " Executing: `"$cmdFile`" $cmdArgs"
        $p = Start-Process -FilePath $cmdFile -ArgumentList $cmdArgs -Wait -PassThru -WindowStyle Hidden
        Write-Host " ExitCode: $($p.ExitCode)"
    }

    # Re-check
    $remaining = Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*,
                                  HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* -ErrorAction SilentlyContinue |
                 Where-Object DisplayName -like $pattern |
                 Select-Object DisplayName, DisplayVersion
    if ($remaining) {
        Write-Host 'Still present:'; $remaining | Format-Table -AutoSize
    } else {
        Write-Host 'All VSTA 2019 entries removed.'
    }
}