﻿$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -EA SilentlyContinue 
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance]  FROM [CMS].[dbo].[DBServer] Where [Status]='Y'" -TrustServerCertificate
foreach($instance in $servers.SqlInstance)
{
$userDb=Get-DbaDatabase -SqlInstance $instance -ExcludeSystem | Select @{n='DateKey';e={(Get-Date).GetDateTimeFormats()[46]}},SqlInstance,Name
$instance
if($userDb){Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'UserDB' -InputObject $userDb  -AutoCreateTable -KeepNulls}
}

#$userDb=Get-DbaDatabase -SqlInstance PRODSQL2K802\PRODSQL2K802 -IncludeLastUsed -ExcludeSystem | Select SqlInstance,Name,LastIndex*
#$userDb.count
#Get-DbaDatabase -SqlInstance GCPSWDWSQL004 | Select SqlInstance,Name, @{Name="Size(GB)";Expression={[math]::round($_.size*1MB/1GB,1)}}  | ft -AutoSize
