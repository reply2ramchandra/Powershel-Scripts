﻿$env:PSModulePath -split ';'
<#
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Unregister-PSRepository -Name PSGallery
Register-PSRepository -Default
Save-Module dbatools
#>