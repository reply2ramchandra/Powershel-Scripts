﻿# PowerShell Script to Restart SSRS on a Remote Server
clear
$remoteServer = "TPAPWSQLSSRS-03"
$serviceName = "SQLServerReportingServices"  # Default service name; adjust if using a named instance

try {
    Write-Host "Connecting to $remoteServer..."
    
    # Check if the service exists
    $service = Get-Service -ComputerName $remoteServer -Name $serviceName -ErrorAction Stop

    if ($service.Status -ne 'Running') {
        Write-Host "Service is not running. Attempting to start..."
        Start-Service -InputObject $service
        Write-Host "Service started successfully."
    } else {
        Write-Host "Service is running. All Looks Good..."
        #Restart-Service -InputObject $service -Force      
    }
}

catch {
    Write-Error "Failed to manage the SSRS service on $remoteServer. Error: $_"
}