﻿#Microsoft ODBC Driver 17 for SQL Server on Windows version 17.10.6.1 
#Microsoft ODBC Driver 18 for SQL Server on Windows version 18.3.3.1
clear-host
$servers=get-Content "T:\Test\620.txt"
foreach($server in $servers)
{
 Invoke-Command -ComputerName $server -ScriptBlock {
<#
$regpath="HKLM:\SOFTWARE\Microsoft\MSODBCSQL13"
$odbc13version=Get-ItemProperty -Path $regpath  -ErrorAction Ignore
$ver=$odbc17version.InstalledVersion
Write-Host "Existing ODBC 13 Version: " $ver -ForegroundColor Green -NoNewline
write-host " " -NoNewline
hostname
$regpath="HKLM:\SOFTWARE\Microsoft\MSODBCSQL13"
$odbc13version=Get-ItemProperty -Path $regpath  -ErrorAction Ignore
$ver=$odbc13version.InstalledVersion
if($ver){
Write-Host "Existing ODBC 13 Version: " $ver -ForegroundColor Green -NoNewline
write-host " " -NoNewline}
else { write-host "NO ODBC13 UPDATE is Required " -ForegroundColor Yellow -NoNewline }
hostname
#>
$regpath="HKLM:\SOFTWARE\Microsoft\MSODBCSQL17"
$odbc17version=Get-ItemProperty -Path $regpath  -ErrorAction Ignore
$ver1=$odbc17version.InstalledVersion
if($ver1){
Write-Host "Existing ODBC 17 Version: " $ver1 -ForegroundColor Green -NoNewline
write-host " " -NoNewline}
else { write-host "NO ODBC17 UPDATE is Required " -ForegroundColor Yellow -NoNewline }
hostname
<#if($ver -ne "17.10.5.1")
{ 
Write-Host "Server Name:"
hostname
Write-Host "Need a ODBC17 update " -ForegroundColor Red
}
#>
$regpath="HKLM:\SOFTWARE\Microsoft\MSODBCSQL18"
$odbc18version=Get-ItemProperty -Path $regpath -ErrorAction Ignore
$ver2=$odbc18version.InstalledVersion
if($ver2){
Write-Host "Existing ODBC 18 Version: " $ver2 -ForegroundColor Green -NoNewline
write-host " " -NoNewline}
else {write-host "NO ODBC18 UPDATE is Required " -ForegroundColor Yellow -NoNewline }
hostname}
}
<#if( -not $ver1)
{
break
Write-Host "Existing ODBC 18 Version: " $ver1 -ForegroundColor Green -NoNewline
Hostname
if($ver -ne "18.3.2.1")
{ 
Write-Host "Server Name:"
hostname
Write-Host "Need a ODBC18 update " -ForegroundColor Red
}
}
#>


#CREATE A FOLDER ON SERVER


$servers=get-Content "T:\Test\5724.txt"
foreach($server in $servers)
{
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="c:\patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}
}


#copy ODBC 17

$patchfile= Get-ChildItem D:\OLEDB_ODBC -Filter '*odbc*17.*.msi' 
$source=$patchfile.FullName 

$servers=get-Content "T:\Test\5724.txt"
foreach($server in $servers)
{
$targetpatchfolder="c:\patch"
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $source -Destination $targetpatchfolder -ToSession $s }

#Update ODBC 17
$servers=get-Content "T:\Test\5724.txt"
foreach($server in $servers)
{
Invoke-Command -ComputerName $server -ScriptBlock {
powershell.exe -command "& msiexec /quiet /passive /qn /i C:\patch\msodbcsql-17.10.6.1.msi IACCEPTMSODBCSQLLICENSETERMS=YES ADDLOCAL=ALL"}}
