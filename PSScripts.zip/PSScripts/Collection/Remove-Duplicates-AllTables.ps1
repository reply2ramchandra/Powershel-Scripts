﻿<#
.SYNOPSIS
Detects (and optionally deletes) duplicate rows from every user table in a database using dbatools.

.DESCRIPTION
Duplicates are defined as rows where ALL non-computed, non-identity, non-rowguid, non-rowversion columns are identical.
One arbitrary row per duplicate group is kept (no ordering preference unless you customize the ORDER BY).
Run first WITHOUT -Execute to review. Then re-run with -Execute to remove duplicates.
Consider adding proper UNIQUE constraints afterward.

.PARAMETER SqlInstance
Target SQL Server instance.

.PARAMETER Database
Target database name.

.PARAMETER Execute
Perform deletions. Omit for report (dry run).

.PARAMETER IncludeSystemSchemas
If set, does not exclude sys, cdc, db_owner, INFORMATION_SCHEMA schemas.

.PARAMETER MinDuplicateGroups
Skip tables having fewer duplicate groups than this threshold (default 1).

.PARAMETER BatchSize
If > 0, deletes duplicates in batches (helps reduce log impact). Otherwise single set-based delete.

.PARAMETER OutputSql
Include the generated DELETE SQL text in the result objects.

.EXAMPLE
.\Remove-Duplicates-AllTables.ps1 -SqlInstance TPAPWSQLDLR005 -Database HPS_FDP

.EXAMPLE
.\Remove-Duplicates-AllTables.ps1 -SqlInstance TPAPWSQLDLR005 -Database HPS_FDP -Execute -BatchSize 5000 -Verbose
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)] [string]$SqlInstance,
    [Parameter(Mandatory=$true)] [string]$Database,
    [switch]$Execute,
    [switch]$IncludeSystemSchemas,
    [int]$MinDuplicateGroups = 1,
    [int]$BatchSize = 0,
    [switch]$OutputSql
)

Import-Module dbatools -ErrorAction Stop

Write-Verbose "Testing connection..."
Test-DbaConnection -SqlInstance $SqlInstance -ErrorAction Stop | Out-Null

$schemaFilter = if ($IncludeSystemSchemas) { "" } else { "AND s.name NOT IN ('sys','cdc','db_owner','INFORMATION_SCHEMA')" }

$tableQuery = @"
SELECT s.name AS SchemaName, t.name AS TableName, t.object_id
FROM sys.tables t
JOIN sys.schemas s ON s.schema_id = t.schema_id
WHERE t.is_ms_shipped = 0
$schemaFilter
ORDER BY s.name, t.name;
"@

$tables = Invoke-DbaQuery -SqlInstance $SqlInstance -Database $Database -Query $tableQuery

if (-not $tables) {
    Write-Warning "No tables found."
    return
}

$result = New-Object System.Collections.Generic.List[Object]
$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
$total = $tables.Count
$index = 0

foreach ($t in $tables) {
    $index++
    $schema = $t.SchemaName
    $table  = $t.TableName
    $objId  = $t.object_id
    $full   = "[$schema].[$table]"

    Write-Progress -Activity "Scanning tables" -Status "$schema.$table ($index of $total)" -PercentComplete (($index / $total) * 100)

    $colQuery = @"
SELECT c.name
FROM sys.columns c
WHERE c.object_id = $objId
  AND c.is_computed = 0
  AND c.is_identity = 0
  AND c.is_rowguidcol = 0
  AND c.system_type_id NOT IN (189) -- timestamp/rowversion
  AND c.generated_always_type = 0
ORDER BY c.column_id;
"@

    $colNames = (Invoke-DbaQuery -SqlInstance $SqlInstance -Database $Database -Query $colQuery).name
    if (-not $colNames -or $colNames.Count -eq 0) {
        Write-Verbose "Skipping $full (no qualifying columns)."
        $result.Add([pscustomobject]@{
            Schema              = $schema
            Table               = $table
            DuplicateGroups     = 0
            RowsDeleted         = 0
            Status              = 'Skipped(NoColumns)'
            ColumnsUsed         = $null
            Sql                 = $null
            ExecutionMs         = 0
        })
        continue
    }

    $colsBracketed = $colNames | ForEach-Object { "[$_]" }
    $colsList = ($colsBracketed -join ',')
    $dupCountQuery = @"
SELECT COUNT(*) AS DupGroups
FROM (
    SELECT $colsList
    FROM $full
    GROUP BY $colsList
    HAVING COUNT(*) > 1
) d;
"@

    try {
        $dupGroups = (Invoke-DbaQuery -SqlInstance $SqlInstance -Database $Database -Query $dupCountQuery).DupGroups
    } catch {
        Write-Warning "Error counting duplicates on $full : $($_.Exception.Message)"
        $result.Add([pscustomobject]@{
            Schema          = $schema
            Table           = $table
            DuplicateGroups = $null
            RowsDeleted     = $null
            Status          = 'Error(DupCount)'
            ColumnsUsed     = $colsList
            Sql             = if ($OutputSql) { $dupCountQuery } else { $null }
            ExecutionMs     = $null
        })
        continue
    }

    if (-not $dupGroups -or $dupGroups -lt $MinDuplicateGroups) {
        Write-Verbose "No (or below threshold) duplicate groups in $full."
        $result.Add([pscustomobject]@{
            Schema          = $schema
            Table           = $table
            DuplicateGroups = $dupGroups
            RowsDeleted     = 0
            Status          = 'NoAction'
            ColumnsUsed     = $colsList
            Sql             = if ($OutputSql) { $dupCountQuery } else { $null }
            ExecutionMs     = 0
        })
        continue
    }

    # Build delete SQL (batch or single)
    if ($BatchSize -gt 0) {
$deleteSql = @"
DECLARE @Rows INT = 1, @Total INT = 0;
WHILE (@Rows > 0)
BEGIN
    ;WITH D AS
    (
        SELECT *,
               rn = ROW_NUMBER() OVER (PARTITION BY $colsList ORDER BY (SELECT 0))
        FROM $full
    )
    DELETE TOP ($BatchSize) FROM D WHERE rn > 1;
    SET @Rows = @@ROWCOUNT;
    SET @Total += @Rows;
END
SELECT DeletedRows = @Total;
"@
    } else {
$deleteSql = @"
;WITH D AS
(
    SELECT *,
           rn = ROW_NUMBER() OVER (PARTITION BY $colsList ORDER BY (SELECT 0))
    FROM $full
)
DELETE FROM D WHERE rn > 1;
SELECT DeletedRows = @@ROWCOUNT;
"@
    }

    $tableSw = [System.Diagnostics.Stopwatch]::StartNew()
    $rowsDeleted = $null
    $status = if ($Execute) { 'Deleted' } else { 'Planned' }

    if ($Execute) {
        try {
            $rowsDeleted = (Invoke-DbaQuery -SqlInstance $SqlInstance -Database $Database -Query $deleteSql).DeletedRows
        } catch {
            $status = 'Error(Delete)'
            Write-Warning "Delete failed on $full : $($_.Exception.Message)"
        }
    }

    $tableSw.Stop()
    $result.Add([pscustomobject]@{
        Schema          = $schema
        Table           = $table
        DuplicateGroups = $dupGroups
        RowsDeleted     = $rowsDeleted
        Status          = $status
        ColumnsUsed     = $colsList
        Sql             = if ($OutputSql) { $deleteSql } else { $null }
        ExecutionMs     = [int]$tableSw.Elapsed.TotalMilliseconds
    })
}

$stopwatch.Stop()

Write-Host "`nCompleted in $([Math]::Round($stopwatch.Elapsed.TotalSeconds,2)) seconds.`n"
$result |
    Sort-Object Schema, Table |
    Format-Table Schema, Table, DuplicateGroups, RowsDeleted, Status, ExecutionMs

Write-Host "`nRowsDeleted is blank for dry run. Use -Execute to perform deletions."
Write-Host "Consider adding proper UNIQUE constraints afterwards."