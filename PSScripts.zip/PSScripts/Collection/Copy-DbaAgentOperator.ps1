﻿Import-Module dbatools -EA SilentlyContinue
Copy-DbaAgentOperator -Source TPASWSQLDL002 -Destination TPAUWSQLDL002
