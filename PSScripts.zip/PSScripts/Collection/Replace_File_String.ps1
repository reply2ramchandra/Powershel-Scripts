# Define the folder path, search string, and replacement string
$folderPath = "\\tpapwmssql002\d$\PSScripts\DailyDBAReporting"
 $searchString = '-TrustServerCertificate' 
 $replacementString = '#-TrustServerCertificate'

# Get all files in the folder (you can filter by extension if needed)
$files = Get-ChildItem -Path $folderPath -Recurse -File

foreach ($file in $files) {
    # Check if the file contains the search string
    if (Select-String -Path $file.FullName -Pattern $searchString -Quiet) {
        # Read the content
        $content = Get-Content -Path $file.FullName -Raw

        # Replace the string
        $newContent = $content -replace $searchString, $replacementString

        # Write the updated content back to the file
        Set-Content -Path $file.FullName -Value $newContent

        Write-Host "Updated: $($file.FullName)"
    }
}
