﻿Install-Module -Name SQLDBAtools
Install-Module -Name EnhancedHTML2 -RequiredVersion 2.0
Install-Module –Name PoshRSJob
Install-Module -Name SQLServer -AllowClobber