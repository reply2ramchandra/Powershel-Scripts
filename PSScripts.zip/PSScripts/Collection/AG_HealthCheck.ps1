﻿# Load DBATools module
Import-Module DBATools -ErrorAction SilentlyContinue
clear
# Define the SQL Server instance
$SqlInstance = "TPATWSQLHHB01"

# Get AG replica status
$agReplicas = Get-DbaAgReplica -SqlInstance $SqlInstance

# Display AG replica roles
$agReplicas | Select-Object AvailabilityGroup, Name, Role, ConnectionState | Format-Table -AutoSize

# Identify primary and secondary replicas
$primary = $agReplicas | Where-Object { $_.Role -eq 'Primary' }
$secondary = $agReplicas | Where-Object { $_.Role -eq 'Secondary' }

Write-Host "`nPrimary Replica: $primary"
Write-Host "`nSecondary Replicas:$secondary"

# Health check for AG
Write-Host "`nRunning AG Health Checks..."
$agHealth = Get-DbaAgDatabase -SqlInstance $SqlInstance

$agHealth | Select-Object AvailabilityGroup, Name, SynchronizationState, IsFailoverReady, IsSuspended | Format-Table -AutoSize

# Optional: Alert if any database is not healthy
$unhealthy = $agHealth | Where-Object { $_.SynchronizationState -ne 'Synchronized' }

if ($unhealthy.Count -gt 0) {
    Write-Warning "`n⚠️ Warning: Some AG databases are not healthy!"
    $unhealthy | Format-Table AvailabilityGroup, Name, SynchronizationState
} else {
    Write-Host "`n✅ All AG databases are healthy."
}
