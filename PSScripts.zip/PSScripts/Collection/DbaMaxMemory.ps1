﻿Import-Module dbatools -EA SilentlyContinue
Test-DbaMaxMemory -SqlInstance TPADWSQLMHCA01
Test-DbaMaxMemory -SqlInstance TPAPWSQLREC001 | Set-DbaMaxMemory
