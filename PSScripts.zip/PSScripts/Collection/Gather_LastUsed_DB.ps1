﻿CLEAR
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
import-module dbatools -EA SilentlyContinue
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT SqlInstance FROM [CMS].[dbo].[DBServer] Where [Status] in ('Y','P') and HostName Not in('HPSSQL03','PCIPWSQL001','localhost')"  -TrustServerCertificate 
foreach($SQLServer in $servers.SqlInstance)
{
Get-DbaDatabase -SqlInstance $SQLServer -IncludeLastUsed -ExcludeSystem | Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'LastUsed_DB' -AutoCreateTable -KeepNulls
}