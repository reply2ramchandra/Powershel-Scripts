﻿clear-host

Write-Host "Lets Remove the patch files copied." -ForegroundColor Magenta
$servers=get-content "T:\Test\HA_Prod.txt"
foreach($server in $servers)
{
Invoke-Command -ComputerName $server -ScriptBlock { 
       $path='C:\patch'
        Get-ChildItem -Path $path -Recurse -ErrorAction SilentlyContinue | Remove-Item -Confirm -ErrorAction SilentlyContinue
        #| Where-Object { ($_.CreationTime -gt $(Get-Date).AddDays( - 1))} | Select-Object Name,@{Name="SizeInMB"; Expression={ [math]::Round($_.Length / 1MB,2)}}  
       }
       }
