﻿Import-Module dbatools -EA SilentlyContinue
Find-DbaDbGrowthEvent -SqlInstance TPAPWSQLALF001 | Format-Table -AutoSize -Wrap

$instances=get-content "T:\Test\OS2019.txt"
foreach($instance in $instances)
{
Find-DbaDbGrowthEvent -SqlInstance $instance| Format-Table -AutoSize -Wrap }
