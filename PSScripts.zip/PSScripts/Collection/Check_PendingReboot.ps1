﻿<#
Import-Module PSWindowsUpdate
$targets=@("TPATWSQLQFILE01","TPAPWSQLGNRA01","TPADWSQLGNXTA01")
#Get-WURebootStatus -ComputerName $targets
Get-WURebootStatus -ComputerName $targets -ErrorAction SilentlyContinue
#>
clear
Import-Module PendingReboot
Test-PendingReboot -ComputerName TPAPWETRSQL002 -SkipConfigurationManagerClientCheck