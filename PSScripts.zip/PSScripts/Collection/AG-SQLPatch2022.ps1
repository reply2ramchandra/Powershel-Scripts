﻿Import-Module dbatools -EA SilentlyContinue
#Step 1 Check AG Primary
Get-DbaAvailabilityGroup -SqlInstance TPAPWSQLGNRA01
#Step 2 Set AG Failover Manual
Get-DbaAgReplica -SqlInstance TPAPWSQLGNRA01 | Out-GridView -Passthru | Set-DbaAgReplica -FailoverMode Manual
#Step 2 Apply Patches on Secondary Node
$server='TPAPWSQLGNRB01'
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -KB 5054531 -Restart -Path C:\Patch -Confirm:$false
#Step 4 Failover AG to Secondary and make it as Primary
#Failover to SqlInstance given
Get-DbaAvailabilityGroup -SqlInstance TPAPWSQLGNRB01 | Out-GridView -Passthru | Invoke-DbaAgFailover -Confirm:$false
#Step 5 Apply Patches Now current Secondary Node
$server='TPAPWSQLGNRA01'
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -KB 5054531 -Restart -Path C:\Patch -Confirm:$false
#Step 6 FailBack AG to Secondary ( Prior Primary) and make it as Primary
#Failover to SqlInstance given
Get-DbaAvailabilityGroup -SqlInstance TPAPWSQLGNRA01 | Out-GridView -Passthru | Invoke-DbaAgFailover -Confirm:$false
