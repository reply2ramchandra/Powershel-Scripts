﻿#refer Get-DbaAgentJob to start the DIFF Backup job
Import-Module dbatools -EA SilentlyContinue 
##Step 1
### SET AGReplica Failover Mode to Manual Before Apply Patches
$primaryR=Get-DbaAvailabilityGroup -SqlInstance TPAPWSQLHHB01 | Select PrimaryReplica
write-Host "PrimaryReplica:" $primaryR.PrimaryReplica -BackgroundColor Green
Get-DbaAgReplica -SqlInstance $primaryR.PrimaryReplica | Out-GridView -Passthru | Set-DbaAgReplica -FailoverMode Manual
##Step 2: Apply Patch on Secondary Node
$server='TPATWSQLMHCB01'
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -KB 5050771 -Restart -Path C:\patch -Confirm:$false

##Step 3 -AG Failover
#Failover to SqlInstance given which is currently secondary now
Get-DbaAvailabilityGroup -SqlInstance TPATWSQLMHCB01 | Out-GridView -Passthru | Invoke-DbaAgFailover -Confirm:$false
#check AG DB sync status and AG role
Get-DbaAgDatabase -SqlInstance TPATWSQLMHCB01 | Select SqlInstance, LocalReplicaRole,Name,SynchronizationState,IsFailoverReady
##Step 4 - Apply now on Secondary Node which was Primary prior
$server='TPATWSQLMHCA01'
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -KB 5050771 -Restart -Path C:\patch -Confirm:$false

##Step 5 -AG FailBack
#Failover to SqlInstance given which is currently secondary now
Get-DbaAvailabilityGroup -SqlInstance TPATWSQLMHCA01 | Out-GridView -Passthru | Invoke-DbaAgFailover -Confirm:$false

## Step 6
### SET AGReplica Failover Mode to Manual Before Apply Patches
Get-DbaAgReplica -SqlInstance TPATWSQLMHCA01 | Out-GridView -Passthru | Set-DbaAgReplica -FailoverMode Automatic
