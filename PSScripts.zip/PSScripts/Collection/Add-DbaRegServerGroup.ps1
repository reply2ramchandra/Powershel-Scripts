﻿Import-Module dbatools -EA SilentlyContinue 
#Remove-DbaRegServerGroup -SqlInstance TPAPWMSSQL002
Add-DbaRegServerGroup -SqlInstance TPAPWMSSQL002 -Name "NonPROD\SQL2012"


Import-Module dbatools -EA SilentlyContinue 
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'

$instances=Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] Where Status='Y' and MajorVersion= 'SQL Server 2000' order by HostName" -TrustServerCertificate


foreach($instance in $instances.SqlInstance)
{
Add-DbaRegServer -SqlInstance TPAPWMSSQL002 -ServerName $instance -Group "SQL 2000"
}

Import-Module dbatools -EA SilentlyContinue 
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'

$instances=Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] Where Status='Y' and MajorVersion= 'SQL Server 2019' order by HostName" -TrustServerCertificate


foreach($instance in $instances.SqlInstance)
{
Add-DbaRegServer -SqlInstance TPAPWMSSQL002 -ServerName $instance -Group "SQL 2019" 
}


Get-DbaRegServerGroup -SqlInstance TPAPWMSSQL002 


#Remove-DbaRegServerGroup -SqlInstance TPAPWMSSQL002 -Group "SQL 2000" -Confirm:$false

##prepare a SQL Query to add Server with Description and make sure Group is already got created
#select 'Add-DbaRegServer -SqlInstance TPAPWMSSQL002 -ServerName '+SqlInstance+' -Name '+SqlInstance+'-'+Application+' -Group "NonProd" '+ ' -ConnectionString ''server='+SqlInstance+';integrated security=true;TrustServerCertificate=True'''  from [CMS].[dbo].[DBServer] Where Status='Y' and Category='NonProd' and MajorVersion= 'SQL Server 2019' order by HostName

#select 'Add-DbaRegServer -SqlInstance TPAPWMSSQL002 -ServerName '+SqlInstance+' -Name '+SqlInstance+'-'+Application+' -Group "NonProd" ' from [CMS].[dbo].[DBServer] Where Status='Y' and Category='NonProd' and MajorVersion= 'SQL Server 2019' order by HostName
#select 'Add-DbaRegServer -SqlInstance TPAPWMSSQL002 -ServerName '+SqlInstance+' -Group "PROD\SQL2019" -Name  "'+SqlInstance+'-'+Application+'"' from [CMS].[dbo].[DBServer] Where Status='Y' and MajorVersion= 'SQL Server 2019' and Category='PROD' order by HostName