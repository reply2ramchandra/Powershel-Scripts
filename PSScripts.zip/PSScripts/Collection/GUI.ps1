﻿<# This form was created using POSHGUI.com  a free online gui designer for PowerShell
.NAME
    Untitled
#>

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$Form                            = New-Object system.Windows.Forms.Form
$Form.ClientSize                 = New-Object System.Drawing.Point(600,600)
$Form.text                       = "HPS MSSQL Inventory"
$Form.TopMost                    = $true

$Button1                         = New-Object system.Windows.Forms.Button
$Button1.text                    = "Get-OSInformation"
$Button1.width                   = 200
$Button1.height                  = 30
$Button1.location                = New-Object System.Drawing.Point(100,250)
$Button1.Font                    = New-Object System.Drawing.Font('Microsoft Sans Serif',10)
$Button1.add_click({a})

$Button2                         = New-Object system.Windows.Forms.Button
$Button2.text                    = "Get-SQL2022"
$Button2.width                   = 160
$Button2.height                  = 30
$Button2.location                = New-Object System.Drawing.Point(100,200)
$Button2.Font                    = New-Object System.Drawing.Font('Microsoft Sans Serif',10)
$Button2.add_click({b})

$Button3                         = New-Object system.Windows.Forms.Button
$Button3.text                    = "Get-SQL2019"
$Button3.width                   = 150
$Button3.height                  = 30
$Button3.location                = New-Object System.Drawing.Point(100,150)
$Button3.Font                    = New-Object System.Drawing.Font('Microsoft Sans Serif',10)
$Button3.add_click({c})

$Button4                         = New-Object system.Windows.Forms.Button
$Button4.text                    = "Send Email"
$Button4.width                   = 140
$Button4.height                  = 30
$Button4.location                = New-Object System.Drawing.Point(100,300)
$Button4.Font                    = New-Object System.Drawing.Font('Microsoft Sans Serif',10)
$Button4.add_click({d})

function a
{
Invoke-Sqlcmd -ServerInstance AD0125 -Database EnsonoDBA -Query "Select * from EnsonoDBA.dbo.InfocrossingOSInventory" | Out-GridView
} 
function b
{
Invoke-Sqlcmd -ServerInstance TPAPWMSSQL002 -Database CMS -Query "SELECT * from [CMS].[dbo].[DBServer] Where Status in('P','Y') and MajorVersion='SQL Server 2022';" -TrustServerCertificate | Out-GridView
}
function c
{
Invoke-Sqlcmd -ServerInstance TPAPWMSSQL002 -Database CMS -Query "SELECT * from [CMS].[dbo].[DBServer] Where Status in('P','Y') and MajorVersion='SQL Server 2019';" -TrustServerCertificate | Out-GridView
} 
function d
{

Remove-Item "I:\Powershell_Scripts\Reports\*.xlsx"

$MainReportFName = "Infocrossing_DBCount_$(Get-Date -Format 'MMddyyyyHH').xlsx"
$MainReportPath = 'I:\Powershell_Scripts\Reports\'+$MainReportFName
$instQuery = @" 
  Select * from [EnsonoDBA].[dbo].[DBCountMain] 
"@
$data  = Invoke-Sqlcmd -ServerInstance AD0125 -Database EnsonoDBA -Query $instQuery | Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors


$insParams = @{
        Path = "$MainReportPath"
        Worksheet = 'DatabaseCount'
        TableName = 'DatabaseCount'
        TableStyle = 'Light9'
        AutoSize = $true
        FreezeTopRow = $true
        AutoFilter = $true
        PassThru = $true
        BoldTopRow = $true
        KillExcel = $true  
    	}
$excelpkg = $data | Export-Excel @insParams -ChartType PieExploded3D -IncludePivotChart -IncludePivotTable -Show -PivotRows ServerMode -PivotData ServerMode -ShowPercent -PivotTableName "SQLServerMode" -ErrorAction Stop  

$splat = @{
        Worksheet = $excelpkg.DatabaseCount
        RuleType = 'Expression'
    }
$lastRow = $excelpkg.DatabaseCount.Dimension.end.row
Add-ConditionalFormatting @splat -Address "A2:M$lastRow" -ConditionValue '=$L2=0' -BackgroundColor yellow
Add-ConditionalFormatting @splat -Address "A2:M$lastRow" -ConditionValue '=$J2="Managed MS SQL HA Instance - Premium"' -BackgroundColor Magenta

# Add new WS for Databases
     $null = Add-Worksheet -ExcelPackage $excelpkg -WorksheetName 'SysVsUserDB' -ClearSheet
     $insParams.TableName = 'SysVsUserDB'
     $insParams.WorkSheet = 'SysVsUserDB'
     $insParams.Remove('Path')

$WCQuery = " SELECT COUNT(ServerName) as TotalServerCount,SUM(SysDBCount) as TotalSysDbsCount , SUM(UserDBCount) as TotalUserDbsCount FROM [EnsonoDBA].[dbo].[DBCountMain] "

$data  = Invoke-Sqlcmd -ServerInstance AD0125 -Database EnsonoDBA -Query $WCQuery | Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors
     $excelpkg = $data | Export-Excel @insParams -ExcelPackage $excelpkg  


# Add new WS for Databases
     $null = Add-Worksheet -ExcelPackage $excelpkg -WorksheetName 'DatabaseCountHistory' -ClearSheet
     $insParams.TableName = 'DatabaseCountHistory'
     $insParams.WorkSheet = 'DatabaseCountHistory'
     $insParams.Remove('Path')

$WCQuery1 = " Select  * from [EnsonoDBA].[dbo].[DBCountMain_V2] "

$data  = Invoke-Sqlcmd -ServerInstance AD0125 -Database EnsonoDBA -Query $WCQuery1 | Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors
     $excelpkg = $data | Export-Excel @insParams -ExcelPackage $excelpkg  -ChartType PieExploded3D -IncludePivotChart -IncludePivotTable -Show -PivotRows reccreatedt -PivotData ServerName -ShowPercent -PivotTableName "SQLInstanceCountByDate" -ErrorAction Stop  

Close-ExcelPackage -ExcelPackage $excelpkg


$runDateTime = Get-Date  
$Folderpath = (Get-ChildItem 'I:\Powershell_Scripts\Reports\*.xlsx').DirectoryName
$Filename = (Get-ChildItem 'I:\Powershell_Scripts\Reports\*.xlsx').name
$rptPath3 = $folderpath + '\'+ $filename 
$emailSMTP = '170.118.32.29'
$body = "<font face='Calibri' color='Green'><b> Client :  INFOCROSSING </b> <br><br>"
$body += "<font face='Calibri' color='Blue'> Hello Team, <br><br>"           
$body += "<font face='Calibri' color='Blue'> This alert is for <b> MSSQL Database Count Report </b> for <b>INFOCROSSING Client</b> pulled today <i>$runDateTime.</i><br><br>"     
$body += "Thank you <br><br>" 
$body += "<font face='Calibri' color='Red'> <b>Note : Empty Servers </b> are highlighted with <b>RED Color</b> <br><br>" 
$body += "<font face='Calibri' color='Yellow'> <b>Note : Empty Servers </b> are highlighted with <b>RED Color</b> <br><br>"   

    $emailParam = @{
        Subject = "INFOCROSSING - Database Count - $(Get-Date -Format d)"
        To = "phanikumar.bellamkonda@ensono.com"
        From = "GlobalMetricsReporting@ensono.com"
        Cc = "phanikumar.bellamkonda@ensono.com"
        Attachments = $rptPath3
        SmtpServer = $emailSMTP
                  
        
        <#Body = "<h5> Client : INFOCROSSING </h5><h4><font face='Calibri' color='Blue'> Hi EnsonoDBA Team </font></h4>
        <h5><font face='Calibri' color='Blue'> This alert is for MSSQL Database Count Report for INFOCROSSING Client. </font></h5>
        <h><font face='Calibri' color='Blue'> Please find attachment for detailed count statistics. </font></h5>
        <h6><font face='Calibri' color='Purple'> Please drop an email to Phanikumar.bellamkonda@ensono.com , in case any report is empty or isues with the report. </font></h6>"
        #>
	#<span style='font-family:Calibri;font-size:14pt;font-style:Bold; '
    }
 

    Send-MailMessage @emailParam -BodyAsHtml -Body $body


}

$Form.controls.AddRange(@($Button1,$Button2,$Button3,$Button4))
$form.Controls.add($Button1)
$form.Controls.add($Button2)
$form.Controls.add($Button3)
$form.Controls.add($Button4)

$form.ShowDialog()


