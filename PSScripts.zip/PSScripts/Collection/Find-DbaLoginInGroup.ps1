﻿Import-Module dbatools -EA SilentlyContinue 
Find-DbaLoginInGroup -SqlInstance TPAPWSQLMHC004  | Where-Object Login -like '*svc_bpoadlf*'


