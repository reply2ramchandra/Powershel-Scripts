﻿##connect to the Server and run
Enable-PSRemoting -Force;