﻿clear-host
$servers=get-content "T:\Test\copy_sw.txt"
Import-Module dbatools -EA SilentlyContinue 
<#$collectionSql = 'TPAPWMSSQL002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT DBS.[HostName] as Host FROM [CMS].[dbo].[OSVersion] OS JOIN  [CMS].[dbo].[DBServer]  DBS ON DBS.[HostName]=OS.[HostName]  where DBS.Status='Y' and DBS.MajorVersion='SQL Server 2019' AND OS.[OSVersion] like '%2019%';" -TrustServerCertificate
foreach($server in $servers.Host)
#>
foreach($server in $servers)
{

Invoke-Command -ComputerName $server -ScriptBlock {
$product=Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP' -recurse | Get-ItemProperty -name Version,Release -EA 0 | Where { $_.PSChildName -match '^(?![SW])\p{L}'} |
Select PSChildName, Version, Release, @{
  name="Product"
  expression={
      switch -regex ($_.Release) {
        "378389" { [Version]"4.5" }
        "378675|378758" { [Version]"4.5.1" }
        "379893" { [Version]"4.5.2" }
        "393295|393297" { [Version]"4.6" }
        "394254|394271" { [Version]"4.6.1" }
        "394802|394806" { [Version]"4.6.2" }
        "460798|460805" { [Version]"4.7" }
        "461308|461310" { [Version]"4.7.1" }
        "461808|461814" { [Version]"4.7.2" }
        "528040|528049" { [Version]"4.8" }
        {$_ -gt 528049} { [Version]"Undocumented version (> 4.8), please update script" }
      }
    }
}

if($product.Product -eq "4.8" -or $product.Product -eq "4.7.2" ) {
write-host "DotNet Product Version: " $product.Product " " -ForegroundColor Green -NoNewline
hostname
}
else 
{
write-host "Does not have either 4.7.x or 4.8 DotNet Version installed " -ForegroundColor Yellow -NoNewline
hostname
}
}
}
<#
clear-host
$server="TPAPWIDESQL001.HPS.HPH.AD"
Invoke-Command -ComputerName $server -ScriptBlock {
$product=Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP' -recurse | Get-ItemProperty -name Version,Release -EA 0 | Where { $_.PSChildName -match '^(?![SW])\p{L}'} |
Select PSChildName, Version, Release, @{
  name="Product"
  expression={
      switch -regex ($_.Release) {
        "378389" { [Version]"4.5" }
        "378675|378758" { [Version]"4.5.1" }
        "379893" { [Version]"4.5.2" }
        "393295|393297" { [Version]"4.6" }
        "394254|394271" { [Version]"4.6.1" }
        "394802|394806" { [Version]"4.6.2" }
        "460798|460805" { [Version]"4.7" }
        "461308|461310" { [Version]"4.7.1" }
        "461808|461814" { [Version]"4.7.2" }
        "528040|528049" { [Version]"4.8" }
        {$_ -gt 528049} { [Version]"Undocumented version (> 4.8), please update script" }
      }
    }
}

if($product.Product -eq "4.8" -or $product.Product -eq "4.7.2" ) {
write-host "DotNet Product Version: " $product.Product " " -ForegroundColor Green -NoNewline
hostname
}
else 
{
write-host "Does not have either 4.7.x or 4.8 DotNet Version installed " -ForegroundColor Yellow -NoNewline
hostname
}
}
#>