﻿Uninstall-Module -Name dbatools -RequiredVersion 2.1.5 -Force
Get-Module -Name dbatools -ListAvailable