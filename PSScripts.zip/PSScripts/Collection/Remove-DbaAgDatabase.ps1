﻿Import-Module dbatools -EA SilentlyContinue
$ag=Get-DbaAvailabilityGroup -SqlInstance tpapwsqlhhb01
$agname=$ag.AvailabilityGroup
Remove-DbaAgDatabase -SqlInstance tpapwsqlhha01 -AvailabilityGroup $agname -Database Harrington_Gateway_WIP -Confirm:$false
