<# RDP SSRS Server and then Run the script #>
# Define SSRS Web Service URL and destination path
$ReportServerUri = "http://tpapwsqlssrs-03/ReportServer/ReportService2010.asmx?wsdl"
$DestinationPath = "D:\SSRS03_Backup"

# Create SSRS proxy
$SSRS = New-WebServiceProxy -Uri $ReportServerUri -UseDefaultCredential -Namespace "SSRS"

# Function to recursively download reports
function Download-SSRSReports {
    param (
        [string]$FolderPath,
        [string]$LocalPath
    )

    # Create local folder if it doesn't exist
    if (!(Test-Path -Path $LocalPath)) {
        New-Item -ItemType Directory -Path $LocalPath | Out-Null
    }

    # Get items in the current folder
    $items = $SSRS.ListChildren($FolderPath, $true)

    foreach ($item in $items) {
        $itemPath = $item.Path
        $itemName = $item.Name
        $itemType = $item.TypeName

        if ($itemType -eq "Folder") {
            # Recurse into subfolder
            $subLocalPath = Join-Path $LocalPath $itemName
            Download-SSRSReports -FolderPath $itemPath -LocalPath $subLocalPath
        }
        elseif ($itemType -eq "Report") {
            # Download report definition
            $reportDefinition = $null
            $reportDefinition = $SSRS.GetItemDefinition($itemPath)

            # Save .rdl file
            $rdlPath = Join-Path $LocalPath "$itemName.rdl"
            [System.IO.File]::WriteAllBytes($rdlPath, $reportDefinition)
            Write-Host "Downloaded: $itemPath -> $rdlPath"
        }
    }
}

# Start backup from root folder
Download-SSRSReports -FolderPath "/" -LocalPath $DestinationPath
