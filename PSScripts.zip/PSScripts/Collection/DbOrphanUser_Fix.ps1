﻿Import-Module dbatools 
Repair-DbaDbOrphanUser -SqlInstance sqlserver2014a -Database db1, db2
