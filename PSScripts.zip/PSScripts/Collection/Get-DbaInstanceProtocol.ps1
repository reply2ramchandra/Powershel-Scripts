﻿Import-Module dbatools -EA SilentlyContinue 
#(Get-DbaClientProtocol -ComputerName TPAPWSQLMHC004 | Where-Object { $_.DisplayName -eq 'Named Pipes' }).Disable()
(Get-DbaInstanceProtocol -ComputerName TPAPWSQLMHC007 | Where-Object { $_.DisplayName -eq 'Named Pipes' }).Enable()

