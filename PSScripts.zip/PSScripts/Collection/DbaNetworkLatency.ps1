﻿Import-Module dbatools -DisableNameChecking 
Test-DbaNetworkLatency -SqlInstance tpatwsqlmhca01