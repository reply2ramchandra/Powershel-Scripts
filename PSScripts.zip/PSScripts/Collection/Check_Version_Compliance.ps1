﻿Import-Module dbatools -EA SilentlyContinue 
Get-DbaProductKey -ComputerName BLDPWAWHDS12 |  Select-Object ComputerName,SqlInstance,Version,Edition
Test-DbaBuild -SqlInstance BLDPWCVLTCOM001\COMMVAULT -Latest -Update | select SqlInstance,BuildLevel,BuildTarget,CULevel,SPLevel,Compliant | Format-Table
Get-DbaService -ComputerName BLDPWCVLTCOM001 | select ComputerName,ServiceName,State | Format-Table
Get-date
