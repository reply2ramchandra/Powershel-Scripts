﻿$files = Get-ChildItem -Path "D:\PSScripts\Scripts\sit_01_job\"
$files=$files.FullName 
foreach($file in $files)
{
$content = Get-Content -Path $file
$content = $content -replace '@notify_level_email=0', '@notify_level_email=2'
Set-Content -Path $file -Value $content
}