﻿#Import-Module -Name PSWindowsUpdate
#Get-WUInstall #List All Windows Updates Installed
$Computers='TPAPWSQLETB01'
Invoke-WUJob -ComputerName $Computers -Script {ipmo PSWindowsUpdate; Install-WindowsUpdate -AcceptAll -AutoReboot | Out-File C:\Windows\PSWindowsUpdate.log } -Confirm:$false -Verbose –RunNow
Get-WUJob -ComputerName $Computers
#Failover to SqlInstance given
Get-DbaAvailabilityGroup -SqlInstance TPAPWSQLETB01 | Out-GridView -Passthru | Invoke-DbaAgFailover -Confirm:$false
$Computers='TPAPWSQLETA01'
Invoke-WUJob -ComputerName $Computers -Script {ipmo PSWindowsUpdate; Get-WUInstall -AcceptAll -AutoReboot | Out-File C:\Windows\PSWindowsUpdate.log } -Confirm:$false -Verbose –RunNow
## Remove ScheduledTask
Invoke-Command ($Computers) {
Unregister-ScheduledTask -TaskName PSWindowsUpdate -Confirm:$false}