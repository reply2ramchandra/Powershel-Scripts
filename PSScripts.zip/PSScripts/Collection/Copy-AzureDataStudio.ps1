﻿Write-Host " Key your Password" -ForegroundColor Green
$user =  [Environment]::username
$cred=Get-Credential $user
$servers=get-content "T:\Test\522.txt"
foreach($server in $servers)
{
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="C:\patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}
#copy patch file
$source='X:\azuredatastudio-windows-arm64-setup-1.51.1.exe'
$target="C:\patch"
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $source -Destination $target -ToSession $s -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
}
clear-host
Write-Host "Lets Review the files copied." -ForegroundColor Magenta
   $servers=get-content "T:\Test\522.txt"
foreach($server in $servers)
{Invoke-Command -ComputerName $Server -ScriptBlock { 
       $path='C:\patch'
        Get-ChildItem -Path $path -Recurse -ErrorAction SilentlyContinue | Where-Object { ($_.CreationTime -gt $(Get-Date).AddDays( - 1))} | Select-Object Name,@{Name="SizeInMB"; Expression={ [math]::Round($_.Length / 1MB,2)}}  
       }}
