﻿#Create a drive mapping, mapping R: to the share on the FS1 server:
New-SmbMapping -LocalPath P: -RemotePath \\hps-tpa-vast.hps.hph.ad\SqlProd