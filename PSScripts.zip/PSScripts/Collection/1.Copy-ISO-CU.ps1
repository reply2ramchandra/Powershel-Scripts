﻿ ##THIS file is subject to change as required over time ###
  ### DON'T CHANGE/MODIFY this Script without Sathiya's  Notice please ####
 #############################
#Read-HostSpecial Function
#############################

Function Read-HostSpecial {
      [cmdletbinding(DefaultParameterSetName="_All")]
      Param(
            [Parameter(Position = 0,Mandatory,HelpMessage = "Enter prompt text.")]
            [Alias("message")]
            [ValidateNotNullorEmpty()]
            [string]$Prompt,
            [Alias("foregroundcolor","fg")]
            [consolecolor]$PromptColor,
            [string]$Title,
            [Parameter(ParameterSetName = "SecureString")]
            [switch]$AsSecureString,
            [Parameter(ParameterSetName = "Set")]
            [ValidateNotNullorEmpty()]
            [string[]]$ValidateSet
      )

Write-Verbose "Starting: $($MyInvocation.Mycommand)"
Write-Verbose "Parameter set = $($PSCmdlet.ParameterSetName)"
Write-Verbose "Bound parameters $($PSBoundParameters | Out-String)"

#combine the Title (if specified) and prompt
$Text = @"
$(if ($Title) {
"$Title`n$("-" * $Title.Length)"
})
$Prompt
"@

 If ($title.length -eq "0"){
      $Object = $Prompt
}
Else {
      $Object = $Text
}


#create a hashtable of parameters to splat to Write-Host
$paramHash = @{
      NoNewLine = $True
      Object = $Object
}

If ($PromptColor) {
    $paramHash.Add("Foregroundcolor",$PromptColor)
}

#display the prompt
Write-Host @paramhash
#get the value
If ($AsSecureString) {
    $r = $host.ui.ReadLineAsSecureString()
}
Else {
  #read console input
  $r = $host.ui.ReadLine()
}

#assume the input is valid unless proved otherwise
$Valid = $True

If ($Valid) {
    Write-Verbose "Writing result to the pipeline"
    #any necessary validation passed
    $r
}
Write-Verbose "Ending: $($MyInvocation.Mycommand)"
} #end function
Import-Module dbatools -EA SilentlyContinue
clear-host
$strtime=Get-Date
Write-Host "Start time : $strtime" -ForegroundColor Yellow
write-host "Welcome you to Copy the SQL Binaries to the target Server.Ensure you attempt at correct HOST." -backgroundColor Cyan
$srv=Read-HostSpecial "Enter Correct Host Name:" -PromptColor Green
$server=$srv
 
 #create a Folder
 
 Invoke-Command -ComputerName $server -ScriptBlock {
 write-host "Lets create a Folder to copy the setup file and other files." -ForegroundColor cyan
$targetpatchfolder="D:\SQL\Software"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}

#Copy the ISO file and Patch File
$usr=Read-HostSpecial "What is your hps a- account, pls enter:" -PromptColor Green
$ver=Read-HostSpecial "Select the SQL Version to copy: Enter 2022 or 2019 or 2017:" -PromptColor Green
$ed=Read-HostSpecial "Confirm the SQL Edition: Press 1 or 2 . 1 for Ent,2 for Std:" -PromptColor Green
if($ver -eq "2022" -and $ed -eq "1")
{
$isofile= Get-ChildItem X:\SQLISO\SQL2022 -Filter '*_Ent_*2022*.ISO' 
$isofile=$isofile.FullName
$cufile= Get-ChildItem X:\SQLISO\CU\2022 -Filter '*2022*.exe' 
$cufile=$cufile.FullName 
#$SSMS= Get-ChildItem X:\SSMS\ -Filter '*SSMS-Setup-ENU-20*.exe' 
#$SSMS=$SSMS.FullName  
$target="D:\SQL\Software"
$cred=Get-Credential $usr
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $isofile -Destination $target -ToSession $s -PassThru -Force
Start-Sleep -Seconds 2
Copy-Item -Path $cufile -Destination $target -ToSession $s -PassThru -Force
Start-Sleep -Seconds 2
#Copy-Item -Path $SSMS -Destination $target -ToSession $s -PassThru -Force
Write-Host "SQL Binary copy completed." -ForegroundColor Cyan
}
elseif ($ver -eq "2022" -and $ed -eq "2") {
$isofile= Get-ChildItem X:\SQLISO\SQL2022 -Filter '*_Standard_*2022*.ISO' 
$isofile=$isofile.FullName
$cufile= Get-ChildItem X:\SQLISO\CU\2022 -Filter '*2022*.exe' 
$cufile=$cufile.FullName 
#$SSMS= Get-ChildItem X:\SQLISO\ -Filter '*SSMS-Setup-ENU-20*.exe' 
#$SSMS=$SSMS.FullName  
$target="D:\SQL\Software"
$cred=Get-Credential $usr
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $isofile -Destination $target -ToSession $s -PassThru -Force
Start-Sleep -Seconds 2
Copy-Item -Path $cufile -Destination $target -ToSession $s -PassThru -Force
Start-Sleep -Seconds 2
#Copy-Item -Path $SSMS -Destination $target -ToSession $s -PassThru -Force
Write-Host "SQL Binary copy completed." -ForegroundColor Cyan
}
elseif($ver -eq "2019" -and $ed -eq "1")
{
$isofile= Get-ChildItem X:\SQLISO\SQL2019 -Filter '*_Ent_*2019*.ISO' 
$isofile=$isofile.FullName
$cufile= Get-ChildItem X:\SQLISO\CU\2019 -Filter '*2019*.exe' 
$cufile=$cufile.FullName 
$SSMS= Get-ChildItem X:\SQLISO\ -Filter '*SSMS-Setup-ENU-20*.exe' 
$SSMS=$SSMS.FullName  
$target="D:\SQL\Software"
$cred=Get-Credential $usr
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $isofile -Destination $target -ToSession $s -PassThru -Force
Start-Sleep -Seconds 2
Copy-Item -Path $cufile -Destination $target -ToSession $s -PassThru -Force
Start-Sleep -Seconds 2
Copy-Item -Path $SSMS -Destination $target -ToSession $s -PassThru -Force
Write-Host "SQL Binary copy completed." -ForegroundColor Cyan
}
elseif ($ver -eq "2019" -and $ed -eq "2") {
$isofile= Get-ChildItem X:\SQLISO\SQL2019 -Filter '*_Standard_*2019*.ISO' 
$isofile=$isofile.FullName
$cufile= Get-ChildItem X:\SQLISO\CU\2019 -Filter '*2019*.exe' 
$cufile=$cufile.FullName 
$SSMS= Get-ChildItem X:\SQLISO\ -Filter '*SSMS-Setup-ENU-20*.exe' 
$SSMS=$SSMS.FullName  
$target="D:\SQL\Software"
$cred=Get-Credential $usr
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $isofile -Destination $target -ToSession $s -PassThru -Force
Start-Sleep -Seconds 2
Copy-Item -Path $cufile -Destination $target -ToSession $s -PassThru -Force
Start-Sleep -Seconds 2
Copy-Item -Path $SSMS -Destination $target -ToSession $s -PassThru -Force
Write-Host "SQL Binary copy completed." -ForegroundColor Cyan
}
elseif($ver -eq "2017" -and $ed -eq "1")
{
$isofile= Get-ChildItem X:\SQLISO\SQL2017 -Filter '*_Ent*2017*.ISO' 
$isofile=$isofile.FullName
$cufile= Get-ChildItem X:\SQLISO\CU\2017 -Filter '*2017*.exe' 
$cufile=$cufile.FullName 
$SSMS= Get-ChildItem X:\SQLISO\ -Filter '*SSMS-Setup-ENU-20*.exe' 
$SSMS=$SSMS.FullName  
$target="D:\SQL\Software"
$cred=Get-Credential $usr
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $isofile -Destination $target -ToSession $s -PassThru -Force
Start-Sleep -Seconds 2
Copy-Item -Path $cufile -Destination $target -ToSession $s -PassThru -Force
Start-Sleep -Seconds 2
Copy-Item -Path $SSMS -Destination $target -ToSession $s -PassThru -Force
Write-Host "SQL Binary copy completed." -ForegroundColor Cyan
}
elseif ($ver -eq "2017" -and $ed -eq "2") {
$isofile= Get-ChildItem X:\SQLISO\SQL2017 -Filter '*_Ent*2017*.ISO' 
$isofile=$isofile.FullName
$cufile= Get-ChildItem X:\SQLISO\CU\2017 -Filter '*2017*.exe' 
$cufile=$cufile.FullName 
$SSMS= Get-ChildItem X:\SQLISO\ -Filter '*SSMS-Setup-ENU-20*.exe' 
$SSMS=$SSMS.FullName  
$target="D:\SQL\Software"
$cred=Get-Credential $usr
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $isofile -Destination $target -ToSession $s -PassThru -Force
Start-Sleep -Seconds 2
Copy-Item -Path $cufile -Destination $target -ToSession $s -PassThru -Force
Start-Sleep -Seconds 2
Copy-Item -Path $SSMS -Destination $target -ToSession $s -PassThru -Force
Write-Host "SQL Binary copy completed." -ForegroundColor Cyan
}
else{Write-Host "Sorry, Enter the correct option." -ForegroundColor Yellow}
Start-Sleep -Seconds 2
#verify the content copied and it's size
Write-Host "Lets Review the files copied." -ForegroundColor Cyan
   Invoke-Command -ComputerName $Server -ScriptBlock { 
       $path='D:\SQL\Software'
        Get-ChildItem -Path $path -Recurse -ErrorAction SilentlyContinue | Select-Object Name,@{Name="SizeInMB"; Expression={ [math]::Round($_.Length / 1MB,2)}}  
       }
$endtime=Get-Date
Write-Host "End time : $endtime" -ForegroundColor Yellow

      