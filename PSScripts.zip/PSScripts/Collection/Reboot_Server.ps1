﻿<# $server='TPATWSQLA01'
if($server -notlike 'TPAP*'){write-host "rebooting the Server: $server" -ForegroundColor Yellow
Restart-Computer -ComputerName $server -Force}
#>
#$server=Get-Content "T:\Test\np_ha_false.txt" | Restart-Computer -ComputerName $server -Force
#Get-Content "T:\Test\np_ha_false.txt" | Restart-Computer -Force
#Restart-Computer -ComputerName TPAPWSQLMHC06 -Force
