﻿ clear
 Import-Module dbatools -EA SilentlyContinue  
 $TargetServer='TPAPWSQLMHC006'
Get-DbaService $TargetServer | Select-Object ComputerName,ServiceName,StartName,State,StartMode
<#
 Import-Module dbatools -EA SilentlyContinue
$sqlserver=Get-Content "T:\Test\afterpatch.txt"
foreach($TargetServer in $sqlserver)
{ 
Get-DbaService $TargetServer | Select-Object ComputerName,ServiceName,StartName,State  | ft -AutoSize }
#>