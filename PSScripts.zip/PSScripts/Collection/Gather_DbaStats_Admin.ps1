﻿clear
# List of source SQL Server instances
$sourceInstances = get-content "T:\Test\admin.txt"

# T-SQL query to get Admin DB stats
$query = @"
USE Admin;
SELECT 
    @@SERVERNAME AS ServerName,
    DB_NAME() AS DatabaseName,
    SUM(size) * 8 / 1024 AS TotalSizeMB,
    SUM(CAST(FILEPROPERTY(name, 'SpaceUsed') AS INT)) * 8 / 1024 AS UsedSpaceMB,
    (SUM(size) - SUM(CAST(FILEPROPERTY(name, 'SpaceUsed') AS INT))) * 8 / 1024 AS FreeSpaceMB, DATABASEPROPERTYEX(DB_NAME(), 'Recovery') AS RecoveryModel
FROM 
    sys.database_files
WHERE 
    type_desc = 'ROWS';
"@

# Target CMS database connection
$targetConnStr = "Server=tpapwmssql002;Database=cms;Trusted_Connection=True;"
$targetConn = New-Object System.Data.SqlClient.SqlConnection $targetConnStr
$targetConn.Open()

# Auto-create DbaStats table if it doesn't exist
$createTableCmd = $targetConn.CreateCommand()
$createTableCmd.CommandText = @"
IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.TABLES 
    WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'DbaStats_Admin'
)
BEGIN
    CREATE TABLE dbo.DbaStats_Admin (
        ServerName NVARCHAR(128),
        DatabaseName NVARCHAR(128),
        TotalSizeMB FLOAT,
        UsedSpaceMB FLOAT,
        FreeSpaceMB FLOAT
    )
END
"@
$createTableCmd.ExecuteNonQuery()

# Loop through source instances
foreach ($sourceInstance in $sourceInstances) {
    try {
        Write-Host "Processing: $sourceInstance"

        # Connect to source instance
        $sourceConnStr = "Server=$sourceInstance;Database=Admin;Trusted_Connection=True;"
        $sourceConn = New-Object System.Data.SqlClient.SqlConnection $sourceConnStr
        $sourceCmd = $sourceConn.CreateCommand()
        $sourceCmd.CommandText = $query
        $sourceConn.Open()

        # Execute and load results
        $reader = $sourceCmd.ExecuteReader()
        $table = New-Object System.Data.DataTable
        $table.Load($reader)
        $sourceConn.Close()

        # Insert into central CMS database
        $bulkCopy = New-Object Data.SqlClient.SqlBulkCopy($targetConn)
        $bulkCopy.DestinationTableName = "dbo.DbaStats_Admin"
        $bulkCopy.WriteToServer($table)

        Write-Host "Data from $sourceInstance inserted successfully."
    } catch {
        Write-Warning "Failed to process ${sourceInstance}: $_"
    }
}

$targetConn.Close()
Write-Host "All done."