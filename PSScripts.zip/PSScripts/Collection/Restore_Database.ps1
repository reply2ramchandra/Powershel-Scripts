﻿ $sourceinstance='TPATWSQL004'
 $folder='DBMigration2022'
 Import-Module dbatools -EA SilentlyContinue 
Backup-DbaDatabase -SqlInstance $sourceinstance -Path \\tpadd9300.healthplan.com\SQLBackups\$folder -ExcludeDatabase master,model,msdb  -Type FULL -CompressBackup -CreateFolder
$backuppath="\\tpadd9300.healthplan.com\SQLBackupsprod\$folder"
$targetInstance=''
Restore-DbaDatabase -SqlInstance $targetInstance -Path $backupath -UseDestinationDefaultDirectories


###restore by passing backup file name
$backupath="\\tpadd9300.healthplan.com\SQLBackupsprod\TPAPWHHSQL004\Tableau_Reporting\FULL\TPAPWHHSQL004_Tableau_Reporting_FULL_20240221_104626.bak"
Restore-DbaDatabase -SqlInstance TPAPWSQLHH00 -Path $backupath -Database Tableau_Reporting -UseDestinationDefaultDirectories -WithReplace

#cleanup backup files
## VERY CAREFUL TO REMOVE THE FILES AND MAKE SURE BACKUP PATH BEFORE YOU CLEANUP
Get-ChildItem $backuppath -filter "*.bak" -Recurse | Remove-Item -force

#-DestinationDataDirectory T:\SQLData -DestinationLogDirectory T:\SQLLog 
#-WithReplace
Import-Module dbatools -EA SilentlyContinue 
$instance='TPAQWSQLDL001'
$result = Restore-DbaDatabase -SqlInstance $instance -Path \\hps-tpa-vast.hps.hph.ad\SqlNonProd\TPAQWDWSQL004\  -DestinationDataDirectory M:\STAGE\SQLData -DestinationLogDirectory L:\LOGS\SQLLog -WithReplace -OutputScriptOnly
$result | Out-File -Filepath X:\scripts\qua_restore.sql

Import-Module dbatools -EA SilentlyContinue 
$instance='TPASWSQLDL002'
$result = Restore-DbaDatabase -SqlInstance $instance -Path \\hps-tpa-vast.hps.hph.ad\SqlNonProd\TPASWSQLDL002\  -DestinationDataDirectory M:\MSTR_MD\SQLData\ -DestinationLogDirectory L:\SQLLogs\ -WithReplace -OutputScriptOnly
$result | Out-File -Filepath X:\scripts\uat2_restore.sql

Get-DbaDbRestoreHistory -SqlInstance TPAPWSQLSTEL003 -Database MSTR_MD_10_2_UAT

Get-DbaBackupInformation -SqlInstance TPAPWEDIAPP001 -Path \\tpadd9300\SQLBackupsprod\TPAPWEDIAPP001\FULL -DirectoryRecurse -ExportPath \\tpadd9300\SQLBackupsprod\TPAPWEDIAPP001\FULL\BackupHistory.xml

Copy-DbaSpConfigure -Source sqlserver2014a -Destination sqlcluster
