﻿#Test-DbaBuild -SqlInstance TPAUWSQLDL001 -Latest -Update | select SqlInstance,BuildLevel,BuildTarget,Compliant
Import-Module dbatools -EA SilentlyContinue
$servers=Get-Content "T:\Test\620.txt"
Update-DbaBuildReference
foreach($server in $servers)
{
Test-DbaBuild -SqlInstance $server -Latest -Update | select SqlInstance,BuildLevel,BuildTarget,Compliant | Format-Table
}


$servers=Get-Content "T:\Test\SqlPatch_2014_instance.txt"
Update-DbaBuildReference
foreach($server in $servers)
{
Test-DbaBuild -SqlInstance $server -Latest -Update | select SqlInstance,BuildLevel,BuildTarget,Compliant | Format-Table
}

$servers=Get-Content "T:\Test\SqlPatch_2016_instance.txt"
Update-DbaBuildReference
foreach($server in $servers)
{
Test-DbaBuild -SqlInstance $server -Latest -Update | select SqlInstance,BuildLevel,BuildTarget,Compliant | Format-Table
}

$servers=Get-Content "T:\Test\SqlPatch_2017_instance.txt"
Update-DbaBuildReference
foreach($server in $servers)
{
Test-DbaBuild -SqlInstance $server -Latest -Update | select SqlInstance,BuildLevel,BuildTarget,Compliant | Format-Table
}

$servers=Get-Content "T:\Test\SqlPatch_2019_instance.txt"
Update-DbaBuildReference
foreach($server in $servers)
{
Test-DbaBuild -SqlInstance $server -Latest -Update |  select SqlInstance,BuildLevel,BuildTarget,Compliant | Format-Table 
}