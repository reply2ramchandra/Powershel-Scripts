﻿clear
Import-Module dbatools -EA SilentlyContinue
Get-DbaDbMailLog -SqlInstance TPAPWDWSQL004 | Where-Object { ($_.LogDate -gt $(Get-Date).AddDays( - 1))}
