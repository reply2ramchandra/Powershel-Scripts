﻿clear
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -EA SilentlyContinue 
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT trim([HostName]) as HostName FROM [CMS].[dbo].[DBServer] Where [Status] in ('Y','P') and HostName Not in('localhost','PCIPWSQL001')"  -TrustServerCertificate 
#$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT trim([HostName]) as HostName FROM [CMS].[dbo].[DBServer] WHERE Status='Y' and MajorVersion='SQL Server 2022' and HA=0 and category='NonProd'; "  -TrustServerCertificate 

# Update [CMS].[dbo].[commandlog] table. 
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "INSERT INTO [CMS].[dbo].[commandlog] ([Description],[Status],[Collectiontime]) VALUES ('DbaService','Started',GETDATE());"  -TrustServerCertificate 

# Actual Script to collect services status from all Active servers.
foreach($SQL_server in $servers.HostName)
{
	
$DbaService =  Get-DbaService -ComputerName $SQL_server  | Select @{n='DateKey';e={(Get-Date).GetDateTimeFormats()[46]}},PSComputerName,ComputerName,DisplayName,ServiceType,ServiceName,StartMode,State,StartName,ProcessId 

# Write out put to [CMS].[dbo].[DbaService]
Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'DbaService' -InputObject $DbaService  -AutoCreateTable -KeepNulls

}

# Mark in [CMS].[dbo].[commandlog] table as Completed.
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  " INSERT INTO [CMS].[dbo].[commandlog] ([Description],[Status],[Collectiontime]) VALUES ('DbaService','Completed',GETDATE());"  -TrustServerCertificate 
#
<#
Write-Host 'TPAPWETRSQL002; TEST-WMSSDGN2-01; HPSSQL03; TPAPWSQLSSRS-03' -ForeGroundColor Yellow
Get-Service -ComputerName TPAPWETRSQL002 | Where-Object {$_.Name -like 'MSSQL*' -or $_.Name -like 'SQLSERVER*' -or $_.Name -like 'SQLAgent*'} | Select Name,Status, StartType
Get-Service -ComputerName TEST-WMSSDGN2-01 | Where-Object {$_.Name -like 'MSSQL*' -or $_.Name -like 'SQLSERVER*' -or $_.Name -like 'SQLAgent*'} | Select Name,Status, StartType
Get-Service -ComputerName HPSSQL03 | Where-Object {$_.Name -like 'MSSQL*' -or $_.Name -like 'SQLSERVER*' -or $_.Name -like 'SQLAgent*'} | Select Name,Status, StartType
Get-Service -ComputerName TPAPWSQLSSRS-03 | Where-Object {$_.Name -like 'Report*'} | Select Name,Status, StartType
#>
