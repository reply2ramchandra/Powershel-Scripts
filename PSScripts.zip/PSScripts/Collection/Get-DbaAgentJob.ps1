﻿Import-Module dbatools -EA SilentlyContinue
#Get-DbaAgentJob -SqlInstance TPAPWANALYTIC01\MHBE -ExcludeDisabledJobs |  Where-Object { ($_.Name -like '*DIFF*')} | Start-DbaAgentJob
$instances=get-content "T:\Test\100924.txt"
foreach($instance in $instances)
{Get-DbaAgentJob -SqlInstance $instance |  Where-Object { ($_.Name -like '*DIFF*')} | Start-DbaAgentJob }

$sqlinstances=get-content "T:\Test\0630.txt"
foreach($sqlinstance in $sqlinstances)
{
Get-DbaAgentJobHistory -SqlInstance $sqlinstance -StartDate '2024-10-04 21:30:00' -EndDate '2024-10-04 22:30:00'  |  Where-Object { ($_.Job -like '*DIFF*') -and ($_.Message -like '*a-sm58408*') } | Select-Object SqlInstance,Job,RunDate,Status }