﻿Import-Module dbatools -EA SilentlyContinue
Get-DbaDbSpace -SqlInstance  TPAPWSQLSSRS-04 -Database ReportServerSSRS01TempDB
#Get-DbaDbSpace -SqlInstance  TPAPWSQLSSRS-04 -Database ReportServerSSRS01TempDB | Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'TlogLargerthanData'  -AutoCreateTable -KeepNulls