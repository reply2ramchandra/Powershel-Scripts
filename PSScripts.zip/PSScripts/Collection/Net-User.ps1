﻿Get-ADPrincipalGroupMembership sm58408 | Select name
NET USER sm58408 /DOMAIN
#dsa.msc