﻿clear-host
$server='TPAPWSQLSANTA01'
Write-Host "Lets Review the files copied." -ForegroundColor Magenta
Invoke-Command -ComputerName $Server -ScriptBlock { 
       $path='C:\patch'
        Get-ChildItem -Path $path -Recurse -ErrorAction SilentlyContinue | Where-Object { ($_.CreationTime -gt $(Get-Date).AddDays( - 10))} | Select-Object Name,@{Name="SizeInMB"; Expression={ [math]::Round($_.Length / 1MB,2)}}  
       }
