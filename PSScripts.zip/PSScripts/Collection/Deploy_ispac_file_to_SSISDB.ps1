# Example: _Import-Module SqlServer
$server = "YourSQL2022Server"
$ispac = "C:\UpgradedSSIS\YourProject.ispac"
$catalogFolder = "YourCatalogFolder"
$projectName = "YourProject"

# Connect to SSISDB and deploy
$connectionString = "Data Source=$server;Initial Catalog=SSISDB;Integrated Security=True"
Invoke-Sqlcmd -Query "CREATE FOLDER [$catalogFolder] ON SSISDB" -ConnectionString $connectionString
Invoke-ISDeploymentWizard -SourcePath $ispac -DestinationServerName $server -DestinationPath "/SSISDB/$catalogFolder"