﻿$server='TPASWSQLDL001'
Invoke-Command -ComputerName $server -ScriptBlock {
 write-host "Lets create a Folder to copy the reg files if not exist." -ForegroundColor cyan
$targetpatchfolder="C:\Patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
} 
Write-Host "Let's copy the Reg File." -ForegroundColor cyan
$regfile= Get-ChildItem X:\GSTSQL001 -Filter '*.reg' 
$regfile=$regfile.FullName 
$target="C:\Patch"
$cred=Get-Credential a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $regfile -Destination $target -ToSession $s  -Force -ErrorAction SilentlyContinue