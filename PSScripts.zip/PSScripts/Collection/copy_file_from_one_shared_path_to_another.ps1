﻿#copy_file_from_one_shared_path_to_another
Get-ChildItem -Path "\\tpa-islstr-01\shares\PUBLIC\DataLink\25.DatalinkFTP\WebResponse_MSTRLogFiles" | Where-Object { $_.Extension -eq ".txt" } |  Copy-Item -Destination "\\tpa-islstr-01\shares\PUBLIC\DataLink\25.DatalinkFTP\WebResponse_MSTRLogFiles\PROD\TPAPWSQLDL005" -Force
Get-ChildItem -Path "\\tpa-islstr-01\shares\PUBLIC\DataLink\25.DatalinkFTP\WebResponse_MSTRLogFiles\Dev\SourceFiles" | Where-Object { $_.Extension -eq ".txt" } |  Copy-Item -Destination "\\tpa-islstr-01\shares\PUBLIC\DataLink\25.DatalinkFTP\WebResponse_MSTRLogFiles\PROD\TPAPWSQLDL005\Source" -Force
Get-ChildItem -Path "\\tpa-islstr-01\shares\PUBLIC\DataLink\25.DatalinkFTP\WEBResponse_SourceFiles_WebAPI" | Where-Object { $_.Extension -eq ".txt" } | Copy-Item -Destination "\\tpa-islstr-01\shares\PUBLIC\DataLink\25.DatalinkFTP\WEBResponse_SourceFiles_WebAPI\TPAPWSQLDL005" -Force
Get-ChildItem -Path "\\tpa-islstr-01\shares\PUBLIC\DataLink\25.DatalinkFTP\WebResponse_SourceFiles_fromCronjob\PROD\Source" | Where-Object { $_.Extension -eq ".txt" } | Copy-Item -Destination "\\tpa-islstr-01\shares\PUBLIC\DataLink\25.DatalinkFTP\WebResponse_SourceFiles_fromCronjob\PROD\TPAPWSQLDL005\Source" -Force
#set NTFS permission to shared path for svc account
#--RDP the File Server 
  icacls "D:\shares\PUBLIC\DataLink\25.DatalinkFTP\" /grant "HPS\svc_tpapwdwsql:(F)" /T
   
     Install-WindowsFeature RSAT-DFS-Mgmt-Con
  Get-DfsnFolder -Path "\\tpa-islstr-01\share\PUBLIC\DataLink\25.DatalinkFTP"
  Get-DfsnFolderTarget -Path "\\tpa-islstr-01\share\PUBLIC\DataLink\25.DatalinkFTP"