﻿Import-Module dbatools -DisableNameChecking
Find-DbaDbUnusedIndex -SqlInstance sql2016 -Database db1, db2
Get-DbaDatabase -SqlInstance sql2016 | Find-DbaDbUnusedIndex
