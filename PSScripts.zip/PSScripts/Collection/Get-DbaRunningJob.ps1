﻿Import-Module dbatools -DisableNameChecking
Get-DbaAgentJob -SqlInstance tpapwdwsql004 | Get-DbaRunningJob