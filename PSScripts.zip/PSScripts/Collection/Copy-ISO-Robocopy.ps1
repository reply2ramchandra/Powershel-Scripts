﻿clear
# remote host name
$remoteHost = 'TPAPWIDESQL001'

# Define local and remote paths
$localpath="X:\SQLISO\SQL2022" # Update this to your actual source path
$remotePath = "D:\SQL\Software"  # Update this to your actual target path

# Check and create remote path if it doesn't exist
Invoke-Command -ComputerName $remoteHost -ScriptBlock {
    param($remotePath)
    if (-not (Test-Path $remotePath)) {
        New-Item -Path $remotePath -ItemType Directory -Force
        Write-Host "Created remote path: $remotePath"
    } else {
        Write-Host "Remote path already exists: $remotePath"
    }
} -ArgumentList $remotePath

# Convert remote path to UNC format for robocopy
$remoteUNC = "\\$remoteHost\$($remotePath.Substring(0,1))$" + $remotePath.Substring(2)

# Use robocopy for fast copying
$robocopyCmd = "robocopy `"$localpath`" `"$remoteUNC`" /MIR /Z /NP /R:2 /W:5"
Invoke-Expression $robocopyCmd

Write-Host "File copy completed." -ForegroundColor Cyan
