﻿$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -EA SilentlyContinue
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] where Status='Y' and HostName<>'TPAPWSQLSSRS-03'" -TrustServerCertificate
foreach($Instance in $servers.SqlInstance)
{
$DbaPort=Get-DbaTcpPort $Instance | Select SqlInstance,IPAddress,Port
Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'DbaPort' -InputObject $DbaPort  -AutoCreateTable -KeepNulls
}

#Get-DbaTcpPort TPAPWSQLMHC006 | Select SqlInstance,IPAddress,Port


 