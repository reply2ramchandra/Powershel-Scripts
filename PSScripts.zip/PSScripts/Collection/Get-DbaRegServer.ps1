﻿import-module dbatools -EA SilentlyContinue
Get-DbaRegServer -SqlInstance TPAPWMSSQL002 -Group ProdAll | Select-Object Name