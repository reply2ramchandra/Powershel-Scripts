﻿#To obtain MS SQL Server application GUIDs on Windows
wmic product where "Name like '%SQL Server%'"  get Name,IdentifyingNumber 
##to uninstall specific GUID
wmic product where "Name like '%SQL Server 2012%'"  get Name,IdentifyingNumber
Start-Process "c:\Windows\system32\msiexec.exe" -ArgumentList "/x {26773F6F-E7B5-4F58-9347-0347C998BA7D}"