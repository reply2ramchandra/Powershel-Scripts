﻿Import-Module dbatools -EA SilentlyContinue
Get-DbaKbUpdate -Name KB5065865 | Save-DbaKbUpdate 
##Later copy it from Q:\