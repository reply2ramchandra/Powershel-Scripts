﻿# PowerShell script to generate CREATE INDEX scripts for all user indexes in a database

# Set your SQL Server and database details
clear
$serverName = "TPATWSQLHHA01"
$databaseName = "ClaimfactsReports"
$outputFile = "D:\Mask\AllIndexes.sql"

# Query to get index details
$query = @"
SELECT 
    sch.name AS SchemaName,
    t.name AS TableName,
    i.name AS IndexName,
    i.type_desc AS IndexType,
    i.is_unique,
    i.is_primary_key,
    i.is_unique_constraint,
    i.filter_definition,
    c.name AS ColumnName,
    ic.is_included_column,
    ic.is_descending_key
FROM sys.indexes i
INNER JOIN sys.tables t ON i.object_id = t.object_id
INNER JOIN sys.schemas sch ON t.schema_id = sch.schema_id
INNER JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
WHERE 
--i.is_primary_key = 0 AND i.is_unique_constraint = 0 AND 
i.type_desc <> 'HEAP'
ORDER BY sch.name, t.name, i.name, ic.key_ordinal
"@

# Run the query and group results by index
$indexData = Invoke-Sqlcmd -ServerInstance $serverName -Database $databaseName -Query $query -TrustServerCertificate

$grouped = $indexData | Group-Object SchemaName, TableName, IndexName

$scriptLines = @()

foreach ($idx in $grouped) {
    $first = $idx.Group[0]
    $schema = $first.SchemaName
    $table = $first.TableName
    $index = $first.IndexName
    $unique = if ($first.is_unique) { "UNIQUE " } else { "" }
    $filter = if ($first.filter_definition) { "WHERE $($first.filter_definition)" } else { "" }
    $indexType = if ($first.IndexType -eq "CLUSTERED") { "CLUSTERED" } else { "NONCLUSTERED" }

    $columns = $idx.Group | Where-Object { -not $_.is_included_column } | ForEach-Object {
        "$($_.ColumnName)$(if ($_.is_descending_key) { " DESC" } else { " ASC" })"
    } 
    $columnsJoined = $columns -join ", " #-join ", "

    $includes = $idx.Group | Where-Object { $_.is_included_column } | ForEach-Object {
        $_.ColumnName
    }

    $includeClause = if ($includes.Count -gt 0) { "INCLUDE ([{0}])" -f ($includes -join "], [") } else { "" }

    $scriptLines += "CREATE $unique$indexType INDEX [$index] ON [$schema].[$table] ($columnsJoined) $includeClause $filter;"
    $scriptLines += ""
}

# Output to file
$scriptLines | Set-Content -Path $outputFile -Encoding UTF8

Write-Host "Index scripts generated at $outputFile"