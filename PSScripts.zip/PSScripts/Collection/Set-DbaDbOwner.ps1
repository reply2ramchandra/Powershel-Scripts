﻿Import-Module dbatools -EA SilentlyContinue 
Set-DbaDbOwner -SqlInstance TPAPWACTSQL001
#Set-DbaDbOwner -SqlInstance sqlserver -Database db1, db2
