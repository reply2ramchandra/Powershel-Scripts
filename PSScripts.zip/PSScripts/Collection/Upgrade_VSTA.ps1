﻿
$server='TPAPWSQLDL006'
Invoke-Command -ComputerName $server -ScriptBlock {
Write-host "***upgrading VSTA***"
powershell.exe -command "& C:\patch\vsta_2022_setup_ENU-17.0.35906.exe /quiet "}


$server='TPAPWSQLSSRS-03'
Invoke-Command -ComputerName $server -ScriptBlock {
Write-host "***upgrading VSTA***"
powershell.exe -command "& C:\patch\vsta_2019_setup_ENU-16.0.35907.exe /quiet"}


$server='TPAPWSQLSSRS-03'
Invoke-Command -ComputerName $server -ScriptBlock {
Write-host "***upgrading VSTA***"
powershell.exe -command "& C:\patch\vsta_2017_setup_ENU-15.0.36010.exe /quiet"}
