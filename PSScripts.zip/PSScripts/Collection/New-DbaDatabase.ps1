﻿import-module dbatools -ErrorAction SilentlyContinue
New-DbaDatabase -SqlInstance localhost -Name DBA_Monitoring -DataFilePath 'M:\Data' -LogFilePath 'L:\SQLLog'
New-DbaLogin -SqlInstance localhost -Login grafana_user
Add-DbaDbRolemember -SqlInstance localhost -Member grafana_user -Role db_reader,db_writer -Database DBA_Monitoring