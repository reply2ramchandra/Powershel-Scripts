﻿clear
Import-Module dbatools -EA SilentlyContinue
Get-DbaMaxMemory -SqlInstance TPAPWSQLDL001
Get-DbaRegServer -SqlInstance sqlcluster | Get-DbaMaxMemory | Where-Object { $_.MaxValue -gt $_.Total }
<#
clear
Import-Module dbatools -EA SilentlyContinue
$instances=get-content "T:\Test\setmaxmem.txt"
foreach($instance in $instances)
{
Get-DbaMaxMemory -SqlInstance $instance}
#>

