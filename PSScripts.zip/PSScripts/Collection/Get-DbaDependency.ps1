﻿clear
Import-Module dbatools -ErrorAction SilentlyContinue
$table = (Get-DbaDatabase -SqlInstance TPAPWSQLDL001 -Database HPS_STAGE).tables | Where-Object Name -eq DIM_LEVEL_CASE_DETAIL
$table | Get-DbaDependency
