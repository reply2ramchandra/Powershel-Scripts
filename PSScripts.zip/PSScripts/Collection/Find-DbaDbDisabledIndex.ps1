﻿clear
Import-Module dbatools -EA SilentlyContinue
Find-DbaDbDisabledIndex -SqlInstance TPAPWSQLMHA001  -Database Harrington_Gateway_WIP -Debug
