﻿clear
Get-date
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -EA SilentlyContinue 
$dbscript= Get-ChildItem X:\SQLPostBuild\CIM\each
$dbscript=$dbscript.FullName
$instances=get-content "T:\Test\100924.txt"
foreach($instance in $instances)
{
$dbs=Get-DbaDatabase -SqlInstance $instance -ExcludeDatabase tempdb | Where-Object  {$_.Status -eq 'Normal'} | select name
foreach($db in $dbs.Name)
{
$CIM_Column=$instance | Invoke-DbaQuery -Database $db -File $dbscript
if($CIM_Column) {Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'CIM_Column' -InputObject $CIM_Column  -AutoCreateTable -KeepNulls}
} #1
} #2
Get-date