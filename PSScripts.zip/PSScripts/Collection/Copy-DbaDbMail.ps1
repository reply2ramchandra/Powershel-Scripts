﻿Import-Module dbatools -EA SilentlyContinue 
Copy-DbaDbMail -Source TPAPWSQLGNXTA01 -Destination TPAPWSQLGNXTB01
