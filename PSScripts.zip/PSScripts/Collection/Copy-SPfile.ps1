﻿$server='PRODSQL2K802'
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="C:\patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}
#copy patch file
##change the path according to ISO file version
$isofile= Get-ChildItem X:\SQLISO\SP -Filter '*2014SP3*.exe' 
$source=$isofile.FullName  
$target="C:\patch"
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $source -Destination $target -ToSession $s
#Check drive free space
Import-Module dbatools -EA SilentlyContinue 
Get-DbaDiskSpace $server 