﻿Import-Module dbatools -EA SilentlyContinue
Get-DbaDatabase -SqlInstance TPATWSQLMHCA01 -Database tempdb | Get-DbaDbFileGrowth | Select-Object SqlInstance, Database, File, FileName, GrowthType, @{Name="GrowthMB";Expression={"{0:N2}" -f ($_.Growth / 1024)}}
#Get-DbaDbFileGrowth -SqlInstance sql2017, sql2016, sql2012 -Database pubs

clear
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -EA SilentlyContinue
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "Truncate table [CMS].[dbo].[Dbgrowth]" 
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] where Status IN ('Y') and category='Prod'" #-TrustServerCertificate
$servers | Select-Object SqlInstance, @{n='Length';e={$_.SqlInstance.Length}} |  Sort-Object Length -Descending
foreach($Instance in $servers.SqlInstance)
{
$Dbgrowth=Get-DbaDatabase -SqlInstance $Instance -ExcludeSystem -Status Normal | Get-DbaDbFileGrowth | Select @{n='DateKey';e={(Get-Date).GetDateTimeFormats()[46]}}, SqlInstance, Database, File, FileName, GrowthType, @{Name="GrowthMB";Expression={"{0:N2}" -f ($_.Growth / 1024)}}
Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'Dbgrowth' -InputObject $Dbgrowth  -AutoCreateTable -KeepNulls 
}


