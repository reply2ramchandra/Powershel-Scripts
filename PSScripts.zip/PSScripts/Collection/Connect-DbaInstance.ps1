﻿Import-Module dbatools -EA SilentlyContinue 
$instance=Find-DbaInstance -ComputerName TPATWSQLSSRS02 
if($instance) { foreach($sqlinstance in $instance.SqlInstance){  Connect-DbaInstance $sqlinstance }}
 <#
 Find-DbaInstance -ComputerName TPAPWSQLARCHNO
 Connect-DbaInstance TPAPWSQLARCHNO
 #>
