﻿Import-Module dbatools -DisableNameChecking
Get-DbaAgentOperator -SqlInstance tpapwsqldl001
Copy-DbaAgentOperator -Source tpapwsqldl001 -Destination tpapwdwsql004 -Operator SQL_ICT_DL # -WhatIf -Force

#New-DbaAgentOperator -SqlInstance TPAPWDWSQL004 -Operator ICT_DL_SQL -EmailAddress "ict-whps1@wipro.com;WHPS-Datalink-Internal@wipro.com;WHPS-MSSQL-Admins@wipro.com" 