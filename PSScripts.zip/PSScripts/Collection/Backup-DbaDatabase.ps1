﻿Import-Module dbatools -EA SilentlyContinue 
$BackupDirectory='\\hps-tpa-vast.hps.hph.ad\SqlNonProd\TPAQWSQLDL002'
if (!(Test-Path $BackupDirectory)) { mkdir $BackupDirectory -Force -ErrorAction Stop }
Backup-DbaDatabase -SqlInstance TPAQWSQLDL002 -Path $BackupDirectory -Database MSTR_MD_10_2_QUA -Type FULL -CompressBackup -CreateFolder

