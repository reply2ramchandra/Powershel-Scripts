﻿Import-Module dbatools -EA SilentlyContinue
$srv='TPAPWSQLSIP01'
Write-Host "Going to Deploy the Post Build Scripts " -ForegroundColor Cyan
$instance=Find-DbaInstance -ComputerName $srv | Select SqlInstance
$serverinstance=$instance.SqlInstance
$postscripts= Get-ChildItem X:\SQLPostBuild\Deploy
$postscripts=$postscripts.FullName 
foreach($deploy in $postscripts)
{
Write-host "Post Build Script Deployment is inprogress...." -ForegroundColor Yellow
$serverinstance | Invoke-DbaQuery -File $deploy -EnableException
}
Write-Host "Post Build completed. You may check your access now." -ForegroundColor Cyan
Start-Sleep -Seconds 3
#Restart the SQL Agent
Write-Host "Going to Restart the SQL Agent" -ForegroundColor Cyan
Start-Sleep -Seconds 3
$TargetServer=$srv
Get-DbaService $TargetServer | Where-Object  {$_.ServiceName -like '*SQLAgent$*' -or $_.ServiceName -eq 'SQLSERVERAGENT'}  | Restart-DbaService -Verbose

