﻿#$servers = "TPATWSQLHHA01","TPAPWSQLSTEL002","TPATWSQLQFILE01" ,"TPAPWPEDSQL001" 
$servers = "TPATWSQLQFILE01"
Invoke-Command -ComputerName $servers -ScriptBlock{Get-SmbShare | Where-Object {$_.Name  -notmatch ".+\$"} | Get-SmbShareAccess | Where-Object {$_.AccountName -eq "Everyone"} | ForEach-Object {  
    #Revoke-SmbShareAccess -name $_.name -AccountName $_.AccountName -Force
    }  
}
$servers = "TPATWSQLHHA01","TPAPWSQLSTEL002","TPATWSQLQFILE01" ,"TPAPWPEDSQL001" 
Invoke-Command -ComputerName $servers -ScriptBlock{Get-SmbShare | Where-Object {$_.Name  -notmatch ".+\$"} | Get-SmbShareAccess | Where-Object {$_.AccountName -eq "Everyone"}   
}
$servers = "TPAPWPEDSQL001"
Invoke-Command -ComputerName $servers -ScriptBlock{Get-SmbShare | Where-Object {$_.Name  -match "wwwroot"}  | Get-SmbShareAccess | select PSComputerName,AccountName,Name }

#Grant-SmbShareAccess -Name "nameoffolder" -AccountName "Contoso\Contoso-HV2$" -AccessRight Full
#$servers = "TPAPWPEDSQL001"
Invoke-Command -ComputerName $servers -ScriptBlock{
Grant-SmbShareAccess -Name "wwwroot" -AccountName "HPS\jcastendyk" -AccessRight Full}

#revoke Access
<#
$servers = "TPAPWPEDSQL001"
Invoke-Command -ComputerName $servers -ScriptBlock{Get-SmbShare | Where-Object {$_.Name  -notmatch ".+\$"} | Get-SmbShareAccess | Where-Object {$_.AccountName -eq "Everyone"} | ForEach-Object {  
    Revoke-SmbShareAccess -name $_.name -AccountName $_.AccountName -Force}  
}
#>
#New-SmbShare -Name "ISO" -Path "X:\SQLISO\SQL2022" -FullAccess "HPS\SG-MSSQL-ADM-PROD" -Description "ISO shared folder"
#Grant-SmbShareAccess -Name "ISO" -AccountName "HPS\a-sm58408" -AccessRight Full