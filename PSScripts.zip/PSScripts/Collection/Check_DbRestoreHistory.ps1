﻿#Get-DbaDbRestoreHistory -SqlInstance sql2014, sql2016 -Exclude db1
Import-Module dbatools 
Get-DbaDbRestoreHistory -SqlInstance TPAPWSQLTEST02\LCS -Database Tableau_Reporting

Import-Module dbatools
Get-DbaDbRestoreHistory -SqlInstance TPAPWSQLTEST02\LCS | FT -AutoSize
clear

Get-DbaDbRestoreHistory -SqlInstance TPAPWSQLTEST02\LCS -Since '2024-06-22 00:47:00'
