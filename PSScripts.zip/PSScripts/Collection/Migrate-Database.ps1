﻿##create a Directory
#$BackupDirectory='\\tpadd9300.healthplan.com\SQLBackups\CHG0080992' ###this is a path for NonProd
#make sure no system DB backup kept at backup directory, otherwise we can't do all db restore at one go
Import-Module dbatools -EA SilentlyContinue 
$BackupDirectory='\\tpadd9300.healthplan.com\SQLBackupsprod\CHG0086467'
if (!(Test-Path $BackupDirectory)) { mkdir $BackupDirectory -Force -ErrorAction Stop }
#Set DB readOnly and Take Backup
#Get-DbaDatabase -SqlInstance HPSSQL06\LCS -ExcludeSystem | Select ComputerName,Name,IsAccessible,SizeMB | FT -AutoSize
#Set-DbaDbState -SqlInstance PRODSQL2K803\PRODSQL2K803 -Database HPS_ODS,HPS_EDW,MSTR_MD_10_2_TEST,MSTR_STATS_10_2_TEST,HPS_RECONLINK,HPS_PBP,HPS_PPM,HPS_RECON -ReadOnly -Force 
#Set-DbaDbState -SqlInstance HPSSQL06\LCS -AllDatabases -ReadOnly -Force 
Start-Sleep -Seconds 5
Backup-DbaDatabase -SqlInstance TPAPWETRSQL002 -Path $BackupDirectory -ExcludeDatabase model,master,msdb -Type FULL -CompressBackup -CreateFolder

Backup-DbaDatabase -SqlInstance TPATWSQL004 -Path $BackupDirectory -Database HPS_ODS,HPS_EDW,MSTR_MD_10_2_TEST,MSTR_STATS_10_2_TEST,HPS_RECONLINK,HPS_PBP,HPS_PPM,HPS_RECON -Type FULL -CompressBackup -CreateFolder
##to take all DB backup using sql login
#$cred=Get-Credential test
#Backup-DbaDatabase -SqlInstance HPSSQL01\SQL01 -Path $BackupDirectory -SqlCredential $cred  -ExcludeDatabase model,master,msdb -Type FULL -CompressBackup -CreateFolder
#Restore Specific DB in Target Server
Import-Module dbatools -EA SilentlyContinue 
$BackupDirectory='\\tpadd9300.healthplan.com\SQLBackupsprod\CHG0086467'
$targetInstance='TPAPWSQLETB01' ##BE CAREFULL OF TARGET SERVERNAME
Restore-DbaDatabase -SqlInstance $targetInstance  -Path $BackupDirectory -DestinationDataDirectory M:\SQLData\ -DestinationLogDirectory L:\SQLLog\ -WithReplace
#restore all DBs in defualt DB path
#Restore-DbaDatabase -SqlInstance $targetInstance -Path $BackupDirectory -UseDestinationDefaultDirectories -WithReplace
#Set-DbaDbState -SqlInstance TPADWSQLDL001 -Database HPS_ODS,HPS_EDW,MSTR_MD_10_2_TEST,MSTR_STATS_10_2_TEST,HPS_RECONLINK,HPS_PBP,HPS_PPM,HPS_RECON -ReadWrite
Start-Sleep -Seconds 5
#FIX OrphanUser
Import-Module dbatools -EA SilentlyContinue 
Repair-DbaDbOrphanUser -SqlInstance TPAPWSQLETB01
Repair-DbaDbOrphanUser -SqlInstance $targetInstance -Database Callcenter,DManage_UAT,DOC_FULFILL_UAT,DocuHPS_DEV,Edify_Application_Test,FRED_DEV,FRED_UAT
Import-Module dbatools -EA SilentlyContinue 
Get-DbaLogin -SqlInstance TPAPWETRSQL002 | Out-GridView -Passthru | Copy-DbaLogin -Destination TPAPWSQLETB01
#remove user
<#
Remove-DbaLogin -SqlInstance $targetInstance -Login svc_RECONLINK_TEST
#Copy Login to Target from Source
Get-DbaLogin -SqlInstance GCPUWDWSQL004 | Out-GridView -Passthru | Copy-DbaLogin -Destination TPAUWSQLDL001
Copy-DbaLogin -Source PRODSQL2K803\PRODSQL2K803 -Destination TPAPWSQLTEL01\PRODSQL2K803 -Login SQLMSRW -force
#syn Permission

Sync-DbaLoginPermission -Source GCPUWDWSQL005 -Destination TPAUWSQLDL003 -Login svc_RECONLINK_PROD, svc_RECONLINK_TEST ,svc_recon_link
#>