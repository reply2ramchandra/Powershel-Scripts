﻿$mysql=get-Content "T:\Test\5724.txt"
$count=$mysql.Count
Write-Host "Total Host to check is : " $count -ForegroundColor Red
$chk=0
Import-Module dbatools -EA SilentlyContinue
foreach($server in $mysql)
{ 
$chk++
Get-DbaOperatingSystem -ComputerName $server | select ComputerName,OSVersion | FT -AutoSize
}
Write-Host "Verified Count:" $chk -ForegroundColor Green

<#
Import-Module dbatools -EA SilentlyContinue
Get-DbaOperatingSystem -ComputerName TPAPWSQLMHC007 | select ComputerName,OSVersion | FT -AutoSize
Get-DbaOperatingSystem -ComputerName TPAPWSQLMHC006 | select ComputerName,OSVersion | FT -AutoSize
#>