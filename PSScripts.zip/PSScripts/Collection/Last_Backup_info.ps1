﻿Import-Module dbatools -DisableNameChecking 
$servers=Get-Content "D:\PSScripts\dashboard\Monitoring_scripts\serverlist.txt"
$pulltime=(Get-Date).ToUniversalTime()
Start-Transcript -Path D:\PSScripts\dashboard\Logs\LastBackup_Info.txt -Append
foreach($server in $servers)
{
Write-host 'Getting LastBackup_Details details for' $server -ForegroundColor Green
Get-DbaLastBackup -SqlInstance $server | Select-Object  ComputerName,InstanceName,Database,LastFullBackup,LastDiffBackup,LastLogBackup,Status,@{Name='SinceFull';Expression={[string] $_.SinceFull}},@{Name='Pulltime';Expression={$pulltime}}`
 | Write-DbaDataTable -SqlInstance tpapwmssql002 -Table LastBackup_Details -Database CMS -AutoCreateTable
Write-host 'LastBackup_Details capturing completed for' $server -ForegroundColor Green
}
Stop-Transcript