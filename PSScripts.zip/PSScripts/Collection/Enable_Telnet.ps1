﻿Enable-WindowsOptionalFeature -Online -FeatureName TelnetClient
#Disable-WindowsOptionalFeature -Online -FeatureName TelnetClient