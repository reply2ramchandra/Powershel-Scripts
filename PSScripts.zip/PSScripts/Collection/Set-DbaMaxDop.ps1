﻿Import-Module dbatools -EA SilentlyContinue
Test-DbaMaxDop -SqlInstance HPSSQL04\SQL04 | Set-DbaMaxDop