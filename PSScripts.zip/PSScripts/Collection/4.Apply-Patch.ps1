﻿##THIS file is subject to change as required over time ###
  ### DON'T CHANGE/MODIFY this Script without Sathiya's  Notice please ####
 #############################
#Read-HostSpecial Function
#############################

Function Read-HostSpecial {
      [cmdletbinding(DefaultParameterSetName="_All")]
      Param(
            [Parameter(Position = 0,Mandatory,HelpMessage = "Enter prompt text.")]
            [Alias("message")]
            [ValidateNotNullorEmpty()]
            [string]$Prompt,
            [Alias("foregroundcolor","fg")]
            [consolecolor]$PromptColor,
            [string]$Title,
            [Parameter(ParameterSetName = "SecureString")]
            [switch]$AsSecureString,
            [Parameter(ParameterSetName = "Set")]
            [ValidateNotNullorEmpty()]
            [string[]]$ValidateSet
      )

Write-Verbose "Starting: $($MyInvocation.Mycommand)"
Write-Verbose "Parameter set = $($PSCmdlet.ParameterSetName)"
Write-Verbose "Bound parameters $($PSBoundParameters | Out-String)"

#combine the Title (if specified) and prompt
$Text = @"
$(if ($Title) {
"$Title`n$("-" * $Title.Length)"
})
$Prompt
"@

 If ($title.length -eq "0"){
      $Object = $Prompt
}
Else {
      $Object = $Text
}


#create a hashtable of parameters to splat to Write-Host
$paramHash = @{
      NoNewLine = $True
      Object = $Object
}

If ($PromptColor) {
    $paramHash.Add("Foregroundcolor",$PromptColor)
}

#display the prompt
Write-Host @paramhash
#get the value
If ($AsSecureString) {
    $r = $host.ui.ReadLineAsSecureString()
}
Else {
  #read console input
  $r = $host.ui.ReadLine()
}

#assume the input is valid unless proved otherwise
$Valid = $True

If ($Valid) {
    Write-Verbose "Writing result to the pipeline"
    #any necessary validation passed
    $r
}
Write-Verbose "Ending: $($MyInvocation.Mycommand)"
}

 Import-Module dbatools -EA SilentlyContinue
$srv=Read-HostSpecial "Enter Correct Host Name:" -PromptColor Green
$server=$srv
 Write-Host "Hope you have copied the SQL patch file already!." -ForegroundColor Yellow
$ver=Read-HostSpecial "Select the SQL Version to apply latest patch: Enter 2022 or 2019 or 2017:" -PromptColor cyan
$con=Read-HostSpecial "Would like to proceed with SQL Patch. Press Y or N to continue." -PromptColor Green
If($con -eq "Y" -or $con -eq "y")
{ 
if($ver -eq "2022") {
Import-Module dbatools -EA Sile
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -KB 5048033 -Restart -Path C:\patch -Confirm:$false}
elseif($ver -eq "2019"){
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -KB 5046860 -Restart -Path C:\patch -Confirm:$false}
elseif($ver -eq "2017"){
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -KB 5046858 -Restart -Path C:\patch -Confirm:$false}
else { Write-Host "Sorry, Check the SQL patch version # and try other option." -ForegroundColor Yellow } }
Else { Write-Host "Terminating without Patching!." -ForegroundColor Yellow
break }