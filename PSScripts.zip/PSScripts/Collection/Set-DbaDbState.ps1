﻿Import-Module dbatools -DisableNameChecking 
Set-DbaDbState -SqlInstance HPSSQL01\SQL01 -Database ABC -Offline
#Set-DbaDbState -SqlInstance TPATWGN2SQL001\IHGN2T01  -AllDatabases -Exclude ABC -ReadOnly -Force
#Set-DbaDbState -SqlInstance TPATWGN2SQL001\IHGN2T01 -Database BATaskSystem ,IWSData -ReadOnly -Force 
Get-DbaDbState -SqlInstance TPAPWSQLHH004 | Where-Object RW -eq 'READ_ONLY' | Set-DbaDbState -ReadWrite
Get-DbaDbState -SqlInstance TPAPWSQLSTEL002 | Where-Object RW -eq 'READ_ONLY' | Set-DbaDbState -ReadWrite
Get-DbaDbState -SqlInstance sql2016 | Where-Object Status -eq 'Offline' | Set-DbaDbState -Online
Set-DbaDbState -SqlInstance sqlserver2014a -Database AB -SingleUser -Force

