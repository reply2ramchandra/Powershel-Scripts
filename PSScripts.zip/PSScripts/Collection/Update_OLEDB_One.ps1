﻿##OLEDB
###https://msrc.microsoft.com/update-guide/en-US/advisory/CVE-2024-28906
#Microsoft OLE DB Driver 19 for SQL Server version prior 19.3.5
#Microsoft OLE DB Driver 18 for SQL Server version prior 18.7.4

clear-host
$server='TPAPWO365SQL001'
 Invoke-Command -ComputerName $server -ScriptBlock {
$regpath="HKLM:\SOFTWARE\Microsoft\MSOLEDBSQL" 
$oledbversion=Get-ItemProperty -Path $regpath -ErrorAction Ignore
$ver=$oledbversion.InstalledVersion
if($ver){
Write-Host "Existing OLEDB Version" $ver -ForegroundColor Green -NoNewline
write-host " " -ForegroundColor Green -NoNewline }
Else { write-host "NO OLEDB18 UPDATE is Required " -ForegroundColor Yellow -NoNewline }
hostname 
$regpath="HKLM:\SOFTWARE\Microsoft\MSOLEDBSQL19" 
$oledbversion=Get-ItemProperty -Path $regpath -ErrorAction Ignore
$ver19=$oledbversion.InstalledVersion
if($ver19){
Write-Host "Existing OLEDB Version" $ver19 -ForegroundColor Green -NoNewline
write-host " " -ForegroundColor Green -NoNewline }
Else { write-host "NO OLEDB19 UPDATE is Required " -ForegroundColor Yellow -NoNewline }
hostname}
<#
if($ver -ne "18.6.7.0")
{ 
Write-Host "Server Name:"
hostname
Write-Host "Need a OLEDB update " -ForegroundColor Red
}
#>

#CREATE A FOLDER ON SERVER
$targetpatchfolder="C:\patch"
$server="TPAPWO365SQL001"
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="C:\patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}


#copy OLEDB 18 file as 
$server="TPAPWO365SQL001"
$patchfile= Get-ChildItem D:\OLEDB_ODBC -Filter '*oledb*18.7.*.msi' 
$source=$patchfile.FullName 
$target='C:\patch'
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $source -Destination $target -ToSession $s -Force 
Start-Sleep -Seconds 2

$server="TPAPWO365SQL001"
Invoke-Command -ComputerName $server -ScriptBlock {
powershell.exe -command "& msiexec /quiet /passive /qn /i c:\patch\msoledbsql-18.7.4.msi IACCEPTMSOLEDBSQLLICENSETERMS=YES"
 } 

#copy OLEDB 19 file as $server="TPAPWSQLDL001"
$server="TPAPWSQLDL001"
$patchfile= Get-ChildItem D:\OLEDB_ODBC -Filter '*oledb*19.3.3*.msi' 
$source=$patchfile.FullName 
$target='C:\patch'
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $source -Destination $target -ToSession $s 


$server="TPAPWSQLDL001"
Invoke-Command -ComputerName $server -ScriptBlock {
powershell.exe -command "& msiexec /quiet /passive /qn /i C:\patch\msoledbsql-19.3.3.msi IACCEPTMSOLEDBSQLLICENSETERMS=YES"
 } 

