﻿clear
Import-Module dbatools -EA SilentlyContinue 
$SqlServers = Invoke-Sqlcmd -Query " SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] Where [Status] IN('Y','P') and HostName NOT IN('PCIPWSQL001');" -ServerInstance "tpapwmssql002"  -TrustServerCertificate 
foreach($SQL_server in $SqlServers.SqlInstance)
 {
             
        Write-Host  " Connected to Server $SQL_server  " -BackgroundColor Magenta
       
         $ServicestatusQuery = Invoke-Sqlcmd -Query "EXEC sp_validatelogins;" -ServerInstance $SQL_server -TrustServerCertificate
         $cnt=$ServicestatusQuery.Count
        if($cnt -ne 0 -and $cnt -ne $null)
        {
        Invoke-Sqlcmd -Query "INSERT INTO CMS.Security.InValidLogin ([NT Login]) Values('$SQL_Server'); " -ServerInstance tpapwmssql002 -TrustServerCertificate
        Write-DbaDataTable -SqlInstance tpapwmssql002 -Database CMS -Schema 'Security' -Table 'InValidLogin' -InputObject $ServicestatusQuery -Verbose 
        }
 }