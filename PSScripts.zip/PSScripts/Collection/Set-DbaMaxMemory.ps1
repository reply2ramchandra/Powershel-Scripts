﻿Import-Module dbatools -EA SilentlyContinue
Set-DbaMaxMemory -SqlInstance PRODSQL2K803\PRODSQL2K803 -Max 24600

