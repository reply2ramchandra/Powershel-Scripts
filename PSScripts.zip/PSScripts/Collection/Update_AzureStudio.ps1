﻿#Update AzureStudio 
$server="TPAPWSQLMHC009"
Invoke-Command -ComputerName $server -ScriptBlock {
powershell.exe -command "& C:\patch\azuredatastudio-windows-arm64-setup-1.51.1.exe /VERYSILENT /MERGETASKS=!runcode"}