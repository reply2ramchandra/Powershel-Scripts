﻿ #create a Folder
$server='tpapwdwsql004'
 Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="C:\tmp\mysql"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}
$mysqlconnector= Get-ChildItem X:\MySQL\MySQL_Dot_Net_Connector -Filter '*9.3.*.msi'
#$mysqlconnector= Get-ChildItem X:\MySQL\MySQL_ODBC_Drivers -Filter '*9.3.*.msi' 
$mysqlconnector=$mysqlconnector.FullName
$target="C:\tmp\mysql"
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $mysqlconnector -Destination $target -ToSession $s -Force