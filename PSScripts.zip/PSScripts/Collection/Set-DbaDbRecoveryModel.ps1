﻿Import-Module dbatools -EA SilentlyContinue
clear
# List of source SQL Server instances
$sourceInstances = get-content "T:\Test\admin_recovery.txt"
foreach($Instance in $sourceInstances)
{
Get-DbaDatabase -SqlInstance $Instance -Database Admin | Set-DbaDbRecoveryModel -RecoveryModel SIMPLE  -Confirm:$false
}
#Get-DbaDbRecoveryModel -SqlInstance TPAUWDWSQL005 -RecoveryModel FULL -ExcludeDatabase master,model,msdb,tempdb | Set-DbaDbRecoveryModel -RecoveryModel Simple  -Confirm:$false