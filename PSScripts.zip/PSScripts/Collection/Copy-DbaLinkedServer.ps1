﻿Import-Module dbatools -EA SilentlyContinue 
Get-DbaLinkedServer TPAQWDWSQL004 | select Name
Copy-DbaLinkedServer -Source TPAQWDWSQL004 -Destination TPAQWSQLDL001 -LinkedServer prodsql2k804,TPATWSQL004,TPAQWDWSQL005 -Force
