# Install the ReportingServicesTools module if not already installed
# Install-Module -Name ReportingServicesTools -Force

# Define SSRS Report Server URL
$reportServerUri = "http://localhost/ReportServer"  # Change to your SSRS URI

# Create proxy to interact with SSRS
$proxy = New-RsWebServiceProxy -ReportServerUri $reportServerUri

# Define backup destination folder
$backupFolder = "C:\SSRS_Backup"

# Create folder if it doesn't exist
if (!(Test-Path -Path $backupFolder)) {
    New-Item -ItemType Directory -Path $backupFolder
}

# Export all items from the root folder ("/") recursively
Out-RsFolderContent -Proxy $proxy -RsFolder "/" -Destination $backupFolder -Recurse

Write-Host "SSRS backup completed. Files saved to $backupFolder"