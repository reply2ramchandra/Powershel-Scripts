﻿### DON'T CHANGE/MODIFY this Script without Sathiya's  Notice please ####
##Check Patch file number once before run ##
##verify the Database directory exist and set properly ##
 clear-host
 #############################
#Read-HostSpecial Function
#############################

Function Read-HostSpecial {
      [cmdletbinding(DefaultParameterSetName="_All")]
      Param(
            [Parameter(Position = 0,Mandatory,HelpMessage = "Enter prompt text.")]
            [Alias("message")]
            [ValidateNotNullorEmpty()]
            [string]$Prompt,
            [Alias("foregroundcolor","fg")]
            [consolecolor]$PromptColor,
            [string]$Title,
            [Parameter(ParameterSetName = "SecureString")]
            [switch]$AsSecureString,
            [Parameter(ParameterSetName = "Set")]
            [ValidateNotNullorEmpty()]
            [string[]]$ValidateSet
      )

Write-Verbose "Starting: $($MyInvocation.Mycommand)"
Write-Verbose "Parameter set = $($PSCmdlet.ParameterSetName)"
Write-Verbose "Bound parameters $($PSBoundParameters | Out-String)"

#combine the Title (if specified) and prompt
$Text = @"
$(if ($Title) {
"$Title`n$("-" * $Title.Length)"
})
$Prompt
"@

 If ($title.length -eq "0"){
      $Object = $Prompt
}
Else {
      $Object = $Text
}


#create a hashtable of parameters to splat to Write-Host
$paramHash = @{
      NoNewLine = $True
      Object = $Object
}

If ($PromptColor) {
    $paramHash.Add("Foregroundcolor",$PromptColor)
}

#display the prompt
Write-Host @paramhash
#get the value
If ($AsSecureString) {
    $r = $host.ui.ReadLineAsSecureString()
}
Else {
  #read console input
  $r = $host.ui.ReadLine()
}

#assume the input is valid unless proved otherwise
$Valid = $True

If ($Valid) {
    Write-Verbose "Writing result to the pipeline"
    #any necessary validation passed
    $r
}
Write-Verbose "Ending: $($MyInvocation.Mycommand)"
} #end function

clear-host
$strtime=Get-Date
Write-Host "Start time : $strtime" -ForegroundColor Yellow
write-host "Welcome you to Upgrade the SQL Server to SQL 2022.Ensure you attempt at correct HOST." -backgroundColor Cyan
$srv=Read-HostSpecial "Enter Correct Host Name:" -PromptColor Green
$server=$srv
##collect OS version
Import-Module dbatools -EA SilentlyContinue
$osver=Get-DbaOperatingSystem -ComputerName $server | select OSVersion
$osver=$osver.OSVersion
write-host "OS version of the $server : $osver" -foregroundcolor Yellow
Write-Host "****IF OS VERSION < 2019 , MAKE SURE .NET VERSION 4.7 AND ABOVE EXIST ON THE SERVER*** " -ForegroundColor Green

##Copy Software
<#
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="D:\SQL\Software"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}}
#copy SOFTWARE/PATCH file
##change the path according to ISO file version##
$isofile= Get-ChildItem X:\SQLISO\SQL2022 -Filter '*_Ent_*2022*.ISO' 
$patchfile= Get-ChildItem X:\SQLISO\CU -Filter '*2022*.exe'
$source=$isofile.FullName 
$patch=$patchfile.FullName 
$target="D:\SQL\Software"
$user =  [Environment]::username
$cred=Get-Credential $user
$s = New-PSSession -ComputerName $server -Credential $cred
write-Host "Wait...Copying Software." -ForegroundColor Cyan
Copy-Item -Path $source -Destination $target -ToSession $s -Force -ErrorAction SilentlyContinue
Copy-Item -Path $patch -Destination $target -ToSession $s -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 5 
Write-Host " Software Copy should have been completed now !" -ForegroundColor green
#>
Import-Module PendingReboot -EA SilentlyContinue
$pr=Test-PendingReboot -ComputerName $server -SkipConfigurationManagerClientCheck
if($pr.IsRebootPending -eq $true){
Write-Host "Found Server reboot is pending . Let's Reboot the Server." -ForegroundColor cyan 
Restart-Computer $server -Force
write-host "Server Reboot is inprogress. Wait for 3 minutes!" -ForegroundColor Yellow
Start-Sleep -seconds 180 
##wait for server comes online

$check=Test-NetConnection -ComputerName $server | select PingSucceeded
$check=$check.PingSucceeded
if($check -eq $True){write-host "Server is back online.!" -ForegroundColor Green}
else { 
write-host "Check why server reboot is taking longer time. And try SQL Upgrade Later!" -ForegroundColor Green
break} }

#Upgrade function

function Upgrade ($a,$b) {

   powershell.exe -command "& $a/setup.exe /action=upgrade /instancename=$b /quiet /UpdateEnabled=0 /IAcceptSQLServerLicenseTerms"
      return " Upgrade attempt is Done"
}

function Mount-ISO {
    param (
        [string]$server
    )
 Invoke-Command -ComputerName $server -ScriptBlock {
 $binarypath="D:\SQL\Software"
 $isoImg = Get-ChildItem -Path $binarypath -Recurse -Filter "*.ISO"
 if($isoImg -ne $null) {write-Host "Wait...Mounting ISO" -ForegroundColor Cyan}
 $isoImg=$isoImg.FullName
 $diskImg = Mount-DiskImage -ImagePath $isoImg 
 # Get mounted ISO volume
 $mountvol = (Get-DiskImage -DevicePath \\.\CDROM1 | Get-Volume).DriveLetter
  write-Host "SQLServerSetup Drive is:" $mountvol } }
 Mount-ISO -server $server
#Setup Drive Letter
 $SetupDrive=Read-HostSpecial "Enter a Setup Drive Letter , else PRESS 1 for remount ISO:" -PromptColor Cyan
#Replace correct Drive Letter
 
  if ($SetupDrive -ne 1) { 
  $mountvol=$SetupDrive+":"
    }
 Else { Mount-ISO -server $server}
 #start SQL upgrade
 Import-Module dbatools -EA SilentlyContinue
 $Instance = Find-DbaInstance -ComputerName $server
 $ins=$Instance.InstanceName
 $confirm=Read-HostSpecial "Want to Start the Upgrade: PRESS Y or N:" -PromptColor Cyan
 $confirm=$confirm.ToUpper()
if($confirm -eq 'Y'){ Invoke-Command -ComputerName $server -ScriptBlock ${function:upgrade} -ArgumentList $mountvol,$ins}
Else
{ break}

Start-Sleep -Seconds 5
#Start SQL patch
$target="D:\SQL\Software"
Import-Module dbatools -EA SilentlyContinue
Update-DbaBuildReference
Update-DbaInstance -ComputerName $server -KB 5050771 -Restart -Path $target -Confirm:$false
Start-Sleep -Seconds 10
#update CMS

$server | Get-DbaService | Start-DbaService
Start-Sleep -Seconds 5
$SQL=Find-DbaInstance -ComputerName $server | Select SqlInstance
$SQL=$SQL.SqlInstance
if($SQL){
$patch = Invoke-DbaQuery -SqlInstance $SQL -Database master -Query "SELECT CONVERT(varchar(9), SERVERPROPERTY('productversion')) as BuildNumber,CONVERT(varchar(9), SERVERPROPERTY('productlevel')) as SPLevel, CONVERT(varchar(9), SERVERPROPERTY('ProductUpdateLevel')) as CULevel" 
$build=$patch.BuildNumber
$sp=$patch.SPLevel
$cu=$patch.CULevel
Invoke-DbaQuery -SqlInstance TPAPWMSSQL002 -Database CMS -Query "Update dbo.DBServer SET BuildNumber='$build',SPLevel='$sp', CULevel='$cu' where SqlInstance='$SQL'" 
Invoke-DbaQuery -SqlInstance TPAPWMSSQL002 -Database CMS -Query "Update dbo.DBServer SET MajorVersion='SQL Server 2022' where SqlInstance='$SQL'" }
else { write-host ' CHECK if SQL Server is up and running fine ' -ForegroundColor Yellow}
Start-Sleep -Seconds 2
##unmount ISO
Invoke-Command -ComputerName $server -ScriptBlock {
$binarypath="D:\SQL\Software"
 $isoImg = Get-ChildItem -Path $binarypath -Recurse -Filter "*.ISO"
 $isoImg=$isoImg.FullName
 if($isoImg -ne $null){ DisMount-DiskImage -ImagePath $isoImg
 write-Host "Trying UnMount ISO is Done!" -ForegroundColor Cyan }
 }
 if($build -like "16.0*")
 {
#cleanup binary
    Invoke-Command -ComputerName $Server -ScriptBlock { 
       $path='D:\SQL\Software'
       Remove-Item -Path $path -Recurse -Force -Verbose
       write-host ' SQL Binary Cleanup is Done! ' -ForegroundColor Yellow
       } }
$endtime=Get-Date
Write-Host "End time : $endtime" -ForegroundColor Green
