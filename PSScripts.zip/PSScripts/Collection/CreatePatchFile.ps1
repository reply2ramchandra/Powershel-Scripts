﻿#create patch file
#replace the -KB value with specific value
# 2012 -KB 5021123; 2014 -KB 5029185 ; 2016 -KB 5046062 ; 2017 -KB 5046858 ; 2019 -KB 5063757 ; 2022 -KB 5063814 
$servers=Get-Content 'T:\test\522.txt'
#$servers.count
foreach($server in $servers){
New-Item -Path "D:\PSScripts\patch\2022\$server.ps1" -ItemType File -Force
Start-Sleep -Seconds 2
Set-Content -Path "D:\PSScripts\patch\2022\$server.ps1" -Value "Import-Module dbatools -EA SilentlyContinue
Update-DbaBuildReference
Update-DbaInstance -ComputerName $server -KB 5054531 -Restart -Path C:\patch -Confirm:`$false"}

#Call all patch file
1..6 | % { Start-Process powershell_ise.exe -verb runas }
