﻿$SQLServerInstance = "TPAUWSQLDL001"
  $SSISCatalogPassword = "AUPa**w03d"
  $SQLServerConnectionString = "Data Source=$SQLServerInstance;Initial Catalog=master;Integrated Security=SSPI;"
  # Pre-Requisite - Enable CLR before creating catalog
  #Connect to SQL server and enable CLR, if this is not already enabled
  Write-Host "Enabling CLR on the SQL Server ...."
  $SQLServer = New-Object Microsoft.SQLServer.Management.SMO.Server $SQLServerInstance
  $configuration = $SQLServer.Configuration
  $CLRValue = $SQLServer.Configuration.IsSqlClrEnabled
  Write-Host $CLRValue.ConfigValue
  If ($CLRValue.ConfigValue -eq 0)
  {
      Write-Host "Enabling CLR on the server $SQLServerInstance"
      $CLRValue.ConfigValue = 1
      $configuration.Alter()
      Write-Host "CLR enabled on the server $SQLServerInstance successfully"
  }
  # Loading IntegrationServices Assembly .........
  [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Management.IntegrationServices") | Out-Null;
  # Store the value of IntegrationServices Assembly name in a string
  # This will avoid to re type the same string again and again
  $SSISNamespace = "Microsoft.SqlServer.Management.IntegrationServices"
  Write-Host "Trying to connect SQL Server...."
  # Create SQL Server connection based on the connection string
  $SQLServerConnection = New-Object System.Data.SqlClient.SqlConnection $SQLServerConnectionString
  Write-Host "SQL Server connection has been enabled successfully"
  # Create Integration Services object based on the SQL Server connection
  Write-Host "Trying to create a object for Integration Service...."
  $IntegrationServices = New-Object $SSISNamespace".IntegrationServices" $SQLServerConnection
  Write-Host "Integration service object has been created successfully"
  Write-Host "Dropping existing SSIS Catalog on the server $SQLServerInstance"
  # Drop the existing catalog if it exists
  if ($IntegrationServices.Catalogs.Count -gt 0)
  {
      Write-Host "Warning !, all the SSIS projects and Packages will be dropped...."
      $IntegrationServices.Catalogs["SSISDB"].Drop()
      Write-Host "Existing SSIS Catalog has been dropped successfully ."
  }
  Write-Host "Creating SSIS Catalog on the server $SQLServerInstance"
  $SSISCatalog = New-Object $SSISNamespace".Catalog" ($IntegrationServices, "SSISDB", $SSISCatalogPassword)
  $SSISCatalog.Create()
  Write-Host "SSIS Catalog has been created successfully on the server $SQLServerInstance"
  $SSISFolder = "X:\test"
  # Look for SSIS ISPAC file (with extension .ISPAC) and return the 
  # name of the SSIS ISPAC file and the directory full path
  $SSISISPACFiles = Get-ChildItem $SSISFolder -Recurse -Filter "*.ispac"
  Foreach ($SSISISPACFile in $SSISISPACFiles)
  {
      #Name of the SSIS ISPAC file , will be used to create SSIS folder
      $SSISFolerName = $SSISISPACFile.BaseName;
      #The name of the directory will be used to locate the ISPAC file
      $SSISDirectory = $SSISISPACFile.FullName;
      Write-Host "Creating the directory $SSISFolerName in the SSIS Catalog........"
      $SSISFolderInCatalog = New-Object $SSISNamespace".CatalogFolder" ($SSISCatalog, $SSISFolerName, $SSISFolerName)
      $SSISFolderInCatalog.Create()
      Write-Host "The directory $SSISFolerName has been successfully created in the SSIS Catalog........"
      #Build the ISPAC file path from the SSIS directory path
      $ISPACFilePath = $SSISISPACFile.FullName
      
      Write-Host "Deploying " $SSISFolerName " project ..."
      # the ISPAC file will be read into a variable for deployment
      [byte[]]$ISPACFile = [System.IO.File]::ReadAllBytes($ISPACFilePath)
      $SSISFolderInCatalog.DeployProject($SSISFolerName, $ISPACFile)
      Write-Host $SSISFolerName " project has been deployed successfully"}