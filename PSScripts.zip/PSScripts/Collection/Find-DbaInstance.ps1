﻿Import-Module dbatools -EA SilentlyContinue  
Find-DbaInstance -ComputerName TPAPWO365SQL001 
Get-DbaProductKey -ComputerName TPASWSQLDL001 ##check for Edition and Version
Test-DbaBuild -SqlInstance TPAPWANALYTIC01 -Latest ##check for existing sql build #