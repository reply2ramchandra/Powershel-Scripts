﻿Import-Module dbatools -DisableNameChecking 
New-DbaLogin -SqlInstance $instance -Login HPS\svc_splunkdb
#New-DbaDbUser -SqlInstance sqlserver2014 -Database DB1 -Login HPS\svc_splunkdb
#New-DbaDbUser -SqlInstance sqlserver2014 -ExcludeDatabase master,model,msdb,tempdb -Login HPS\svc_splunkdb
Add-DbaDbRoleMember -SqlInstance $instance -Role db_datareader -User HPS\svc_splunkdb