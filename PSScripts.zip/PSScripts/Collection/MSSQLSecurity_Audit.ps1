﻿<#*************************************************************

Description - This is for AUdit Purpose, this script will pull the login information of all Active Servers in HPS Doamin.

Stage-01 :  This stage will gather login information on all Active Servers and Store it into a table.
Stage-02 :  This stage will dump the above gathered login information into a Excel.
Stage-03 :  This stage will reports the data to DBA team.(Email Trigger)

*************************************************************#>
<# ==============================================================================================================================================================================
                                                                                  STAGE -  01 
                                                   This stage will gahter login information on all Active Servers and Store it into a table.
   ==============================================================================================================================================================================#>
Import-Module dbatools -EA SilentlyContinue 
$Query = " Select DEFAULT_DOMAIN()[DomainName],
@@Servername AS ServerName,loginname,createdate,CONVERT(VARCHAR(23),GETDATE(),120) AS RecCreatedDate  from 
sys.syslogins; "

$SqlServers = Invoke-Sqlcmd -Query " SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] Where [Status] IN('Y','P') and HostName<>'PCIPWSQL001' " -ServerInstance "tpapwmssql002"  -TrustServerCertificate 

foreach($SQL_server in $SqlServers.SqlInstance)
{
             
        Write-Host  " Connected to Server $SQL_server  " -BackgroundColor Magenta
         $ServicestatusQuery = Invoke-Sqlcmd -Query $Query -ServerInstance $SQL_server -TrustServerCertificate
        Write-DbaDataTable -SqlInstance tpapwmssql002 -Database CMS -Schema 'Security' -Table 'SecurityAudit_temp' -InputObject $ServicestatusQuery -Verbose -AutoCreateTable

}

Invoke-Sqlcmd -Query " ALTER TABLE [CMS].[Security].[SecurityAudit_temp] ADD RunID INT ; " -ServerInstance "tpapwmssql002" -TrustServerCertificate
##create SecurityAudit table if does not exist for first time
<#
USE CMS
CREATE TABLE [Security].[SecurityAudit](
	[DomainName] [nvarchar](max) NULL,
	[ServerName] [nvarchar](max) NULL,
	[loginname] [nvarchar](max) NULL,
	[createdate] [datetime2](7) NULL,
	[RecCreatedDate] [nvarchar](max) NULL,
	[RunID] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

$RunIDUpdate = "UPDATE [CMS].[Security].[SecurityAudit_temp] SET [RunID]=1"
#>
#enable this from second run onwards
$RunIDUpdate = " DECLARE @NoOfLoops INT;
Set @NoOfLoops = (Select MAX(ISNULL(RunID,0)) FROM [CMS].[Security].[SecurityAudit])
SET @NoOfLoops = @NoOfLoops + 1;
select @NoOfLoops
UPDATE [CMS].[Security].[SecurityAudit_temp] SET [RunID] = @NoOfLoops "



Invoke-Sqlcmd -Query $RunIDUpdate -ServerInstance "tpapwmssql002" -TrustServerCertificate
Invoke-Sqlcmd -Query "DELETE FROM [CMS].[Security].[SecurityAudit_temp] WHERE loginname like '##%'; " -ServerInstance "tpapwmssql002" -TrustServerCertificate
Invoke-Sqlcmd -Query "DELETE FROM [CMS].[Security].[SecurityAudit_temp] WHERE loginname like 'NT %'; " -ServerInstance "tpapwmssql002" -TrustServerCertificate
Invoke-Sqlcmd -Query "INSERT INTO [CMS].[Security].[SecurityAudit] Select * from [CMS].[Security].[SecurityAudit_temp]; " -ServerInstance "tpapwmssql002" -TrustServerCertificate
Invoke-Sqlcmd -Query " DECLARE 
@Description nvarchar(max),
@Collection nvarchar(max),
@runid nvarchar(max),
@LoginCount INT;
Set @LoginCount = (SELECT count(*) FROM [CMS].[Security].[SecurityAudit_temp])
set @Description = N'MSSQL Security Audit Report - HPS'
set @Collection = (Select CONVERT(VARCHAR(23),GETDATE(),120))
set @runid = (Select max(RunID) FROM [CMS].[Security].[SecurityAudit_temp] )
INSERT INTO [CMS].[Collection].[CollectionReport] ([RunID],[Description],[RecCreatedDate],[Count])  VALUES (@runid,@Description,@Collection,@LoginCount);
 " -ServerInstance "tpapwmssql002" -TrustServerCertificate


Invoke-Sqlcmd -Query " DROP table [CMS].[Security].[SecurityAudit_temp]; " -ServerInstance "tpapwmssql002" -TrustServerCertificate


<# ==============================================================================================================================================================================
                                                                                  STAGE -  02 
                                                                     This stage will dump the above gahtered login information into a Excel.
   ==============================================================================================================================================================================#>

Remove-Item –path D:\PSScripts\AuditReport\* -include *.xlsx

$MainReportFName = "HPS_SecurityAudit_$(Get-Date -Format 'MMddyyyyHHMM').xlsx"
$MainReportPath = 'D:\PSScripts\AuditReport\'+$MainReportFName
$instQuery = @" 
/* This is to Pull Current Week Report */
Use CMS
GO
Declare @RunID INT;
Set @RunID = (Select MaX(RunID) FROM [CMS].[Security].[SecurityAudit])
SELECT [DomainName]
      ,[ServerName]
      ,[loginname]
      ,[createdate]
      ,[RecCreatedDate]
      ,[RunID]  FROM [CMS].[Security].[SecurityAudit] Where RunID = @RunID Order by ServerName Desc
"@
$data  = Invoke-Sqlcmd -ServerInstance tpapwmssql002 -Database CMS -Query $instQuery | Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors

$insParams = @{
        Path = "$MainReportPath"
        Worksheet = 'MSSQLSecurityAudit'
        TableName = 'MSSQLSecurityAudit'
        TableStyle = 'Light9'
        AutoSize=$True
        FreezeTopRow = $true
        PassThru = $true
        BoldTopRow = $true
         	}
$excelpkg = $data | Export-Excel @insParams 
 
# Add new WS for Databases
     $null = Add-Worksheet -ExcelPackage $excelpkg -WorksheetName 'NeedToTerminate' -ClearSheet
     #$null = Add-Worksheet -ExcelPackage $excelpkg -WorksheetName 'NeedToTerminate' ##for First time
     $insParams.TableName = 'NeedToTerminate'
     $insParams.WorkSheet = 'NeedToTerminate'
     $insParams.Remove('Path')

$WCQuery = " Use CMS
GO
Declare @RunID INT;
Set @RunID = (Select MaX(RunID) FROM [CMS].[Security].[SecurityAudit])
SELECT TOP (1000) llp.[DomainName]
      ,llp.[ServerName]
      ,llp.[loginname]
      ,llp.[createdate]
      ,llp.[RecCreatedDate]
      ,llp.[RunID]
	  --,SAE.comments
  FROM [CMS].[Security].[SecurityAudit] AS llp
  --left Join  [Security].[SecurityAudit_exemptions] AS SAE on sae.loginname = llp.loginname 
  where SUSER_SID( llp.loginname ) IS NULL
  AND  llp.RunID = @RunID 
  AND llp.loginname like '%\%'
  Order by llp.ServerName Desc "

$data1  = Invoke-Sqlcmd -ServerInstance tpapwmssql002 -Database CMS -Query $WCQuery | Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors
$excelpkg = $data1 | Export-Excel @insParams -ExcelPackage $excelpkg  


# Add new WS for Databases
     $null = Add-Worksheet -ExcelPackage $excelpkg -WorksheetName 'MSSQLSecurityAuditStats' -ClearSheet
     #$null = Add-Worksheet -ExcelPackage $excelpkg -WorksheetName 'MSSQLSecurityAuditStats' ##for First time
     $insParams.TableName = 'MSSQLSecurityAuditStats'
     $insParams.WorkSheet = 'MSSQLSecurityAuditStats'
     $insParams.Remove('Path')

$WCQuery = " Select * from [CMS].[Collection].[CollectionReport] Where Description like 'MSSQL Security Audit Report - HPS' order by runid desc "

$data2  = Invoke-Sqlcmd -ServerInstance tpapwmssql002 -Database CMS -Query $WCQuery | Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors
$excelpkg = $data2 | Export-Excel @insParams -ExcelPackage $excelpkg 

Close-ExcelPackage -ExcelPackage $excelpkg


<# ==============================================================================================================================================================================
                                                                                  STAGE -  03 
                                                                     This stage will reports the data to DBA team.
   ==============================================================================================================================================================================#>

$runDateTime = Get-Date  
$Folderpath = (Get-ChildItem 'D:\PSScripts\AuditReport\*.xlsx').DirectoryName
$Filename = (Get-ChildItem 'D:\PSScripts\AuditReport\*.xlsx').name
$rptPath3 = $folderpath + '\'+ $filename 
$emailSMTP = "smtprelay.healthplan.com"
$body = "<font face='Calibri' color='Green'><b> Client :  HPS </b> <br><br>"
$body += "<font face='Calibri' color='Blue'> Hello Team, <br><br>"           
$body += "<font face='Calibri' color='Blue'> This alert is for <b> MSSQL Security Audit Report </b> for <b>HPS Client</b> pulled today <i>$runDateTime.</i><br><br>"     
$body += "Thank you <br><br>" 
 

    $emailParam = @{
        Subject = " MSSQL Security Audit Report - HPS - $(Get-Date -Format d)"
        To = "sathiyaneethi.mani@wipro.com"
        #To = "WHPS-MSSQL-Admins@wipro.com"
        From = "GlobalMetricsReporting@healthplan.com"
        Cc = "sathiyaneethi.mani@wipro.com"
        Attachments = $rptPath3
        SmtpServer = $emailSMTP
    }
Send-MailMessage @emailParam -BodyAsHtml -Body $body

#ramchandraiah.maddineni1@wipro.com
#kishore.chittampalli@wipro.com
##"WHPS-MSSQL-Admins@wipro.com","gitta.amulya@wipro.com","kishore.chittampalli@wipro.com"
## "WHPS-MSSQL-Admins@wipro.com","gitta.amulya@wipro.com","kishore.chittampalli@wipro.com","ramchandraiah.maddineni1@wipro.com"
##"WHPS-MSSQL-Admins@wipro.com","gitta.amulya@wipro.com","kishore.chittampalli@wipro.com","ramchandraiah.maddineni1@wipro.com"