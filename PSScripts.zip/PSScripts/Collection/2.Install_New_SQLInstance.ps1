﻿ ### DON'T CHANGE/MODIFY this Script without Sathiya's  Notice please ####
   <#
 This PowerShell script is designed to automate the installation of SQL Server, including:
Validating drive letters
Rebooting the server
Mounting the ISO
Installing SQL Server and SSMS
Running post-build scripts
Cleaning up installation files
 #>
 clear
 #Make Sure you have copied the S/W files.( ISO,Patch and SSMS)
 
Function Read-HostSpecial {
      [cmdletbinding(DefaultParameterSetName="_All")]
      Param(
            [Parameter(Position = 0,Mandatory,HelpMessage = "Enter prompt text.")]
            [Alias("message")]
            [ValidateNotNullorEmpty()]
            [string]$Prompt,
            [Alias("foregroundcolor","fg")]
            [consolecolor]$PromptColor,
            [string]$Title,
            [Parameter(ParameterSetName = "SecureString")]
            [switch]$AsSecureString,
            [Parameter(ParameterSetName = "Set")]
            [ValidateNotNullorEmpty()]
            [string[]]$ValidateSet
      )

Write-Verbose "Starting: $($MyInvocation.Mycommand)"
Write-Verbose "Parameter set = $($PSCmdlet.ParameterSetName)"
Write-Verbose "Bound parameters $($PSBoundParameters | Out-String)"

#combine the Title (if specified) and prompt
$Text = @"
$(if ($Title) {
"$Title`n$("-" * $Title.Length)"
})
$Prompt
"@

 If ($title.length -eq "0"){
      $Object = $Prompt
}
Else {
      $Object = $Text
}


#create a hashtable of parameters to splat to Write-Host
$paramHash = @{
      NoNewLine = $True
      Object = $Object
}

If ($PromptColor) {
    $paramHash.Add("Foregroundcolor",$PromptColor)
}

#display the prompt
Write-Host @paramhash
#get the value
If ($AsSecureString) {
    $r = $host.ui.ReadLineAsSecureString()
}
Else {
  #read console input
  $r = $host.ui.ReadLine()
}

#assume the input is valid unless proved otherwise
$Valid = $True

If ($Valid) {
    Write-Verbose "Writing result to the pipeline"
    #any necessary validation passed
    $r
}
Write-Verbose "Ending: $($MyInvocation.Mycommand)"
} #end function

clear-host
$strtime=Get-Date
Write-Host "Start time : $strtime" -ForegroundColor Yellow
write-host "Welcome you to install the SQL Server.Ensure you attempt at correct HOST." -backgroundColor Cyan
$srv=Read-HostSpecial "Enter Correct Host Name:" -PromptColor Green
$server=$srv
#check drive allocation Unit
Import-Module dbatools -EA SilentlyContinue
$driveLetter=Get-DbaDiskSpace $server
 if($driveLetter.Name -notcontains "T:\" -and $driveLetter.Name -notcontains "M:\" -and $driveLetter.Name -notcontains "L:\" -and $driveLetter.Name -notcontains "D:\"){
 Write-Host "Drive(s) Exist: " $driveLetter.Name  -BackgroundColor Green
 write-host "Kindly ensure Drive Letters match with standard. Please stop and review the Drives before proceed" -backgroundColor Cyan
 $OK=Read-HostSpecial "Are you OK? Wanted to continue , Confirm Y or N:" -PromptColor Green
 if($OK -eq "Y" -or $OK -eq "y")
 {
 
 } Else { break}
                  }
 else{  
 write-host "All Drive Letters exist. Proceed with SQL Install After reboot." -backgroundColor Cyan
  }

#reboot the machine before install SQL
$rboot=Read-HostSpecial "Want to Apply Policy and reboot( Y/N) :" -PromptColor Cyan
$rboot.ToUpper()
if($rboot -eq 'Y')
{
$server=$srv
Invoke-Command -ComputerName $server -ScriptBlock {
$regpath="HKLM:\Software\Microsoft\Cryptography\Protect\Providers\df9d8cd0-1501-11d1-8c7a-00c04fc297eb"
$name="ProtectionPolicy"
$value=1
New-ItemProperty -Path $regpath -Name $name -Value $value -PropertyType DWORD -Force
start-Sleep -Seconds 2
write-host "Server Reboot is inprogress. Wait for 3 minutes!" -ForegroundColor Yellow
Restart-Computer . -Force} 
Start-Sleep -seconds 200 }

##wait for server be online
$server=$srv
$check=Test-NetConnection -ComputerName $server | select PingSucceeded
$check=$check.PingSucceeded
if($check -eq $True){write-host "Server is back online. You are good to proceed Happily!" -ForegroundColor Green}
else { 
write-host "Check why server reboot is taking longer time. And try SQL Install Later!" -ForegroundColor Green
break}

#Mount the ISO
$server=$srv
function Mount-ISO {
    param (
        [string]$server
    )
 Invoke-Command -ComputerName $server -ScriptBlock {
 $binarypath="D:\SQL\Software"
 $isoImg = Get-ChildItem -Path $binarypath -Recurse -Filter "*.ISO"
 if($isoImg -ne $null) {write-Host "Wait...Mounting ISO" -ForegroundColor Cyan}
 $isoImg=$isoImg.FullName
 $diskImg = Mount-DiskImage -ImagePath $isoImg 
 # Get mounted ISO volume
 $mountvol = (Get-DiskImage -DevicePath \\.\CDROM1 | Get-Volume).DriveLetter
 write-Host "SQLServerSetup Drive is:" $mountvol } }
 Mount-ISO -server $server
#Setup Drive Letter
 $SetupDrive=Read-HostSpecial "Enter a Setup Drive Letter , else PRESS 1 for remount ISO:" -PromptColor Cyan
#Replace correct Drive Letter
 
  if ($SetupDrive -ne 1) { 
  $mountvol=$SetupDrive+":"
    }
 Else { Mount-ISO -server $server}
 <#$SetupDrive=Read-HostSpecial "Look at above result and confirm ,Is SQLSetup Drive E:\ ? Press Y if Yes, Press 1 to remount ISO, or else Enter a Setup Drive Letter." -PromptColor Cyan
#Replace correct Drive Letter
 if($SetupDrive -eq "Y") {Set-DbatoolsConfig -Name Path.SQLServerSetup -Value E:\}
  Elseif ($SetupDrive -ne "Y" -and $SetupDrive -ne "1") { 
  $mountvol=$SetupDrive+":\"
  
  Set-DbatoolsConfig -Name Path.SQLServerSetup -Value $mountvol
 }
 Else { Mount-ISO -server $server}
 #>
 Set-DbatoolsConfig -Name Path.SQLServerSetup -Value $mountvol
 write-Host "       ***************Drive Letter Used*******************" -ForegroundColor Magenta
 write-Host "       ===================================================" -ForegroundColor Magenta
 write-Host "         D- SQLRoot , M- SQLData ,L- SQLLog , T- SQLTemp  " -ForegroundColor Magenta
 write-Host "       ***************************************************" -ForegroundColor Magenta
 $vers=Read-HostSpecial "Hope you have SQL Setup file copied already. Select the SQL Version to Install: Enter 2022 or 2019 or 2017:" -PromptColor Cyan
 $namedinstance=Read-HostSpecial "Press Numeric 1 to continue with Default Instance else Enter the Name of Instance :" -PromptColor Cyan
 $server=$srv
 $Instance = Find-DbaInstance -ComputerName $server
 if ($Instance -eq $null -and $namedinstance -eq "1" )
 {
 Write-host " Default DB Instance Build is inprogress...." -ForegroundColor Yellow
  Install-DbaInstance -ComputerName $server -Version $vers -InstancePath D:\SQLServer -Restart -DataPath M:\SQLDATA -LogPath L:\SQLLog -TempPath T:\Tempdb -UpdateSourcePath D:\SQL\Software -PerformVolumeMaintenanceTasks  -Confirm:$false
 }
 Else{ write-Host " Named DB Instance Build is inprogress...." -ForegroundColor Yellow
  Install-DbaInstance -ComputerName $server -Version $vers -InstanceName $namedinstance -InstancePath D:\SQLServer -Restart -DataPath M:\SQLData\$namedinstance -LogPath L:\SQLLog\$namedinstance -TempPath T:\Tempdb\$namedinstance -UpdateSourcePath D:\SQL\Software -PerformVolumeMaintenanceTasks  -Confirm:$false
  }
 Start-Sleep -seconds 5
 write-Host "Look at the result in the PS console. If NO Error during SQL Install. Let's Install the SSMS " -ForegroundColor Green
 $ssmsinstall = Read-Hostspecial "Want to Proceed with SSMS install. You must enter Y or N to continue:" -promptcolor Cyan
 If ($ssmsinstall -eq "Y" -or $ssmsinstall -eq "y") {
 Invoke-Command -ComputerName $server -ScriptBlock {
 $filepath= Get-ChildItem -path D:\SQL\Software -Filter "*SSMS*.exe" 
 $filepath=$filepath.FullName
write-host "Beginning SSMS install..." -ForegroundColor Yellow -nonewline
$Parms = " /Install /Quiet /Norestart /Logs D:\SQL\log.txt"
$Prms = $Parms.Split(" ")
& "$filepath" $Prms | Out-Null
Write-Host "SSMS installation complete" -ForegroundColor Green } } 
else { continue }

Start-Sleep -seconds 5
$postbuild = Read-Hostspecial "Want to Proceed with post build step. You must enter Y or N to continue:" -promptcolor Cyan
#deploy the postbuild script on the target instance
if($postbuild -eq "Y")
{
Write-Host "Going to Deploy the Post Build Scripts " -ForegroundColor Cyan
$instance=Find-DbaInstance -ComputerName $srv | Select SqlInstance
$serverinstance=$instance.SqlInstance
$postscripts= Get-ChildItem X:\SQLPostBuild\Deploy
$postscripts=$postscripts.FullName 
foreach($deploy in $postscripts)
{
Write-host "Post Build Script Deployment is inprogress...." -ForegroundColor Yellow
$serverinstance | Invoke-DbaQuery -File $deploy -EnableException
}
Write-Host "Post Build completed. You may check your access now." -ForegroundColor Cyan
Start-Sleep -Seconds 3
#Restart the SQL Agent
Write-Host "Going to Restart the SQL Agent" -ForegroundColor Cyan
$TargetServer=$srv
Get-DbaService $TargetServer | Where-Object  {$_.ServiceName -like '*SQLAgent$*' -or $_.ServiceName -eq 'SQLSERVERAGENT'}  | Restart-DbaService -Verbose
}
Else { break }
Start-Sleep -Seconds 2

write-Host "Wait...UnMounting ISO" -ForegroundColor Cyan
#unmount disk
$server=$srv
Invoke-Command -ComputerName $server -ScriptBlock {
$binarypath="D:\SQL\Software"
 $isoImg = Get-ChildItem -Path $binarypath -Recurse -Filter "*.ISO"
 $isoImg=$isoImg.FullName
 if($isoImg -ne $null){ DisMount-DiskImage -ImagePath $isoImg
 write-Host "UnMounting ISO is Done!" -ForegroundColor Cyan }
 }
 Start-Sleep -Seconds 3
$cleanup = Read-Hostspecial "Want to cleanup the s/w copied . You must enter Y or N to continue:" -promptcolor Cyan
 If ($cleanup -eq "Y" -or $cleanup -eq "y") {
##cleanup software copied
$server=$srv
Invoke-Command -ComputerName $server -ScriptBlock {
$binarypath="D:\SQL\Software"
Get-ChildItem -Path $binarypath -Recurse| Remove-Item -force } }
else { Write-Host "OK. You may cleanup manually later." -ForegroundColor Green}
Start-Sleep -Seconds 5
Write-Host "Let's Connect the sql instance remotely and verify.Look at the output" -ForegroundColor Green 
$Ins = Find-DbaInstance -ComputerName $server
$remoteconnect=Connect-DbaInstance -SqlInstance $Ins
if($remoteconnect -ne $null)
{Write-host "All looks Good!" -ForegroundColor Cyan }
#$remoteconnect 
else { write-host "Oops! Check what went wrong with the connectivity of DB server remotely !" -ForegroundColor DarkYellow}
Start-Sleep -Seconds 2
$endtime=Get-Date
Write-Host "End time : $endtime" -ForegroundColor Yellow