﻿Import-Module dbatools -EA SilentlyContinue
#Get-DbaService -ComputerName TPAPWRECSQL001 | Where-Object {$_.StartMode -ne 'Disabled'} | Set-Service –StartupType Disabled
#Stop-DbaService -ComputerName TPAPWRECSQL001 -Force
#Get-DbaService -ComputerName  WIN-BPO-03
#Stop-Computer -ComputerName  HPSSQL11 -Force
Test-NetConnection HPSSQL11