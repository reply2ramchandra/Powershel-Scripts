﻿clear
# Load SMO and Registered Servers assemblies
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Management.RegisteredServers") | Out-Null

# Connect to the CMS
$cmsServer = "TPAPWMSSQL002"  # Replace with your actual CMS server name
$serverConnection = New-Object Microsoft.SqlServer.Management.Common.ServerConnection($cmsServer)
$regServerStore = New-Object Microsoft.SqlServer.Management.RegisteredServers.RegisteredServersStore($serverConnection)

# Access the root group
$rootGroup = $regServerStore.ServerGroups["DatabaseEngineServerGroup"]

# Recursive function to list all registered servers in all groups
function List-RegisteredServers($group) {
    foreach ($regServer in $group.RegisteredServers) {
        Write-Host "Server Name: $($regServer.Name)"
        Write-Host "Server Description: $($regServer.Description)"
        Write-Host "Server Connection String: $($regServer.ConnectionString)"
        Write-Host "----------------------------------------"
       
    
    }

    foreach ($subGroup in $group.ServerGroups) {
        List-RegisteredServers $subGroup
    }
}

# Start listing from the root group
List-RegisteredServers $rootGroup
