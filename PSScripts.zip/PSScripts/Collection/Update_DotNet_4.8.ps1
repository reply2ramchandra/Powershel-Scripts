﻿$server='TPATWSQLCLU04'
Invoke-Command -ComputerName $server -ScriptBlock {
Write-host "***Reboot Would Happen post Update***"
powershell.exe -command "& C:\patch\NDP48-x86-x64-AllOS-ENU.exe /quiet IACCEPTMSDOTNETLICENSETERMS=YES"}