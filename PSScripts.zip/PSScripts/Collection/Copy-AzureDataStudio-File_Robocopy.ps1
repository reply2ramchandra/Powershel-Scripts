﻿Clear-Host

# Remote host name
$remoteHost = 'TPAPWSQLMHC009'

# Define local and remote paths
$localFile = "X:\azuredatastudio-windows-arm64-setup-1.51.1.exe"
$remotePath = "C:\patch"

# Extract source directory and file name
$localDir = Split-Path $localFile -Parent
$fileName = Split-Path $localFile -Leaf

# Check and create remote path if it doesn't exist
Invoke-Command -ComputerName $remoteHost -ScriptBlock {
    param($remotePath)
    if (-not (Test-Path $remotePath)) {
        New-Item -Path $remotePath -ItemType Directory -Force
        Write-Host "Created remote path: $remotePath"
    } else {
        Write-Host "Remote path already exists: $remotePath"
    }
} -ArgumentList $remotePath

# Convert remote path to UNC format for robocopy
$remoteUNC = "\\$remoteHost\$($remotePath.Substring(0,1))$" + $remotePath.Substring(2)

# Use robocopy to copy only the specific file
$robocopyCmd = "robocopy `"$localDir`" `"$remoteUNC`" `"$fileName`" /Z /NP /R:2 /W:5"
Invoke-Expression $robocopyCmd

Write-Host "File copy completed." -ForegroundColor Cyan
