﻿$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -DisableNameChecking 
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] where Status='Y'"
foreach($Instance in $servers.SqlInstance)
{
$IPAddress=Test-DbaConnection $Instance | Select ComputerName,IPAddress,DomainName
Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'Server_IPAddress' -InputObject $IPAddress  -AutoCreateTable -KeepNulls
}