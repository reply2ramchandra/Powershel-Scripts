﻿$server='TPATWSQLHHA01'
Invoke-Command -ComputerName $server -ScriptBlock {
 write-host "Lets create a Folder to copy the reg files if not exist." -ForegroundColor cyan
$targetpatchfolder="C:\Patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
} 
Write-Host "Let's copy the Reg File." -ForegroundColor cyan
$cufile= Get-ChildItem X:\WindowsKB -Filter '*KB*.msu' 
$cufile=$cufile.FullName 
$target="C:\Temp"
$cred=Get-Credential a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $cufile -Destination $target -ToSession $s  -Force -ErrorAction SilentlyContinue

#Lets review the file copied
Write-Host "Lets Review the files copied." -ForegroundColor Magenta
Invoke-Command -ComputerName $Server -ScriptBlock { 
       $path='C:\Temp'
        Get-ChildItem -Path $path -Recurse -ErrorAction SilentlyContinue | Where-Object { ($_.CreationTime -gt $(Get-Date).AddDays( - 1))} | Select-Object Name,@{Name="SizeInMB"; Expression={ [math]::Round($_.Length / 1MB,2)}}  
       }