﻿# Remove directory
$Server='BLDTWVSQL004'
    Invoke-Command -ComputerName $Server -ScriptBlock { 
       $path='C:\patch'
       $content=Get-ChildItem -path $path -ErrorAction SilentlyContinue | Select-Object Name,@{Name="SizeInMB"; Expression={ [math]::Round($_.Length / 1MB,2)}} 
       $content
       $yes=Read-Host "Want to delete, Press Y or N to continue"

       if($yes -eq "Y"){ Remove-Item -Path $path -Recurse -Force} else { break}}