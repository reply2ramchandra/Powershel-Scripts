﻿#Update MySQL ODBC
$server='TPAPWDWSQL004'
Invoke-Command -ComputerName $server -ScriptBlock {
powershell.exe -command "& msiexec /quiet /passive /qn /i C:\tmp\mysql\mysql-connector-net-9.3.0.msi IACCEPTMYSQLCONNECTORNETLICENSETERMS=YES"
}