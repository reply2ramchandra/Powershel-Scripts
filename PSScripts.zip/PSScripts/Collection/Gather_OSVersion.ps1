﻿clear
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -EA SilentlyContinue
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT trim([HostName]) as HostName FROM [CMS].[dbo].[DBServer] Where [Status] IN ('P','Y') and HostName<>'PCIPWSQL001'" -TrustServerCertificate
foreach($SQL_server in $servers.HostName)
{
$OsVersion=Get-DbaOperatingSystem -ComputerName $SQL_server
Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'OSVersion' -InputObject $OsVersion  -AutoCreateTable -KeepNulls 
}