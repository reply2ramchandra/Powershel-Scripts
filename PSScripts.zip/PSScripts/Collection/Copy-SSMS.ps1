﻿$server='TPADWSQLALF001'
$SSMS= Get-ChildItem "G:\Software\Microsoft\_SQL Server" -Filter 'SSMS-Setup-ENU-20.2.exe' 
$SSMS=$SSMS.FullName  
$target="D:\SQL\Software"
$user =  [Environment]::username
$cred=Get-Credential $user
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $SSMS -Destination $target -ToSession $s -PassThru -Force
Write-Host "SQL Binary copy completed." -ForegroundColor Cyan