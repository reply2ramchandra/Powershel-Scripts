﻿$server="TPAPWUTIL001"
Invoke-Command -ComputerName $server -ScriptBlock {
powershell.exe -command "& msiexec /x C:\patch\msodbcsql-18.3.3.1.msi /qn"
}