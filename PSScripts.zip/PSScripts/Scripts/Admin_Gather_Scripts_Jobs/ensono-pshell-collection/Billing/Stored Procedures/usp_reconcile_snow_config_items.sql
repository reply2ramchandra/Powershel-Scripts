﻿CREATE PROCEDURE [Billing].[usp_reconcile_snow_config_items]
 @SqlInstance VARCHAR(256) = NULL
,@DateToLook SMALLDATETIME = NULL

/***************************************************************************************************************************************
	Copyright © 2021 Ensono LP, USA. All rights reserved

	Purpose: To gather Configuration Items info to reconcile the SQL rdbms and database CIs and sync with eCMDB
	

	History:
	------------------------------------------------------------------------------------------------------------------------------------
	Author                                 Date Created                Comments
	------------------------------------------------------------------------------------------------------------------------------------
	Harsha vasa                              2021-10-13                  Initial draft



    ------------------------------------------------------------------------------------------------------------------------------------

	Documentation:
	--------------
            ASCII(169) - ©


	Execution Samples:
	------------------
	# 1 :  Will take start date of the month (default) and pull the info
    EXEC [Billing].[usp_reconcile_snow_config_items]

	#2 :  Specific date CI count
	EXEC [Billing].[usp_reconcile_snow_config_items] '01/15/2021'

***************************************************************************************************************************************/
AS
	BEGIN

		-- default to start of the month
		DECLARE @DateKey SMALLDATETIME;
		SET @DateKey = COALESCE(@DateToLook, [Admin].fn_startofmonth(GETDATE()));

		;
		WITH MonthlyCI
		AS
		(SELECT
				s.SqlInstance											  AS SqlInstance
			   ,'SQL Server Instance'									  AS [CiType]
			   ,CAST([Billing].format_ci(s.SqlInstance) AS VARCHAR(1024)) AS [CiName]
			   ,CONVERT(VARCHAR(1024), 'rdbms')							  AS [Database]
			FROM Inventory.ServerList AS s
			WHERE s.SqlInstance LIKE COALESCE(@SqlInstance, '%')
			AND ((IsActive = 1
			AND SupportGroup IS NOT NULL)
			OR EXISTS (SELECT
					1
				FROM Inventory.SqlServerProperties AS sp
				WHERE DateKey = @DateKey
				AND sp.SqlInstance = s.SqlInstance)
			)

			UNION ALL

			SELECT
				dp.SqlInstance
			   ,'SQL Server Database'
			   ,CAST(mc.[CiName] + ':' + dp.[DatabaseName] AS VARCHAR(1024))
			   ,dp.[DatabaseName]
			FROM MonthlyCI AS mc
			INNER JOIN [Inventory].[Databases] AS dp
				ON mc.SqlInstance = dp.SqlInstance
					AND mc.[CiType] = 'SQL Server Instance'
			WHERE dp.DateKey = @DateKey)

		SELECT
			[CiName] AS [CI Name]
		   ,[CiType] AS [CI Type]
		   ,SqlInstance
		   ,[Database]
		FROM MonthlyCI;



	END;