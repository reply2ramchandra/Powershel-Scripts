﻿CREATE TABLE [Billing].[NonCollectionDatabases]
(
	[SqlInstance]    VARCHAR (256)   NOT NULL,
    [DatabaseName]   VARCHAR (1024)  NOT NULL,
	CONSTRAINT FK_NonCollectionDatabases_SqlInstance FOREIGN KEY ([SqlInstance]) REFERENCES [Inventory].[ServerList] ([SqlInstance]) ON DELETE CASCADE
)
