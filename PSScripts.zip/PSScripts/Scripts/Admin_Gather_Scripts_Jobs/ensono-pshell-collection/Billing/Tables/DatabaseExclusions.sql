﻿CREATE TABLE [Billing].[DatabaseExclusions]
(
	SqlInstance VARCHAR(128) NULL,
	DatabaseName VARCHAR(128) NOT NULL
)
