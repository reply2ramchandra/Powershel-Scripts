﻿CREATE VIEW [Admin].[vSqlHosts]
AS
	SELECT DISTINCT
		COALESCE( hn.Host,sl.MachineName ) AS [ComputerName]
	   ,sl.Domain
	   ,sl.Environment
	-- COALESCE( hn.Host, sl.MachineName,LEFT( sl.SqlInstance,ISNULL( NULLIF( CHARINDEX( '\',sl.SqlInstance ),0 ),LEN( sl.SqlInstance ) + 1 ) - 1 )) + '.' + Domain
	FROM Inventory.ServerList AS sl
	LEFT OUTER JOIN Inventory.[ClusterNodeNames] AS hn ON sl.SqlInstance = hn.SqlInstance
	WHERE (IsActive = 1 AND SupportGroup IS NOT NULL)
	AND MachineName IS NOT NULL

