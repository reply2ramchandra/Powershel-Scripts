﻿CREATE VIEW Admin.vLatestDatabaseFiles
AS
	SELECT
		df.DateKey
	   ,df.SqlInstance
	   ,df.[Database]
	   ,df.LogicalName
	   ,df.ID
	   ,df.MaxSizeMb
	   ,df.Growth
	   ,df.GrowthType
	   ,df.SizeMb
	FROM Inventory.DatabaseFiles AS df
	WHERE df.DateKey = (SELECT TOP 1 DateKey FROM Inventory.DatabaseFiles ORDER BY DateKey DESC)
