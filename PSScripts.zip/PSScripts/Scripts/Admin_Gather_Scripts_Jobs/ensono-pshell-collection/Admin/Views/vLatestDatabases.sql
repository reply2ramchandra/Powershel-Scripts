﻿CREATE VIEW [Admin].[vLatestDatabases]
AS
SELECT
	[d].DateKey
   ,[d].SqlInstance
   ,[d].DatabaseName
   ,[d].[Size]
   ,[d].RecoveryModel
   ,[d].[Owner]
   ,[d].PageVerify
   ,CAST(REPLACE([d].CompatibilityLevel,'Version',SPACE(0)) AS INT) AS CompatibilityLevel
   ,[d].LastBackupDate
   ,[d].LastDifferentialBackupDate
   ,[d].LastLogBackupDate
   ,[d].[Status]
   ,CASE
		WHEN [d].DatabaseName IN ('master','msdb','model','tempdb','DBA') THEN 'SYSTEM'
		ELSE 'USER'
	END DbCategory
FROM Inventory.[Databases] AS [d]
WHERE [d].DateKey = (SELECT TOP 1 DateKey FROM Inventory.[Databases] ORDER BY DateKey DESC)