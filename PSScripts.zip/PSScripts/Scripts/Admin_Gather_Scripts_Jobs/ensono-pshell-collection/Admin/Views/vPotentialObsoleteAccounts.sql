CREATE VIEW [Admin].[vPotentialObsoleteAccounts]
AS
	SELECT
		llp.SqlInstance
	   ,sl.MachineName
	   ,llp.LoginAccount
	   ,llp.LoginType
	   ,llp.CreateDate
	FROM Admin.vLatestLoginProperties AS llp
	CROSS APPLY ( SELECT MachineName FROM Inventory.ServerList WHERE SqlInstance = llp.SqlInstance) AS sl
	WHERE SUSER_SID( llp.LoginAccount ) IS NULL
	AND llp.LoginType = 'U'
	AND llp.LoginAccount NOT LIKE ('NT Service\%')
	AND llp.LoginAccount NOT LIKE sl.MachineName + '%' -- Computer account (Local)
