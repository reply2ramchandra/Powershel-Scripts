CREATE VIEW [Admin].[vLastBackupDate]
AS
SELECT sd.DateKey,
       sd.SqlInstance,
       sd.[DatabaseName] AS DatabaseName,
       RecoveryModel,
       LastBackupDate,
       LastDifferentialBackupDate,
       LastLogBackupDate
FROM Inventory.[Databases] AS sd
    LEFT OUTER JOIN Inventory.[AgBackupNodePreferrence] AS ad
        ON sd.SqlInstance = ad.SqlInstance
           AND sd.[DatabaseName] = ad.DatabaseName
WHERE [sd].DateKey = (SELECT TOP 1 DateKey FROM Inventory.[Databases] ORDER BY DateKey DESC)
AND
      (
          ad.IsPreferredNode IS NULL
          OR ad.IsPreferredNode = 1
      )
      AND sd.[DatabaseName] != 'tempdb'
      AND sd.[Status] = 'Normal'
GO
