﻿CREATE VIEW [Admin].[vLatestLoginProperties]
AS
	SELECT
		l.DateKey
	   ,l.SqlInstance
	   ,l.[Name] AS LoginAccount
	   ,CASE l.LoginType
			WHEN 'SqlLogin' THEN 'S'
			WHEN 'WindowsUser' THEN 'U'
			ELSE 'G'
		END		 LoginType
	   ,l.PrincipalId
	   ,l.DefaultDatabase
	   ,l.CreateDate
	FROM Inventory.Logins AS l
	WHERE [l].DateKey = (SELECT TOP 1 DateKey FROM Inventory.Logins ORDER BY DateKey DESC)



