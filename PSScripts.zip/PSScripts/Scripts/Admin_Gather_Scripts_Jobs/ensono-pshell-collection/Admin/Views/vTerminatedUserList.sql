﻿CREATE VIEW [Admin].[vTerminatedUserList]
AS
	SELECT
		SqlInstance
	   ,LoginAccount
	   ,LoginType
	FROM Admin.vLatestLoginProperties
	WHERE EXISTS (SELECT * FROM Admin.ImportWeeklyTerminatedUsers WHERE LoginAccount LIKE '%' + NetworkId)

