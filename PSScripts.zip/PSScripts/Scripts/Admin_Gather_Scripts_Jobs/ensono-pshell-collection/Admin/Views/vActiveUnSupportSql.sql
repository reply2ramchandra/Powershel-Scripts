﻿CREATE VIEW [Admin].[vActiveUnSupportSql]
AS 
SELECT  SqlInstance
	   ,Environment
       ,Domain
       ,HasAccess
FROM [Inventory].[ServerList]
WHERE IsActive = 1 AND SupportGroup IS NULL
