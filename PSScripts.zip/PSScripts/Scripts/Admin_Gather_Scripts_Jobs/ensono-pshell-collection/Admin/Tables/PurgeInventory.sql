﻿CREATE TABLE [Admin].[PurgeInventory]
(
	[Schema] VARCHAR(256) NOT NULL CONSTRAINT DF_PurgeInventory_Schema DEFAULT ('Inventory'),
	[Table] VARCHAR(256),
	[ColumnName] VARCHAR(256) NOT NULL CONSTRAINT DF_PurgeInventory_ColumnName DEFAULT ('DateKey'),
	[Retention] SMALLINT NULL CONSTRAINT DF_PurgeInventory_Retention DEFAULT (40)
)
