﻿CREATE TABLE [Admin].[ImportWeeklyTerminatedUsers]
(
	[EmployeeId] VARCHAR(256) NULL,
	[NetworkId] VARCHAR(256) NULL
)
