CREATE PROCEDURE [Admin].[usp_forecast_diskspace] @Server	   VARCHAR(128) = NULL
												 ,@StartDate   DATE			= NULL
												 ,@EndDate	   DATE			= NULL
												 ,@MonthPeriod SMALLINT		= 13
												 ,@Forecast	   BIT			= 0      -- Default No forecast report is generated
												 ,@Review	   VARCHAR(12)  = 'Used' -- 'Used,Free,Total'
AS
	/***************************************************************************************************************************************
			
			Purpose: This stored procedure is used to analyze and forecast the Disk volumes (Mount Point) capacity.
			
	
			History:
			--------------------------------------------------------------------------------------------------------------------------------
			Author                                 Date Created                                Comments
			--------------------------------------------------------------------------------------------------------------------------------
			Harsha vasa                              2016-01-05                              Initial draft

			Harsha Vasa                              2016-01-12                              Modified the Flag to validate the server.LINE 124
			                                                                                 Moved scalar functions to respective schema as 
																							 intended. LINE 135
																							 Replaced IF clauses execution query with one 
																							 Master Dynamic query to generate at runtime.
	
	
	
		    --------------------------------------------------------------------------------------------------------------------------------
	
			Documentation:
			--------------
			1) Dynamic construction of month strings
			2) Forecast has been made on Monthly basis and gives an estimate of #of months to fill the MountPoint.
			3) Calculate Peak Growth & Avg Growth
			    -- Peak Growth = MAX Value of (Difference of Max and Min value of DiskSpace Per Month) -- complete cycle
	            -- Avg Growth  = (Difference between Avg Diskspace of Last Month and First Month in the cycle ) / #of Months
	        4) [DaysToFill@Peak] = Estimate # of days to fill the disk @Peak utilization
			5) [DaysToFill@Avg] = Estimate # of days to fill the disk @Avg utilization
	
			Execution Samples:
			------------------
			*********************************************************************************************************************************
			A) Forecast:
			*********************************************************************************************************************************
				1) Exec Admin.usp_forecast_diskspace @Forecast = 1
				-- Retrieve ALL servers info with usage of last 13 months period which is default

				2) Exec Admin.usp_forecast_diskspace @Server = 'SQL Server Name',@StartDate ='2015-01-01',@EndDate ='2015-10-01', @Forecast = 1
				-- Retrieves ONLY specified server 'SQL Server Name'. Forecast will be analyzed based on Start and End Date.

				3) Exec Admin.usp_forecast_diskspace @MonthPeriod = 10, @Forecast = 1
				-- Analyze ALL servers for last 10 month period and build the Forecast
             
			********************************************************************************************************************************
			B) Review:
			*********************************************************************************************************************************
	            1) Exec Admin.usp_forecast_diskspace @review = 'Used' ; other valid parameters = Free, Total
				-- Retrieve ALL servers info based on input parameter and report the usage with comments included

				2) Exec Admin.usp_forecast_diskspace @Server = 'SQL Server Name',@StartDate ='2015-01-01',@EndDate ='2015-10-01', @review = 'Used'
				-- Retrieves ONLY specified server 'SQL Server Name'. Analyzed based on StartDate, End Date and @review parameter

				3) Exec Admin.usp_forecast_diskspace @MonthPeriod = 10, @review = 'Free'
				-- Analyze ALL servers for last 10 month period
	    ***************************************************************************************************************************************/

	BEGIN
		SET NOCOUNT ON;
		SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

		DECLARE @iStartDate DATETIME
			   ,@iEndDate DATETIME
			   ,@param VARCHAR(28)
			   ,@dMonthString VARCHAR(1000)
			   ,@dMonCoSelectString VARCHAR(8000)
			   ,@dMonCoAscString VARCHAR(4000)
			   ,@dMonCoDescString VARCHAR(4000)
			   ,@dServerList VARCHAR(1000)
			   ,@eStageDisk NVARCHAR(4000)
			   ,@eSql NVARCHAR(MAX)
			   ,@rc BIT = 1;


		IF OBJECT_ID( 'tempdb..#gDate' ) IS NOT NULL
			DROP TABLE #gDate;

		-- Generate Date Keys 

		CREATE TABLE #gDate (DateKeys DATETIME PRIMARY KEY CLUSTERED);

		-- Stage Disk Data

		CREATE TABLE #sDiskRepo (DateKey DATETIME
								,SqlInstance NVARCHAR(128)
								,ComputerName NVARCHAR(128)
								,Drive VARCHAR(60)
								,MaxUsedMB DECIMAL(20,2));

		CREATE CLUSTERED INDEX CIX_ServerName_MountPoint_Date_Key ON #sDiskRepo (SqlInstance,Drive,DateKey);

		-- Server Validation

		IF LTRIM( RTRIM( @Server ) ) IS NOT NULL
		AND NOT EXISTS (
			  SELECT
				  *
			  FROM Inventory.ServerList
			  WHERE SqlInstance = @Server
			  AND (IsActive = 1 AND ConnectionMethod IS NOT NULL)
		)
			 BEGIN
				 RAISERROR ('The server specified %s either doesn''t exist or inactive.',16,1,@Server) WITH NOWAIT;
				 RETURN (@rc);
			 END;

		BEGIN TRY

			SET @iEndDate = COALESCE( @EndDate,CONVERT( DATE,GETDATE() ) );

			SET @iEndDate = [Admin].fn_endofmonth( @iEndDate );    -- End of Month
			SET @iStartDate = COALESCE( @StartDate,DATEADD( MONTH,DATEDIFF( MONTH,0,@iEndDate ) - (@MonthPeriod - 1),0 ) )


			-- Populate dates
			;
			WITH C0
			AS (
				  SELECT
					  *
				  FROM (VALUES(0)
							 ,(0)
							 ,(0)
							 ,(0)) X (v)
			),  -- 4 
			C1
			AS (SELECT a.v FROM C0 AS a CROSS JOIN C0 AS b)  -- 16
			,
			CNums
			AS (SELECT ROW_NUMBER() OVER (ORDER BY v) AS n FROM C1)

			INSERT INTO #gDate
			SELECT
				@iStartDate AS dates
			UNION ALL
			SELECT
				DATEADD( MONTH,n,@iStartDate ) AS pcDate
			FROM CNums
			WHERE n <= DATEDIFF( MONTH,@iStartDate,@iEndDate );


			-- Dynamic Strings
			-- #1 Months


			SELECT
				@dMonthString = STUFF( ((
					  SELECT
						  ',' + QUOTENAME( LEFT( CONVERT( VARCHAR(8),i.DateKeys,112 ),6 ) )
					  FROM #gDate AS i
					  ORDER BY i.DateKeys
					  FOR XML PATH (''),TYPE
				)
				.value( '.','varchar(max)' )),1,1,'' )
			   ,@dMonCoDescString = 'COALESCE(' + STUFF( ((
					  SELECT
						  ',' + QUOTENAME( LEFT( CONVERT( VARCHAR(8),i.DateKeys,112 ),6 ) )
					  FROM #gDate AS i
					  ORDER BY i.DateKeys DESC
					  FOR XML PATH (''),TYPE
				)
				.value( '.','varchar(max)' )),1,1,'' ) + ',0)'
			   ,@dMonCoAscString = 'COALESCE(' + STUFF( ((
					  SELECT
						  ',' + QUOTENAME( LEFT( CONVERT( VARCHAR(8),i.DateKeys,112 ),6 ) )
					  FROM #gDate AS i
					  ORDER BY i.DateKeys
					  FOR XML PATH (''),TYPE
				)
				.value( '.','varchar(max)' )),1,1,'' ) + ',0)'

			   ,@dMonCoSelectString = +STUFF( ((
					  SELECT
						  ',' + 'COALESCE(' + QUOTENAME( LEFT( CONVERT( VARCHAR(8),i.DateKeys,112 ),6 ) ) + ',0) AS ' + QUOTENAME( LEFT( CONVERT( VARCHAR(8),i.DateKeys,112 ),6 ) )
					  FROM #gDate AS i
					  ORDER BY i.DateKeys
					  FOR XML PATH (''),TYPE
				)
				.value( '.','varchar(max)' )),1,1,'' )

			FROM #gDate AS tm;

			IF @Server IS NOT NULL
				 BEGIN
					 SET @dServerList = N'AND sl.SqlInstance = N''' + RTRIM( LTRIM( @Server ) ) + '''';
				 END;

			-- Validate the input parameter and assign default if NULL;

			SELECT
				@param =
						CASE
							WHEN @Review = 'Used' THEN '[TotalGB]-[FreeGB]'
							WHEN @Review = 'Free' THEN 'FreeGB'
							WHEN @Review = 'Total' THEN 'TotalGB'
							ELSE 'UsedDiskSpaceMB'
						END;

			SET @eStageDisk =
			N'; WITH DiskSpaceRepo
					AS
						(
							SELECT
								DSRMP.DateKey
                                ,sl.SqlInstance
								,DSRMP.ComputerName
								,DSRMP.Drive
								,' +
									CASE
										WHEN @Forecast = 1 THEN 'DSRMP.[TotalGB]-DSRMP.[FreeGB]'
										ELSE @param
									END + ' As [DiskSpaceMB]' + '
							FROM Inventory.ServerList AS sl
	  LEFT OUTER JOIN Inventory.ClusterNodeNames AS HN ON HN.SqlInstance = sl.SqlInstance
	  INNER JOIN Inventory.DiskSpace AS DSRMP ON DSRMP.ComputerName = COALESCE( HN.Host,sl.MachineName )
	  WHERE DSRMP.DateKey BETWEEN  @iStartDate AND @iEndDate
							' + COALESCE( @dServerList,'' ) + '
						),
						cMaxValues
						AS 
						(
							SELECT
							 		 DateKey
									,SqlInstance
                                    ,ComputerName
									,Drive
									,DiskSpaceMB
									,ROW_NUMBER() OVER (PARTITION BY SqlInstance, ComputerName ,Drive, YEAR(DateKey), MONTH(DateKey) ORDER BY DiskSpaceMB DESC) AS rn
							FROM DiskSpaceRepo
						)						  
						    SELECT   DateKey
									,SqlInstance
                                    ,ComputerName
									,Drive
									,DiskSpaceMB
							FROM cMaxValues
							WHERE rn = 1
							OPTION (RECOMPILE);';

			-- Load into Stage Table

			INSERT INTO #sDiskRepo
			EXEC sys.sp_executesql @eStageDisk
								  ,N'@iStartDate DateTime,@iEndDate DateTime'
								  ,@iStartDate
								  ,@iEndDate;

			-- Build Master Dynamic Query

			SET @eSql = N'; WITH c1 AS ( SELECT
							   DR.DateKey
							  ,DR.SqlInstance
                              ,DR.ComputerName
							  ,DR.Drive
							  ,DR.MaxUsedMB
						    	' +
								   CASE
									   WHEN @Forecast = 1 THEN ',DR.MaxUsedMB - ca1.MaxUsedMB AS PrevMax
								  ,DATEDIFF(dd, ca1.DateKey, DR.DateKey) AS DaysDiff'
									   ELSE ''
								   END + CHAR( 10 ) +
			'FROM #sDiskRepo AS DR
							  ' +
								 CASE
									 WHEN @Forecast = 1 THEN 'OUTER APPLY (
									SELECT TOP 1
											DR1.DateKey
										,DR1.MaxUsedMB
									FROM #sDiskRepo AS DR1
									WHERE DR1.SqlInstance = DR.SqlInstance
									AND DR1.ComputerName = DR.ComputerName
									AND DR1.Drive = DR.Drive
									AND DR1.DateKey < DR.DateKey
									ORDER BY DR1.DateKey DESC
								) ca1'
									 ELSE ''
								 END + CHAR( 10 ) +
			')' + CHAR( 10 ) +
			'SELECT
						     SqlInstance
                            ,ComputerName
							,Drive
							,' + @dMonCoSelectString + '
							' +
							   CASE
								   WHEN @Forecast = 1 THEN ',ca1.PercentFree
											,ca1.FreeGB
											,COALESCE(PeakGrowth,0) AS PeakGrowth
											,COALESCE(AvgGrowth,0) AS AvgGrowth
											,[DaysToFill@Peak] = FLOOR((ca1.FreeGB / CASE WHEN PeakGrowth > 0 THEN PeakGrowth ELSE 1 END ))
											,[DaysToFill@Avg] =	 FLOOR((ca1.FreeGB / CASE WHEN AvgGrowth > 0 THEN AvgGrowth ELSE 1 END ))'
								   ELSE ',ca2.Growth
										 ,CASE WHEN ' + @dMonCoAscString + ' = 0 THEN ''CD Drive or No Data Collected''
											  WHEN SIGN (ca2.Growth) = 1 THEN ''Increase In ' + @Review + ' Disk Space''
											  WHEN SIGN (ca2.Growth) = -1 THEN ''Decrease In ' + @Review + ' Disk Space''
											  WHEN SIGN (ca2.Growth) = 0 THEN ''No Growth''
											END As Comments'
							   END + CHAR( 10 ) +
			'FROM 
								 (
									SELECT	 CONVERT(Varchar(6),DateKey,112) AS YYYYMM
											,SqlInstance
                                            ,ComputerName
											,Drive
											,MaxUsedMB
											' +
											   CASE
												   WHEN @Forecast = 1 THEN ',CEILING(MAX(PrevMax * 1.0 / DaysDiff) OVER (PARTITION BY c1.ComputerName, c1.Drive))	AS PeakGrowth
																 ,CEILING(SUM(PrevMax * 1.0) OVER (PARTITION BY c1.ComputerName, c1.Drive)	
																	/ SUM(DaysDiff) OVER (PARTITION BY c1.ComputerName, c1.Drive))   AS AvgGrowth'
												   ELSE ''
											   END + CHAR( 10 ) +
			'FROM c1
								) sub 
								PIVOT (MAX(MaxUsedMB) FOR YYYYMM IN (' + @dMonthString + ')) AS PVT
								' +
								   CASE
									   WHEN @Forecast = 1 THEN 'CROSS APPLY (
											  SELECT TOP 1 PercentFree, FreeGB FROM Inventory.DiskSpace WHERE ComputerName = PVT.ComputerName AND Drive = PVT.Drive ORDER BY DateKey DESC
											) ca1'
									   ELSE 'CROSS APPLY ( SELECT (' + @dMonCoDescString + '-' + @dMonCoAscString + ') As Growth) ca2'
								   END + CHAR( 10 ) +
			'ORDER BY ComputerName,Drive' +
						 CASE
							 WHEN @Forecast = 1 THEN ',PercentFree'
							 ELSE ''
						 END + SPACE(1) + 
			'OPTION (RECOMPILE);';

			-- PRINT @eSql;
			EXEC @rc = sys.sp_executesql @eSql
											 ,N'@iStartDate DateTime,@iEndDate DateTime'
											 ,@iStartDate
											 ,@iEndDate;

		END TRY
		BEGIN CATCH

			SET @rc = 1

			EXEC [Admin].usp_error_handler

		END CATCH;

		-- clear from cache

		DROP TABLE #gDate;
		DROP TABLE #sDiskRepo;

		RETURN (@rc);

	END;
	GO
