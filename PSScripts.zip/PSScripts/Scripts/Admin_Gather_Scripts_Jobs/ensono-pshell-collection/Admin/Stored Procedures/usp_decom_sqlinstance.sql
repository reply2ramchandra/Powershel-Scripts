CREATE PROCEDURE [Admin].[usp_decom_sqlinstance] @sqlinstance VARCHAR(256),@additional_comments VARCHAR(256) = NULL
AS

	/***************************************************************************************************************************************
		Copyright � 2020 Ensono LP, USA. All rights reserved

		Purpose: Update Sql Server entry in ServerList Table when decommissioned
		

		History:
		------------------------------------------------------------------------------------------------------------------------------------
		Author                                 Date Created                Comments
		------------------------------------------------------------------------------------------------------------------------------------
		Harsha vasa                              2020-10-27                  Initial draft



	    ------------------------------------------------------------------------------------------------------------------------------------

		Documentation:
		--------------
        * Affected Table Name: ServerList
		* Include additional comments section to log Change Ticket/ TeamTrak # etc.,


		Execution Samples:
		------------------
		1) EXEC Inventory.usp_decom_sqlinstance 'SqlInstance To Decom'

    ***************************************************************************************************************************************/

	SET NOCOUNT ON

	BEGIN

		IF NOT EXISTS (SELECT 1 FROM Inventory.[ServerList] WHERE SqlInstance = @sqlinstance)
			 BEGIN
				 RAISERROR ('Could not find SqlInstance: ''%s'' in the inventory..',16,1,@sqlinstance)
                 RETURN
			 END

		-- Update ServerList Table
		BEGIN TRY
			BEGIN TRANSACTION

			UPDATE Inventory.[ServerList]
			SET IsActive = 0
			   ,HasAccess = 'N'
			   ,SupportGroup = NULL
               ,ConnectionMethod = NULL
			   ,[Description] = COALESCE(@additional_comments + SPACE(1),'') + 'DECOMMISSIONED ON --' + CONVERT( VARCHAR(12),GETDATE(),7 ) + '::' + COALESCE([Description],'')
			WHERE SqlInstance = @sqlinstance

			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH

			IF @@trancount <> 0
				ROLLBACK TRANSACTION

		END CATCH



	END