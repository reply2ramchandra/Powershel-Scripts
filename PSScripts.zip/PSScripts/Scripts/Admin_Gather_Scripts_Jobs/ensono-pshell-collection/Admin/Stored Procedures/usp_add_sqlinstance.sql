CREATE PROCEDURE [Admin].[usp_add_sqlinstance] @SqlInstance VARCHAR(256)
											  ,@Environment CHAR(1)
											  ,@Domain		VARCHAR(128)
											  ,@Description VARCHAR(1024) = NULL
AS


	/***************************************************************************************************************************************
		Copyright © 2021 Ensono LP, USA. All rights reserved

		Purpose: Add SQLInstance to Inventory for collection and other DBA related stuff
		

		History:
		------------------------------------------------------------------------------------------------------------------------------------
		Author                                 Date Created                Comments
		------------------------------------------------------------------------------------------------------------------------------------
		Harsha vasa                              2021-01-29                  Initial draft



	    ------------------------------------------------------------------------------------------------------------------------------------

		Documentation:
		--------------
                ASCII(169) - ©


		Execution Samples:
		------------------
		
		EXEC Admin.[usp_add_sqlinstance] @SqlInstance = 'Server To Add', 
										 @Environment = 'D', 
										 @Domain = 'INT.ENSONO.COM', 
										 @Description = 'Development server for *&&&&* application'


    ***************************************************************************************************************************************/
	SET NOCOUNT ON;

	BEGIN

		IF EXISTS (SELECT 1 FROM Inventory.ServerList AS sl WHERE sl.SqlInstance = @SqlInstance)
        BEGIN
			RAISERROR ('SqlInstance: [%s] specified already exists. Please check and rerun...',16,1,@SqlInstance) WITH NOWAIT;
            RETURN
        END
		IF @Environment NOT IN ('P','T','U','S','D','Q','O','R')
			 BEGIN
				 RAISERROR ('Valid Environment Values: 
	        P = Production
            T = Test
            U = UAT
            S = Stage
            D = Development
            Q = QA
            O = PreProd
            R = DR',16,1) WITH NOWAIT;
                RETURN;
			 END

		IF @Description IS NULL
			 BEGIN
				 SET @Description = UPPER(@SqlInstance) +
												  CASE @Environment
													  WHEN 'P' THEN 'Production'
													  WHEN 'T' THEN 'Test'
													  WHEN 'U' THEN 'UAT'
													  WHEN 'S' THEN 'Stage'
													  WHEN 'D' THEN 'Development'
													  WHEN 'Q' THEN 'QA'
													  WHEN 'O' THEN 'PreProd'
													  WHEN 'R' THEN 'DR'
												  END + '::CREATED ON' + CONVERT( VARCHAR(12),GETDATE(),7 )
			 END

		BEGIN TRY
			BEGIN TRANSACTION
			INSERT INTO Inventory.ServerList( SqlInstance
											 ,Environment
											 ,Domain
											 ,[Description] )
			VALUES (UPPER(@SqlInstance),UPPER(@Environment),UPPER(@Domain),@Description);

			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH

			IF @@trancount <> 0
				ROLLBACK TRANSACTION

		END CATCH

	END