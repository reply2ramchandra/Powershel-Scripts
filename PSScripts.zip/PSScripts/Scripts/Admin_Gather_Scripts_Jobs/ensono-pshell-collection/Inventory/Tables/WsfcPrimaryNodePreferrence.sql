﻿CREATE TABLE [Inventory].[WsfcPrimaryNodePreferrence]
(
	[SqlInstance] VARCHAR(256) NOT NULL
)
