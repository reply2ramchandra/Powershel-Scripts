﻿CREATE TABLE [Inventory].[AdvancedConfigurationItems]
(
	[SqlInstance] VARCHAR(256) NOT NULL
)
