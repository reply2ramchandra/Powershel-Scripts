CREATE TABLE [Inventory].[ServerUptime]
(
	[DateKey]           SMALLDATETIME,
    [SqlInstance]       VARCHAR(256) NOT NULL,
	[ComputerName]      VARCHAR(256) NULL,
	[WindowsBootTime]   DATETIME2(1) NULL,
	[SqlStartTime]      DATETIME2(1) NULL
    CONSTRAINT FK_ServerUptime_SqlInstance FOREIGN KEY ([SqlInstance]) REFERENCES [Inventory].[ServerList] ([SqlInstance]) ON DELETE CASCADE
) 

GO

CREATE CLUSTERED INDEX [CX_ServerUptime_SqlInstance] ON [Inventory].[ServerUptime] ([SqlInstance])

GO