CREATE TABLE [Inventory].[DiskSpace] (
    [DateKey]       SMALLDATETIME,
    [ComputerName]  VARCHAR(256),    
    [Drive]         VARCHAR(256)   NULL,
    [TotalGB]       FLOAT  NULL,
    [FreeGB]        FLOAT  NULL,
    [PercentFree]   FLOAT  NULL,
    [BlockSize]     FLOAT  NULL
);


GO



CREATE CLUSTERED INDEX [CX_DiskSpace_DateKey] ON [Inventory].[DiskSpace] (DateKey)
