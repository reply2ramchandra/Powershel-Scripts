CREATE TABLE [Inventory].[Logins] (
    [DateKey]         SMALLDATETIME,
    [SqlInstance]     VARCHAR (256)  NOT NULL,
    [Name]            VARCHAR (1024) NOT NULL,
    [LoginType]       VARCHAR (64)   NULL,
    [CreateDate]      DATETIME2 (1)  NULL,
    [DefaultDatabase] VARCHAR (1024) NULL,
    [Language]        VARCHAR (256)  NULL,
    [PrincipalId]     INT NULL, 
    CONSTRAINT FK_Logins_SqlInstance FOREIGN KEY ([SqlInstance]) REFERENCES [Inventory].[ServerList] ([SqlInstance]) ON DELETE CASCADE
);


GO



CREATE CLUSTERED INDEX [CX_Logins_DateKey] ON [Inventory].[Logins] ([DateKey])

GO



CREATE INDEX [NIX_Logins_SqlInstance_Name] ON [Inventory].[Logins] ([SqlInstance],[Name])
GO
