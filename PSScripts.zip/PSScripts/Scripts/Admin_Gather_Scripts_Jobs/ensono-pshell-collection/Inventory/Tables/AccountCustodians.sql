﻿CREATE TABLE [Inventory].[AccountCustodians]
(
	[LoginName] VARCHAR(256),
	[AccountOwnerGroup] VARCHAR(256),
    [UserToValidate] VARCHAR(256)
)
