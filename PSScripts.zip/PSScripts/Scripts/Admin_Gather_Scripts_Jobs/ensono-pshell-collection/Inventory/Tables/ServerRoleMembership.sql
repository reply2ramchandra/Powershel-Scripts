﻿CREATE TABLE [Inventory].[ServerRoleMembership]
(
	[SqlInstance] VARCHAR(256) NOT NULL
)
