CREATE TABLE [Inventory].[ClusterNodeNames] (
    [SqlInstance]  VARCHAR (256) NULL,
    [Host]         VARCHAR (256) ,
    CONSTRAINT FK_ClusterNodeNames_SqlInstance FOREIGN KEY ([SqlInstance]) REFERENCES [Inventory].[ServerList] ([SqlInstance]) ON DELETE CASCADE
);


GO

