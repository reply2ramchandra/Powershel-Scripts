﻿CREATE TABLE [Inventory].[OperatingSystemInfo]
(
	[DateKey] SMALLDATETIME NOT NULL, 
    [ComputerName] VARCHAR(256) NULL,
    [Manufacturer] VARCHAR(256) NULL, 
    [OSVersion] VARCHAR(128) NULL, 
    [SPVersion] INT NULL, 
    [Architecture] VARCHAR(32) NULL, 
    [Version] VARCHAR(64) NULL, 
    [InstallDate] DATETIME NULL, 
    [LastBootTime] DATETIME NULL, 
    [TimeZone] NVARCHAR(128) NULL, 
    [PowerShellVersion] VARCHAR(16) NULL, 
    [ActivePowerPlan] VARCHAR(64) NULL, 
    [VisibleMemoryInMB] INT NULL, 
    [IsWsfc] BIT NOT NULL
)

GO

CREATE CLUSTERED INDEX [CX_OperatingSystemInfo_ComputerName] ON [Inventory].[OperatingSystemInfo] (ComputerName)