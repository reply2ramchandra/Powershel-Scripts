-- Integrated with Collection Process
-- All the pre-requisties should be made available on collection jobs server typically Collection Management Server. One exception is LSC, where collection jobs are running
-- on Customer Utility server because Firewall dependencies (PWPAXD-UTLDBA01) 

--------------------
-- Pre-requisties
--------------------

-- >. Powershell Version
    -- 5.1 

-- >. Required Powershell Modules
    -- dbatools
    -- dbcchecks
    -- FailoverClusters (Enable windows feature "Failover Clustering" from Server Manager to install module)
    -- SqlServer
    -- ImportExcel

-- >. Define Timings of Maintenance Window
-- We need this timings to update the Job Schedules to run our Pre and Post Snapshot Jobs
-- Usually for US Customers:  
    -- 3rd Saturday 10PM - 6AM (Prod)
    -- 2nd Saturday 10PM - 6AM (NonProd)
    


--------------------------------------
--- Define Workflow
--------------------------------------

-- >. Items to Collect as part of PreSnopshot
    -- Sql Services (Instance,ServiceAccount,LastRebootTime,NodeName)
    -- Database Status
    -- Job Status
    -- SQL Cluster ??
        -- Resources and Ownership
        -- Preferred Node
    -- AlwaysOn AG ??
        -- AG Status
        -- Primary Replica    
    -- Replication ??

-- >. Schedule PreSnapshot around 7 - 8PM CST
    --         

