﻿
SET NOCOUNT ON;

DECLARE @Wmi32Class TABLE ([command] VARCHAR(MAX));
DECLARE @Sql VARCHAR(512);
DECLARE @ComputerName VARCHAR(256);

DECLARE @Original_AdvOptions_State SQL_VARIANT;
DECLARE @Original_CmdShell_State SQL_VARIANT;
DECLARE @Current_AdvOptions_State SQL_VARIANT
DECLARE @Current_CmdShell_State SQL_VARIANT;
SET @Original_AdvOptions_State = 0;
SET @Original_CmdShell_State = 0;
SET @Current_AdvOptions_State = 0;
SET @Current_CmdShell_State = 0;

/*  ENABLE XP_CMDSHELL  */
SELECT
	@Original_AdvOptions_State = value_in_use
FROM master.sys.configurations
WHERE name = 'show advanced options'
SELECT
	@Original_CmdShell_State = value_in_use
FROM master.sys.configurations
WHERE name = 'xp_cmdshell'

IF @Original_AdvOptions_State = 0
	 BEGIN
		 EXEC sp_configure 'show advanced options'
						  ,1
		 RECONFIGURE WITH OVERRIDE
	 END

IF @Original_CmdShell_State = 0
	 BEGIN
		 --    PRINT 'Changing xp_cmdshell is off - CHANGING to on'
		 EXEC sp_configure 'xp_cmdshell'
						  ,1
		 RECONFIGURE WITH OVERRIDE
	 END

/* END */


IF SERVERPROPERTY( 'IsClustered' ) = 1
	DECLARE cur CURSOR FAST_FORWARD READ_ONLY LOCAL
	FOR
		SELECT
			NodeName
		FROM sys.dm_os_cluster_nodes   -- ALL NODES
ELSE
	DECLARE cur CURSOR FAST_FORWARD READ_ONLY LOCAL
	FOR
		SELECT
			CAST( SERVERPROPERTY( 'ComputerNamePhysicalNetBIOS' ) AS VARCHAR(256) )

OPEN cur
FETCH NEXT FROM cur INTO @ComputerName
WHILE @@fetch_status = 0
	 BEGIN
		 SET @Sql = 'powershell.exe -c "Get-WmiObject -ComputerName' + SPACE( 1 ) + @ComputerName + ' -Class Win32_Volume -Filter ''DriveType = 3''| Select-Object SystemName,Name,Capacity,Freespace,BlockSize | Foreach-Object{$_.Name+''&''+$_.Capacity/1GB+''#''+$_.freespace/1GB+''@''+$_.BlockSize+''>''+$_.SystemName+''<''}"';

		 INSERT INTO @Wmi32Class
		 EXEC [master].sys.xp_cmdshell @Sql;

		 IF @@error > 0
		 OR @@rowcount = 0
			  BEGIN
				  RAISERROR ('Error while executing xp_cmdshell cmd.Check if it is enabled or log entries for additional details',16,1) WITH NOWAIT;
			  --RETURN (1);
			  END;

		 FETCH NEXT FROM cur INTO @ComputerName
	 END
CLOSE cur
DEALLOCATE cur

SELECT
	CAST( CONVERT( VARCHAR,GETDATE(),23 ) AS SMALLDATETIME )													AS DateKey
   ,ISNULL( NULLIF( ComputerName,'' ),CAST( SERVERPROPERTY( 'ComputerNamePhysicalNetBIOS' ) AS VARCHAR(256) ) ) AS ComputerName
   ,base.drive																									AS Drive
   ,CEILING( base.TotalGB )																						AS TotalGB
   ,base.FreeGB																									AS FreeGB
   ,ROUND( CAST( base.FreeGB / base.TotalGB * 100 AS DECIMAL(5,2) ),1 )											AS PercentFree
   ,base.[BlockSize]

FROM (
	  SELECT
		  RTRIM( LTRIM( SUBSTRING( command,1,CHARINDEX( '&',command,1 ) - 1 ) ) )														   AS drive
		 ,CAST( RTRIM( LTRIM( SUBSTRING( command,t1.capacity + 1,CHARINDEX( '#',t1.tail,1 ) - 1 ) ) ) AS FLOAT )						   AS TotalGB
		 ,CAST( RTRIM( LTRIM( CONVERT( DECIMAL(10,2),SUBSTRING( command,t2.freespace + 1,CHARINDEX( '@',t2.tail,1 ) - 1 ) ) ) ) AS FLOAT ) AS FreeGB
		 ,CAST( RTRIM( LTRIM( SUBSTRING( command,t3.[BlockSize] + 1,CHARINDEX( '>',t3.tail,1 ) - 1 ) ) ) AS FLOAT )						   AS [BlockSize]
		 ,CAST( RTRIM( LTRIM( SUBSTRING( command,t4.[ComputerName] + 1,CHARINDEX( '<',t4.tail,1 ) - 1 ) ) ) AS VARCHAR(256) )			   AS [ComputerName]
	  FROM @Wmi32Class
	  CROSS APPLY (
			SELECT
				CHARINDEX( '&',command,0 )						 AS capacity
			   ,STUFF( command,1,CHARINDEX( '&',command,1 ),'' ) AS tail
	  ) t1
	  CROSS APPLY (
			SELECT
				CHARINDEX( '#',command,0 )						 AS freespace
			   ,STUFF( command,1,CHARINDEX( '#',command,1 ),'' ) AS tail
	  ) t2
	  CROSS APPLY (
			SELECT
				CHARINDEX( '@',command,0 )						 AS [BlockSize]
			   ,STUFF( command,1,CHARINDEX( '@',command,1 ),'' ) AS tail
	  ) t3
	  CROSS APPLY (
			SELECT
				CHARINDEX( '>',command,0 )						 AS [ComputerName]
			   ,STUFF( command,1,CHARINDEX( '>',command,1 ),'' ) AS tail
	  ) t4
	  WHERE command LIKE '[C-Z][:]%'  -- Change to C-Z to list all Drives
) base
ORDER BY ComputerName,Drive;


/* REVERT TO ORIGINAL STATE */
SELECT
	@Current_CmdShell_State = value_in_use
FROM master.sys.configurations
WHERE name = 'xp_cmdshell'

IF @Original_CmdShell_State <> @Current_CmdShell_State
	 BEGIN
		 --PRINT 'Reverting xp_cmdshell state'
		 EXEC sp_configure 'xp_cmdshell'
						  ,0
		 RECONFIGURE WITH OVERRIDE
	 END

SELECT
	@Current_AdvOptions_State = value_in_use
FROM master.sys.configurations
WHERE name = 'show advanced options'

IF @Original_AdvOptions_State <> @Current_AdvOptions_State
	 BEGIN
		 --PRINT 'Reverting show advanced options state'
		 RECONFIGURE WITH OVERRIDE
	 END

/* END */


SET NOCOUNT OFF;
