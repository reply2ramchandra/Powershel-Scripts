﻿/*
	Created by HPS\a-sm58408 using dbatools Export-DbaScript for objects on TPAPWDWSQL004 at 01/06/2025 06:30:21
	See https://dbatools.io/Export-DbaScript for more information
*/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'0000_ETL - TRIGGER DATALINK LOAD_ODS', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'SQL Admin_ICT_DL', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PREVIOUS_LOAD_STATUS', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'------------------------
--PREVIOUS_LOAD_STATUS
------------------------

/*Modified the exisitng Job logic to check if any dependant job are running or not before incremental load Job start
09/18/2020 Smruti Palai  merging step 5 and step 6 of the ETL - TRIGGER DATALINK LOAD_HDS
09/21/2020 Smruti Palai removed the temporary table and placed the logic inside while loop */

-------------Check job running status of job which are depedant job for Incremental load
Use msdb
GO


WHILE 1=1
BEGIN 
IF((Select Count(s1.job_id)
       from(Select s.Job_ID 
			     ,s.name
			FROM msdb.dbo.sysjobs s 
			where name in(Select JOB_NAME from HPS_Config.dbo.ETL_JOBS_ODS))S1
		INNER JOIN (
		-----Get currently running jobs
					SELECT
						ja.job_id,
						j.name AS job_name,
						ja.start_execution_date,      
						ISNULL(last_executed_step_id,0)+1 AS current_executed_step_id,
						Js.step_name
					FROM msdb.dbo.sysjobactivity ja 
					LEFT JOIN msdb.dbo.sysjobhistory jh ON ja.job_history_id = jh.instance_id
					JOIN msdb.dbo.sysjobs j ON ja.job_id = j.job_id
					JOIN msdb.dbo.sysjobsteps js
						ON ja.job_id = js.job_id
						AND ISNULL(ja.last_executed_step_id,0)+1 = js.step_id
					WHERE
					  ja.session_id = (
						SELECT TOP 1 session_id FROM msdb.dbo.syssessions ORDER BY agent_start_date DESC
					  )
					AND start_execution_date IS NOT NULL
					AND stop_execution_date IS NULL
					) rs
		ON s1.Job_ID=rs.job_id) =0 
		AND ((select max(HPDQ_AVAILABLE) from HPS_CONFIG.DBO.LOAD_REFRESH_STATUS) < (select HPDQ_AVAILABLE from HPS_CONFIG.DBO.HPDQ_REFRESH))
		-- AND ((select cast(HPDQ_AVAILABLE as date) from HPS_CONFIG.DBO.HPDQ_REFRESH) = (select CAST(getdate() as date)) )
				)
  BEGIN

  PRINT ''Not Running''
  BREAK

  END
ELSE
BEGIN
Waitfor delay ''00:10:00'';
 Continue
  END
END



INSERT INTO HPS_CONFIG.DBO.LOAD_REFRESH_STATUS (LOAD_DATE,HPDQ_REHRESH_STATUS, HPDQ_AVAILABLE)
VALUES(CAST(GETDATE() as DATE),''N'',(select HPDQ_AVAILABLE from HPS_CONFIG.DBO.HPDQ_REFRESH))


INSERT INTO HPS_CONFIG.DBO.LOAD_REFRESH_STATUS_RENEWAL_AND_ODS_STG (LOAD_DATE,HPDQ_REHRESH_STATUS)
VALUES(CAST(GETDATE() as DATE),''N'')


/*
UPDATE HPS_CONFIG.DBO.LOAD_REFRESH_STATUS SET HPDQ_AVAILABLE = (SELECT HPDQ_AVAILABLE FROM HPS_CONFIG.DBO.HPDQ_REFRESH)
WHERE LOAD_DATE IN (SELECT MAX(LOAD_DATE) FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS)

	
UPDATE 
HPS_LOADING.DBO.LOAD_REFRESH_STATUS
SET LOAD_START_DATETIME=GETDATE()
WHERE LOAD_DATE= (SELECT MAX(LOAD_DATE) FROM HPS_LOADING.DBO.LOAD_REFRESH_STATUS) AND LOAD_START_DATETIME IS NULL

*/', 
		@database_name=N'HPS_Config', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute job ''ETL HPS_ODS Stage tables''', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/*DECLARE @ODS_STAGE_LOAD_STATUS NVARCHAR(1)
SELECT 
@ODS_STAGE_LOAD_STATUS= 
ODS_STAGE_LOAD_STATUS FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS
WHERE LOAD_DATE = (SELECT MAX(LOAD_DATE) FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS
IF @ODS_STAGE_LOAD_STATUS IS NULL
BEGIN
EXEC msdb.dbo.sp_start_job ''ETL HPS_ODS Stage tables''
UPDATE HPS_LOADING.DBO.LOAD_REFRESH_STATUS
SET ODS_STAGE_LOAD_STATUS=''Y'' WHERE LOAD_DATE = (SELECT MAX(LOAD_DATE) FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS)
AND ODS_STAGE_LOAD_STATUS IS NULL
END
*/


DECLARE @ODS_STAGE_LOAD_STATUS NVARCHAR(1)
SELECT 
@ODS_STAGE_LOAD_STATUS= 
HPS_ODS_STAGE_LOAD_STATUS FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS_RENEWAL_AND_ODS_STG
WHERE LOAD_DATE = (SELECT MAX(LOAD_DATE) FROM  HPS_CONFIG.DBO.LOAD_REFRESH_STATUS_RENEWAL_AND_ODS_STG)
IF @ODS_STAGE_LOAD_STATUS IS NULL
BEGIN
/*
EXEC msdb.dbo.sp_start_job ''006_ETL HPS_ODS Stage tables''
UPDATE HPS_CONFIG.DBO.LOAD_REFRESH_STATUS_RENEWAL_AND_ODS_STG
SET HPS_ODS_STAGE_LOAD_STATUS=''Y'' 
, HPS_ODS_STAGE_LOAD_START_DATETIME = GETDATE()
WHERE LOAD_DATE = (SELECT MAX(LOAD_DATE) FROM  HPS_CONFIG.DBO.LOAD_REFRESH_STATUS_RENEWAL_AND_ODS_STG)
AND HPS_ODS_STAGE_LOAD_STATUS IS NULL

*/
---Newly added logic for handling multiple calls for the same job
  IF NOT EXISTS(     
                     select 1 
                     from msdb.dbo.sysjobs_view job  
                     inner join msdb.dbo.sysjobactivity activity on job.job_id = activity.job_id 
                     where  
                           activity.run_Requested_date is not null  
                     and activity.stop_execution_date is null  
                     and job.name = ''006_ETL HPS_ODS Stage tables'' 
	     and cast(activity.run_Requested_date as date)=cast(getdate() as date) 
                     )
       BEGIN      
              EXEC msdb.dbo.sp_start_job ''006_ETL HPS_ODS Stage tables''
			  UPDATE  HPS_CONFIG.DBO.LOAD_REFRESH_STATUS_RENEWAL_AND_ODS_STG
			  SET HPS_ODS_STAGE_LOAD_STATUS=''Y'' , HPS_ODS_STAGE_LOAD_START_DATETIME = GETDATE()
			  WHERE LOAD_DATE = (SELECT MAX(LOAD_DATE) FROM  HPS_CONFIG.DBO.LOAD_REFRESH_STATUS_RENEWAL_AND_ODS_STG)
				    AND HPS_ODS_STAGE_LOAD_STATUS IS NULL

UPDATE 
			HPS_CONFIG.DBO.LOAD_REFRESH_STATUS
			SET LOAD_START_DATETIME=GETDATE()
			WHERE LOAD_DATE= (SELECT MAX(LOAD_DATE) FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS) AND LOAD_START_DATETIME IS NULL


       END 

END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'LOAD - RENEWAL_DASHBOARD_INCR', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/*DECLARE @RENEWAL_DASHBOARD_LOAD_STATUS NVARCHAR(1)
SELECT @RENEWAL_DASHBOARD_LOAD_STATUS= RENEWAL_DASHBOARD_LOAD_STATUS FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS
WHERE LOAD_DATE = (SELECT MAX(LOAD_DATE) FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS)
IF @RENEWAL_DASHBOARD_LOAD_STATUS IS NULL
BEGIN
EXEC msdb.dbo.sp_start_job ''RENEWAL_DASHBOARD_INCR''
--EXEC msdb.dbo.sp_start_job ''RENEWAL_DASHBOARD_FULL''
UPDATE HPS_CONFIG.DBO.LOAD_REFRESH_STATUS
SET RENEWAL_DASHBOARD_LOAD_STATUS=''Y'' WHERE LOAD_DATE = (SELECT MAX(LOAD_DATE) FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS)
AND RENEWAL_DASHBOARD_LOAD_STATUS IS NULL
END
*/


DECLARE @RENEWAL_DASHBOARD_LOAD_STATUS NVARCHAR(1)
SELECT @RENEWAL_DASHBOARD_LOAD_STATUS= RENEWAL_DASHBOARD_LOAD_STATUS FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS_RENEWAL_AND_ODS_STG
WHERE LOAD_DATE = (SELECT MAX(LOAD_DATE) FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS_RENEWAL_AND_ODS_STG)
IF @RENEWAL_DASHBOARD_LOAD_STATUS IS NULL
BEGIN
/*
EXEC msdb.dbo.sp_start_job ''RENEWAL_DASHBOARD_INCR''
UPDATE HPS_CONFIG.DBO.LOAD_REFRESH_STATUS_RENEWAL_AND_ODS_STG
SET RENEWAL_DASHBOARD_LOAD_STATUS=''Y'' 
, RENEWAL_DASHBOARD_LOAD_START_DATETIME = GETDATE() 
WHERE LOAD_DATE = (SELECT MAX(LOAD_DATE) FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS_RENEWAL_AND_ODS_STG)
AND RENEWAL_DASHBOARD_LOAD_STATUS IS NULL
*/
---Newly added logic for handling multiple calls for the same job
     IF NOT EXISTS(     
                  select 1
                     from msdb.dbo.sysjobs_view job  
                     inner join msdb.dbo.sysjobactivity activity on job.job_id = activity.job_id 
                     where  
                           activity.run_Requested_date is not null  
                     and activity.stop_execution_date is null  
                     and job.name = ''005_ETL_RENEWAL_DASHBOARD_INCR''
					 and cast(activity.run_Requested_date as date)=cast(getdate() as date) 

                     )
       BEGIN      
              EXEC msdb.dbo.sp_start_job ''005_ETL_RENEWAL_DASHBOARD_INCR''; 
              UPDATE HPS_CONFIG.DBO.LOAD_REFRESH_STATUS_RENEWAL_AND_ODS_STG
              SET RENEWAL_DASHBOARD_LOAD_STATUS=''Y'' , RENEWAL_DASHBOARD_LOAD_START_DATETIME = GETDATE() 
              WHERE LOAD_DATE = (SELECT MAX(LOAD_DATE) FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS_RENEWAL_AND_ODS_STG)
                             AND RENEWAL_DASHBOARD_LOAD_STATUS IS NULL
       END 
       --------------------------
END
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Sync_level tables', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE HPS_ODS
GO

if (select count(0) from conformed_DIM_LEVEL_CASE_DETAIL) > 0

BEGIN

--Rename existing Dimensions
EXEC sp_rename ''dbo.DIM_LEVEL_CASE_DETAIL'', ''DIM_LEVEL_CASE_DETAIL_OLD''

--Rename conformed Dimension
EXEC sp_rename ''dbo.conformed_DIM_LEVEL_CASE_DETAIL'', ''DIM_LEVEL_CASE_DETAIL''

--Rename old Dimension
EXEC SP_RENAME ''dbo.DIM_LEVEL_CASE_DETAIL_OLD'', ''conformed_DIM_LEVEL_CASE_DETAIL''

END

------------------------------------------------------------------------------

if (select count(0) from conformed_DIM_LEVEL_INDIVIDUAL_LIST_BILL) > 0

BEGIN

--Rename existing Dimensions
EXEC sp_rename ''dbo.DIM_LEVEL_INDIVIDUAL_LIST_BILL'', ''DIM_LEVEL_INDIVIDUAL_LIST_BILL_OLD''

--Rename conformed Dimension
EXEC sp_rename ''dbo.conformed_DIM_LEVEL_INDIVIDUAL_LIST_BILL'', ''DIM_LEVEL_INDIVIDUAL_LIST_BILL''

--Rename old Dimension
EXEC SP_RENAME ''dbo.DIM_LEVEL_INDIVIDUAL_LIST_BILL_OLD'', ''conformed_DIM_LEVEL_INDIVIDUAL_LIST_BILL''

END', 
		@database_name=N'HPS_ODS', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'INSERT LOAD STATUS', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @LOAD_DATE DATE
SELECT  @LOAD_DATE= COALESCE(MAX(LOAD_DATE),''1900-01-01'') FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS
IF @LOAD_DATE<CAST(GETDATE() AS DATE) 
INSERT INTO HPS_CONFIG.DBO.LOAD_REFRESH_STATUS(LOAD_DATE,HPDQ_REHRESH_STATUS,DW_REFRESH_TIME) 
SELECT CAST(GETDATE() as DATE),''N'',DW_REFRESH_TIME FROM HPS_CONFIG.dbo.HPDQ_REFRESH

/*DECLARE @LOAD_DATE DATETIME2(7)
SELECT  @LOAD_DATE= COALESCE(MAX(LOAD_DATE),''1900-01-01 00:00:00.0000000'') FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS
IF @LOAD_DATE<CAST(GETDATE() AS DATETIME2(7)) 
INSERT INTO HPS_CONFIG.DBO.LOAD_REFRESH_STATUS(LOAD_DATE,HPDQ_REHRESH_STATUS)
VALUES(CAST(GETDATE() as DATETIME2(7)),''N'')*/


/*DECLARE @LOAD_DATE DATETIME2(7)
SELECT  @LOAD_DATE= COALESCE(MAX(LOAD_DATE),''1900-01-01 00:00:00.0000000'') FROM 
HPS_CONFIG.DBO.LOAD_REFRESH_STATUS
IF @LOAD_DATE<(Select HPDQ_AVAILABLE from HPS_LOADING.dbo.HPDQ_REFRESH)
 INSERT INTO HPS_CONFIG.DBO.LOAD_REFRESH_STATUS(LOAD_DATE,HPDQ_REHRESH_STATUS)
VALUES(CAST(GETDATE() as DATETIME2(7)),''N'')*/', 
		@database_name=N'HPS_Config', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'LOAD - DAILY_ACTIVITY_REPORT', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @DAR_LOAD_STATUS NVARCHAR(1)
SELECT @DAR_LOAD_STATUS= DAR_LOAD_STATUS FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS
WHERE LOAD_DATE = (SELECT MAX(LOAD_DATE) FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS)
IF @DAR_LOAD_STATUS IS NULL
BEGIN
/*
EXEC msdb.dbo.sp_start_job ''002_ETL - DAILY_ACTIVITY_REPORT''
UPDATE HPS_CONFIG.DBO.LOAD_REFRESH_STATUS
SET DAR_LOAD_STATUS=''Y'' WHERE LOAD_DATE = (SELECT MAX(LOAD_DATE) FROM HPS_LOADING.DBO.LOAD_REFRESH_STATUS)
AND DAR_LOAD_STATUS IS NULL
*/
 IF NOT EXISTS(     
                     select 1 
                     from msdb.dbo.sysjobs_view job  
                     inner join msdb.dbo.sysjobactivity activity on job.job_id = activity.job_id 
                     where  
                           activity.run_Requested_date is not null  
                     and activity.stop_execution_date is null  
                     and job.name = ''002_ETL - DAILY_ACTIVITY_REPORT''
		and cast(activity.run_Requested_date as date)=cast(getdate() as date) 
                     ) 
       BEGIN      
              EXEC msdb.dbo.sp_start_job ''002_ETL - DAILY_ACTIVITY_REPORT''; 
              UPDATE HPS_CONFIG.DBO.LOAD_REFRESH_STATUS
              SET DAR_LOAD_STATUS=''Y'' WHERE LOAD_DATE = (SELECT MAX(LOAD_DATE) FROM HPS_CONFIG.DBO.LOAD_REFRESH_STATUS)
              AND DAR_LOAD_STATUS IS NULL
       END 


END
', 
		@database_name=N'HPS_Config', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DATALINK ETL LOAD SCHEDULE', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=4, 
		@freq_subday_interval=15, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20190705, 
		@active_end_date=99991231, 
		@active_start_time=1400, 
		@active_end_time=235959, 
		@schedule_uid=N'd3e2b6a7-c037-417b-ba0f-7d8ba7bb10f1'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

