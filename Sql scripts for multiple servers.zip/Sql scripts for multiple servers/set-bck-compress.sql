 --DECLARE @sqlcmd NVARCHAR(MAX);
 -- SELECT
	--				 name,value_in_use
	--			  FROM [master].sys.configurations where name='backup compression default'
 --IF EXISTS (SELECT
	--				 1
	--			  FROM [master].sys.configurations where name='backup compression default' and value_in_use=0)

	--			  BEGIN
	--				 SET @sqlcmd = N'EXEC sp_configure ''show advanced options'', 1;' + CHAR( 13 ) + 'RECONFIGURE WITH OVERRIDE;' + CHAR( 13 )
	--				 + 'EXEC sp_configure N' + CHAR( 39 ) + 'backup compression default' + CHAR( 39 ) + ',' + CONVERT( VARCHAR(128),1 ) + ';' + CHAR( 13 )
	--				 + 'RECONFIGURE WITH OVERRIDE;'
	--				 EXEC [master].sys.sp_executesql @sqlcmd;
	--			 END

				 SELECT @@servername as srv,
					 name,value_in_use
				  FROM [master].sys.configurations where name='backup compression default'