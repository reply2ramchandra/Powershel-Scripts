IF EXISTS(select 1 from msdb..sysschedules where name='BI-WEEKLY')
BEGIN
EXEC msdb.dbo.sp_attach_schedule  @job_name = N'Output File Cleanup', @schedule_name = N'BI-WEEKLY';
END
ELSE
BEGIN

EXEC msdb.dbo.sp_add_schedule  @schedule_name = N'BI-WEEKLY', @freq_type			   = 8
										  ,@freq_interval		   = 1
										  ,@freq_subday_interval   = 6
										  ,@freq_subday_type=1
										  ,@freq_recurrence_factor = 2  ,@active_start_time = 010000;

EXEC msdb.dbo.sp_attach_schedule  @job_name = N'Output File Cleanup', @schedule_name = N'BI-WEEKLY';
END
