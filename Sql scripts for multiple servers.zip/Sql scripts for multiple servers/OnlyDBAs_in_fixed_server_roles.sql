
USE [master]
GO
SET NOCOUNT ON

DECLARE @IncludeSummaryRpt     bit

SET @IncludeSummaryRpt = 1

DECLARE @SQLServer			varchar(128)
		,@TestId	varchar(10)
		,@Description		varchar(512)
		,@SQL				varchar(4000)
		,@SQLVersionMajor   int		
		,@DbName            varchar(128)
		,@CompatLevel       tinyint 
		
		
--SET @SQLVersionMajor = LEFT(CAST(SERVERPROPERTY('ProductVersion') AS varchar(25)), CHARINDEX('.', CAST(SERVERPROPERTY('ProductVersion') AS varchar(25))) - 1)

    BEGIN
        CREATE TABLE #Report
        (
		        SQLServer			varchar(128)	NOT NULL
		        ,TestId		varchar(10)		NOT NULL
		        ,TestDesc	varchar(256)	NOT NULL
		        ,DbName				varchar(128)	NULL
		        ,Description		varchar(2048)	NULL
		        ,FixScript			varchar(2048)	NULL
		        ,RollbackScript		varchar(2048)	NULL
        )

        SET @SQLServer = CAST(SERVERPROPERTY('MachineName') AS varchar(128)) + CASE WHEN CAST(SERVERPROPERTY('InstanceName') AS varchar(128)) IS NULL THEN '' ELSE '\' + CAST(SERVERPROPERTY('InstanceName') AS varchar(128)) END
       -- SET @SQLVersionMinor = SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') AS varchar(25)), CHARINDEX('.', CAST(SERVERPROPERTY('ProductVersion') AS varchar(25))) + 1, LEN(CAST(SERVERPROPERTY('ProductVersion') AS varchar(25))) - CHARINDEX('.', REVERSE(CAST(SERVERPROPERTY('ProductVersion') AS varchar(25)))) - 2)
        --SET @SQLVersionBuild = SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') AS varchar(25)), LEN(CAST(SERVERPROPERTY('ProductVersion') AS varchar(25))) - CHARINDEX('.', REVERSE(CAST(SERVERPROPERTY('ProductVersion') AS varchar(25)))) + 2, LEN(CAST(SERVERPROPERTY('ProductVersion') AS varchar(25))))
        --SET @SQLServicePack = CAST(ISNULL(SERVERPROPERTY('ProductLevel'), 'NULL') AS varchar(25))

        DECLARE CURSOR_DB CURSOR FAST_FORWARD
        FOR
            SELECT      name 
                        ,cmptlevel 
            FROM        sysdatabases
            WHERE       DATABASEPROPERTY(name, 'IsOffline') = 0
              AND       DATABASEPROPERTY(name, 'IsInRecovery') = 0
              AND       DATABASEPROPERTY(name, 'IsShutDown') = 0
              AND       DATABASEPROPERTY(name, 'IsSuspect') = 0
             -- AND       DATABASEPROPERTY(name, 'IsNotRecovered') = 0
              AND       DATABASEPROPERTY(name, 'IsInStandBy')= 0
            ORDER BY    name
			
			-- CLOSE CURSOR_DB


/* 
	        TEST ID:      100
        	
	        DESCRIPTION:  ONLY DBAS IN FIXED SERVER ROLES
        */
        SET @TestId = '100'
        SET @Description = 'Only DBAs in fixed server roles'

        IF OBJECT_ID('tempdb..#DBA_ExclusionList') IS NOT NULL
            DROP TABLE #DBA_ExclusionList

        CREATE TABLE #DBA_ExclusionList
        (
            Account		varchar(128)
        )

        INSERT INTO #DBA_ExclusionList VALUES('sa')
        INSERT INTO #DBA_ExclusionList VALUES('NT SERVICE\SQLWriter')
		INSERT INTO #DBA_ExclusionList VALUES('NT SERVICE\Winmgmt')
        INSERT INTO #DBA_ExclusionList VALUES('NT Service\MSSQLSERVER')
		INSERT INTO #DBA_ExclusionList VALUES('NT AUTHORITY\SYSTEM')
		INSERT INTO #DBA_ExclusionList VALUES('NT SERVICE\SQLSERVERAGENT')
		INSERT INTO #DBA_ExclusionList VALUES('HPS\SG-MSSQL-ADM-PROD')
		INSERT INTO #DBA_ExclusionList VALUES('db2ssrs')
		INSERT INTO #DBA_ExclusionList VALUES('HPS\a-sm58408')
		INSERT INTO #DBA_ExclusionList VALUES('HPS\a-RMaddineni')
		INSERT INTO #DBA_ExclusionList VALUES('HPS\RMaddineni')
		INSERT INTO #DBA_ExclusionList VALUES('HPS\a-kc16622')
		INSERT INTO #DBA_ExclusionList VALUES('HPS\svc_TPAPWIDESQL001')
        INSERT INTO #DBA_ExclusionList VALUES('DISTRIBUTOR_ADMIN')
         INSERT INTO #DBA_ExclusionList VALUES('HPS\svc_TPAPWSQLACT')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_tpapwairsql')
 INSERT INTO #DBA_ExclusionList VALUES('HPS\hps_alfdb_sa')
 INSERT INTO #DBA_ExclusionList VALUES('HPS\svc_hpssql')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_TPAPWPEDSQL')
 INSERT INTO #DBA_ExclusionList VALUES('NT Service\MSSQL$MHBE')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_TPAPWSQLBMC')
 INSERT INTO #DBA_ExclusionList VALUES('LocalSystem')
 INSERT INTO #DBA_ExclusionList VALUES('HPS\svc_TPAPWLVBDG')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_tpapwdwsql')
 INSERT INTO #DBA_ExclusionList VALUES('HPS\svc_datalinksql')
 INSERT INTO #DBA_ExclusionList VALUES('NT Service\MSSQLSERVER')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_prodsql2k804')
 INSERT INTO #DBA_ExclusionList VALUES('HPS\svc_aoet')
 INSERT INTO #DBA_ExclusionList VALUES('HPS\svc_aognr')
 INSERT INTO #DBA_ExclusionList VALUES('HPS\svc_TPAPWSQLHH')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_TPAPWSQLSSRS-04')
 INSERT INTO #DBA_ExclusionList VALUES('HPS\TPAPWILMTSQL')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_TPAPWIDESQL')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_TPAPWISSQL')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_HPSSQL11')
 INSERT INTO #DBA_ExclusionList VALUES('HPS\svc_EPO')
 INSERT INTO #DBA_ExclusionList VALUES('HPS\svcSQLTPAPWPESQL01')
 INSERT INTO #DBA_ExclusionList VALUES('HPS\svcSQLTPAPWPESQL02')
 INSERT INTO #DBA_ExclusionList VALUES('HPS\svc_TPAPWSQLREC')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_tpapwsqlrob')
 INSERT INTO #DBA_ExclusionList VALUES('svc_hpssql@HPS.HPH.AD')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_SQL_TPAPWSQLSSP')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_TPAPWSP16SQL')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svctaniumsql')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_tpapwhds_11')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_TPAPWTRSQL')
 INSERT INTO #DBA_ExclusionList VALUES('HPS\nicendm')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_bldpwrogger11')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svcVC4DBagent')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_tpapwvsql')
 INSERT INTO #DBA_ExclusionList VALUES('hps\svc_tpapwsql003')
 INSERT INTO #DBA_ExclusionList VALUES('HPS\ICMInstall')
 INSERT INTO #DBA_ExclusionList VALUES('svc_IderaDM')
 INSERT INTO #DBA_ExclusionList VALUES('HPS\svc_tpapwnicesql')
 INSERT INTO #DBA_ExclusionList VALUES('NT SERVICE\SQLTELEMETRY')
 INSERT INTO #DBA_ExclusionList VALUES('SQLLINK')
  INSERT INTO #DBA_ExclusionList VALUES('servicelink')
 
        
        INSERT INTO #Report
        SELECT		@SQLServer
	                ,@TestId
	                ,@Description
	                ,'master'
	                ,QUOTENAME(A.name) + ' is a member of Server Fixed Role sysadmin.'
                    ,CASE WHEN UPPER(A.name) = 'BUILTIN\ADMINISTRATORS' THEN 'USE [master];DECLARE @Message varchar(256); IF NOT EXISTS(SELECT * FROM syslogins WHERE UPPER(name) = ''HPS\SG-MSSQL-ADM-PROD'' AND sysadmin = 1) BEGIN SET @Message = ''BUILTIN\Administrators account cannot be removed, the hps\SG-MSSQL-ADM-PROD account does not exist or does not have sysadmin.  Please add this group account manually and remove BUILTIN\Administrators.'' RAISERROR (@Message, 18, 1) END ELSE BEGIN IF EXISTS(SELECT * FROM syslogins WHERE UPPER(name) = ''BUILTIN\ADMINISTRATORS'') EXECUTE sp_revokelogin ''BUILTIN\ADMINISTRATORS'' END ' ELSE 'EXECUTE master..sp_dropsrvrolemember @loginame = N''' + A.name + ''', @rolename = N''sysadmin''' END
                    ,CASE WHEN UPPER(A.name) = 'BUILTIN\ADMINISTRATORS' THEN 'USE [master];EXECUTE sp_grantlogin ''BUILTIN\ADMINISTRATORS'';EXECUTE master..sp_addsrvrolemember @loginame = N''BUILTIN\ADMINISTRATORS'', @rolename = N''sysadmin'' ' ELSE 'EXECUTE master..sp_addsrvrolemember @loginame = N''' + A.name + ''', @rolename = N''sysadmin''' END
        FROM		master..syslogins A
		                LEFT JOIN #DBA_ExclusionList B ON UPPER(A.name) = UPPER(B.Account)
        WHERE		A.sysadmin = 1
          AND		B.Account IS NULL
        UNION ALL
        SELECT		@SQLServer
	                ,@TestId
	                ,@Description
	                ,'master'
	                ,QUOTENAME(A.name) + ' is a member of Server Fixed Role securityadmin.'
	                ,'EXECUTE master..sp_dropsrvrolemember @loginame = N''' + A.name + ''', @rolename = N''securityadmin'''
	                ,'EXECUTE master..sp_addsrvrolemember  @loginame = N''' + A.name + ''', @rolename = N''securityadmin'''
        FROM		master..syslogins A
		                LEFT JOIN #DBA_ExclusionList B ON UPPER(A.name) = UPPER(B.Account)
        WHERE		A.securityadmin = 1
          AND		B.Account IS NULL
          AND		UPPER(A.name) <> 'HPS\MSSQL'
        UNION ALL
        SELECT		@SQLServer
	                ,@TestId
	                ,@Description
	                ,'master'
	                ,QUOTENAME(A.name) + 'is a member of Server Fixed Role serveradmin.'
	                ,'EXECUTE master..sp_dropsrvrolemember @loginame = N''' + A.name + ''', @rolename = N''serveradmin'''
	                ,'EXECUTE master..sp_addsrvrolemember  @loginame = N''' + A.name + ''', @rolename = N''serveradmin'''
        FROM		master..syslogins A
		                LEFT JOIN #DBA_ExclusionList B ON UPPER(A.name) = UPPER(B.Account)
        WHERE		A.serveradmin = 1
          AND		B.Account IS NULL
        UNION ALL
        SELECT		@SQLServer
	                ,@TestId
	                ,@Description
	                ,'master'
	                ,QUOTENAME(A.name) + ' is a member of Server Fixed Role setupadmin.'
	                ,'EXECUTE master..sp_dropsrvrolemember @loginame = N''' + A.name + ''', @rolename = N''setupadmin'''
	                ,'EXECUTE master..sp_addsrvrolemember  @loginame = N''' + A.name + ''', @rolename = N''setupadmin'''
        FROM		master..syslogins A
		                LEFT JOIN #DBA_ExclusionList B ON UPPER(A.name) = UPPER(B.Account)
        WHERE		A.setupadmin = 1
                   AND		UPPER(A.name) <> 'HPS\DBA'
          AND		B.Account IS NULL
        UNION ALL
        SELECT		@SQLServer
	                ,@TestId
	                ,@Description
	                ,'master'
	                ,QUOTENAME(A.name) + ' is a member of Server Fixed Role processadmin.'
	                ,'EXECUTE master..sp_dropsrvrolemember @loginame = N''' + A.name + ''', @rolename = N''processadmin'''
	                ,'EXECUTE master..sp_addsrvrolemember  @loginame = N''' + A.name + ''', @rolename = N''processadmin'''
        FROM		master..syslogins A
		                LEFT JOIN #DBA_ExclusionList B ON UPPER(A.name) = UPPER(B.Account)
        WHERE		A.processadmin = 1
          AND		B.Account IS NULL
        UNION ALL
        SELECT		@SQLServer
	                ,@TestId
	                ,@Description
	                ,'master'
	                ,QUOTENAME(A.name) + ' is a member of Server Fixed Role diskadmin.'
	                ,'EXECUTE master..sp_dropsrvrolemember @loginame = N''' + A.name + ''', @rolename = N''diskadmin'''
	                ,'EXECUTE master..sp_addsrvrolemember  @loginame = N''' + A.name + ''', @rolename = N''diskadmin'''
        FROM		master..syslogins A
		                LEFT JOIN #DBA_ExclusionList B ON UPPER(A.name) = UPPER(B.Account)
        WHERE		A.diskadmin = 1
          AND		B.Account IS NULL
        UNION ALL
        SELECT		@SQLServer
	                ,@TestId
	                ,@Description
	                ,'master'
	                ,QUOTENAME(A.name) + 'is a member of Server Fixed Role dbcreator.'
	                ,'EXECUTE master..sp_dropsrvrolemember @loginame = N''' + A.name + ''', @rolename = N''dbcreator'''
	                ,'EXECUTE master..sp_addsrvrolemember  @loginame = N''' + A.name + ''', @rolename = N''dbcreator'''
        FROM		master..syslogins A
		                LEFT JOIN #DBA_ExclusionList B ON UPPER(A.name) = UPPER(B.Account)
        WHERE		A.dbcreator = 1
          AND		B.Account IS NULL
        UNION ALL
        SELECT		@SQLServer
	                ,@TestId
	                ,@Description
	                ,'master'
	                ,QUOTENAME(A.name) + 'is a member of Server Fixed Role bulkadmin.'
	                ,'EXECUTE master..sp_dropsrvrolemember @loginame = N''' + A.name + ''', @rolename = N''bulkadmin'''
	                ,'EXECUTE master..sp_addsrvrolemember  @loginame = N''' + A.name + ''', @rolename = N''bulkadmin'''
        FROM		master..syslogins A
		                LEFT JOIN #DBA_ExclusionList B ON UPPER(A.name) = UPPER(B.Account)
        WHERE		A.bulkadmin = 1           AND		B.Account IS NULL
        	  
        DROP TABLE #DBA_ExclusionList
		END
DEALLOCATE CURSOR_DB

        SELECT      name                AS [Database Not Online]
                    ,cmptlevel          AS [Compatibility Level]
                    ,CASE 
                        WHEN DATABASEPROPERTY(name, 'IsOffline') = 1        THEN 'OFFLINE'
                        WHEN DATABASEPROPERTY(name, 'IsInRecovery') = 1     THEN 'IN RECOVERY'
                        WHEN DATABASEPROPERTY(name, 'IsShutDown') = 1       THEN 'SUSPECT'
                        WHEN DATABASEPROPERTY(name, 'IsSuspect') = 1        THEN 'SUSPECT'
                        WHEN DATABASEPROPERTY(name, 'IsNotRecovered') = 1   THEN 'NOT RECOVERED'
                        WHEN DATABASEPROPERTY(name, 'IsInStandBy')= 1       THEN 'STAND BY'
                     END                AS [Status]
        FROM        sysdatabases
        WHERE       DATABASEPROPERTY(name, 'IsOffline') = 1
           OR       DATABASEPROPERTY(name, 'IsInRecovery') = 1
           OR       DATABASEPROPERTY(name, 'IsShutDown') = 1
           OR       DATABASEPROPERTY(name, 'IsSuspect') = 1
           OR       DATABASEPROPERTY(name, 'IsNotRecovered') = 1
           OR       DATABASEPROPERTY(name, 'IsInStandBy')= 1
        ORDER BY    name
		SELECT      SQLServer
                        ,TestId
                        ,TestDesc
                        ,COUNT(*) AS Findings
            FROM        #Report
            GROUP BY    SQLServer
                        ,TestId
                        ,TestDesc
            ORDER BY    CASE WHEN ISNUMERIC(TestId) = 0 THEN 0 ELSE CAST(TestId AS int) END

        SELECT      * 
        FROM        #Report
        ORDER BY    CASE WHEN ISNUMERIC(TestId) = 0 THEN 0 ELSE CAST(TestId AS int) END

        DROP TABLE #Report